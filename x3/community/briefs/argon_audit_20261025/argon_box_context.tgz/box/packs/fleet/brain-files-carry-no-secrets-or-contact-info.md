---
title: Brain files hold no secrets, contact info, media or pasted pack or canon text
applies_when:
  - writing a learning, plan, review, decision, handoff or open-issue file into the brain
  - reviewing a file that will be uploaded to the Drive brain
tags: [brain, hygiene, secrets, privacy, drive]
---

Never write tokens, cookies, passwords, API keys, phone numbers, email addresses, home addresses or account numbers. Use a placeholder for a real person's name unless the file needs it. Markdown only: link to media, never embed it. Cite pack and canon files by path; never paste their text. Status lives only in the project NEXT.md; one open issue per file in 05_open-issues/.
