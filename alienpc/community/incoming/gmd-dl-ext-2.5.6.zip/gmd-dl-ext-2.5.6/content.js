// Grok 視頻下載器 - Content Script
// 自動在 Grok 頁面上運行

// 防止重複注入
if (window.__grokVideoDownloaderLoaded) {
    console.log('Content script already loaded, skipping...');
} else {
window.__grokVideoDownloaderLoaded = true;

// Reference SystemLogger from window (exported by logger.js)
const SystemLogger = window.SystemLogger;

const STORAGE_KEY = 'grok_video_downloader';
const HISTORY_KEY = 'grok_video_download_history';
// Temp staging key for Import Data: popup writes the parsed file here so the
// content script can read it back from storage, avoiding the 64MiB
// tabs.sendMessage limit on large exports. Removed immediately after reading.
const IMPORT_STAGING_KEY = 'grok_import_staging';

// Story Mode 狀態追蹤（Side Panel 是否連接）
let storyModeActive = false;

// Queue Mode 狀態追蹤（Queue Side Panel 是否連接）
let queueModeActive = false;

// HD 升級狀態追蹤
let upgradeInProgress = false;
let upgradeAbortRequested = false;
let upgradeCurrentProgress = { current: 0, total: 0, success: 0, fail: 0 };
let upgradeScanCache = null; // cached scan results: { videos, timestamp }

// Queue processing state
let queueProcessingActive = false;
let queueWaitingForResult = false; // Set after prompt submission, prevents re-submission on SPA navigation
let _queueResultPending = false;

// 下載狀態追蹤
let downloadInProgress = false;
let downloadAbortRequested = false;
// True while a generateMedia request is being served. Guards against a second
// concurrent generate (e.g. the popup's watchdog re-enabled the button while
// this one was still walking conversations) and lets cancelDownload abort a
// running generate through the same downloadAbortRequested flag every phase
// already polls via signalAborted/isAborted.
let generateInProgress = false;
let downloadCurrentProgress = { phase: '', current: 0, total: 0, success: 0, fail: 0 };
const VIDEO_DOWNLOAD_RATE_LIMIT = 250; // 影片下載數量限制，超過此數量自動暫停以避免 rate limit

// Insert an extra micro-pause every N downloads to let Chrome's Safe Browsing
// queue drain — heavy uninterrupted bursts can build up internal verdict state
// and contribute to shared_proto_db bloat.
const BURST_PAUSE_EVERY = 25;
const BURST_PAUSE_MS = 100;

// allmedia scan resume checkpoint: { v, scope, pageToken, pageCount, assetIds, updatedAt }.
// Written after every good page, cleared on a healthy completion.
const ALLMEDIA_SCAN_CHECKPOINT_KEY = 'grok_allmedia_scan_checkpoint';
const allmediaScanCheckpointStore = {
    load: async () => (await chrome.storage.local.get(ALLMEDIA_SCAN_CHECKPOINT_KEY))[ALLMEDIA_SCAN_CHECKPOINT_KEY] || null,
    save: (cp) => chrome.storage.local.set({ [ALLMEDIA_SCAN_CHECKPOINT_KEY]: cp }),
    clear: () => chrome.storage.local.remove(ALLMEDIA_SCAN_CHECKPOINT_KEY)
};

// Base delay between allmedia /rest/assets page fetches (see grok-assets.js).
const ALLMEDIA_PAGE_THROTTLE_MS = (globalThis.GrokAssets && GrokAssets.ASSET_PAGE_THROTTLE_MS) || 1200;

// 使用 chrome.storage.local 替代 localStorage（更可靠）
// In-memory cache to avoid repeated large storage reads (state can be 30MB+)
let stateCache = null;

async function saveState(state) {
    stateCache = state;
    return chrome.storage.local.set({ [STORAGE_KEY]: state });
}

async function loadState() {
    if (stateCache) return stateCache;
    const result = await chrome.storage.local.get(STORAGE_KEY);
    stateCache = result[STORAGE_KEY] || null;
    return stateCache;
}

async function clearState() {
    stateCache = null;
    return chrome.storage.local.remove(STORAGE_KEY);
}

// 取得下載路徑設定（見 src/utils.js GrokUtils.getDownloadPaths）

// 下載歷史管理（永久記錄）— 使用 Set 快取避免 OOM
let historyCache = null; // Set<string>, loaded once

async function ensureHistoryCache() {
    if (historyCache) return historyCache;
    const result = await chrome.storage.local.get(HISTORY_KEY);
    historyCache = new Set(result[HISTORY_KEY] || []);

    // Remove keys whose downloads were later interrupted (recorded by background).
    // A key is only removed from the shared list if this cache actually deleted
    // it from its own Set — unmatched keys are left for the other cache (tag
    // history) to consume. This avoids permanently dropping composite keys that
    // belong to the other cache when caches load in a different order.
    const { grok_interrupted_keys = [] } = await chrome.storage.local.get('grok_interrupted_keys');
    if (grok_interrupted_keys.length > 0) {
        const deleted = new Set();
        for (const k of grok_interrupted_keys) {
            if (historyCache.delete(k)) deleted.add(k);
        }
        if (deleted.size > 0) {
            await chrome.storage.local.set({ [HISTORY_KEY]: [...historyCache] });
            await chrome.storage.local.set({
                grok_interrupted_keys: grok_interrupted_keys.filter(k => !deleted.has(k))
            });
        }
    }

    return historyCache;
}

async function getDownloadHistory() {
    const cache = await ensureHistoryCache();
    return [...cache];
}

async function addToHistory(videoId) {
    const cache = await ensureHistoryCache();
    cache.add(videoId);
}

async function isInHistory(videoId) {
    const cache = await ensureHistoryCache();
    return cache.has(videoId);
}

async function flushHistory() {
    if (!historyCache) return;
    // Union with the latest stored history before writing — another tab may have
    // added ids since this cache was loaded. A flush must never clobber those.
    const stored = (await chrome.storage.local.get(HISTORY_KEY))[HISTORY_KEY] || [];
    // Exclude keys pending interrupted-removal — a key can already be persisted in
    // storage (sendDownloadRequest resolved on download START) before the async
    // `downloadInterrupted` event deletes it from this in-memory cache. Without this
    // guard, the union above would resurrect it from storage on every flush, since
    // the cache stays warm across popup-triggered runs on the grok.com SPA.
    const { grok_interrupted_keys = [] } = await chrome.storage.local.get('grok_interrupted_keys');
    const pendingRemoval = new Set(grok_interrupted_keys);
    for (const id of stored) if (!pendingRemoval.has(id)) historyCache.add(id);
    await chrome.storage.local.set({ [HISTORY_KEY]: [...historyCache] });
}

async function clearHistory() {
    historyCache = null;
    return chrome.storage.local.remove(HISTORY_KEY);
}

// Tag 下載歷史管理（與一般歷史完全分離）
const TAG_HISTORY_KEY = 'grok_tag_download_history';
let tagHistoryCache = null; // Set<string>, loaded once

async function ensureTagHistoryCache() {
    if (tagHistoryCache) return tagHistoryCache;
    const result = await chrome.storage.local.get(TAG_HISTORY_KEY);
    tagHistoryCache = new Set(result[TAG_HISTORY_KEY] || []);

    // Remove keys whose downloads were later interrupted (recorded by background).
    // A key is only removed from the shared list if this cache actually deleted
    // it from its own Set — unmatched keys are left for the other cache (plain
    // history) to consume. This avoids permanently dropping composite keys that
    // belong to the other cache when caches load in a different order.
    const { grok_interrupted_keys = [] } = await chrome.storage.local.get('grok_interrupted_keys');
    if (grok_interrupted_keys.length > 0) {
        const deleted = new Set();
        for (const k of grok_interrupted_keys) {
            if (tagHistoryCache.delete(k)) deleted.add(k);
        }
        if (deleted.size > 0) {
            await chrome.storage.local.set({ [TAG_HISTORY_KEY]: [...tagHistoryCache] });
            await chrome.storage.local.set({
                grok_interrupted_keys: grok_interrupted_keys.filter(k => !deleted.has(k))
            });
        }
    }

    return tagHistoryCache;
}

async function getTagDownloadHistory() {
    const cache = await ensureTagHistoryCache();
    return [...cache];
}

async function addToTagHistory(compositeId) {
    const cache = await ensureTagHistoryCache();
    cache.add(compositeId);
}

async function flushTagHistory() {
    if (!tagHistoryCache) return;
    // Union with the latest stored tag history before writing — another tab may
    // have added ids since this cache was loaded. A flush must never clobber those.
    const stored = (await chrome.storage.local.get(TAG_HISTORY_KEY))[TAG_HISTORY_KEY] || [];
    // Exclude keys pending interrupted-removal — see flushHistory() for rationale.
    const { grok_interrupted_keys = [] } = await chrome.storage.local.get('grok_interrupted_keys');
    const pendingRemoval = new Set(grok_interrupted_keys);
    for (const id of stored) if (!pendingRemoval.has(id)) tagHistoryCache.add(id);
    await chrome.storage.local.set({ [TAG_HISTORY_KEY]: [...tagHistoryCache] });
}

async function clearTagHistory() {
    tagHistoryCache = null;
    return chrome.storage.local.remove(TAG_HISTORY_KEY);
}

function tagHistoryKey(tagId, fileId) {
    return `${tagId}_${fileId}`;
}

// Conversation (allmedia) 下載歷史管理（與一般歷史、Tag 歷史完全分離）
// 因為 by-conversation 將檔案存放在各自對話的資料夾結構中，與 favorite 共用歷史
// 會導致對話資料夾內容不完整（見 D1 決策，取代先前「與 favorite 共用預設歷史」的設計）。
const CONVERSATION_HISTORY_KEY = 'grok_conversation_download_history';
let conversationHistoryCache = null; // Set<string>, loaded once

async function ensureConversationHistoryCache() {
    if (conversationHistoryCache) return conversationHistoryCache;
    const result = await chrome.storage.local.get(CONVERSATION_HISTORY_KEY);
    conversationHistoryCache = new Set(result[CONVERSATION_HISTORY_KEY] || []);

    // Remove keys whose downloads were later interrupted (recorded by background).
    // A key is only removed from the shared list if this cache actually deleted
    // it from its own Set — unmatched keys are left for the other caches (plain
    // history, tag history) to consume. This avoids permanently dropping composite
    // keys that belong to another cache when caches load in a different order.
    const { grok_interrupted_keys = [] } = await chrome.storage.local.get('grok_interrupted_keys');
    if (grok_interrupted_keys.length > 0) {
        const deleted = new Set();
        for (const k of grok_interrupted_keys) {
            if (conversationHistoryCache.delete(k)) deleted.add(k);
        }
        if (deleted.size > 0) {
            await chrome.storage.local.set({ [CONVERSATION_HISTORY_KEY]: [...conversationHistoryCache] });
            await chrome.storage.local.set({
                grok_interrupted_keys: grok_interrupted_keys.filter(k => !deleted.has(k))
            });
        }
    }

    return conversationHistoryCache;
}

async function getConversationDownloadHistory() {
    const cache = await ensureConversationHistoryCache();
    return [...cache];
}

async function addToConversationHistory(id) {
    const cache = await ensureConversationHistoryCache();
    cache.add(id);
}

async function flushConversationHistory() {
    if (!conversationHistoryCache) return;
    // Union with the latest stored conversation history before writing — another
    // tab may have added ids since this cache was loaded. A flush must never
    // clobber those.
    const stored = (await chrome.storage.local.get(CONVERSATION_HISTORY_KEY))[CONVERSATION_HISTORY_KEY] || [];
    // Exclude keys pending interrupted-removal — see flushHistory() for rationale.
    const { grok_interrupted_keys = [] } = await chrome.storage.local.get('grok_interrupted_keys');
    const pendingRemoval = new Set(grok_interrupted_keys);
    for (const id of stored) if (!pendingRemoval.has(id)) conversationHistoryCache.add(id);
    await chrome.storage.local.set({ [CONVERSATION_HISTORY_KEY]: [...conversationHistoryCache] });
}

async function clearConversationHistory() {
    conversationHistoryCache = null;
    await chrome.storage.local.remove(CONVERSATION_HISTORY_KEY);
    // The sticky quality store is consumed ONLY by the allmedia paths, so the
    // allmedia reset button is its semantically exact escape hatch. Deliberately
    // NOT wired to clearHistory (favorite namespace, unrelated) — and clearing
    // it here has no collateral cost, since the store is a derived, rebuildable
    // index rather than dedupe state.
    await clearQualityStickyStore();
    // Same reasoning for the prompt cache: a derived, rebuildable index that
    // only the generate paths consume. Nothing else clears it.
    await clearPromptCache();
}

// ==========================================================================
// Sticky highest-quality store (Plan A)
//
// grok's POST /rest/media/post/get returns an UNSTABLE hdMediaUrl for freshly
// rendered videos: polling the SAME id 6x within ~2s returned HD in 4 of 6
// polls for one video and 3 of 6 for another, while resolutionName stayed
// stable. The HD rendition genuinely exists; the URL READ is unreliable
// (CDN/replica propagation). Without this store, repeating "upgrade last N
// hours" flip-flops a video between SD (-> offer HD upgrade) and HD (-> offer
// 1080p), and the tier stats jump around.
//
// Remedy: remember, per asset id, the HIGHEST quality evidence ever resolved,
// and never let a later flaky read downgrade it. Only ABOVE-SD videos get a
// record — sd is the floor and an SD read carries zero information.
// ==========================================================================
const QUALITY_STICKY_KEY = 'grok_video_quality_sticky';
let qualityStickyCache = null; // { v:1, e: { [assetId]: {k,h,r,ts} } }, loaded once
// Ids removed since the last flush. REQUIRED: flushQualityStickyStore's cross-tab
// join (mergeStickyQualityStores) is a monotone UNION with the copy still on disk
// and has no deletion channel of its own — an id merely deleted from
// qualityStickyCache is re-added from `stored` and written straight back, which
// made eviction a silent no-op. These ids are subtracted AFTER the union, then
// cleared. Kept module-level (not per-store-facade) so evictStickyQuality and the
// facade's evict() share one correct path.
let qualityStickyEvicted = new Set();

async function ensureQualityStickyCache() {
    if (qualityStickyCache) return qualityStickyCache;
    const result = await chrome.storage.local.get(QUALITY_STICKY_KEY);
    qualityStickyCache = GrokUtils.pruneStickyQualityStore(result[QUALITY_STICKY_KEY], { now: Date.now() });
    return qualityStickyCache;
}

async function flushQualityStickyStore() {
    if (!qualityStickyCache) return;
    // Union with the latest stored copy before writing — another tab may have
    // learned entries since this cache was loaded. The join is monotone, so a
    // flush can never lower a tier. Same idiom as flushHistory().
    const stored = (await chrome.storage.local.get(QUALITY_STICKY_KEY))[QUALITY_STICKY_KEY];
    const merged = GrokUtils.mergeStickyQualityStores(stored, qualityStickyCache, { now: Date.now() });
    // Apply pending evictions AFTER the union — see qualityStickyEvicted. This is
    // the ONLY way a positively-dead remembered URL can leave the store before its
    // TTL expires (and the TTL never refreshes for it, because ts is bumped only
    // when a FRESH read confirms the tier).
    if (qualityStickyEvicted.size > 0) {
        for (const id of qualityStickyEvicted) delete merged.e[id];
        qualityStickyEvicted.clear();
    }
    qualityStickyCache = merged;
    await chrome.storage.local.set({ [QUALITY_STICKY_KEY]: qualityStickyCache });
}

/**
 * @returns {Promise<?{get:Function, put:Function, evict:Function, flush:Function}>}
 *   null on ANY storage failure — the caller then degrades to today's
 *   live-only behaviour instead of breaking list generation.
 */
async function getQualityStickyStore() {
    try {
        await ensureQualityStickyCache();
        // NOTE: these closures read the module-level `qualityStickyCache` on every
        // call and MUST NOT close over the object returned by ensure...(): flush
        // REPLACES qualityStickyCache with the merged result, and a captured stale
        // reference would silently drop every put() made after the first flush.
        return {
            get:   (id) => (qualityStickyCache && qualityStickyCache.e[id]) || null,
            // A put always wins over a pending eviction for the same id: fresh
            // above-SD evidence observed after the eviction is, by definition, not
            // the dead URL that caused it.
            put:   (id, rec) => { if (qualityStickyCache) { qualityStickyCache.e[id] = rec; qualityStickyEvicted.delete(id); } },
            evict: (id) => { if (qualityStickyCache) { delete qualityStickyCache.e[id]; qualityStickyEvicted.add(id); } },
            flush: flushQualityStickyStore
        };
    } catch (error) {
        console.warn('[StickyQuality] store unavailable, falling back to live-only resolution:', error);
        return null;
    }
}

/**
 * Positive evidence that a remembered URL is dead (403/404/410 at download
 * time). Deletes the entry and persists immediately — evictions are rare.
 */
async function evictStickyQuality(id) {
    try {
        await ensureQualityStickyCache();
        if (qualityStickyCache) {
            // Record the eviction even when the id is absent from THIS tab's cache:
            // it may still be on disk (or arrive there from another tab), and the
            // flush's union would otherwise hand the dead URL straight back.
            delete qualityStickyCache.e[id];
            qualityStickyEvicted.add(id);
            await flushQualityStickyStore();
        }
    } catch (error) {
        console.warn('[StickyQuality] eviction failed (non-fatal):', error);
    }
}

async function clearQualityStickyStore() {
    qualityStickyCache = null;
    // The whole key is gone, so pending evictions have nothing left to subtract —
    // keeping them would only make a future flush drop ids relearned after the
    // clear.
    qualityStickyEvicted.clear();
    return chrome.storage.local.remove(QUALITY_STICKY_KEY);
}

// ==========================================================================
// Persistent prompt cache
//
// grok removed `mediaGenInput` from /rest/assets, so prompts are recovered by
// GrokAssets.fetchConversationAssetMetadata: ONE GET /responses per
// conversation, sequential, 600 ms throttle, not batchable. Measured: 41
// conversations = 58 s, so a whole-library regenerate (~600 conversations) is
// ~14 min — and it repeated on EVERY regenerate, because list rows never carry
// a prompt and every item counted as "needing". Prompts are immutable per
// assetId (an edit/regenerate is a NEW assetId), so a persistent cache is
// exactly right and never goes stale. Same patterns as the sticky store above:
// loaded once per content-script lifetime, read-merge-write flush (union with
// the copy on disk so parallel tabs don't clobber each other), capped with
// hysteresis, and every storage error swallowed — a failing cache must never
// break generate.
// ==========================================================================
const PROMPT_CACHE_KEY = 'grok_prompt_cache';
let promptCache = null; // { v:1, e: { [assetId]: {p,s,t} } }, loaded once

async function ensurePromptCache() {
    if (promptCache) return promptCache;
    const result = await chrome.storage.local.get(PROMPT_CACHE_KEY);
    promptCache = GrokUtils.prunePromptCacheStore(result[PROMPT_CACHE_KEY]);
    return promptCache;
}

async function flushPromptCache() {
    if (!promptCache) return;
    try {
        // Union with the latest stored copy before writing — another tab may
        // have learned entries since this cache was loaded. The join keeps every
        // prompt and sourceAssetId either side knows. Same idiom as flushHistory().
        const stored = (await chrome.storage.local.get(PROMPT_CACHE_KEY))[PROMPT_CACHE_KEY];
        const merged = GrokUtils.mergePromptCacheStores(stored, promptCache);
        promptCache = merged;
        await chrome.storage.local.set({ [PROMPT_CACHE_KEY]: promptCache });
    } catch (error) {
        console.warn('[PromptCache] flush failed (non-fatal):', error);
    }
}

/**
 * @returns {Promise<?{get:Function, put:Function, size:Function, flush:Function}>}
 *   null on ANY storage failure — the caller then degrades to fetch-only
 *   recovery instead of breaking list generation.
 */
async function getPromptCache() {
    try {
        await ensurePromptCache();
        // NOTE: these closures read the module-level `promptCache` on every call
        // and MUST NOT close over the object returned by ensure...(): flush
        // REPLACES promptCache with the merged result, and a captured stale
        // reference would silently drop every put() made after the first flush.
        return {
            get: (id) => (promptCache && promptCache.e[id]) || null,
            // Stores only entries worth keeping (non-empty prompt OR a
            // sourceAssetId); never lets a bare re-put erase a known field.
            put: (id, rec) => {
                if (!promptCache || !id) return;
                const p = (rec && typeof rec.p === 'string' && rec.p.trim() !== '') ? rec.p : '';
                const s = (rec && typeof rec.s === 'string' && rec.s !== '') ? rec.s : null;
                const prev = promptCache.e[id];
                const next = { p: p || (prev ? prev.p : ''), s: s || (prev ? prev.s : null), t: Date.now() };
                if (!next.p && !next.s) return;
                promptCache.e[id] = next;
            },
            size: () => (promptCache ? Object.keys(promptCache.e).length : 0),
            flush: flushPromptCache
        };
    } catch (error) {
        console.warn('[PromptCache] cache unavailable, falling back to fetch-only prompt recovery:', error);
        return null;
    }
}

async function clearPromptCache() {
    promptCache = null;
    promptConvDone = null;
    await chrome.storage.local.remove(PROMPT_CONV_DONE_KEY);
    return chrome.storage.local.remove(PROMPT_CACHE_KEY);
}

// 2026-10-24 patch: conversations whose /responses were already fetched
// successfully (prompts for every asset they carry are in grok_prompt_cache).
// The next run skips them, so an interrupted prompt walk resumes instead of
// restarting from zero. { v:1, c: { [conversationId]: fetchedAtMs } }.
const PROMPT_CONV_DONE_KEY = 'grok_prompt_conv_done';
let promptConvDone = null;
async function ensurePromptConvDone() {
    if (promptConvDone) return promptConvDone;
    try {
        const raw = (await chrome.storage.local.get(PROMPT_CONV_DONE_KEY))[PROMPT_CONV_DONE_KEY];
        promptConvDone = (raw && raw.v === 1 && raw.c && typeof raw.c === 'object') ? raw : { v: 1, c: {} };
    } catch (e) {
        promptConvDone = { v: 1, c: {} };
    }
    return promptConvDone;
}
async function flushPromptConvDone() {
    if (!promptConvDone) return;
    try {
        const stored = (await chrome.storage.local.get(PROMPT_CONV_DONE_KEY))[PROMPT_CONV_DONE_KEY];
        // Merge IN PLACE: recoverConversationPrompts holds a reference to
        // promptConvDone and keeps marking conversations on it — replacing the
        // object here silently dropped every mark after the first flush.
        if (stored && stored.v === 1 && stored.c) {
            for (const [cid, t] of Object.entries(stored.c)) {
                if (!(cid in promptConvDone.c)) promptConvDone.c[cid] = t;
            }
        }
        await chrome.storage.local.set({ [PROMPT_CONV_DONE_KEY]: promptConvDone });
    } catch (error) {
        console.warn('[PromptConvDone] flush failed (non-fatal):', error);
    }
}

// 2026-10-24 patch: live generate progress, surfaced by getStatus
// (top-level generateProgress, and displayStats.generateProgress /
// displayStats.promptsProgress) so a long walk is visible without the popup.
let generateProgress = null; // { phase, current, total, text, updatedAt }
function setGenerateProgress(phase, current, total) {
    generateProgress = {
        phase, current, total,
        text: total != null ? `${phase} ${current}/${total}` : `${phase} ${current}`,
        updatedAt: Date.now()
    };
}

// 取得 Grok Tag 列表 = collection/list ∪ folder/list
async function fetchTagList() {
    // Grok's tag migration is incomplete in BOTH directions (issue #13):
    // newly created tags exist only in the collection store (#12), while
    // several older tags exist only in the legacy folder store and most
    // migrated tags are under-populated on the collection side. Neither store
    // is authoritative, so list the union (GrokAssets.listTagsUnion merges by
    // id, then by exact name; `id` prefers the collectionId so tag-history
    // keys stay stable). One store failing must not hide the other.
    try {
        const union = await GrokAssets.listTagsUnion(fetch);
        if (union.errors.length) {
            console.warn('Tag list: one store failed, showing the other:', union.errors.join('; '));
        }
        // Keep the `folders` response key: it is the established message
        // contract with the popup's tag selector.
        return {
            success: true,
            folders: union.tags,
            source: 'union',
            counts: union.counts
        };
    } catch (error) {
        console.error('Failed to fetch tag list:', error);
        return { success: false, error: error.message };
    }
}

// Skip-on-disk: optional imported media-id list ({ v, ids, importedAt }).
// Consulted by every history adapter's has(), so download loops and stats
// skip those ids; never written into the real download history.
const SKIP_IDS_KEY = 'grok_skip_ids';
let skipIdSetCache = null;
async function ensureSkipIdSet() {
    if (skipIdSetCache) return skipIdSetCache;
    try {
        const rec = (await chrome.storage.local.get(SKIP_IDS_KEY))[SKIP_IDS_KEY];
        skipIdSetCache = new Set((rec && Array.isArray(rec.ids)) ? rec.ids : []);
    } catch (e) {
        skipIdSetCache = new Set();
    }
    return skipIdSetCache;
}
async function importSkipIds(list, { replace = false } = {}) {
    const incoming = ContentUtils.normalizeSkipIds(list);
    const current = replace ? new Set() : new Set(await ensureSkipIdSet());
    const before = current.size;
    for (const id of incoming) current.add(id);
    await chrome.storage.local.set({ [SKIP_IDS_KEY]: { v: 1, ids: [...current], importedAt: Date.now() } });
    skipIdSetCache = current;
    await SystemLogger.info('Skip list imported', `${incoming.length} id(s) read, list ${before} → ${current.size}${replace ? ' (replaced)' : ''}`);
    return { success: true, read: incoming.length, before, after: current.size };
}
async function clearSkipIds() {
    skipIdSetCache = null;
    await chrome.storage.local.remove(SKIP_IDS_KEY);
    return { success: true };
}

// History adapter + skip-on-disk ids (see withSkipIds in content-utils.js).
async function getEffectiveHistory(state) {
    return ContentUtils.withSkipIds(await getBaseHistory(state), await ensureSkipIdSet());
}

// Tag-aware history adapter — transparently handles tag-prefixed keys
// so existing download functions can use the same .has()/.add()/.flush() pattern
async function getBaseHistory(state) {
    // by-conversation (allmedia) uses its OWN history namespace — NOT shared
    // with favorite — because it stores files under per-conversation folders;
    // sharing favorite's history would leave those folders empty for items
    // already downloaded via favorite. Checked before the tagId branch since
    // filterOptions.tagId is always null for this source.
    if (state.filterOptions?.source === 'allmedia') {
        const cache = await ensureConversationHistoryCache();
        // Prefix keys with 'conv_' so this namespace can never collide with the
        // default (favorite) namespace's identical `${assetId}`/`${assetId}_hd`
        // keys in the shared grok_interrupted_keys reconciliation mechanism —
        // mirrors the tag adapter's tagId prefix below.
        const P = 'conv_';
        return {
            has: (key) => cache.has(P + key),
            toArray: () => {
                // Return keys without the conv_ prefix for GrokUtils compatibility
                return [...cache].filter(k => k.startsWith(P)).map(k => k.slice(P.length));
            },
            add: async (key) => addToConversationHistory(P + key),
            flush: flushConversationHistory,
            keyFor: (key) => P + key
        };
    }
    const tagId = state.filterOptions?.tagId;
    if (!tagId) {
        const cache = await ensureHistoryCache();
        return {
            has: (key) => cache.has(key),
            toArray: () => [...cache],
            add: addToHistory,
            flush: flushHistory,
            keyFor: (key) => key
        };
    }
    const tagCache = await ensureTagHistoryCache();
    return {
        has: (key) => tagCache.has(tagHistoryKey(tagId, key)),
        toArray: () => {
            // Return keys without tag prefix for GrokUtils compatibility
            const prefix = tagId + '_';
            return [...tagCache].filter(k => k.startsWith(prefix)).map(k => k.slice(prefix.length));
        },
        add: async (key) => addToTagHistory(tagHistoryKey(tagId, key)),
        flush: flushTagHistory,
        keyFor: (key) => tagHistoryKey(tagId, key)
    };
}

// Tag-aware path resolver — overrides images/videos/projects paths for tag mode
function getEffectivePaths(paths, state) {
    if (state.filterOptions?.source === 'allmedia') {
        // by-conversation groups images+videos of one conversation TOGETHER under
        // paths.conversations/<subfolder> — the per-item subfolder is applied
        // directly in the download loop (Task D3). Returning paths unchanged
        // here just ensures allmedia doesn't fall through into the tag branch
        // below (tagId is always null for this source).
        return paths;
    }
    const tagId = state.filterOptions?.tagId;
    if (!tagId) return paths;
    const tagName = state.filterOptions?.tagName || 'unnamed_tag';
    const sanitized = GrokUtils.sanitizeTagName(tagName);
    const tagDir = `${paths.tags}/${sanitized}`;
    return {
        ...paths,
        images: `${tagDir}/images`,
        videos: `${tagDir}/videos`,
        projects: tagDir
    };
}

// Per-item media directory resolver (Task D3) — for allmedia (by-conversation)
// items carrying a `subfolder` (assigned by assignConversationSubfolders,
// called from generateMediaListFromAllMedia during list generation), routes
// BOTH images and videos into paths.conversations/<subfolder> so a
// conversation's images and videos end up TOGETHER in the same folder.
// Favorite/tag items (source !== 'allmedia', or no subfolder) fall through
// to the normal paths.images/paths.videos — unaffected. An allmedia item that
// somehow still lacks a subfolder (e.g. a list saved before this assignment
// existed) falls through to the same flat images/videos dir as a last resort
// (startAutoDownload's no-network defensive fallback also backfills it there).
function resolveMediaDir(paths, state, item, kind) {
    if (state.filterOptions?.source === 'allmedia' && item && item.subfolder) {
        return `${paths.conversations}/${item.subfolder}`;
    }
    return kind === 'video' ? paths.videos : paths.images;
}

// Picks the prompt that names a title-less conversation folder: the
// EARLIEST-created prompt-bearing IMAGE; if no image carries a prompt, the
// earliest prompt-bearing item of any type. '' when nothing has a prompt.
function pickEarliestPrompt(convItems) {
    const timeOf = (it) => {
        const ms = it.createTime ? new Date(it.createTime).getTime() : NaN;
        return Number.isNaN(ms) ? Infinity : ms;
    };
    let best = null;
    let bestMs = Infinity;
    let bestIsImage = false;
    for (const it of convItems) {
        // A prompt that is only `@<assetId>` refs / `--k=v` flags is not a
        // usable name — skip it so a later nameable candidate wins instead
        // of the folder collapsing to the conversation-id fallback.
        if (!GrokUtils.hasNameablePrompt(it.prompt, 90)) continue;
        const isImage = it.type === 'image';
        const ms = timeOf(it);
        // Images beat non-images regardless of time; within the same class, earliest wins.
        if (best === null || (isImage && !bestIsImage) || (isImage === bestIsImage && ms < bestMs)) {
            best = it;
            bestMs = ms;
            bestIsImage = isImage;
        }
    }
    return best ? best.prompt : '';
}

// Per-conversation subfolder assignment (Task D3) — images+videos generated
// within the SAME conversation download TOGETHER into one folder named after
// the conversation's title. Called from generateMediaListFromAllMedia, right
// after the title fetch, so its progress shows on the GENERATE button
// (phase:'titles') and the download itself starts instantly.
//
// Folder format matches the by-project convention (see GrokUtils.groupPostsByProject):
// `{yyyymmdd}_{sanitizedTitle}_{shortConversationId}` — the date comes from the
// EARLIEST createTime among the conversation's items, so a conversation whose
// generations straddle midnight still lands in one folder instead of splitting.
//
// Pure/sync, mutates `items` in place (and returns them for convenience) —
// extracted so tests can exercise the assignment rule directly.
// @param {Array} items - image/video download-data items (mapAssetToDownloadData shape)
// @param {Object} titleMap - `{ [conversationId]: title }`, e.g. from GrokAssets.fetchConversationTitles
// @returns {Array} the same `items` array, mutated
function assignConversationSubfolders(items, titleMap) {
    // Group items by conversation id first, so the folder name (which depends
    // on the EARLIEST createTime across the whole conversation) can be
    // computed once per conversation and applied uniformly to every item in it.
    const byConversation = new Map();
    for (const item of items) {
        if (!item.sourceConversationId) continue;
        const cid = item.sourceConversationId;
        if (!byConversation.has(cid)) byConversation.set(cid, []);
        byConversation.get(cid).push(item);
    }

    for (const [cid, convItems] of byConversation) {
        let earliestMs = null;
        let earliestCreateTime = null;
        for (const item of convItems) {
            if (!item.createTime) continue;
            const ms = new Date(item.createTime).getTime();
            if (Number.isNaN(ms)) continue;
            if (earliestMs === null || ms < earliestMs) {
                earliestMs = ms;
                earliestCreateTime = item.createTime;
            }
        }

        const dateStr = GrokUtils.formatDateYYYYMMDD(earliestCreateTime);
        const title = (titleMap && titleMap[cid]) || '';
        // Many conversations (esp. the post-2026-07 model) carry NO title, but
        // their assets still have a prompt (mediaGenInput.textToImage.prompt →
        // item.prompt). Prefer the title; fall back to the conversation's asset
        // prompt so the folder stays meaningful; only 'untitled' when neither
        // a title nor any asset prompt exists.
        // Which asset prompt: the EARLIEST-created prompt-bearing IMAGE (the
        // same earliest-createTime rule the date part uses). Items arrive
        // newest-first and videos now carry their own animation prompt
        // ("make it wave"), so "first prompt-bearing item" would name the
        // folder after the video instead of the image it was made from.
        // If no image has a prompt, the earliest prompt-bearing item of any type.
        const assetPrompt = title.trim() ? '' : pickEarliestPrompt(convItems);
        const nameSource = title.trim() || assetPrompt.trim();
        const namePart = nameSource
            ? GrokUtils.sanitizePromptForFilename(nameSource, 90, cid)
            : 'untitled';
        const shortId = cid.slice(-8);
        const folder = `${dateStr}_${namePart}_${shortId}`;

        for (const item of convItems) {
            item.subfolder = folder;
        }
    }

    // No sourceConversationId (e.g. a directly-uploaded/standalone asset) —
    // group it alone under its own assetId folder.
    for (const item of items) {
        if (!item.sourceConversationId) {
            item.subfolder = item.id;
        }
    }

    return items;
}

// Bounded-concurrency video-quality resolution with throttled progress
// reporting (Task D) — replaces the old serial 200ms-throttled loop inside
// generateMediaListFromAllMedia. resolveVideoQuality now retries 429/5xx
// internally (see src/grok-assets.js), so running a burst of calls under
// mapWithConcurrency's concurrency cap is safe and much faster on large
// libraries (hundreds of videos).
// Mutates videoData items in place; a skipped item keeps its null quality
// fields (unresolved -> classified SD downstream, unchanged behavior).
// @param {Array} videoData - video download-data items to resolve
// @param {{has: Function}} hist - resolved effective-history object (already awaited)
// @param {boolean} hdPriority - passed through to resolveImpl
// @param {Object} deps
// @param {Function} deps.resolveImpl - async (id, hdPriority) => resolved-quality-object|null
// @param {Function} deps.mapImpl - bounded-concurrency mapper, e.g. GrokUtils.mapWithConcurrency
// @param {Function} [deps.onProgress] - (current, total) => void, throttled (every 5th + final)
// @param {Function} [deps.isAborted] - () => boolean, checked per item before resolving
// @param {number} [deps.concurrency=5]
// @param {?Object} [deps.sticky] - sticky highest-quality store from
//   getQualityStickyStore(); {get,put,evict,flush}. When null the function
//   behaves EXACTLY as before. ANY new allmedia caller MUST pass this or it
//   forfeits flap protection.
// @returns {Promise<Array>} the same `videoData` array, mutated
async function resolveVideoQualitiesWithProgress(videoData, hist, hdPriority, { resolveImpl, mapImpl, onProgress, isAborted, concurrency = 5, sticky = null } = {}) {
    // Skip resolving only when the item's history status is ALREADY certain
    // without resolving: an unresolved item always has
    // hd1080Url/hdUrl/resolutionName === null (mapAssetToDownloadData), so it
    // will always compute the '_sd' HD-priority history key (see
    // GrokUtils.filterVideosForHdPriority). A lone `_hd` record is NOT
    // sufficient to skip — that would leave the item unresolved with a
    // mismatching '_sd' key and cause a spurious duplicate download.
    const toResolve = videoData.filter(item => !(hist.has(item.id) || hist.has(`${item.id}_sd`)));
    const total = toResolve.length;
    if (total === 0) return videoData;

    let completed = 0;
    let finalReported = false;
    const reportProgress = () => {
        completed++;
        if (onProgress && (completed % 5 === 0 || completed === total)) {
            onProgress(completed, total);
            if (completed === total) finalReported = true;
        }
    };

    // A `null` from resolveImpl means UNRESOLVED (its own internal 429/5xx
    // retries were exhausted under sustained rate-limiting) — NOT genuine SD.
    // A genuine SD video resolves to an object with null hd1080Url/hdUrl.
    // Collected here so the recovery pass below gets a chance to retry them
    // instead of silently misclassifying a rate-limited HD video as SD.
    const unresolved = [];

    // Items whose fresh read came back LOWER than the remembered tier and that
    // already got their one confirmation re-read this run.
    const downgradeRechecked = new Set();

    const resolveOne = async (item) => {
        const resolved = await resolveImpl(item.id, hdPriority);
        let merged = GrokUtils.mergeStickyVideoQuality(
            resolved,
            sticky ? sticky.get(item.id) : null,
            { now: Date.now() }
        );

        // Transient-flicker confirmation: hdMediaUrl verifiably flaps on/off for
        // freshly rendered videos (HD present in 4/6 and 3/6 live polls), so ONE
        // extra read usually returns a FRESH url and spares us from serving a
        // remembered one. At most one re-read per item per run.
        if (merged.suppressedDowngrade && sticky && !downgradeRechecked.has(item.id)) {
            downgradeRechecked.add(item.id);
            const second = await resolveImpl(item.id, hdPriority);
            if (second) {
                merged = GrokUtils.mergeStickyVideoQuality(second, sticky.get(item.id), { now: Date.now() });
            }
        }

        // UNCHANGED: never recompute item.url. pickVideoUrl(item, true) is
        // hd1080Url || hdUrl || url, so restoring the HD fields is sufficient for
        // HD-priority downloads, while leaving url at the fresh/base
        // assets.grok.com/{key} keeps the NON-HD-priority branch downloading a
        // genuinely current SD file under its '_sd' key.
        if (resolved) item.url = resolved.url || item.url;

        if (merged.tier) {
            item.hd1080Url = merged.hd1080Url;
            item.hdUrl = merged.hdUrl;
            item.resolutionName = merged.resolutionName;
            // __qualityResolved means "a LIVE read succeeded for this item on this
            // run" — callers like scanVideosForUpgrade's allmedia branch use it to
            // tell a real classification apart from an UNKNOWN tier that never got
            // resolved (Review Finding 2). It must therefore track `resolved`, NOT
            // merged.tier: when resolveImpl returned null (retries exhausted, or a
            // permanent 404 because the post is gone) the tier below comes purely
            // from the store, and treating that as resolved would put a possibly
            // non-existent video on the upgrade work list while the scan still
            // reported itself complete. Such items are marked __qualityStickyOnly
            // instead — they keep their remembered URLs (that IS the flap
            // protection the download path wants) but stay out of the upgrade
            // classification, exactly as before the sticky store existed.
            // Set on BOTH the first pass and the recovery pass below, since
            // resolveOne is shared by both; a successful recovery-pass read
            // therefore upgrades sticky-only back to resolved.
            if (resolved) {
                item.__qualityResolved = true;
                delete item.__qualityStickyOnly;
            } else {
                item.__qualityStickyOnly = true;
                delete item.__qualityResolved;
            }
            if (merged.fromSticky) item.__qualityFromSticky = true;
            else delete item.__qualityFromSticky;
            if (sticky && merged.record) sticky.put(item.id, merged.record);
        }

        // Still queued for the low-concurrency recovery pass even when a record
        // covered it — a successful retry overwrites the remembered URLs with
        // fresh ones, which is strictly better.
        if (!resolved) unresolved.push(item);
    };

    try {
        await mapImpl(toResolve, concurrency, async (item) => {
            if (isAborted && isAborted()) return;
            await resolveOne(item);
            reportProgress();
        });

        // Recovery pass: retry ONLY the still-null items, at a low concurrency (2)
        // so a sustained 429 storm gets room to clear instead of immediately
        // hitting the same wall again. Runs silently (no onProgress calls) — these
        // items were already counted once in the pass above, so reporting them
        // again would double-count past `total`. Genuine 404s stay null (correct
        // SD classification); rate-limited ones get a second chance to resolve.
        if (unresolved.length > 0 && !(isAborted && isAborted())) {
            const retryItems = unresolved.splice(0, unresolved.length);
            await mapImpl(retryItems, 2, async (item) => {
                if (isAborted && isAborted()) return;
                await resolveOne(item);
            });
        }

        // On abort, items skipped above return before ever calling reportProgress,
        // so `completed` never reaches `total` and onProgress's terminal
        // (completed === total) branch never fires — leaving a caller's UI (e.g.
        // button text) stuck showing stale progress. Emit one terminal update
        // reflecting whatever actually completed (never exceeds total).
        if (onProgress && !finalReported) {
            onProgress(completed, total);
        }
    } finally {
        // Persist what was learned even on abort or throw.
        if (sticky) {
            try { await sticky.flush(); } catch (error) {
                console.warn('[StickyQuality] flush failed (non-fatal):', error);
            }
        }
    }

    return videoData;
}

// Backfills prompt/filename for imageToVideo-generated videos (Task: allmedia
// video-prompt resolution). An image-generated video has no prompt of its
// own (ContentUtils.mapAssetToDownloadData leaves item.prompt === '' for it,
// per GrokAssets.extractAssetPrompt) — only `sourceAssetId` (the id of the
// source image asset, see GrokAssets.extractSourceAssetId). When that source
// image is ALSO present in the same allmedia scan, this borrows its prompt
// and re-derives the video's filename via ContentUtils.buildAssetFilename —
// the SAME builder mapAssetToDownloadData used — so prompt/custom filename
// modes work for image-generated videos too instead of falling back to the
// asset id. Purely additive: mutates matching video items in place; a video
// whose source image isn't in `items` (e.g. filtered out by date range) is
// left untouched, keeping its existing assetId-based filename.
// @param {Array} items - mapped download items (images and videos mixed)
// @param {Object} options - same options object passed to mapAssetToDownloadData
//   (filenameMode/promptAsFilename/filenameTemplateImage/filenameTemplateVideo)
// @returns {Array} the same `items` array, mutated
function backfillVideoPromptsFromSource(items, options = {}) {
    const promptById = new Map();
    for (const it of items) {
        if (it.type === 'image' && it.prompt) promptById.set(it.id, it.prompt);
    }

    const filenameMode = options.filenameMode || (options.promptAsFilename ? 'prompt' : 'native');

    for (const it of items) {
        if (it.type !== 'video' || it.prompt || !it.sourceAssetId) continue;

        const srcPrompt = promptById.get(it.sourceAssetId);
        if (!srcPrompt) continue; // source image not in scope -> leave assetId-based filename

        it.prompt = srcPrompt;
        it.originalPrompt = srcPrompt;
        it.filename = ContentUtils.buildAssetFilename({
            assetId: it.id,
            ext: GrokUtils.getExtFromMediaUrl(it.url, 'mp4'),
            isVideo: true,
            createTime: it.createTime,
            prompt: srcPrompt,
            filenameMode,
            filenameTemplateImage: options.filenameTemplateImage,
            filenameTemplateVideo: options.filenameTemplateVideo
        });
    }

    return items;
}

// ==========================================
// Prompt recovery via /responses (2026-09)
//
// grok removed `mediaGenInput` from /rest/assets rows (list AND single), so
// mapRawAsset's extractAssetPrompt yields '' for every asset. The full row —
// mediaGenInput included — still comes back inside the owning conversation's
// GET /rest/app-chat/conversations/{cid}/responses body (see
// GrokAssets.fetchConversationAssetMetadata). These two helpers restore the
// prompt (and sourceAssetId) on already-mapped items BEFORE the downstream
// steps that depend on it: backfillVideoPromptsFromSource (needs the source
// image's prompt) and assignConversationSubfolders (uses item.prompt as the
// folder-name fallback when the conversation title is blank).
// ==========================================

// Pure/sync, mutates `items` in place.
// For each item whose prompt is empty/blank: if `byAssetId` has an entry with
// a non-empty prompt → set prompt + originalPrompt (and rebuild the filename
// from it when `options` is given, since tag/favorite items keep their BAKED
// filename at download time). sourceAssetId is filled whenever the item's is
// null/undefined and the map has one. A non-empty existing prompt is NEVER
// overwritten (legacy-fallback tag items may carry one from the post row; if
// grok restores mediaGenInput on the list, this becomes a no-op).
//
// Map-aware source fallback (2026-09-09 live data: 8/30 videos): when the
// item's own entry has NO prompt but a sourceAssetId (item's or entry's) whose
// entry DOES carry one, borrow that prompt. The /responses body attaches the
// input image's full row to the human turn, so the source image's entry is in
// the map even when the image itself is outside `items` (date-window or
// tag scans) — the case backfillVideoPromptsFromSource cannot cover.
// @param {Array} items - mapped download items (images and videos mixed)
// @param {Map} byAssetId - GrokAssets.fetchConversationAssetMetadata().byAssetId
// @param {Object} [options] - same options object passed to mapAssetToDownloadData
// @returns {{filled: number, skipped: number}}
function applyConversationPrompts(items, byAssetId, options = null) {
    let filled = 0;
    let skipped = 0;
    if (!byAssetId || typeof byAssetId.get !== 'function') return { filled, skipped: (items || []).length };

    const filenameMode = options ? (options.filenameMode || (options.promptAsFilename ? 'prompt' : 'native')) : null;

    for (const it of items || []) {
        const entry = byAssetId.get(it.id);
        if (entry && (it.sourceAssetId === null || it.sourceAssetId === undefined) && entry.sourceAssetId) {
            it.sourceAssetId = entry.sourceAssetId;
        }

        const hasPrompt = typeof it.prompt === 'string' && it.prompt.trim() !== '';
        if (hasPrompt) {
            skipped++;
            continue;
        }

        let prompt = (entry && typeof entry.prompt === 'string' && entry.prompt.trim()) ? entry.prompt : '';
        if (!prompt) {
            const sourceId = it.sourceAssetId || (entry && entry.sourceAssetId) || null;
            const sourceEntry = sourceId ? byAssetId.get(sourceId) : null;
            if (sourceEntry && typeof sourceEntry.prompt === 'string' && sourceEntry.prompt.trim()) {
                prompt = sourceEntry.prompt;
            }
        }
        if (!prompt) {
            skipped++;
            continue;
        }

        it.prompt = prompt;
        it.originalPrompt = prompt;
        // Only asset-model items (mapAssetToDownloadData shape, `mimeType` set)
        // are rebuilt — legacy post-row items use a different filename builder.
        if (options && it.mimeType && it.url) {
            const isVideo = it.type === 'video';
            it.filename = ContentUtils.buildAssetFilename({
                assetId: it.id,
                ext: GrokUtils.getExtFromMediaUrl(it.url, isVideo ? 'mp4' : 'jpg'),
                isVideo,
                createTime: it.createTime,
                prompt,
                filenameMode,
                filenameTemplateImage: options.filenameTemplateImage,
                filenameTemplateVideo: options.filenameTemplateVideo
            });
        }
        filled++;
    }

    return { filled, skipped };
}

// Orchestrates the recovery for one generate run:
//   1. cache pass — serve prompt-less items from the persistent prompt cache
//      (own entry, plus the source image's entry so the map-aware fallback in
//      applyConversationPrompts runs on the SAME code path as a live fetch);
//   2. collect the conversation ids of ONLY the items STILL missing a prompt
//      (sourceConversationId, else currentConversationId) and fetch their
//      /responses (progress on the GENERATE button via phase:'prompts'; abort
//      via downloadAbortRequested);
//   3. apply the fetched map (merged with the cache hits, so a fetched video
//      can still borrow a cached source-image prompt);
//   4. write EVERY entry of the fetched map into the cache — the whole
//      conversation, not just the requested items, so a later date-window/tag
//      scan of the same conversation costs nothing — and flush ONCE.
// Logs the funnel. Tolerant: never throws, never blocks the run.
// @returns {Promise<{filled: number, skipped: number, conversationsRequested: number, conversationsFetched: number, errors: number, cacheHits: number}>}
async function recoverConversationPrompts(items, options, label) {
    const empty = { filled: 0, skipped: 0, conversationsRequested: 0, conversationsFetched: 0, errors: 0, cacheHits: 0 };
    const lacksPrompt = (it) => !(typeof it.prompt === 'string' && it.prompt.trim() !== '');
    const needingInitial = (items || []).filter(lacksPrompt);
    if (needingInitial.length === 0) return empty;

    const prefix = label ? label + ': ' : '';

    // --- 1. cache pass ---------------------------------------------------
    const cache = await getPromptCache(); // null when storage is unusable
    const cacheHitsMap = new Map(); // byAssetId-shaped: { prompt, sourceAssetId }
    const toEntry = (rec) => ({ prompt: rec.p || '', sourceAssetId: rec.s || null });
    let cacheHits = 0;
    if (cache) {
        for (const it of needingInitial) {
            const rec = cache.get(it.id);
            if (rec) cacheHitsMap.set(it.id, toEntry(rec));
            const sourceId = it.sourceAssetId || (rec && rec.s) || null;
            if (sourceId && !cacheHitsMap.has(sourceId)) {
                const sourceRec = cache.get(sourceId);
                if (sourceRec) cacheHitsMap.set(sourceId, toEntry(sourceRec));
            }
        }
        if (cacheHitsMap.size > 0) {
            cacheHits = applyConversationPrompts(items, cacheHitsMap, options).filled;
            // Re-put every hit so `t` reflects last USE, not last fetch —
            // otherwise the cap prune evicts exactly the assets served from
            // cache on every run (least-recently-fetched), forcing a rolling
            // refetch. Flushed once below (with or without a fetch).
            for (const id of cacheHitsMap.keys()) {
                const rec = cache.get(id);
                if (rec) cache.put(id, { p: rec.p, s: rec.s });
            }
        }
    }

    const needing = needingInitial.filter(lacksPrompt);
    const logSummary = async (fetched, requested, filled, errors, extra = '') => {
        const summary = `${prefix}assets filled ${filled}/${needingInitial.length}, errors ${errors}, `
            + `cache hits ${cacheHits}, conversations fetched ${fetched}/${requested}` + extra;
        console.log(`  📝 提示詞復原: ${summary}`);
        if (errors > 0) {
            await SystemLogger.warn('Prompt recovery', summary);
        } else {
            await SystemLogger.info('Prompt recovery', summary);
        }
    };

    const allCids = needing.map(it => it.sourceConversationId || it.currentConversationId).filter(Boolean);
    // Skip conversations a previous (possibly interrupted) run already fetched:
    // everything they could yield is already in the cache.
    const convDone = cache ? await ensurePromptConvDone() : null;
    const cids = convDone ? allCids.filter(cid => !convDone.c[cid]) : allCids;
    const skippedDoneConvs = new Set(allCids.filter(cid => convDone && convDone.c[cid])).size;
    if (skippedDoneConvs > 0) {
        await SystemLogger.info('Prompt recovery', `${prefix}skipping ${skippedDoneConvs} conversation(s) already fetched by an earlier run`);
    }
    if (cids.length === 0) {
        // Everything was served from the cache, or the remainder is
        // unrecoverable (e.g. Jan-2026 migration orphans without a conversation).
        if (cacheHits > 0) {
            if (cache) await cache.flush(); // persist the refreshed `t` (one write per generate)
            await logSummary(0, 0, cacheHits, 0);
        } else if (needing.length > 0) {
            // Nothing to fetch and nothing cached: say so rather than leaving
            // the log silent about why these items have no prompt.
            await SystemLogger.info('Prompt recovery',
                `${prefix}${needing.length} item(s) have no conversation id — prompts unrecoverable via /responses`);
        }
        return { ...empty, filled: cacheHits, skipped: needingInitial.length - cacheHits, cacheHits };
    }

    // --- 2. fetch only the conversations still missing ----------------------
    // Incremental persistence: every ~50 conversations or ~30s the cache and
    // the done-conversation set are flushed, so a dead tab / cancel / reload
    // loses at most one interval of work.
    const persister = GrokAssets.createIncrementalPersister({
        flushEvery: 50,
        flushIntervalMs: 30000,
        flush: async () => {
            if (cache) await cache.flush();
            await flushPromptConvDone();
        }
    });
    let result;
    try {
        result = await GrokAssets.fetchConversationAssetMetadata(fetch, cids, {
            signalAborted: () => downloadAbortRequested,
            maxRetries: 5,
            retryBaseMs: 2000,
            retryMaxMs: 30000,
            maxConsecutiveErrors: 10,
            onConversation: async (cid, convEntries) => {
                if (cache) convEntries.forEach((entry, id) => cache.put(id, { p: entry.prompt, s: entry.sourceAssetId }));
                if (convDone) convDone.c[cid] = Date.now();
                await persister.tick();
            },
            onProgress: (current, total) => {
                setGenerateProgress('prompts', current, total);
                chrome.runtime.sendMessage({
                    action: 'generateListProgress',
                    phase: 'prompts',
                    current,
                    total
                }).catch(() => {}); // popup may be closed
            }
        });
    } catch (error) {
        // fetchConversationAssetMetadata is designed to never throw — defensive only.
        await persister.finish();
        console.warn('  ⚠️ 提示詞復原失敗:', error.message);
        await SystemLogger.warn('Prompt recovery', `${prefix}failed: ${error.message}`);
        return { ...empty, filled: cacheHits, skipped: needingInitial.length - cacheHits, cacheHits };
    }

    // --- 3. apply (fetched map ∪ cache hits, fetched entries win) -----------
    const byAssetId = result.byAssetId || new Map();
    for (const [id, entry] of cacheHitsMap) {
        if (!byAssetId.has(id)) byAssetId.set(id, entry);
    }
    // A video's sourceAssetId may only become known from the fetched row
    // (list rows carry no mediaGenInput). If the /responses body did not also
    // include the source image's row, the cache may still hold that image's
    // prompt from an earlier run — pull it in so the map-aware fallback in
    // applyConversationPrompts can borrow it, same as a live hit would.
    if (cache) {
        const wanted = new Set();
        byAssetId.forEach((entry) => { if (entry && entry.sourceAssetId) wanted.add(entry.sourceAssetId); });
        for (const it of needing) { if (it.sourceAssetId) wanted.add(it.sourceAssetId); }
        for (const sourceId of wanted) {
            if (byAssetId.has(sourceId)) continue;
            const rec = cache.get(sourceId);
            if (rec) byAssetId.set(sourceId, toEntry(rec));
        }
    }
    const applied = applyConversationPrompts(items, byAssetId, options);

    // --- 4. remember the WHOLE fetched conversations, flush once ------------
    if (cache && result.byAssetId && typeof result.byAssetId.forEach === 'function') {
        result.byAssetId.forEach((entry, id) => cache.put(id, { p: entry.prompt, s: entry.sourceAssetId }));
    }
    // Final flush on finish AND on cancel/stopped-early (cache + done set).
    if (cache) await cache.flush();
    await flushPromptConvDone();

    await logSummary(result.conversationsFetched, result.conversationsRequested, cacheHits + applied.filled, result.errors,
        (result.stoppedEarly ? ' (stopped early: consecutive failures)' : '') + (result.aborted ? ' (aborted)' : ''));

    return {
        filled: cacheHits + applied.filled,
        skipped: applied.skipped,
        conversationsRequested: result.conversationsRequested,
        conversationsFetched: result.conversationsFetched,
        errors: result.errors,
        stoppedEarly: !!result.stoppedEarly,
        aborted: !!result.aborted,
        cacheHits
    };
}

// Result shape returned when a generate path SKIPS prompt recovery (settings
// do not consume prompts) — same keys as recoverConversationPrompts' empty
// result so the error folding below treats it as a clean run.
const EMPTY_PROMPT_RECOVERY = Object.freeze({ filled: 0, skipped: 0, conversationsRequested: 0, conversationsFetched: 0, errors: 0, cacheHits: 0 });

// Text for generateResult.scanError describing a prompt-recovery failure, or
// null when recovery was clean. Both generate paths fold this into the
// `partial` flag so the popup shows msgGenerateListPartial instead of a clean
// success while metadata.json / prompt-mode filenames silently lack prompts.
function describePromptRecoveryErrors(recovery) {
    if (!recovery || !(recovery.errors > 0)) return null;
    const skipped = recovery.conversationsRequested - recovery.conversationsFetched;
    return `${recovery.errors} conversation prompt fetch error(s)`
        + (recovery.stoppedEarly ? ` — prompt recovery stopped early, ${skipped}/${recovery.conversationsRequested} conversations not fetched` : '');
}

// ==========================================
// Last Frame Extraction (for AI video extension workflows)
// ==========================================

/**
 * Extract a frame from a video at a specific position
 * @param {string} videoUrl - URL of the video to extract frame from
 * @param {string} videoId - ID for naming the output file
 * @param {string} position - 'first' or 'last' frame
 * @returns {Promise<{success: boolean, dataUrl?: string, filename?: string, error?: string}>}
 */
async function extractVideoFrame(videoUrl, videoId, position = 'last') {
    // Fetch video directly in content script (inherits page cookies)
    // This avoids the overhead of base64 encoding/decoding through background script
    let blobUrl = null;

    try {
        const response = await fetch(videoUrl, { credentials: 'include' });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        const blob = await response.blob();
        blobUrl = URL.createObjectURL(blob);
    } catch (error) {
        console.log('  ⚠️ Video fetch failed:', error.message);
        return {
            success: false,
            error: `Failed to fetch video: ${error.message}`
        };
    }

    return new Promise((resolve) => {
        const video = document.createElement('video');
        video.muted = true;
        video.preload = 'metadata'; // Only load metadata first for faster seek

        const cleanup = () => {
            video.remove();
            if (blobUrl) {
                URL.revokeObjectURL(blobUrl);
            }
        };

        // Timeout to prevent hanging
        const timeout = setTimeout(() => {
            cleanup();
            resolve({
                success: false,
                error: 'Frame extraction timed out'
            });
        }, 30000); // 30 second timeout

        video.onloadedmetadata = () => {
            // Seek to the desired position (like ffmpeg -ss before -i for fast seek)
            if (position === 'first') {
                video.currentTime = 0.01;
            } else {
                // Seek to last frame (slightly before end to ensure we get a frame)
                video.currentTime = Math.max(0, video.duration - 0.1);
            }
        };

        video.onseeked = () => {
            try {
                const canvas = document.createElement('canvas');
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(video, 0, 0);

                // Convert to PNG data URL
                const dataUrl = canvas.toDataURL('image/png');

                clearTimeout(timeout);
                cleanup();

                const suffix = position === 'first' ? 'first_frame' : 'last_frame';

                resolve({
                    success: true,
                    dataUrl: dataUrl,
                    width: canvas.width,
                    height: canvas.height,
                    filename: `grok_video_${videoId}_${suffix}.png`
                });
            } catch (error) {
                clearTimeout(timeout);
                cleanup();
                resolve({
                    success: false,
                    error: error.message || 'Failed to draw frame to canvas'
                });
            }
        };

        video.onerror = (e) => {
            clearTimeout(timeout);
            cleanup();
            resolve({
                success: false,
                error: 'Failed to load video for frame extraction'
            });
        };

        video.src = blobUrl;
        video.load();
    });
}

/**
 * Send a download request to background and throw on failure.
 * Checks the response so callers can detect errors via try/catch.
 */
async function sendDownloadRequest(url, filename, overwrite = false, historyKey = null) {
    if (!url || typeof url !== 'string' || (!/^https?:\/\//.test(url) && !url.startsWith('data:'))) {
        throw new Error(`No valid URL available for: ${filename}`);
    }

    let downloadUrl = url;

    // assets.grok.com requires authentication cookies that chrome.downloads.download
    // does not send. Fetch via content script (which has page cookies) and convert to
    // data URL so the download succeeds. A `data:` URL (e.g. a metadata .json whose
    // body quotes an assets.grok.com media URL) is already self-contained — never
    // route it through the fetch.
    if (!url.startsWith('data:') && url.includes('assets.grok.com')) {
        try {
            downloadUrl = await fetchAsDataUrl(url);
        } catch (error) {
            // Large / slow files (long HD videos): a data URL from here can
            // exceed the ~64 MB message limit or the 15 s timeout. Let the
            // background fetch it (cookies via host_permissions, 300 s) and
            // download it directly. Dead URLs (403/404/410) still throw.
            if (!(error && (error.tooLarge || error.timeout))) throw error;
            const bg = await chrome.runtime.sendMessage({ action: 'downloadViaBackground', url, filename, overwrite, historyKey });
            if (!bg?.success) {
                const err = new Error(bg?.error || 'Background download failed');
                if (bg?.status) err.status = bg.status;
                throw err;
            }
            return;
        }
    }

    const msg = { action: 'download', url: downloadUrl, filename };
    if (overwrite) msg.overwrite = true;
    if (historyKey) msg.historyKey = historyKey;
    const result = await chrome.runtime.sendMessage(msg);
    if (!result?.success) {
        throw new Error(result?.error || 'Download failed');
    }
}

/**
 * Fetch a URL with page credentials and return its content as a data URL.
 * Used for authenticated CDN URLs (e.g. assets.grok.com) that
 * chrome.downloads.download cannot access directly.
 */
// ~46 MiB binary -> ~61 MiB data URL, just under the 64 MiB message limit
// (anything bigger always failed before; it now goes through the background).
const FETCH_AS_DATA_URL_MAX_BYTES = 46 * 1024 * 1024;
async function fetchAsDataUrl(url) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);
    try {
        const response = await fetch(url, {
            credentials: 'include',
            signal: controller.signal
        });
        clearTimeout(timeoutId); // timeout covers the response headers only (as before)
        if (response.ok) {
            const len = Number(response.headers.get('content-length') || 0);
            if (len > FETCH_AS_DATA_URL_MAX_BYTES) {
                controller.abort();
                throw Object.assign(new Error(`Too large for in-page download (${Math.round(len / 1048576)} MB): ${url}`), { tooLarge: true });
            }
        }
        if (!response.ok) {
            // .status lets the caller distinguish a dead URL (403/404/410) from a
            // transient failure without brittle message parsing.
            const err = new Error(`Fetch failed (${response.status}): ${url}`);
            err.status = response.status;
            throw err;
        }
        const blob = await response.blob();
        if (blob.size > FETCH_AS_DATA_URL_MAX_BYTES) {
            throw Object.assign(new Error(`Too large for in-page download: ${url}`), { tooLarge: true });
        }
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.onerror = () => reject(new Error(`Failed to convert blob to data URL: ${url}`));
            reader.readAsDataURL(blob);
        });
    } catch (error) {
        clearTimeout(timeoutId);
        if (error.tooLarge) throw error;
        if (error.name === 'AbortError') {
            throw Object.assign(new Error(`Fetch timed out (15s): ${url}`), { timeout: true });
        }
        throw error;
    }
}

/**
 * Download the last frame of a video as PNG
 * @param {string} videoUrl - URL of the video
 * @param {string} videoId - ID for naming
 * @param {string} position - 'first' or 'last'
 */
async function downloadVideoFrame(videoUrl, videoId, position = 'last') {
    console.log(`  📸 正在提取${position === 'first' ? '首' : '末'}幀...`);

    const result = await extractVideoFrame(videoUrl, videoId, position);

    if (result.success) {
        try {
            const paths = await GrokUtils.getDownloadPaths();
            await sendDownloadRequest(result.dataUrl, `${paths.videos}/${result.filename}`);
            console.log(`  ✓ ${position === 'first' ? '首' : '末'}幀已下載: ${result.filename}`);
            return true;
        } catch (error) {
            console.error(`  ⚠️ ${position === 'first' ? '首' : '末'}幀下載失敗:`, error);
            return false;
        }
    } else {
        console.error(`  ⚠️ 幀提取失敗:`, result.error);
        return false;
    }
}

// 使用 GrokUtils.flattenPosts 替代本地實作

// 生成媒體列表（圖片和視頻）
async function generateMediaList(options = { includeImages: true, includeVideos: true }) {
    // "所有生成媒體" (allmedia, by-conversation) is a separate source (/rest/assets
    // — the complete asset library) with its own fetch/mapping/quality-resolution
    // path. It uses its OWN download-history namespace (grok_conversation_download_history,
    // via getEffectiveHistory's source==='allmedia' branch) — NOT shared with
    // favorite — because files land under per-conversation folders. Favorite/tag
    // behavior below is unchanged.
    if (options.source === 'allmedia') {
        return await generateMediaListFromAllMedia(options);
    }

    // Tags live in TWO incompletely-migrated stores (issues #12/#13): new tags
    // only in collections, several older tags only in the legacy folder store,
    // and most migrated tags under-populated on the collection side. A tag
    // download therefore takes the union pipeline (collection ∪ legacy folder
    // -> /rest/assets, with legacy rows as metadata fallback).
    if (options.tagId) {
        return await generateMediaListFromTag(options);
    }

    console.log('='.repeat(60));
    console.log('📋 生成媒體下載列表');
    console.log('='.repeat(60));
    console.log('');

    await SystemLogger.info('Generate List started', `Mode: ${options.downloadMode || 'standard'}${options.tagId ? ', Tag: ' + options.tagName : ''}`);

    const allPosts = [];
    let cursor = null;
    let scanError = null;
    let earlyStopped = false;
    const API_URL = 'https://grok.com/rest/media/post/list';

    // Lower-bound cutoff for early-stop heuristic.
    // API returns posts in descending createTime order (with minor intra-page noise),
    // so once an entire page (parent + nested children) falls below this cutoff,
    // no remaining page can produce in-range items — safe to break.
    // Only applies to filters with a lower bound; toDate/tag/no-filter still scan fully.
    const lowerBoundCutoff = options.fromDate != null
        ? options.fromDate
        : (options.hoursLimit ? Date.now() - options.hoursLimit * 3600 * 1000 : null);

    function pageHasInRangeItem(pagePosts) {
        const stack = [...pagePosts];
        while (stack.length) {
            const node = stack.pop();
            if (node.createTime && new Date(node.createTime).getTime() >= lowerBoundCutoff) {
                return true;
            }
            if (node.childPosts && node.childPosts.length) {
                stack.push(...node.childPosts);
            }
        }
        return false;
    }

    try {
        while (true) {
            const payload = {
                limit: 40,
                filter: GrokUtils.buildLikedFilter({ folderId: options.tagId })
            };

            if (cursor) {
                payload.cursor = cursor;
            }

            const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                throw new Error(`API returned HTTP ${response.status}`);
            }

            const data = await response.json();
            const posts = data.posts || [];

            if (posts.length === 0) break;

            allPosts.push(...posts);
            console.log(`  ✓ ${allPosts.length} 個項目`);

            // Notify popup of scan progress
            chrome.runtime.sendMessage({
                action: 'generateListProgress',
                count: allPosts.length
            }).catch(() => {}); // popup may be closed

            // Early-stop: if a lower-bound time filter is set and this entire page
            // (including nested children) is older than the cutoff, no later page
            // can contribute in-range items.
            if (lowerBoundCutoff !== null && !pageHasInRangeItem(posts)) {
                earlyStopped = true;
                console.log(`  ⏹ 整頁皆早於時間下限，提早結束分頁`);
                break;
            }

            if (!data.nextCursor) break;
            cursor = data.nextCursor;

            await new Promise(resolve => setTimeout(resolve, 300));
        }

    } catch (error) {
        // Keep partial allPosts and continue — caller surfaces the warning.
        scanError = error;
        console.error('❌ 掃描中斷，保留部分結果:', error.message);
        await SystemLogger.warn(
            'Generate List partial',
            `${allPosts.length} posts collected before error: ${error.message}`
        );
    }

    // Only abort entirely when nothing at all was collected before the error.
    if (allPosts.length === 0 && scanError) {
        await SystemLogger.fail('Generate List failed', scanError.message);
        return null;
    }

    await SystemLogger.info(
        'API scan completed',
        `Found ${allPosts.length} posts${earlyStopped ? ' (early-stopped)' : ''}${scanError ? ' (partial)' : ''}`
    );

    // 遞歸提取所有帖子（包括子帖子）
    const flattenedPosts = GrokUtils.flattenPosts(allPosts);

    // 按 createTime 升序排列（舊→新）
    flattenedPosts.sort((a, b) => {
        const ta = a.createTime ? new Date(a.createTime).getTime() : 0;
        const tb = b.createTime ? new Date(b.createTime).getTime() : 0;
        return ta - tb;
    });

    console.log(`  📊 總項目（含子項目）: ${flattenedPosts.length}`);

    // 分離圖片和視頻
    let { images, videos } = ContentUtils.separateByMediaType(flattenedPosts);
    const allImagesUnfiltered = [...images];
    const allVideosUnfiltered = [...videos];

    // 如果有日期過濾，應用過濾
    if (options.fromDate || options.toDate) {
        const fromTimestamp = options.fromDate || null;
        const toTimestamp = options.toDate || null;
        const beforeCount = { images: images.length, videos: videos.length };

        // 檢查第一個項目是否有 createTime
        const sampleItem = images[0] || videos[0];
        if (sampleItem && !sampleItem.createTime) {
            console.warn('⚠️  警告: createTime 欄位不存在');
            console.log('📋 可用欄位:', Object.keys(sampleItem));
            console.log('');
        }

        // 過濾函數：檢查是否在日期範圍內
        const isInDateRange = (itemTimestamp) => {
            if (fromTimestamp && itemTimestamp < fromTimestamp) return false;
            if (toTimestamp && itemTimestamp > toTimestamp) return false;
            return true;
        };

        images = images.filter(img => {
            if (!img.createTime) {
                console.warn(`⚠️  圖片 ${img.id} 缺少 createTime，將被排除`);
                return false;
            }
            const itemTimestamp = new Date(img.createTime).getTime();
            return isInDateRange(itemTimestamp);
        });

        videos = videos.filter(vid => {
            if (!vid.createTime) {
                console.warn(`⚠️  視頻 ${vid.id} 缺少 createTime，將被排除`);
                return false;
            }
            const itemTimestamp = new Date(vid.createTime).getTime();
            return isInDateRange(itemTimestamp);
        });

        console.log('📅 日期過濾:');
        if (fromTimestamp) console.log(`  From: ${new Date(fromTimestamp).toLocaleString()}`);
        if (toTimestamp) console.log(`  To: ${new Date(toTimestamp).toLocaleString()}`);
        console.log(`  圖片: ${beforeCount.images} → ${images.length}`);
        console.log(`  視頻: ${beforeCount.videos} → ${videos.length}`);

        // 顯示過濾後的第一個和最後一個項目的時間
        const allFiltered = [...images, ...videos];
        if (allFiltered.length > 0) {
            const times = allFiltered.map(item => new Date(item.createTime).getTime());
            const earliest = new Date(Math.min(...times));
            const latest = new Date(Math.max(...times));

            console.log('');
            console.log('📊 過濾結果時間範圍:');
            console.log(`  最早: ${earliest.toLocaleString()}`);
            console.log(`  最晚: ${latest.toLocaleString()}`);
        }
        console.log('');
    }

    // 如果有小時限制，應用過濾
    if (options.hoursLimit) {
        const cutoffTime = Date.now() - (options.hoursLimit * 60 * 60 * 1000);
        const beforeCount = { images: images.length, videos: videos.length };
        images = images.filter(img => {
            if (!img.createTime) return false;
            return new Date(img.createTime).getTime() >= cutoffTime;
        });
        videos = videos.filter(v => {
            if (!v.createTime) return false;
            return new Date(v.createTime).getTime() >= cutoffTime;
        });
        console.log(`🕐 時間過濾 (${options.hoursLimit}h): 圖片 ${beforeCount.images}→${images.length}, 影片 ${beforeCount.videos}→${videos.length}`);
    }

    console.log('');
    console.log(`✅ 找到 ${images.length} 個圖片, ${videos.length} 個視頻`);
    console.log('');

    // 根據選項過濾
    let imageData = [];
    let videoData = [];

    // 使用 GrokUtils.formatDateYYYYMMDD, GrokUtils.formatDateWithTime, GrokUtils.sanitizePromptForFilename

    if (options.includeImages) {
        imageData = images.map(img => ContentUtils.mapImageToDownloadData(img, options));
    }

    if (options.includeVideos) {
        videoData = videos.map(v => ContentUtils.mapVideoToDownloadData(v, options));
    }

    // 建立未過濾的完整資料（用於 popup 狀態顯示）
    const allImageData = options.includeImages
        ? allImagesUnfiltered.map(img => ContentUtils.mapImageToDownloadData(img, options))
        : [];
    const allVideoData = options.includeVideos
        ? allVideosUnfiltered.map(v => ContentUtils.mapVideoToDownloadData(v, options))
        : [];

    // 檢查歷史記錄，使用 ContentUtils 計算統計
    // Task D4: use the SOURCE-EFFECTIVE history (tag mode -> tag namespace) rather
    // than the default/favorite history directly, so tag stats reflect tag dedup.
    // (favorite mode has no tagId, so this resolves to the same default history.)
    const effHistForStats = await getEffectiveHistory({ filterOptions: { tagId: options.tagId } });
    const history = { has: (k) => effHistForStats.has(k) }; // includes skip-on-disk ids
    const hdPriority = options.hdPriority !== false;

    const imageStats = ContentUtils.calculateImageStats(imageData, history);
    const videoStats = ContentUtils.calculateVideoStats(videoData, history, hdPriority);

    console.log('📊 下載統計:');
    if (options.includeImages) {
        console.log(`  🖼️  圖片: ${imageStats.total} 個`);
        console.log(`     已下載: ${imageStats.alreadyDownloaded} 個（將跳過）`);
        console.log(`     待下載: ${imageStats.needDownload} 個`);
    }
    if (options.includeVideos) {
        console.log(`  🎬 視頻: ${videoStats.totalFiles} 個檔案 (含 HD)`);
        console.log(`     已下載: ${videoStats.alreadyDownloadedFiles} 個檔案（將跳過）`);
        console.log(`     待下載: ${videoStats.needDownloadFiles} 個檔案`);
    }
    console.log('');

    // 建立專案分組（用於 Project 模式）
    // 注意：不對 parent 進行時間過濾，而是在下載時對 children 進行過濾
    // 這樣可以支援「parent 是舊的，但最近新增了 children」的情況
    // 無論下載模式，都計算專案數量供狀態顯示
    const allProjects = GrokUtils.groupPostsByProject(allPosts);
    const projectCount = allProjects.length;
    console.log(`📂 專案總數: ${projectCount}`);
    let projects = [];
    if (options.downloadMode === 'project') {
        projects = allProjects;
        console.log(`📂 專案模式: 建立了 ${projects.length} 個專案資料夾`);
        if (options.fromDate || options.toDate) {
            console.log(`📅 將在下載時對 children 進行時間過濾`);
        }
    }

    const state = {
        images: imageData,
        videos: videoData,
        allImages: allImageData,
        allVideos: allVideoData,
        projects: projects, // 專案分組資料（Project 模式使用）
        projectCount: projectCount, // 專案總數（所有模式都顯示）
        currentPhase: 'images', // 'images' or 'videos' or 'projects'
        currentIndex: 0,
        downloadedImages: [], // 本次已下載的圖片
        downloadedVideos: [], // 本次已下載的視頻
        downloadedProjects: [], // 本次已下載的專案
        failed: [],
        startTime: Date.now(),
        skipDownloaded: true, // 默認跳過已下載
        completed: false, // 是否完成
        // 保存生成時的過濾條件
        filterOptions: {
            includeImages: options.includeImages,
            includeVideos: options.includeVideos,
            fromDate: options.fromDate || null,
            fromDateString: options.fromDate ? new Date(options.fromDate).toLocaleDateString() : null,
            toDate: options.toDate || null,
            toDateString: options.toDate ? new Date(options.toDate).toLocaleDateString() : null,
            hdPriority: options.hdPriority !== false, // 預設為 true
            saveMetadata: options.saveMetadata === true, // 預設為 false
            promptAsFilename: options.promptAsFilename === true, // 向後相容
            filenameMode: options.filenameMode || (options.promptAsFilename === true ? 'prompt' : 'native'),
            filenameTemplateImage: options.filenameTemplateImage || '',
            filenameTemplateVideo: options.filenameTemplateVideo || '',
            downloadMode: options.downloadMode || 'standard', // 下載模式: 'standard' or 'project'
            hoursLimit: options.hoursLimit || null,
            tagId: options.tagId || null,
            tagName: options.tagName || null
        }
    };

    await saveState(state);

    // 記錄生成完成
    if (options.downloadMode === 'project') {
        await SystemLogger.ok('Generate List completed', `Projects: ${projectCount}, Images: ${imageStats.needDownload}, Videos: ${videoStats.needDownloadFiles}`);
    } else {
        await SystemLogger.ok('Generate List completed', `Images: ${imageStats.needDownload}/${imageStats.total}, Videos: ${videoStats.needDownloadFiles}/${videoStats.totalFiles}`);
    }

    console.log('✅ 媒體列表已保存');
    console.log('');
    console.log('💡 點擊擴展圖標，然後點擊「開始下載」');
    console.log('');

    // 發送消息給 popup
    chrome.runtime.sendMessage({
        action: 'mediaGenerated',
        imageCount: imageStats.total,
        videoCount: videoStats.totalFiles, // 發送檔案數量
        alreadyDownloadedImages: imageStats.alreadyDownloaded,
        alreadyDownloadedVideos: videoStats.alreadyDownloadedFiles,
        needDownloadImages: imageStats.needDownload,
        needDownloadVideos: videoStats.needDownloadFiles,
        rateLimitWarning: videoStats.needDownloadFiles > VIDEO_DOWNLOAD_RATE_LIMIT
    });

    return {
        images: imageData,
        videos: videoData,
        partial: !!scanError,
        scanError: scanError ? scanError.message : null,
        earlyStopped
    };
}

// "所有生成媒體" (allmedia, by-conversation) 下載來源 — 拉取完整資產庫 (/rest/assets)
// 使用獨立的對話下載歷史命名空間（grok_conversation_download_history），
// 不與 favorite 共用 — 因為檔案存放於各自對話的資料夾結構中。
// Build a tag download item from a legacy post/list row for an id that
// /rest/assets did not return (issue #13). Mirrors the favorite path: image vs
// video is decided by mediaType (ContentUtils.separateByMediaType's contract),
// falling back to the mediaUrl extension when mediaType is absent, and the
// item is produced by the same mappers the favorite path uses so it carries
// id/type/url/filename/createTime/prompt and, for videos, hdUrl/hd1080Url/
// resolutionName. Returns null when the row cannot yield a downloadable item.
function buildTagItemFromLegacyPost(post, options) {
    if (!post || !post.id || !post.mediaUrl) return null;
    let isVideo;
    if (post.mediaType === 'MEDIA_POST_TYPE_VIDEO') isVideo = true;
    else if (post.mediaType === 'MEDIA_POST_TYPE_IMAGE') isVideo = false;
    else isVideo = /\.(mp4|webm|mov)(\?|$)/i.test(post.mediaUrl);
    return isVideo
        ? ContentUtils.mapVideoToDownloadData(post, options)
        : ContentUtils.mapImageToDownloadData(post, options);
}

// "標籤" (tag) 下載來源 — collection store ∪ legacy folder store（issue #13）。
// Grok 的標籤遷移雙向皆不完整：實測同一帳號同一時刻，Airo 在 collection/assets/list
// 只有 2 筆、legacy folder post/list 卻有 233 筆（Hidden 20 vs 310、R18 76 vs 171），
// 而新標籤只存在於 collection（#12）。兩邊都不權威，因此：
//   1. 以 tagId/tagName 分別在兩個 store 找到 collectionId / folderId
//   2. ids = collection assetIds ∪ legacy post ids（assetId === post.id，同一命名空間）
//   3. 以 /rest/assets 批次取 metadata；/rest/assets 沒回的 id 若有 legacy row，
//      改用 favorite 路徑的 mapImageToDownloadData / mapVideoToDownloadData 建立
// 保留 TAG 專屬的歷史命名空間（tagId 前綴）與 tag 資料夾結構；不做對話子資料夾。
async function generateMediaListFromTag(options) {
    console.log('='.repeat(60));
    console.log(`📋 生成媒體下載列表（標籤: ${options.tagName || options.tagId}）`);
    console.log('='.repeat(60));

    await SystemLogger.info('Generate List started', `Mode: tag, Tag: ${options.tagName || options.tagId}`);

    const hdPriority = options.hdPriority !== false;
    const includeImages = options.includeImages !== false;
    const includeVideos = options.includeVideos !== false;
    const tagLabel = options.tagName || options.tagId;

    const sendCount = (count) => {
        chrome.runtime.sendMessage({ action: 'generateListProgress', count }).catch(() => {}); // popup may be closed
    };

    // The popup hands us a single id (collectionId when the tag has one, else
    // the legacy folderId) plus the name; find the tag in EACH store.
    const sources = await GrokAssets.resolveTagSources(fetch, { tagId: options.tagId, tagName: options.tagName });
    console.log(`  🔎 標籤來源: collectionId=${sources.collectionId || '-'}, folderId=${sources.folderId || '-'}`);
    // A store whose LIST endpoint failed is skipped by the union walk (its id
    // cannot be resolved), which reproduces the exact issue-#13 symptom on a
    // single transient 429. That must be a scan error, not a console whisper:
    // it reaches SystemLogger here, the ids line below, and `partial` at the end.
    const storeErrors = (sources.errors || []).length;
    const unavailable = [];
    if (!sources.collectionsAvailable) unavailable.push('collection store unavailable');
    if (!sources.foldersAvailable) unavailable.push('legacy store unavailable');
    if (storeErrors > 0) {
        console.warn('  ⚠️ 標籤清單部分失敗:', sources.errors.join('; '));
        await SystemLogger.warn(
            'Tag scan: store unavailable',
            `Tag ${tagLabel}: ${sources.errors.join('; ')} — that store's contents are skipped this run`
        );
    }

    const idResult = await GrokAssets.listTagAssetIdsUnion(fetch, sources, {
        signalAborted: () => downloadAbortRequested,
        onProgress: (p) => sendCount(p.count)
    });

    const assetIds = idResult.ids;
    console.log(`  📊 標籤資產數: collection ${idResult.collectionCount} + legacy ${idResult.legacyCount} -> union ${idResult.unionCount}（錯誤: ${idResult.errors}）`);
    await SystemLogger.info(
        'Tag scan: ids',
        `Tag ${tagLabel}: collection ${idResult.collectionCount} + legacy ${idResult.legacyCount} -> union ${idResult.unionCount} ids`
        + ` (collection pages ${idResult.collectionPages}, legacy pages ${idResult.legacyPages}`
        + `${idResult.errors ? `, ${idResult.errors} page error(s)` : ''}`
        + `${unavailable.length ? `, ${unavailable.join(', ')}` : ''})`
    );

    const assetResult = await GrokAssets.getAssetsByIds(fetch, assetIds, {
        signalAborted: () => downloadAbortRequested,
        onProgress: (p) => sendCount(p.count)
    });

    // Every requested id must be accounted for. An id /rest/assets omits is
    // first recovered from its legacy post row (the row carries mediaUrl /
    // hdMediaUrl, so the favorite-path mappers can build the item); only ids
    // absent from BOTH stores are reported as missing (issue #13).
    const legacyItems = [];
    const stillMissing = [];
    for (const id of assetResult.missingIds || []) {
        const row = idResult.legacyRowsById.get(id);
        const item = row ? buildTagItemFromLegacyPost(row, options) : null;
        if (item) legacyItems.push(item);
        else stillMissing.push(id);
    }
    if (legacyItems.length > 0) {
        console.log(`  ↩️ ${legacyItems.length} 個資產改由 legacy post row 建立`);
        await SystemLogger.info(
            'Tag scan: legacy fallback',
            `Tag ${tagLabel}: ${legacyItems.length} id(s) not returned by /rest/assets were built from their legacy post rows`
        );
    }
    if (stillMissing.length > 0) {
        console.warn(`  ⚠️ ${stillMissing.length} 個資產在兩個來源都沒有 metadata，已略過`);
        await SystemLogger.warn(
            'Tag scan: missing metadata',
            `Tag ${tagLabel}: requested ${assetResult.requested}, `
            + `returned ${assetResult.assets.length}, legacy-fallback ${legacyItems.length}, missing ${stillMissing.length}`
            + ` (first: ${stillMissing.slice(0, 5).join(', ')})`
        );
    }
    await SystemLogger.info(
        'API scan completed',
        `Tag ${tagLabel}: ${assetResult.assets.length} assets + ${legacyItems.length} legacy`
        + ` (requested ${assetResult.requested})`
        + `${idResult.errors || assetResult.errors || storeErrors ? ` (errors: ${idResult.errors + assetResult.errors + storeErrors})` : ''}`
    );

    const items = assetResult.assets.map(a => ContentUtils.mapAssetToDownloadData(a, options)).concat(legacyItems);
    // Legacy LIKED rows (pre-migration) carry prompt/originalPrompt in memory
    // already. Apply them to asset-built items whose /rest/assets row has no
    // mediaGenInput BEFORE the /responses walk: migration orphans (no
    // conversation id — never recoverable via /responses) get their prompt,
    // and every id the legacy store answers is dropped from the throttled
    // walk. applyConversationPrompts never overwrites a non-empty prompt and
    // rebuilds the baked asset-style filename. Live NSFW 2026-09-10: 61/61
    // legacy rows had the prompt; 1 orphan was written with prompt:"".
    const legacyPromptMap = new Map();
    for (const [id, row] of idResult.legacyRowsById) {
        const p = row && (row.originalPrompt || row.prompt);
        if (typeof p === 'string' && p.trim() !== '') legacyPromptMap.set(id, { prompt: p, sourceAssetId: null });
    }
    const legacyPromptsFilled = legacyPromptMap.size > 0 ? applyConversationPrompts(items, legacyPromptMap, options).filled : 0;
    if (legacyPromptsFilled > 0) {
        console.log(`  📝 ${legacyPromptsFilled} 個提示詞取自 legacy post row`);
        await SystemLogger.info(
            'Prompt recovery',
            `Tag ${tagLabel}: ${legacyPromptsFilled} prompt(s) taken from legacy post rows (${legacyPromptMap.size} row(s) carried one)`
        );
    }
    // /rest/assets no longer carries mediaGenInput (2026-09) — restore prompts
    // from each conversation's /responses BEFORE the backfill below needs them.
    // Gated by the settings that consume prompts (Option A): tag folders are
    // named by tag, so with native filenames and no metadata nothing would
    // ever show a prompt — skip the (throttled) /responses walk entirely and
    // record the scope so the popup can ask for a regenerate if the settings
    // later start needing prompts.
    let promptRecovery = EMPTY_PROMPT_RECOVERY;
    let promptScope = 'none';
    if (GrokUtils.promptsNeededFor(options)) {
        promptRecovery = await recoverConversationPrompts(items, options, `Tag ${tagLabel}`);
        promptScope = 'all';
    } else {
        await SystemLogger.info('Prompt recovery', `Tag ${tagLabel}: skipped — current settings do not use prompts`);
    }
    // Videos generated from an image carry no prompt of their own — borrow the
    // source image's, exactly as the allmedia path does.
    backfillVideoPromptsFromSource(items, options);

    const imageData = includeImages ? items.filter(i => i.type === 'image') : [];
    const videoData = includeVideos ? items.filter(i => i.type === 'video') : [];

    // Quality resolution against the TAG history namespace (tagId-prefixed), so
    // an item already downloaded under a different tag still resolves here.
    if (videoData.length > 0) {
        const hist = await getEffectiveHistory({ filterOptions: { tagId: options.tagId } });
        await resolveVideoQualitiesWithProgress(videoData, hist, hdPriority, {
            resolveImpl: (id, hd) => GrokAssets.resolveVideoQuality(fetch, id, hd),
            mapImpl: GrokUtils.mapWithConcurrency,
            onProgress: (current, total) => {
                setGenerateProgress('resolving', current, total);
                chrome.runtime.sendMessage({
                    action: 'generateListProgress',
                    phase: 'resolving',
                    current,
                    total
                }).catch(() => {}); // popup may be closed
            },
            isAborted: () => downloadAbortRequested,
            sticky: await getQualityStickyStore()
        });
    }

    console.log('');
    console.log(`✅ 找到 ${imageData.length} 個圖片, ${videoData.length} 個視頻（標籤）`);

    const effHistForStats = await getEffectiveHistory({ filterOptions: { tagId: options.tagId } });
    const history = { has: (k) => effHistForStats.has(k) }; // includes skip-on-disk ids
    const imageStats = ContentUtils.calculateImageStats(imageData, history);
    const videoStats = ContentUtils.calculateVideoStats(videoData, history, hdPriority);

    const state = {
        images: imageData,
        videos: videoData,
        allImages: imageData,
        allVideos: videoData,
        projects: [], // 資產無父子結構，標籤來源不支援 Project 模式
        projectCount: 0,
        currentPhase: 'images',
        currentIndex: 0,
        downloadedImages: [],
        downloadedVideos: [],
        downloadedProjects: [],
        failed: [],
        startTime: Date.now(),
        skipDownloaded: true,
        completed: false,
        filterOptions: {
            includeImages,
            includeVideos,
            fromDate: null,   // 標籤來源不套用日期篩選（與既有行為一致）
            fromDateString: null,
            toDate: null,
            toDateString: null,
            hdPriority,
            saveMetadata: options.saveMetadata === true,
            promptAsFilename: options.promptAsFilename === true,
            filenameMode: options.filenameMode || (options.promptAsFilename === true ? 'prompt' : 'native'),
            filenameTemplateImage: options.filenameTemplateImage || '',
            filenameTemplateVideo: options.filenameTemplateVideo || '',
            downloadMode: 'standard',
            hoursLimit: null,
            tagId: options.tagId,
            tagName: options.tagName || '',
            source: 'tag',
            promptScope
        }
    };

    await saveState(state);

    await SystemLogger.ok('Generate List completed', `Images: ${imageStats.needDownload}/${imageStats.total}, Videos: ${videoStats.needDownloadFiles}/${videoStats.totalFiles}`);
    // The tag history is its OWN namespace — "Reset Download History" does not
    // clear it, so a tag can legitimately yield only the newest file. State it
    // explicitly instead of leaving the user to guess why the list is short.
    const alreadyHave = imageStats.alreadyDownloaded + videoStats.alreadyDownloadedFiles;
    if (alreadyHave > 0) {
        await SystemLogger.info(
            'Tag scan: already downloaded',
            `Tag ${options.tagName || options.tagId}: ${alreadyHave} item(s) skipped as already in this tag's history`
            + ' — use "Clear Tag History" to re-download them'
        );
    }
    await SystemLogger.info(
        'Tag scan: funnel',
        `ids ${assetIds.length} (collection ${idResult.collectionCount} + legacy ${idResult.legacyCount})`
        + ` -> assets ${assetResult.assets.length} + legacy-fallback ${legacyItems.length} + legacy-prompts ${legacyPromptsFilled}`
        + ` -> images ${imageData.length} + videos ${videoData.length}`
        + ` -> need ${imageStats.needDownload + videoStats.needDownloadFiles}`
    );
    console.log('✅ 媒體列表已保存（標籤）');

    chrome.runtime.sendMessage({
        action: 'mediaGenerated',
        imageCount: imageStats.total,
        videoCount: videoStats.totalFiles,
        alreadyDownloadedImages: imageStats.alreadyDownloaded,
        alreadyDownloadedVideos: videoStats.alreadyDownloadedFiles,
        needDownloadImages: imageStats.needDownload,
        needDownloadVideos: videoStats.needDownloadFiles,
        rateLimitWarning: videoStats.needDownloadFiles > VIDEO_DOWNLOAD_RATE_LIMIT
    });

    const promptError = describePromptRecoveryErrors(promptRecovery);
    const totalErrors = idResult.errors + assetResult.errors + storeErrors + promptRecovery.errors;
    const scanErrorParts = [];
    if (idResult.errors + assetResult.errors > 0) scanErrorParts.push(`${idResult.errors + assetResult.errors} fetch error(s) during tag scan`);
    if (storeErrors > 0) scanErrorParts.push(`tag store unavailable (${sources.errors.join('; ')})`);
    if (promptError) scanErrorParts.push(promptError);
    return {
        images: imageData,
        videos: videoData,
        partial: totalErrors > 0,
        scanError: totalErrors > 0 ? scanErrorParts.join('; ') : null,
        earlyStopped: false
    };
}

async function generateMediaListFromAllMedia(options) {
    console.log('='.repeat(60));
    console.log('📋 生成媒體下載列表（所有生成媒體）');
    console.log('='.repeat(60));
    console.log('');

    await SystemLogger.info('Generate List started', 'Mode: allmedia');

    const hdPriority = options.hdPriority !== false;
    const includeImages = options.includeImages !== false;
    const includeVideos = options.includeVideos !== false;

    // Same option fields + conversion as the favorite path's lowerBoundCutoff
    // (see generateMediaList above): dateRange -> fromDate/toDate as given;
    // lastHours -> fromDate derived from hoursLimit, toDate unbounded;
    // all -> both null (options.fromDate/toDate/hoursLimit all unset).
    const fromDate = options.fromDate != null
        ? options.fromDate
        : (options.hoursLimit ? Date.now() - options.hoursLimit * 3600 * 1000 : null);
    const toDate = options.toDate || null;

    let result;
    try {
        // Resume checkpoint (chrome.storage.local, ALLMEDIA_SCAN_CHECKPOINT_KEY):
        // a stopped/partial scan continues from its last good cursor.
        result = await GrokAssets.scanAllWithCheckpoint(fetch, {
            store: allmediaScanCheckpointStore,
            scope: { fromDate: options.fromDate, toDate: options.toDate, hoursLimit: options.hoursLimit },
            modelGeneratedOnly: true,
            // 1200ms base cadence: the endpoint rate-limits by request count
            // (~30 pages at 600ms -> 429). Ratchets up after any error; each
            // failed page is retried 15/30/60/120/180s (honoring Retry-After).
            throttleMs: ALLMEDIA_PAGE_THROTTLE_MS,
            fromDate,
            toDate,
            onProgress: (p) => {
                setGenerateProgress('scan', p.assetCount, null);
                chrome.runtime.sendMessage({
                    action: 'generateListProgress',
                    count: p.assetCount
                }).catch(() => {}); // popup may be closed
            },
            // 2026-10-24: the by-id re-read of a resumed scan (~500 batches)
            // used to report nothing, so getStatus looked frozen at "scan N".
            onByIdProgress: (p) => setGenerateProgress('reread', p.count, p.total),
            signalAborted: () => downloadAbortRequested
        });
    } catch (error) {
        // listAllGeneratedAssets is designed to never throw (it backs off and
        // returns partial results on error) — this catch is defensive only.
        console.error('❌ 所有生成媒體掃描失敗:', error.message);
        await SystemLogger.fail('Generate List failed', error.message);
        return null;
    }

    if (!result || result.assets.length === 0) {
        await SystemLogger.warn('Generate List partial', 'No assets collected (allmedia)');
    }
    if (result && result.resumed) {
        await SystemLogger.info(
            'Generate List resumed',
            `allmedia scan resumed at page ${result.resumedFromPage} from checkpoint: +${result.headNew} new since, ${result.recoveredRows} earlier rows re-read by id${result.missingRows ? ', ' + result.missingRows + ' no longer returned' : ''}`
        );
    }
    if (result && result.aborted) {
        await SystemLogger.warn('Generate List partial', `allmedia scan stopped by user after ${result.pageCount} pages; checkpoint kept for resume`);
    }
    if (result && result.partial) {
        await SystemLogger.warn(
            'Generate List partial',
            `allmedia scan stopped after ${result.pageCount} pages: page failed after all retries (${result.lastError || 'error'}; failed attempts: ${result.retryErrors})`
        );
    }

    console.log(`  📊 資產總數: ${result.assets.length}（頁數: ${result.pageCount}, 錯誤: ${result.errors}）`);
    await SystemLogger.info(
        'API scan completed',
        `Found ${result.assets.length} assets (allmedia, pages: ${result.pageCount}${result.errors ? ', errors: ' + result.errors : ''})`
    );

    const items = result.assets.map(a => ContentUtils.mapAssetToDownloadData(a, options));

    // Per-conversation folders: images+videos generated within the SAME
    // conversation download TOGETHER into one folder named after the
    // conversation's title. The title fetch happens HERE (during generate,
    // not at download start) so its progress shows on the GENERATE button
    // (phase:'titles') — where the user's focus already is — and the
    // download itself can then start instantly. Batched via
    // conversations-many (fast); tolerant of failure — a failed/aborted
    // fetch falls back to an empty titleMap, and assignConversationSubfolders
    // handles that by naming the folder "untitled" rather than aborting.
    // Fetched BEFORE prompt recovery: when the settings do not consume
    // prompts, the titles decide which (few) conversations still need one.
    const cids = items.map(it => it.sourceConversationId).filter(Boolean);
    let titleMap = {};
    try {
        titleMap = await GrokAssets.fetchConversationTitles(fetch, {
            conversationIds: cids,
            signalAborted: () => downloadAbortRequested,
            onProgress: (cur, total) => {
                setGenerateProgress('titles', cur, total);
                chrome.runtime.sendMessage({
                    action: 'generateListProgress',
                    phase: 'titles',
                    current: cur,
                    total
                }).catch(() => {}); // popup may be closed
            }
        });
    } catch (error) {
        titleMap = {};
    }
    // A title fetch that produced NOTHING for a non-empty request (thrown,
    // aborted, or every batch rejected) makes every conversation look
    // untitled below — which, under settings that don't use prompts, turns the
    // cheap folder-name pass into the full /responses walk. Keep the walk (so
    // folders don't all become "untitled" over one transient 429) but say so.
    const titlesUnavailable = cids.length > 0 && Object.keys(titleMap).length === 0;

    // /rest/assets no longer carries mediaGenInput (2026-09) — restore prompts
    // (and sourceAssetId) from each conversation's /responses, since both the
    // video backfill and the conversation-folder name below depend on them.
    // Gated by the settings that consume prompts (Option A):
    //   'all'     — prompt/custom-{prompt} filenames or metadata.json: every
    //               prompt-less item's conversation is walked (as before);
    //   'folders' — nothing surfaces a prompt except the folder-name fallback
    //               for conversations WITHOUT a title, so only THOSE items'
    //               conversations are walked (often none on a titled library).
    // The scope is recorded in filterOptions so the popup can ask for a
    // regenerate when the settings later start needing prompts.
    let promptRecovery = EMPTY_PROMPT_RECOVERY;
    let promptScope;
    if (GrokUtils.promptsNeededFor(options)) {
        promptScope = 'all';
        promptRecovery = await recoverConversationPrompts(items, options, 'allmedia');
    } else {
        promptScope = 'folders';
        const hasTitle = (cid) => typeof titleMap[cid] === 'string' && titleMap[cid].trim() !== '';
        // Key on sourceConversationId ONLY: assignConversationSubfolders groups by
        // it and gives items without one their own id folder, so a prompt fetched
        // for a currentConversationId-only item could never name anything.
        const untitledItems = items.filter(it => {
            const cid = it.sourceConversationId;
            return cid && !hasTitle(cid);
        });
        if (untitledItems.length > 0) {
            if (titlesUnavailable) {
                await SystemLogger.warn('Prompt recovery',
                    `allmedia (folder names): conversation titles unavailable — naming folders by prompt fallback for ${new Set(untitledItems.map(it => it.sourceConversationId)).size} conversation(s), which costs a full /responses walk`);
            }
            promptRecovery = await recoverConversationPrompts(untitledItems, options, 'allmedia (folder names)');
        } else {
            await SystemLogger.info('Prompt recovery', 'allmedia (folder names): skipped — every conversation has a title and current settings do not use prompts');
        }
    }

    // Videos generated from an image (imageToVideo) have no prompt of their
    // own — borrow the SOURCE image's prompt so prompt/custom filename modes
    // work for them too (see backfillVideoPromptsFromSource above).
    backfillVideoPromptsFromSource(items, options);

    assignConversationSubfolders(items, titleMap);

    let imageData = includeImages ? items.filter(i => i.type === 'image') : [];
    let videoData = includeVideos ? items.filter(i => i.type === 'video') : [];

    // 解析視頻畫質（有限並行，並跳過已在歷史記錄中的項目以避免不必要的請求）。
    // source:'allmedia' routes getEffectiveHistory to the independent
    // conversation history namespace (not the default/favorite one).
    // Bounded concurrency (5) replaces the old serial 200ms-throttled loop —
    // resolveVideoQuality now retries 429/5xx internally, so a burst of
    // parallel calls is safe. Progress is reported via 'generateListProgress'
    // (phase:'resolving') so the popup doesn't look frozen on large libraries.
    if (videoData.length > 0) {
        const hist = await getEffectiveHistory({ filterOptions: { source: 'allmedia' } });
        await resolveVideoQualitiesWithProgress(videoData, hist, hdPriority, {
            resolveImpl: (id, hd) => GrokAssets.resolveVideoQuality(fetch, id, hd),
            mapImpl: GrokUtils.mapWithConcurrency,
            onProgress: (current, total) => {
                setGenerateProgress('resolving', current, total);
                chrome.runtime.sendMessage({
                    action: 'generateListProgress',
                    phase: 'resolving',
                    current,
                    total
                }).catch(() => {}); // popup may be closed
            },
            isAborted: () => downloadAbortRequested,
            sticky: await getQualityStickyStore()
        });
    }

    console.log('');
    console.log(`✅ 找到 ${imageData.length} 個圖片, ${videoData.length} 個視頻（所有生成媒體）`);
    console.log('');

    // Task D4: stats MUST be computed against the allmedia (conversation) history
    // namespace, not the default/favorite one — an item downloaded via favorite
    // but never via allmedia still needs downloading here.
    // Never let a PARTIAL scan shrink the stored list: union by asset id with
    // the previously stored allmedia list (same date filter only), so a failed
    // page late in the scan can't throw away the rest of the library.
    if (result.partial || result.aborted || result.errors > 0) {
        try {
            const g = GrokAssets.mergePartialWithStored(await loadState(), {
                images: imageData,
                videos: videoData,
                scope: { fromDate: options.fromDate, toDate: options.toDate, hoursLimit: options.hoursLimit },
                includeImages,
                includeVideos
            });
            imageData = g.images;
            videoData = g.videos;
            const scopeRank = { none: 0, folders: 1, all: 2 };
            if (g.merged && g.prevPromptScope in scopeRank && scopeRank[g.prevPromptScope] < scopeRank[promptScope]) {
                promptScope = g.prevPromptScope;
            }
            if (g.merged) {
                await SystemLogger.warn(
                    'Generate List partial — merged',
                    `Partial scan (${g.newCount}) merged with stored list (${g.prevCount}) by asset id: +${g.addedImages} images, +${g.addedVideos} videos kept from stored list`
                );
            } else if (g.prevCount > g.newCount) {
                await SystemLogger.warn('Generate List partial', `Stored list (${g.prevCount}) has a different scope; not merged`);
            }
        } catch (e) {
            console.warn('partial-merge guard failed:', e && e.message);
        }
    }

    const effHistForStats = await getEffectiveHistory({ filterOptions: { source: 'allmedia' } });
    const history = { has: (k) => effHistForStats.has(k) }; // includes skip-on-disk ids
    const imageStats = ContentUtils.calculateImageStats(imageData, history);
    const videoStats = ContentUtils.calculateVideoStats(videoData, history, hdPriority);

    const state = {
        images: imageData,
        videos: videoData,
        allImages: imageData,
        allVideos: videoData,
        projects: [], // allmedia 資產無父子結構，不支援 Project 模式
        projectCount: 0,
        currentPhase: 'images',
        currentIndex: 0,
        downloadedImages: [],
        downloadedVideos: [],
        downloadedProjects: [],
        failed: [],
        startTime: Date.now(),
        skipDownloaded: true,
        completed: false,
        filterOptions: {
            includeImages,
            includeVideos,
            fromDate: options.fromDate || null,
            fromDateString: options.fromDate ? new Date(options.fromDate).toLocaleDateString() : null,
            toDate: options.toDate || null,
            toDateString: options.toDate ? new Date(options.toDate).toLocaleDateString() : null,
            hdPriority,
            saveMetadata: options.saveMetadata === true,
            promptAsFilename: options.promptAsFilename === true,
            filenameMode: options.filenameMode || (options.promptAsFilename === true ? 'prompt' : 'native'),
            filenameTemplateImage: options.filenameTemplateImage || '',
            filenameTemplateVideo: options.filenameTemplateVideo || '',
            downloadMode: 'standard', // allmedia 資產無父子結構，一律標準模式
            hoursLimit: options.hoursLimit || null,
            tagId: null, // allmedia 使用獨立的 conversation 歷史命名空間（非 tag 命名空間），由 source:'allmedia' 決定
            tagName: null,
            source: 'allmedia',
            promptScope
        }
    };

    await saveState(state);

    await SystemLogger.ok('Generate List completed', `Images: ${imageStats.needDownload}/${imageStats.total}, Videos: ${videoStats.needDownloadFiles}/${videoStats.totalFiles}`);

    console.log('✅ 媒體列表已保存（所有生成媒體）');
    console.log('');

    chrome.runtime.sendMessage({
        action: 'mediaGenerated',
        imageCount: imageStats.total,
        videoCount: videoStats.totalFiles,
        alreadyDownloadedImages: imageStats.alreadyDownloaded,
        alreadyDownloadedVideos: videoStats.alreadyDownloadedFiles,
        needDownloadImages: imageStats.needDownload,
        needDownloadVideos: videoStats.needDownloadFiles,
        rateLimitWarning: videoStats.needDownloadFiles > VIDEO_DOWNLOAD_RATE_LIMIT
    });

    const promptError = describePromptRecoveryErrors(promptRecovery);
    const scanErrorParts = [];
    if (result.errors > 0) scanErrorParts.push(`${result.errors} page fetch error(s) during allmedia scan`);
    if (promptError) scanErrorParts.push(promptError);
    return {
        images: imageData,
        videos: videoData,
        partial: scanErrorParts.length > 0,
        scanError: scanErrorParts.length > 0 ? scanErrorParts.join('; ') : null,
        earlyStopped: false
    };
}

// Re-derive an allmedia image's filename at DOWNLOAD time (mirrors the video
// download loop, which already re-derives). This means a filenameMode change —
// or a code change to the naming logic — takes effect WITHOUT regenerating the
// list. Favorite/tag keep their generate-time baked filename (a stable
// convention with the prompt always available at generate).
function resolveImageDownloadFilename(img, state) {
    if (state?.filterOptions?.source !== 'allmedia') return img.filename;
    const fo = state.filterOptions || {};
    const ext = GrokUtils.getExtFromMediaUrl(img.url, 'jpg');
    return ContentUtils.buildAssetFilename({
        assetId: img.id,
        ext,
        isVideo: false,
        createTime: img.createTime,
        prompt: img.originalPrompt || img.prompt,
        filenameMode: fo.filenameMode || (fo.promptAsFilename ? 'prompt' : 'native'),
        filenameTemplateImage: fo.filenameTemplateImage
    });
}

// Video counterpart of resolveImageDownloadFilename. For allmedia the disk
// name is the SAME ContentUtils.buildAssetFilename output stored in
// state.videos[].filename — in prompt mode that carries the short-id suffix
// that keeps a same-prompt + same-second batch from colliding (the old
// `${quality}_${ts}_${prompt}` rebuild dropped it). `secondRendition` marks the
// extra HD file of the non-HD-priority path, which needs its own name next to
// the base one: `_hd` goes before the extension. Favorite/tag sources keep
// the legacy quality-prefixed naming.
// @param {Object} video - state.videos[] item
// @param {Object} state - download state (filterOptions.source/filenameMode/...)
// @param {Object} opts - { quality: 'hd'|'sd', url: the rendition being downloaded, secondRendition }
// @returns {string} basename with extension
function resolveVideoDownloadFilename(video, state, { quality = 'sd', url, secondRendition = false } = {}) {
    const fo = state?.filterOptions || {};
    const filenameMode = fo.filenameMode || (fo.promptAsFilename ? 'prompt' : 'native');
    const ext = GrokUtils.getExtFromMediaUrl(url || video.url, 'mp4');
    const effectivePrompt = video.originalPrompt || video.prompt;

    if (fo.source === 'allmedia') {
        const base = ContentUtils.buildAssetFilename({
            assetId: video.id,
            ext,
            isVideo: true,
            createTime: video.createTime,
            prompt: effectivePrompt,
            filenameMode,
            filenameTemplateVideo: fo.filenameTemplateVideo
        });
        return secondRendition ? base.replace(/(\.[^.]+)$/, `_${quality}$1`) : base;
    }

    if (filenameMode === 'custom') {
        const applied = GrokUtils.applyFilenameTemplate(fo.filenameTemplateVideo || '', {
            createTime: video.createTime, id: video.id, prompt: effectivePrompt, quality
        });
        return `${applied}.${ext}`;
    }
    if (filenameMode === 'prompt') {
        const dateTimeStr = GrokUtils.formatDateWithTime(video.createTime);
        return `${quality}_${dateTimeStr}_${GrokUtils.sanitizePromptForFilename(effectivePrompt, 120, video.id)}.${ext}`;
    }
    return `grok_video_${quality}_${GrokUtils.formatDateYYYYMMDD(video.createTime)}_${video.id}.${ext}`;
}

// 批量下載圖片
async function downloadImages() {
    const state = await loadState();

    if (!state || !state.images || state.images.length === 0) {
        console.log('⊘ 沒有圖片需要下載');
        // 圖片下載完成，檢查是否需要下載視頻
        if (state && state.videos && state.videos.length > 0) {
            console.log('');
            console.log('🎬 開始下載視頻...');
            console.log('');
            await startVideoDownload();
        } else {
            await finishAllDownloads();
        }
        return;
    }

    const hist = await getEffectiveHistory(state);
    const needDownload = ContentUtils.dropSkipped(state.images.filter(img => !hist.has(img.id)), hist);

    console.log('='.repeat(60));
    console.log('🖼️  開始批量下載圖片');
    console.log('='.repeat(60));
    console.log(`總圖片: ${state.images.length} 個`);
    console.log(`已下載: ${state.images.length - needDownload.length} 個（將跳過）`);
    console.log(`待下載: ${needDownload.length} 個`);
    console.log('');

    await SystemLogger.info('Image download started', `Total: ${needDownload.length} images`);

    if (needDownload.length === 0) {
        console.log('✅ 所有圖片都已下載！');
        console.log('');

        // 圖片下載完成，檢查是否需要下載視頻
        if (state.videos && state.videos.length > 0) {
            console.log('🎬 開始下載視頻...');
            console.log('');
            await startVideoDownload();
        } else {
            await finishAllDownloads();
        }
        return;
    }

    // 批量下載圖片
    let successCount = 0;
    let failCount = 0;
    const rawPaths = await GrokUtils.getDownloadPaths();
    const paths = getEffectivePaths(rawPaths, state);

    // 更新下載進度
    downloadCurrentProgress = { phase: 'images', current: 0, total: needDownload.length, success: 0, fail: 0 };

    for (let i = 0; i < needDownload.length; i++) {
        // 檢查是否被中斷
        if (downloadAbortRequested) {
            console.log('⚠️ 下載被使用者中斷（圖片階段）');
            await saveState(state);
            await handleDownloadAbort(successCount, failCount, 'images');
            return;
        }

        const img = needDownload[i];
        const imageDir = resolveMediaDir(paths, state, img, 'image');
        // Re-derive at download time (allmedia) so filenameMode/code changes
        // apply without regenerating; favorite/tag keep their baked filename.
        const imageFilename = resolveImageDownloadFilename(img, state);
        // 更新進度
        downloadCurrentProgress = { phase: 'images', current: i + 1, total: needDownload.length, success: successCount, fail: failCount };
        console.log(`[${i + 1}/${needDownload.length}] ${img.id}`);

        try {
            // 使用 chrome.downloads API 下載圖片
            await sendDownloadRequest(img.url, `${imageDir}/${imageFilename}`, false, hist.keyFor(img.id));

            // 如果啟用了 saveMetadata，同時下載 .json 檔案
            if (state.filterOptions?.saveMetadata) {
                const metadata = {
                    id: img.id,
                    type: img.type,
                    url: img.url,
                    filename: imageFilename,
                    userId: img.userId,
                    createTime: img.createTime,
                    prompt: img.prompt,
                    originalPrompt: img.originalPrompt,
                    downloadedAt: new Date().toISOString()
                };
                const jsonFilename = imageFilename.replace(/\.[^.]+$/, '.json');
                const jsonDataUrl = GrokUtils.generateJsonDataUrl(metadata);
                await sendDownloadRequest(jsonDataUrl, `${imageDir}/${jsonFilename}`);
            }

            // 添加到歷史記錄
            await hist.add(img.id);
            if (!state.downloadedImages.includes(img.id)) {
                state.downloadedImages.push(img.id);
            }

            // 更新圖片的下載狀態
            const imageIndex = state.images.findIndex(image => image.id === img.id);
            if (imageIndex !== -1) {
                state.images[imageIndex].downloaded = true;
                state.images[imageIndex].downloadedAt = Date.now();
            }

            console.log('  ✓ 下載成功');
            await SystemLogger.ok('Image downloaded', img.id);
            successCount++;

            // 每 10 個項目或最後一個才寫入狀態和歷史
            if ((i + 1) % 10 === 0 || i === needDownload.length - 1) {
                await saveState(state);
                await hist.flush();
            }

            // 延遲以避免過快請求
            await new Promise(resolve => setTimeout(resolve, 500));

            // Burst-boundary breather: let Safe Browsing flush internal state
            if (successCount > 0 && successCount % BURST_PAUSE_EVERY === 0) {
                await new Promise(resolve => setTimeout(resolve, BURST_PAUSE_MS));
            }

        } catch (error) {
            console.log('  ✗ 下載失敗:', error.message);
            await SystemLogger.fail('Image download failed', `${img.id} - ${error.message}`);
            state.failed.push({
                id: img.id,
                type: 'image',
                error: error.message
            });
            failCount++;
            // 錯誤時立即保存狀態以保留失敗記錄
            if ((i + 1) % 10 === 0 || i === needDownload.length - 1) {
                await saveState(state);
                await hist.flush();
            }
        }
    }

    console.log('');
    console.log('📊 圖片下載完成');
    console.log(`  成功: ${successCount}/${needDownload.length}`);
    console.log(`  失敗: ${failCount}/${needDownload.length}`);
    console.log('');
    await SystemLogger.info('Image download phase completed', `Success: ${successCount}, Failed: ${failCount}`);

    // 圖片下載完成，檢查是否需要下載視頻
    if (state.videos && state.videos.length > 0) {
        const videoHist = await getEffectiveHistory(state);
        const needDownloadVideos = state.videos.filter(v => {
            const isNative720p = !(v.hd1080Url || v.hdUrl) && v.resolutionName === '720p';
            if (isNative720p) {
                return !videoHist.has(`${v.id}_hd`);
            }
            const sdMissing = !videoHist.has(v.id) && !videoHist.has(`${v.id}_sd`);
            const hdMissing = (v.hd1080Url || v.hdUrl) ? !videoHist.has(v.id + '_hd') : false;
            return sdMissing || hdMissing;
        });

        if (needDownloadVideos.length > 0) {
            console.log('🎬 開始下載視頻...');
            console.log('');
            await startVideoDownload();
        } else {
            await finishAllDownloads();
        }
    } else {
        await finishAllDownloads();
    }
}

// 開始視頻下載
async function startVideoDownload() {
    const state = await loadState();

    if (!state || !state.videos || state.videos.length === 0) {
        console.log('⊘ 沒有視頻需要下載');
        await finishAllDownloads();
        return;
    }

    const hist = await getEffectiveHistory(state);
    const historyArray = hist.toArray(); // Array for GrokUtils compatibility
    const hdPriority = state.filterOptions?.hdPriority !== false; // 預設為 true

    // 檔名由 resolveVideoDownloadFilename 依 filterOptions（source / filenameMode /
    // filenameTemplateVideo）在下載時決定。

    // 過濾出需要下載的視頻（使用 GrokUtils）
    const needDownload = ContentUtils.dropSkipped(GrokUtils.filterVideosForHdPriority(state.videos, historyArray, hdPriority), hist);

    // 計算總檔案數（使用 GrokUtils）
    const totalFiles = GrokUtils.calculateTotalVideoFiles(state.videos, hdPriority);
    const downloadedFiles = totalFiles - needDownload.length;

    console.log('='.repeat(60));
    console.log('🎬 開始批量下載視頻');
    console.log('='.repeat(60));
    console.log(`HD 優先模式: ${hdPriority ? '✅ 開啟' : '❌ 關閉'}`);
    console.log(`總視頻: ${state.videos.length} 個`);
    console.log(`已下載: ${downloadedFiles} 個（將跳過）`);
    console.log(`待下載: ${needDownload.length} 個`);
    console.log('');

    await SystemLogger.info('Video download started', `Total: ${needDownload.length} videos, HD Priority: ${hdPriority}`);

    if (needDownload.length === 0) {
        console.log('✅ 所有視頻都已下載！');
        await finishAllDownloads();
        return;
    }

    // 更新狀態為視頻下載階段
    state.currentPhase = 'videos';
    await saveState(state);

    // 批量下載視頻
    let successCount = 0;
    let failCount = 0;
    const rawPaths = await GrokUtils.getDownloadPaths();
    const paths = getEffectivePaths(rawPaths, state);

    // 更新下載進度
    downloadCurrentProgress = { phase: 'videos', current: 0, total: needDownload.length, success: 0, fail: 0 };

    for (let i = 0; i < needDownload.length; i++) {
        // 檢查是否被中斷
        if (downloadAbortRequested) {
            console.log('⚠️ 下載被使用者中斷（視頻階段）');
            await saveState(state);
            await handleDownloadAbort(successCount, failCount, 'videos');
            return;
        }

        const video = needDownload[i];
        const videoDir = resolveMediaDir(paths, state, video, 'video');
        // 更新進度
        downloadCurrentProgress = { phase: 'videos', current: i + 1, total: needDownload.length, success: successCount, fail: failCount };
        const dateStr = GrokUtils.formatDateYYYYMMDD(video.createTime);
        console.log(`[${i + 1}/${needDownload.length}] ${video.id} (${dateStr})`);

        // Basename of the primary file written for this video; the metadata
        // .json sidecar shares it.
        let mediaFilename = null;
        try {
            if (hdPriority) {
                // HD 優先模式：只下載一個版本（1080p > HD(720p) > 原始畫質）
                const hasHd = !!(video.hd1080Url || video.hdUrl);
                const isNative720p = !hasHd && video.resolutionName === '720p';
                const downloadUrl = GrokUtils.pickVideoUrl(video, true);
                const quality = (hasHd || isNative720p) ? 'hd' : 'sd';
                const historyKey = `${video.id}_${quality}`;

                mediaFilename = resolveVideoDownloadFilename(video, state, { quality, url: downloadUrl });
                const filename = `${videoDir}/${mediaFilename}`;

                console.log(`  ⬇️  下載 ${quality.toUpperCase()} 畫質...`);
                await sendDownloadRequest(downloadUrl, filename, false, hist.keyFor(historyKey));

                await hist.add(historyKey);
                console.log(`  ✓ ${quality.toUpperCase()} 版本下載完成`);

            } else {
                // 非 HD 優先模式：下載所有版本 (舊邏輯)
                const isNative720p = !(video.hd1080Url || video.hdUrl) && video.resolutionName === '720p';
                mediaFilename = resolveVideoDownloadFilename(video, state, { quality: isNative720p ? 'hd' : 'sd', url: video.url });

                if (isNative720p) {
                    // 原生 720p：只有一個版本，直接以 HD 品質下載
                    const hdKey = `${video.id}_hd`;
                    if (!hist.has(hdKey)) {
                        const filename = `${videoDir}/${mediaFilename}`;
                        console.log(`  ⬇️  下載 720p (原生 HD)...`);
                        await sendDownloadRequest(video.url, filename, false, hist.keyFor(hdKey));
                        await hist.add(hdKey);
                        console.log(`  ✓ 720p 版本下載完成`);
                    }
                } else {
                    // SD 版本
                    const sdKey = `${video.id}_sd`;
                    if (!hist.has(video.id) && !hist.has(sdKey)) {
                        const filename = `${videoDir}/${mediaFilename}`;
                        console.log(`  ⬇️  下載 SD 畫質...`);
                        await sendDownloadRequest(video.url, filename, false, hist.keyFor(sdKey));
                        await hist.add(sdKey);
                        console.log(`  ✓ SD 版本下載完成`);
                    }
                }

                // HD 版本（只有非原生 720p 才需要檢查；1080p > HD(720p)）
                const hdDownloadUrl = video.hd1080Url || video.hdUrl;
                if (hdDownloadUrl && !hist.has(video.id + '_hd')) {
                    // Second rendition next to the base file: allmedia gets a
                    // `_hd` suffix, legacy sources their usual `hd_` prefix.
                    const hdFilename = `${videoDir}/${resolveVideoDownloadFilename(video, state, { quality: 'hd', url: hdDownloadUrl, secondRendition: true })}`;
                    console.log(`  ⬇️  下載 HD 畫質...`);
                    await sendDownloadRequest(hdDownloadUrl, hdFilename, false, hist.keyFor(video.id + '_hd'));
                    await hist.add(video.id + '_hd');
                    console.log(`  ✓ HD 版本下載完成`);
                }
            }

            if (!state.downloadedVideos.includes(video.id)) {
                state.downloadedVideos.push(video.id);
            }

            // 如果啟用了 saveMetadata，同時下載 .json 檔案
            if (state.filterOptions?.saveMetadata) {
                const quality = hdPriority ? (((video.hd1080Url || video.hdUrl) || video.resolutionName === '720p') ? 'hd' : 'sd') : 'sd';
                const metadata = {
                    id: video.id,
                    type: video.type,
                    url: video.url,
                    hdUrl: video.hdUrl,
                    filename: mediaFilename,
                    detailUrl: video.detailUrl,
                    userId: video.userId,
                    createTime: video.createTime,
                    prompt: video.prompt,
                    originalPrompt: video.originalPrompt,
                    downloadedQuality: quality,
                    downloadedAt: new Date().toISOString()
                };
                const jsonFilename = mediaFilename.replace(/\.[^.]+$/, '.json');
                const jsonDataUrl = GrokUtils.generateJsonDataUrl(metadata);
                await sendDownloadRequest(jsonDataUrl, `${videoDir}/${jsonFilename}`);
            }

            // 更新單個項目狀態
            const videoIndex = state.videos.findIndex(v => v.id === video.id);
            if (videoIndex !== -1) {
                state.videos[videoIndex].downloaded = true;
                state.videos[videoIndex].downloadedAt = Date.now();
            }

            console.log('  ✓ 下載成功');
            await SystemLogger.ok('Video downloaded', video.id);
            successCount++;

            // Rate limit protection: pause after every VIDEO_DOWNLOAD_RATE_LIMIT successful downloads
            if (successCount > 0 && successCount % VIDEO_DOWNLOAD_RATE_LIMIT === 0) {
                console.log(`⏸️ Rate limit: ${successCount} videos downloaded, pausing...`);
                await saveState(state);
                await hist.flush();
                const cooldownResult = await handleRateLimitPause(successCount, failCount, 'videos');
                if (cooldownResult === 'aborted') {
                    await handleDownloadAbort(successCount, failCount, 'videos');
                    return;
                }
                // cooldownResult === 'resume' → continue loop
            }

            // 只有在 Story Mode 活跃時才自動提取末幀
            if (storyModeActive) {
                console.log('  📸 Story Mode 活躍，提取末幀...');
                const frameSourceUrl = GrokUtils.pickVideoUrl(video, true);
                await downloadVideoFrame(frameSourceUrl, video.id, 'last');
            }

            // 每 10 個項目或最後一個才寫入狀態和歷史
            if ((i + 1) % 10 === 0 || i === needDownload.length - 1) {
                await saveState(state);
                await hist.flush();
            }

            // 延遲以避免過快請求
            await new Promise(resolve => setTimeout(resolve, 1000));

            // Burst-boundary breather: let Safe Browsing flush internal state
            if (successCount > 0 && successCount % BURST_PAUSE_EVERY === 0) {
                await new Promise(resolve => setTimeout(resolve, BURST_PAUSE_MS));
            }

        } catch (error) {
            // Positive evidence that a REMEMBERED url is dead. Only explicit
            // 403/404/410 — never a timeout, 429 or network blip, so a flaky
            // connection cannot wipe the store. evictStickyQuality never throws.
            if (video.__qualityFromSticky && [403, 404, 410].includes(error.status)) {
                await evictStickyQuality(video.id);
            }
            console.log('  ✗ 下載失敗:', error.message);
            await SystemLogger.fail('Video download failed', `${video.id} - ${error.message}`);
            state.failed.push({
                id: video.id,
                type: 'video',
                error: error.message
            });
            failCount++;
            // 錯誤時也按批次保存
            if ((i + 1) % 10 === 0 || i === needDownload.length - 1) {
                await saveState(state);
                await hist.flush();
            }
        }
    }

    console.log('');
    console.log('📊 視頻下載完成');
    console.log(`  成功: ${successCount}/${needDownload.length}`);
    console.log(`  失敗: ${failCount}/${needDownload.length}`);
    console.log('');
    await SystemLogger.info('Video download phase completed', `Success: ${successCount}, Failed: ${failCount}`);

    await finishAllDownloads();
}

// 開始自動下載（統一入口）
async function startAutoDownload() {
    // 檢查是否已在下載中
    if (downloadInProgress) {
        return {
            success: false,
            reason: 'download_already_in_progress',
            inProgress: true,
            ...downloadCurrentProgress
        };
    }

    const state = await loadState();

    if (!state) {
        console.log('❌ 沒有媒體列表');
        console.log('💡 請先生成下載列表');
        return { success: false, reason: 'no_list' };
    }

    if ((!state.images || state.images.length === 0) &&
        (!state.videos || state.videos.length === 0)) {
        console.log('❌ 沒有媒體需要下載');
        console.log('💡 請先生成下載列表');
        return { success: false, reason: 'no_media' };
    }

    // 預熱歷史快取（tag mode 用 tag history）
    const hist = await getEffectiveHistory(state);
    const hdPriority = state.filterOptions?.hdPriority !== false;
    const downloadMode = state.filterOptions?.downloadMode || 'standard';

    // 檢查是否所有內容都已下載
    if (downloadMode === 'project' && state.projects && state.projects.length > 0) {
        // Project 模式：用 per-file history 檢查每個專案
        // Build a Set-like wrapper that countProjectsNeedDownload can use with .has()
        const histWrapper = { has: (key) => hist.has(key) };
        const needProjects = countProjectsNeedDownload(state.projects, histWrapper, state.filterOptions);
        if (needProjects === 0) {
            console.log('='.repeat(60));
            console.log('✅ 所有專案都已下載過');
            console.log('='.repeat(60));
            console.log(`專案: ${state.projects.length} 個（全部已下載）`);
            console.log('');
            console.log('💡 如需重新下載，請先清除歷史記錄');
            return {
                success: false,
                reason: 'all_downloaded',
                imageCount: state.images?.length || 0,
                videoCount: state.videos?.length || 0
            };
        }
    } else {
        // 標準模式：檢查圖片和視頻
        const needDownloadImages = ContentUtils.dropSkipped(state.images?.filter(img => !hist.has(img.id)) || [], hist);
        const historyArrayForUtils = hist.toArray();
        const needDownloadVideos = ContentUtils.dropSkipped(GrokUtils.filterVideosForHdPriority(state.videos || [], historyArrayForUtils, hdPriority), hist);

        if (needDownloadImages.length === 0 && needDownloadVideos.length === 0) {
            console.log('='.repeat(60));
            console.log('✅ 所有內容都已下載過');
            console.log('='.repeat(60));
            console.log(`圖片: ${state.images?.length || 0} 個（全部已下載）`);
            console.log(`視頻: ${state.videos?.length || 0} 個（全部已下載）`);
            console.log('');
            console.log('💡 如需重新下載，請先清除歷史記錄');
            return {
                success: false,
                reason: 'all_downloaded',
                imageCount: state.images?.length || 0,
                videoCount: state.videos?.length || 0
            };
        }
    }

    // Arm the entry guard SYNCHRONOUSLY, before any of the awaited work below
    // — otherwise a second startAutoDownload() arriving during that window
    // reads downloadInProgress as still false and races past the guard at
    // the top of this function (double-download race, Review Finding 2). Any
    // failure from here through the end of this function resets the flag
    // (the preamble's own catch below, or the main try/finally further down)
    // so a failed start can never leave it stuck true.
    downloadInProgress = true;
    downloadAbortRequested = false;
    downloadCurrentProgress = { phase: 'starting', current: 0, total: 0, success: 0, fail: 0 };

    try {
        // Per-conversation folders (Task D3): the title fetch + subfolder
        // assignment normally happens during generate now (see
        // generateMediaListFromAllMedia), so by the time we get here every
        // item should already carry a `.subfolder`. This is a no-network
        // DEFENSIVE fallback only, for an allmedia state that predates that
        // change (e.g. a list generated before this version, or a resumed
        // download) — it assigns id/"untitled"-based subfolders synchronously
        // instead of leaving items to fall through to the flat images/videos
        // dir (Review Finding 3: never let a folder-assignment gap abort the
        // download start).
        if (state.filterOptions?.source === 'allmedia') {
            const allItems = [...(state.images || []), ...(state.videos || [])];
            if (allItems.some(item => !item.subfolder)) {
                assignConversationSubfolders(allItems, {});
                await saveState(state);
            }
        }

        // 重置狀態
        state.currentIndex = 0;
        state.downloadedImages = []; // 重置本次圖片下載記錄
        state.downloadedVideos = []; // 重置本次視頻下載記錄
        state.downloadedProjects = []; // 重置本次專案下載記錄
        state.failed = [];
        state.startTime = Date.now();
        state.completed = false; // 重置完成標記
        state.aborted = false; // Clear aborted flag from previous run
        state.rateLimitPaused = false; // Clear rate limit pause flag
        await saveState(state);
    } catch (error) {
        // Preamble failed (subfolder assignment, state save, ...) — the
        // download never actually started, so reset the guard here rather
        // than leaving it stuck true for every future call.
        downloadInProgress = false;
        console.error('❌ 下載準備失敗', error);
        return { success: false, reason: 'start_failed', error: error && error.message };
    }

    try {
        console.log('='.repeat(60));
        console.log('🚀 開始自動下載');
        console.log('='.repeat(60));
        console.log('');

        const imageCount = state.images?.length || 0;
        const videoCount = state.videos?.length || 0;
        const projectCount = state.projects?.length || 0;
        await SystemLogger.info('Download started', `Images: ${imageCount}, Videos: ${videoCount}, Projects: ${projectCount}`);

        // 檢查下載模式（downloadMode 已在上方宣告）
        if (downloadMode === 'project' && state.projects && state.projects.length > 0) {
            // Project 模式：按專案資料夾下載
            console.log(`📂 專案模式: ${state.projects.length} 個專案`);
            state.currentPhase = 'projects';
            await saveState(state);
            await downloadProjects();
        } else {
            // 標準模式：先下載圖片，再下載視頻
            if (state.images && state.images.length > 0) {
                state.currentPhase = 'images';
                await saveState(state);
                await downloadImages();
            } else if (state.videos && state.videos.length > 0) {
                state.currentPhase = 'videos';
                await saveState(state);
                await startVideoDownload();
            }
        }

        return { success: true };
    } finally {
        // 保底：無論正常完成、中斷或例外拋出，都確保下載狀態解除，
        // 避免中途拋錯導致 downloadInProgress 卡死為 true。
        // downloadImages/startVideoDownload/downloadProjects 正常路徑下
        // 已透過 finishAllDownloads()/handleDownloadAbort() 重置過，這裡重複賦值是無害的保險。
        downloadInProgress = false;
    }
}

// 在詳情頁找到並點擊下載按鈕
// Legacy findAndClickDownloadButton / handleCurrentVideo / goToNextVideo removed.
// Video downloads now use batch mode via startVideoDownload() → background.js,
// no page navigation needed.

// Issue #7 diagnostics: read an upscale response body without assuming the response
// object supports .text(). The body can only be consumed once, so the loop reads it
// here and passes the text to is1080pPaidGateError instead of the raw response.
async function readUpscaleResponseBody(response, maxLength = 500) {
    if (!response || typeof response.text !== 'function') return '';
    try {
        const text = await response.text();
        return text.length > maxLength ? text.slice(0, maxLength) + '…' : text;
    } catch (e) {
        return `<body read failed: ${e.message}>`;
    }
}

// 偵測 1080p 升級 API 是否回傳「帳號未開通付費方案」的門檻錯誤
// 已知格式：HTTP 400 { code: 9, message: "1080p video upscale is not available" }
// 此為帳號層級限制（非單一影片問題），一旦命中即可停止後續所有 1080p 請求。
// bodyText 由呼叫端預先讀取（issue #7 診斷會記錄每個 response body）。
function is1080pPaidGateError(response, bodyText) {
    if (response.status !== 400) return false;

    let parsed = null;
    try {
        parsed = JSON.parse(bodyText);
    } catch (e) {
        parsed = null;
    }

    if (parsed && parsed.code === 9) return true;
    return /1080p[\s\S]*not available/i.test(bodyText);
}

// 升級收藏的視頻到 HD
async function upgradeFavoritesToHD(options = {}) {
    // 如果已經在進行中，返回當前狀態
    if (upgradeInProgress) {
        return {
            success: false,
            error: 'upgrade_already_in_progress',
            inProgress: true,
            ...upgradeCurrentProgress
        };
    }

    console.log('='.repeat(60));
    console.log('🚀 開始升級收藏視頻到 HD');
    console.log('='.repeat(60));
    console.log('');

    // 設定狀態
    upgradeInProgress = true;
    upgradeAbortRequested = false;
    upgradeCurrentProgress = { current: 0, total: 0, success: 0, fail: 0 };

    const API_UPSCALE_URL = 'https://grok.com/rest/media/video/upscale';

    // 1080p upscale requires a SuperGrok Heavy account — it's an explicit user opt-in
    // (default off). Used both to gate the rescan-path work list below AND as the
    // authoritative per-video guard in the loop (so a stale cache or the internal
    // rescan can never fire a 1080p request when the option is off).
    const include1080p = options.include1080p === true;

    // Scan source: 'favorite' (liked posts via /rest/media/post/list, default) or
    // 'allmedia' (whole generated library via /rest/assets). Used to gate cache reuse
    // below — a cache from a DIFFERENT source must never be silently reused.
    const source = options.source === 'allmedia' ? 'allmedia' : 'favorite';

    // Use cached scan results if available (from scanVideosForUpgrade /
    // scanFavoritesForUpgrade) AND it matches the requested source, otherwise rescan.
    let videosNeedUpgrade;
    let allVideosCount;
    let scanPartial = false; // true if the (re)scan below stopped early / was aborted / hit errors

    if (upgradeScanCache && upgradeScanCache.source === source && (Date.now() - upgradeScanCache.timestamp < 5 * 60 * 1000)) {
        console.log('  ✅ 使用掃描緩存，跳過重複掃描');
        videosNeedUpgrade = upgradeScanCache.videos;
        allVideosCount = videosNeedUpgrade.length; // approximate, used only for logging
        upgradeScanCache = null; // clear cache after use
    } else {
        console.log('  ⚠️ 無快取或來源不同，重新掃描...');
        upgradeScanCache = null;

        await SystemLogger.info('HD upgrade started', 'Scanning videos...');

        chrome.runtime.sendMessage({
            action: 'upgradeProgress',
            status: 'scanning',
            message: source === 'allmedia' ? 'scanning_allmedia' : 'scanning_favorites'
        });

        const scanResult = await scanVideosForUpgrade({
            source,
            hoursLimit: options.hoursLimit,
            include1080p: options.include1080p
        });

        if (!scanResult || scanResult.success === false) {
            console.error('❌ 掃描失敗:', scanResult && scanResult.error);
            upgradeInProgress = false;
            chrome.runtime.sendMessage({ action: 'upgradeProgress', status: 'idle' });
            return scanResult || { success: false, error: 'scan_failed' };
        }

        videosNeedUpgrade = upgradeScanCache?.videos || [];
        allVideosCount = videosNeedUpgrade.length;
        scanPartial = !!scanResult.partial;
        upgradeScanCache = null;
    }

    // Apply time filter if specified — FAVORITE ONLY. The favorite scan caches the
    // UNfiltered work list, so this loop must window it by hoursLimit itself. Allmedia's
    // scan already early-stopped at fromDate (listAllGeneratedAssets), so its cached list
    // is already date-bounded — re-applying this filter here would be redundant AND would
    // wrongly drop any allmedia video with a null createTime (which the scan deliberately
    // treats as in-range, e.g. metadata that never carried a timestamp).
    if (options.hoursLimit && source !== 'allmedia') {
        const cutoffTime = Date.now() - (options.hoursLimit * 60 * 60 * 1000);
        videosNeedUpgrade = videosNeedUpgrade.filter(v => {
            if (!v.createTime) return false;
            return new Date(v.createTime).getTime() >= cutoffTime;
        });
        console.log(`  🕐 時間過濾 (${options.hoursLimit}h): ${videosNeedUpgrade.length} 個`);
    }

    console.log(`  🔍 需要升級: ${videosNeedUpgrade.length} 個`);

    await SystemLogger.info('HD upgrade started', `${videosNeedUpgrade.length} videos to upgrade`);

    if (videosNeedUpgrade.length === 0) {
        upgradeInProgress = false;
        chrome.runtime.sendMessage({ action: 'upgradeProgress', status: 'idle' });
        await SystemLogger.ok('HD upgrade completed', 'All videos already have HD version');
        return { success: true, upgradedCount: 0, total: 0, scanPartial };
    }

    // 3. 逐個升級
    let successCount = 0;
    let failCount = 0;
    // 一旦偵測到帳號級 1080p 付費門檻，設為 true 並停止再送出任何 1080p 升級請求
    // （SD→HD 的 upTarget==='hd' 請求不受影響，繼續正常處理）
    let resolution1080pUnavailable = false;
    let skipped1080pCount = 0;
    // 使用者未勾選「升級至 1080p」選項而被權威把關略過的數量（與帳號付費門檻略過分開計數）
    let skipped1080pUserGatedCount = 0;

    // 更新總數
    upgradeCurrentProgress.total = videosNeedUpgrade.length;

    for (let i = 0; i < videosNeedUpgrade.length; i++) {
        // 檢查是否被中斷
        if (upgradeAbortRequested) {
            console.log('⚠️ 升級被使用者中斷');
            upgradeInProgress = false;
            upgradeAbortRequested = false;
            chrome.runtime.sendMessage({ action: 'upgradeProgress', status: 'idle' });
            return {
                success: false,
                error: 'aborted',
                aborted: true,
                upgradedCount: successCount,
                failCount: failCount,
                total: videosNeedUpgrade.length,
                resolution1080pUnavailable,
                skipped1080pCount,
                skipped1080pUserGatedCount
            };
        }

        const video = videosNeedUpgrade[i];

        // 更新進度追蹤
        upgradeCurrentProgress = {
            current: i + 1,
            total: videosNeedUpgrade.length,
            success: successCount,
            fail: failCount
        };

        // 通知進度
        chrome.runtime.sendMessage({
            action: 'upgradeProgress',
            status: 'upgrading',
            current: i + 1,
            total: videosNeedUpgrade.length,
            success: successCount,
            fail: failCount
        });

        const upTarget = GrokUtils.classifyVideoQuality(video).upgradeTarget; // 'hd' | '1080p'

        // 權威把關：使用者未勾選「升級至 1080p」選項 → 即使快取或內部重掃仍含 1080p
        // 目標視頻，也一律跳過，絕不送出 1080p 升級請求（SD→HD 請求不受影響）
        if (upTarget === '1080p' && !include1080p) {
            skipped1080pUserGatedCount++;
            console.log(`[${i + 1}/${videosNeedUpgrade.length}] ⏭️ 跳過 1080p 升級（未啟用「升級至 1080p」選項）: ${video.id}`);
            continue;
        }

        // 帳號已確認無 1080p 權限 → 不再送出任何 1080p 請求，直接跳過
        // （SD→HD 的 upTarget==='hd' 請求完全不受影響，繼續正常處理）
        if (resolution1080pUnavailable && upTarget === '1080p') {
            skipped1080pCount++;
            console.log(`[${i + 1}/${videosNeedUpgrade.length}] ⏭️ 跳過 1080p 升級（帳號無 1080p 權限）: ${video.id}`);
            continue;
        }

        const targetResolution = GrokUtils.UPSCALE_TARGET[upTarget];

        console.log(`[${i + 1}/${videosNeedUpgrade.length}] 升級視頻 ID: ${video.id} →${upTarget}`);

        try {
            const response = await fetch(API_UPSCALE_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ videoId: video.id, targetResolution })
            });

            // Issue #7 diagnostics: the upscale endpoint is asynchronous on Grok's
            // side, so HTTP 200 only means "request accepted", not "upgrade done".
            // Log every response body so exported logs show what the server actually
            // said per video — needed to confirm/refute job-supersede behavior.
            const responseBody = await readUpscaleResponseBody(response);
            const httpStatus = response.status || (response.ok ? 200 : 0);
            const logDetail = `${video.id} → ${upTarget} - HTTP ${httpStatus} - ${responseBody || '<empty body>'}`;

            if (response.ok) {
                console.log(`  ✓ 升級請求成功: ${video.id}`);
                successCount++;
                await SystemLogger.info('Upscale response [#7]', logDetail);
            } else if (response.status === 429) {
                console.warn(`  ⚠️ Rate limited (429): ${video.id} — 額外等待 5s`);
                failCount++;
                await SystemLogger.warn('Upscale response [#7]', logDetail);
                await new Promise(resolve => setTimeout(resolve, 5000));
            } else if (upTarget === '1080p' && is1080pPaidGateError(response, responseBody)) {
                console.warn(`  🔒 1080p 升級需要付費方案（帳號層級限制），停止後續 1080p 請求: ${video.id}`);
                resolution1080pUnavailable = true;
                skipped1080pCount++;
                await SystemLogger.warn('Upscale response [#7]', `${logDetail} - 1080p paid gate`);
            } else {
                console.error(`  ✗ 升級請求失敗: ${video.id} - HTTP ${response.status}`);
                failCount++;
                await SystemLogger.fail('Upscale response [#7]', logDetail);
            }
        } catch (error) {
            console.error(`  ✗ 請求錯誤: ${video.id} - ${error.message}`);
            failCount++;
            await SystemLogger.fail('Upscale response [#7]', `${video.id} → ${upTarget} - network error - ${error.message}`);
        }

        // 延遲 2 秒，避免過於頻繁
        await new Promise(resolve => setTimeout(resolve, 2000));
    }

    // 完成，重置狀態
    upgradeInProgress = false;
    chrome.runtime.sendMessage({ action: 'upgradeProgress', status: 'idle' });

    await SystemLogger.info('HD upgrade completed', `Success: ${successCount}, Failed: ${failCount}, Total: ${videosNeedUpgrade.length}`);

    // 重新整理頁面以更新 HD 狀態
    if (successCount > 0) {
        console.log('刷新頁面以更新 HD 狀態...');
        setTimeout(() => {
            window.location.href = 'https://grok.com/imagine/saved';
        }, 1500);
    }

    return {
        success: true,
        upgradedCount: successCount,
        failCount: failCount,
        total: videosNeedUpgrade.length,
        scanPartial,
        resolution1080pUnavailable,
        skipped1080pCount,
        skipped1080pUserGatedCount
    };
}

// 掃描視頻 HD 升級狀態（不執行升級）— source-aware: 'favorite'（收藏，預設）
// 或 'allmedia'（完整生成媒體庫 /rest/assets）。升級執行迴圈（upgradeFavoritesToHD）
// 對來源無感知 — 只消費這裡產出的 { id, hdUrl/hd1080Url/resolutionName, createTime } 列表。
async function scanVideosForUpgrade(options = {}) {
    console.log('='.repeat(60));
    console.log('🔍 掃描視頻 HD 升級狀態');
    console.log('='.repeat(60));
    console.log('');

    const source = options.source === 'allmedia' ? 'allmedia' : 'favorite';

    let allVideos = [];
    let scanError = null;
    // Count of videos whose quality could never be resolved (429 storm exhausted
    // retries + the recovery pass) — allmedia-only; stays 0 for 'favorite' (quality
    // is inline on the post, no resolve step). See Review Finding 2.
    let resolveFailedCount = 0;
    // How many tiers came from the sticky highest-quality store rather than from
    // THIS scan (the fresh read was lower, or null). Additive telemetry only.
    let stickyResolvedCount = 0;

    if (source === 'favorite') {
        const API_LIST_URL = 'https://grok.com/rest/media/post/list';
        let cursor = null;

        try {
            while (true) {
                const payload = {
                    limit: 40,
                    filter: GrokUtils.buildLikedFilter()
                };

                if (cursor) {
                    payload.cursor = cursor;
                }

                const response = await fetch(API_LIST_URL, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });

                if (!response.ok) {
                    scanError = new Error(`HTTP ${response.status}`);
                    console.error(`❌ 掃描中斷（HTTP ${response.status}），保留部分結果 (${allVideos.length} 個視頻)`);
                    await SystemLogger.warn(
                        'HD upgrade scan partial',
                        `HTTP ${response.status} — stopping with partial results (${allVideos.length} videos scanned so far)`
                    );
                    break;
                }

                const data = await response.json();
                const posts = data.posts || [];

                if (posts.length === 0) break;

                const flattened = GrokUtils.flattenPosts(posts);
                const videos = flattened.filter(p => p.mediaType === 'MEDIA_POST_TYPE_VIDEO');

                allVideos.push(...videos);

                console.log(`  ✓ 掃描中... 已找到 ${allVideos.length} 個視頻`);

                if (!data.nextCursor) break;
                cursor = data.nextCursor;

                await new Promise(resolve => setTimeout(resolve, 300));
            }
        } catch (error) {
            console.error('❌ 掃描失敗:', error);
            return { success: false, error: error.message };
        }
    } else {
        // source === 'allmedia': whole generated library via /rest/assets. Assets
        // carry no inline quality (mapAssetToDownloadData starts hd/1080p fields
        // at null) — resolveVideoQuality must run per-video before classification
        // can tell tiers apart, otherwise every asset looks SD.
        //
        // This whole-library scan+resolve can take minutes (paging + one request
        // per video) and runs BEFORE the popup's confirm() dialog — without this,
        // the existing cancelUpgrade/upgradeInProgress wiring is dead for this
        // path (Review Finding 3). Own upgradeInProgress for the duration ONLY if
        // it isn't already owned by an outer upgradeFavoritesToHD call (its
        // no-cache rescan fallback calls this function while upgradeInProgress is
        // already true) — otherwise we'd clear it out from under the subsequent
        // real upgrade loop and break ITS cancel button.
        const ownsUpgradeInProgress = !upgradeInProgress;
        if (ownsUpgradeInProgress) {
            upgradeInProgress = true;
            upgradeAbortRequested = false;
        }

        try {
            const fromDate = options.hoursLimit
                ? Date.now() - options.hoursLimit * 3600 * 1000
                : (options.fromDate ?? null);
            const toDate = options.toDate ?? null;

            let res;
            try {
                res = await GrokAssets.listAllGeneratedAssets(fetch, {
                    modelGeneratedOnly: true,
                    fromDate,
                    toDate,
                    signalAborted: () => upgradeAbortRequested,
                    onProgress: (p) => chrome.runtime.sendMessage({
                        action: 'upgradeProgress',
                        status: 'scanning',
                        count: p.assetCount
                    }).catch(() => {})
                });
            } catch (error) {
                // listAllGeneratedAssets is designed to never throw (it backs off and
                // returns partial results on error) — this catch is defensive only.
                console.error('❌ 全部生成媒體掃描失敗:', error);
                return { success: false, error: error.message };
            }

            const videoItems = res.assets
                .map(a => ContentUtils.mapAssetToDownloadData(a, {}))
                .filter(i => i.type === 'video');

            // Resolve EVERY video's current quality — no history-based skip (the
            // {has:()=>false} hist below) because an upgrade scan must classify each
            // video's CURRENT tier, not just ones never downloaded before.
            await resolveVideoQualitiesWithProgress(videoItems, { has: () => false }, true, {
                resolveImpl: (id, hd) => GrokAssets.resolveVideoQuality(fetch, id, hd),
                mapImpl: GrokUtils.mapWithConcurrency,
                isAborted: () => upgradeAbortRequested,
                sticky: await getQualityStickyStore(),
                onProgress: (current, total) => chrome.runtime.sendMessage({
                    action: 'upgradeProgress',
                    status: 'resolving',
                    current,
                    total
                }).catch(() => {})
            });

            // A video whose quality never resolved (429 storm exhausted retries +
            // the recovery pass) has an UNKNOWN tier — never put it on the upgrade
            // work list. classifyVideoQuality would read its still-null hd fields
            // as 'sd' and fire a wrong-direction SD->HD upscale at a video that may
            // already be HD/1080p (Review Finding 2). Only resolved videos are
            // classified/eligible below; the rest are surfaced via
            // resolveFailedCount so the caller can tell the user.
            //
            // __qualityResolved requires a LIVE read this run, so a video carrying
            // ONLY sticky-store evidence (__qualityStickyOnly — e.g. the post now
            // 404s because it was deleted) also lands in resolveFailedCount rather
            // than being upscaled from remembered fields.
            const resolvedVideoItems = videoItems.filter(v => v.__qualityResolved === true);
            resolveFailedCount = videoItems.length - resolvedVideoItems.length;
            // How many tiers came from the sticky store rather than from THIS
            // scan (fresh read was lower, or null). Additive telemetry only.
            stickyResolvedCount = resolvedVideoItems.filter(v => v.__qualityFromSticky === true).length;
            allVideos = resolvedVideoItems;

            if (upgradeAbortRequested) {
                scanError = new Error('aborted');
            } else if (res.errors > 0) {
                scanError = new Error(`asset_scan_errors:${res.errors}`);
            } else if (resolveFailedCount > 0) {
                scanError = new Error(`${resolveFailedCount} video(s) could not be quality-resolved and were skipped`);
            }
        } finally {
            if (ownsUpgradeInProgress) {
                upgradeInProgress = false;
            }
        }
    }

    const native720p = allVideos.filter(v => v.resolutionName === '720p' && GrokUtils.classifyVideoQuality(v).tier !== '1080p').length;
    // alreadyHD is kept (backward compatible) but actually counts videos whose tier is
    // already '1080p' (upgradeTarget === null) — Task A2/B named it before the 1080p tier
    // existed. Task U3 exposes the accurate name (already1080p) plus a finer upgradeTarget
    // breakdown (needHdUpgrade / need1080Upgrade). These three describe the WHOLE library
    // via classifyVideoQuality and are never gated by include1080p — only the effective
    // work list below (videosNeedUpgrade / needUpgrade) respects that option.
    const needHdUpgrade = allVideos.filter(v => GrokUtils.classifyVideoQuality(v).upgradeTarget === 'hd').length;
    const need1080Upgrade = allVideos.filter(v => GrokUtils.classifyVideoQuality(v).upgradeTarget === '1080p').length;
    const alreadyHD = allVideos.length - needHdUpgrade - need1080Upgrade;
    const already1080p = alreadyHD;

    // 1080p upscale requires a SuperGrok Heavy account — explicit user opt-in (default
    // off). Gates the EFFECTIVE work list only; the informational counts above are not
    // affected. The time filter below applies on top of this same gated list.
    const include1080p = options.include1080p === true;
    const videosNeedUpgrade = allVideos.filter(v => {
        const t = GrokUtils.classifyVideoQuality(v).upgradeTarget;
        return t !== null && (include1080p || t !== '1080p');
    });

    console.log(`  📊 掃描完成 (${source}):`);
    console.log(`     總視頻數: ${allVideos.length}`);
    console.log(`     已是 1080p: ${already1080p}`);
    if (native720p > 0) {
        console.log(`     原生 720p: ${native720p}`);
    }
    console.log(`     需要升級: ${videosNeedUpgrade.length} (→HD: ${needHdUpgrade}, →1080p: ${need1080Upgrade})`);

    // Apply time filter if specified. Favorites apply it here as a POST-filter
    // (createTime only known after the scan). Allmedia already early-stopped the
    // scan itself at fromDate (see listAllGeneratedAssets' newest-first paging),
    // so its work list is already date-bounded and needs no further filtering.
    let needUpgradeFiltered = videosNeedUpgrade.length;
    if (source === 'favorite' && options.hoursLimit) {
        const cutoffTime = Date.now() - (options.hoursLimit * 60 * 60 * 1000);
        const timeFiltered = videosNeedUpgrade.filter(v => {
            if (!v.createTime) return false;
            return new Date(v.createTime).getTime() >= cutoffTime;
        });
        needUpgradeFiltered = timeFiltered.length;
        console.log(`     時間過濾 (${options.hoursLimit}h): ${needUpgradeFiltered}`);
    }

    // Cache scan results for upgradeFavoritesToHD to reuse. `source` lets the
    // rescan-fallback there refuse a stale cross-source cache (e.g. a favorite
    // scan sitting around when the user then requests an allmedia upgrade).
    upgradeScanCache = { videos: videosNeedUpgrade, source, timestamp: Date.now() };

    return {
        success: true,
        total: allVideos.length,
        alreadyHD: alreadyHD,
        already1080p: already1080p,
        native720p: native720p,
        needUpgrade: videosNeedUpgrade.length,
        needHdUpgrade: needHdUpgrade,
        need1080Upgrade: need1080Upgrade,
        needUpgradeFiltered: needUpgradeFiltered,
        hoursLimit: options.hoursLimit || null,
        partial: !!scanError,
        scanError: scanError ? scanError.message : null,
        resolveFailedCount,
        stickyResolvedCount,
        source
    };
}

// ==========================================
// Project 模式下載
// ==========================================

/**
 * 檢查單一專案是否有檔案需要下載
 * @param {Object} project - 專案物件
 * @param {Set} history - 下載歷史 Set
 * @param {Object} options - { hdPriority, includeImages, includeVideos, fromTimestamp, toTimestamp, hoursLimit }
 * @returns {boolean} 是否有檔案需要下載
 */
function projectHasFilesToDownload(project, history, options = {}) {
    const { hdPriority = true, includeImages = true, includeVideos = true } = options;
    const hoursCutoff = options.hoursLimit ? Date.now() - (options.hoursLimit * 60 * 60 * 1000) : null;

    const isInDateRange = (createTime) => {
        if (hoursCutoff) {
            if (!createTime) return true;
            return new Date(createTime).getTime() >= hoursCutoff;
        }
        if (!options.fromTimestamp && !options.toTimestamp) return true;
        if (!createTime) return true;
        const t = new Date(createTime).getTime();
        if (options.fromTimestamp && t < options.fromTimestamp) return false;
        if (options.toTimestamp && t > options.toTimestamp) return false;
        return true;
    };

    // 檢查 parent
    if (project.parent && project.parent.mediaUrl) {
        const parentId = project.parent.postId || project.parent.id;
        if (!history.has(parentId)) return true;
    }

    // 檢查 children
    const filteredChildren = (project.children || []).filter(child => isInDateRange(child.createTime));
    if ((options.fromTimestamp || options.toTimestamp) && filteredChildren.length === 0) return false;

    for (const child of filteredChildren) {
        const childId = child.postId || child.id;
        const isChildImage = child.mediaType === 'MEDIA_POST_TYPE_IMAGE';

        if (isChildImage && !includeImages) continue;
        if (!isChildImage && !includeVideos) continue;

        if (isChildImage) {
            if (child.mediaUrl && !history.has(childId)) return true;
        } else {
            if (hdPriority) {
                const hasHd = !!(child.hd1080MediaUrl || child.hdMediaUrl);
                const isNative720p = !hasHd && child.resolutionName === '720p';
                const quality = (hasHd || isNative720p) ? 'hd' : 'sd';
                const downloadUrl = child.hd1080MediaUrl || child.hdMediaUrl || child.mediaUrl;
                if (downloadUrl && !history.has(`${childId}_${quality}`)) return true;
            } else {
                const isNative720p = !(child.hd1080MediaUrl || child.hdMediaUrl) && child.resolutionName === '720p';
                if (isNative720p) {
                    if (child.mediaUrl && !history.has(`${childId}_hd`)) return true;
                } else {
                    if (child.mediaUrl && !history.has(`${childId}_sd`)) return true;
                    if ((child.hd1080MediaUrl || child.hdMediaUrl) && !history.has(`${childId}_hd`)) return true;
                }
            }
        }
    }

    return false;
}

/**
 * 計算需要下載的專案數量
 */
function countProjectsNeedDownload(projects, history, filterOptions) {
    const options = {
        hdPriority: filterOptions?.hdPriority !== false,
        includeImages: filterOptions?.includeImages !== false,
        includeVideos: filterOptions?.includeVideos !== false,
        fromTimestamp: filterOptions?.fromDate || null,
        toTimestamp: filterOptions?.toDate || null,
        hoursLimit: filterOptions?.hoursLimit || null
    };
    let count = 0;
    for (const project of projects) {
        if (projectHasFilesToDownload(project, history, options)) count++;
    }
    return count;
}

/**
 * 下載專案（Project 模式）
 * 每個專案包含：source image + generated videos + metadata.json
 */
async function downloadProjects() {
    const state = await loadState();

    if (!state || !state.projects || state.projects.length === 0) {
        console.log('⊘ 沒有專案需要下載');
        await finishAllDownloads();
        return;
    }

    const hist = await getEffectiveHistory(state);
    const history = { has: (key) => hist.has(key) }; // compat wrapper for inline history.has() calls
    const hdPriority = state.filterOptions?.hdPriority !== false;
    const includeImages = state.filterOptions?.includeImages !== false;
    const includeVideos = state.filterOptions?.includeVideos !== false;
    const filenameMode = state.filterOptions?.filenameMode
        || (state.filterOptions?.promptAsFilename === true ? 'prompt' : 'native');
    const promptAsFilename = filenameMode === 'prompt'; // kept for legacy compat
    const filenameTemplateImage = state.filterOptions?.filenameTemplateImage || '';
    const filenameTemplateVideo = state.filterOptions?.filenameTemplateVideo || '';
    const fromTimestamp = state.filterOptions?.fromDate || null;
    const toTimestamp = state.filterOptions?.toDate || null;
    const hoursLimit = state.filterOptions?.hoursLimit || null;
    const hoursCutoff = hoursLimit ? Date.now() - (hoursLimit * 60 * 60 * 1000) : null;

    // Helper: 檢查時間是否在範圍內
    const isInDateRange = (createTime) => {
        if (hoursCutoff) {
            if (!createTime) return true;
            return new Date(createTime).getTime() >= hoursCutoff;
        }
        if (!fromTimestamp && !toTimestamp) return true; // 沒有時間限制
        if (!createTime) return true; // 沒有時間資訊，預設通過
        const itemTimestamp = new Date(createTime).getTime();
        if (fromTimestamp && itemTimestamp < fromTimestamp) return false;
        if (toTimestamp && itemTimestamp > toTimestamp) return false;
        return true;
    };

    console.log('='.repeat(60));
    console.log('📂 開始批量下載專案');
    console.log('='.repeat(60));
    console.log(`HD 優先模式: ${hdPriority ? '✅ 開啟' : '❌ 關閉'}`);
    if (fromTimestamp || toTimestamp) {
        console.log(`📅 時間過濾: ${fromTimestamp ? new Date(fromTimestamp).toLocaleDateString() : '不限'} ~ ${toTimestamp ? new Date(toTimestamp).toLocaleDateString() : '不限'}`);
    }
    console.log(`總專案: ${state.projects.length} 個`);
    console.log('');

    await SystemLogger.info('Project download started', `Total: ${state.projects.length} projects, HD Priority: ${hdPriority}`);

    // 批量下載專案
    let successCount = 0;
    let failCount = 0;
    let videoDownloadCount = 0; // Track video downloads across projects for rate limit
    let fileDownloadCount = 0; // Track every file (source/image/video) for burst-boundary breather
    let rateLimitHit = false;
    const rawPaths = await GrokUtils.getDownloadPaths();
    const paths = getEffectivePaths(rawPaths, state);

    // 更新下載進度
    downloadCurrentProgress = { phase: 'projects', current: 0, total: state.projects.length, success: 0, fail: 0 };

    for (let i = 0; i < state.projects.length; i++) {
        // 檢查是否被中斷
        if (downloadAbortRequested) {
            console.log('⚠️ 下載被使用者中斷（專案階段）');
            // Save in-memory state before abort (downloadedProjects may not be persisted due to batched saves)
            await saveState(state);
            await handleDownloadAbort(successCount, failCount, 'projects');
            return;
        }

        const project = state.projects[i];
        // 更新進度
        downloadCurrentProgress = { phase: 'projects', current: i + 1, total: state.projects.length, success: successCount, fail: failCount };

        // 跳過已全部下載的專案（per-file history 檢查）
        if (!projectHasFilesToDownload(project, history, {
            hdPriority, includeImages, includeVideos,
            fromTimestamp, toTimestamp, hoursLimit
        })) {
            continue;
        }

        const paths = await GrokUtils.getDownloadPaths();
        const projectFolder = `${paths.projects}/${project.folderName}`;

        console.log(`[${i + 1}/${state.projects.length}] 📂 ${project.folderName}`);

        try {
            // Helper: 取得檔案名稱用的 prompt 後綴（僅在 promptAsFilename 開啟時使用）
            const getPromptSuffix = (item, maxLen = 60) => {
                if (!promptAsFilename) return '';
                const prompt = item.originalPrompt || item.prompt || '';
                // refs-only / flags-only prompts have no nameable part — omit the
                // suffix entirely rather than emitting '_untitled'.
                if (!GrokUtils.hasNameablePrompt(prompt, maxLen)) return '';
                return '_' + GrokUtils.sanitizePromptForFilename(prompt, maxLen, '');
            };

            // 過濾符合時間範圍的 children
            const filteredChildren = (project.children || []).filter(child =>
                isInDateRange(child.createTime)
            );

            // 如果有時間過濾且沒有符合條件的 children，跳過此專案
            if ((fromTimestamp || toTimestamp) && filteredChildren.length === 0) {
                console.log(`  ⏭️  無符合時間範圍的 children，跳過`);
                continue;
            }

            // 1. 下載 parent（source image）
            // 只在有符合條件的 children 時才下載 parent
            if (project.parent && project.parent.mediaUrl) {
                const parentId = project.parent.postId || project.parent.id;
                const parentExt = GrokUtils.getExtFromMediaUrl(project.parent.mediaUrl, 'png');
                const parentPromptSuffix = getPromptSuffix(project.parent, 80);
                // When promptAsFilename is off, include full parentId so user can navigate back to Grok
                const parentIdSuffix = promptAsFilename ? '' : `_${parentId}`;

                if (!history.has(parentId)) {
                    console.log(`  📷 下載來源圖片...`);
                    let sourceFilename;
                    if (filenameMode === 'custom') {
                        const applied = GrokUtils.applyFilenameTemplate(filenameTemplateImage, {
                            createTime: project.parent.createTime, id: parentId,
                            prompt: project.parent.originalPrompt || project.parent.prompt, quality: ''
                        });
                        sourceFilename = `${projectFolder}/${applied}.${parentExt}`;
                    } else {
                        sourceFilename = `${projectFolder}/source${parentPromptSuffix}${parentIdSuffix}.${parentExt}`;
                    }
                    try {
                        await sendDownloadRequest(project.parent.mediaUrl, sourceFilename, false, hist.keyFor(parentId));
                        await hist.add(parentId);
                    } catch (parentErr) {
                        console.log(`  ⚠️ 來源圖片下載失敗 (${parentErr.message})，繼續下載 children...`);
                    }
                }
            }

            // 2. 下載 children（可能是 image edits 或 videos）
            // 檔名格式：[type]_[quality]_[prompt]_[postId後8碼].[ext]
            // 使用 postId 作為唯一標識，避免新增/刪除 children 時檔名變動
            if (filteredChildren.length > 0) {
                for (let j = 0; j < filteredChildren.length; j++) {
                    const child = filteredChildren[j];
                    const childId = child.postId || child.id;
                    const shortId = childId.slice(-8);
                    const isChildImage = child.mediaType === 'MEDIA_POST_TYPE_IMAGE';
                    const childPromptSuffix = getPromptSuffix(child, 60);

                    if (isChildImage && !includeImages) {
                        continue; // 使用者未選擇下載圖片，跳過
                    }
                    if (!isChildImage && !includeVideos) {
                        continue; // 使用者未選擇下載影片，跳過
                    }

                    // Use full childId when promptAsFilename is off (for Grok navigation), shortId when on (prompt is already descriptive)
                    const fileId = promptAsFilename ? shortId : childId;

                    if (isChildImage) {
                        // 處理 image edit children
                        const imgExt = GrokUtils.getExtFromMediaUrl(child.mediaUrl, 'jpg');

                        if (child.mediaUrl && !history.has(childId)) {
                            console.log(`  🖼️  下載衍生圖片 ${shortId}...`);
                            let childImgFilename;
                            if (filenameMode === 'custom') {
                                const applied = GrokUtils.applyFilenameTemplate(filenameTemplateImage, {
                                    createTime: child.createTime, id: childId,
                                    prompt: child.originalPrompt || child.prompt, quality: ''
                                });
                                childImgFilename = `${projectFolder}/${applied}.${imgExt}`;
                            } else {
                                childImgFilename = `${projectFolder}/image${childPromptSuffix}_${fileId}.${imgExt}`;
                            }
                            await sendDownloadRequest(child.mediaUrl, childImgFilename, false, hist.keyFor(childId));
                            await hist.add(childId);
                        }
                    } else {
                        // 處理 video children
                        const buildChildVideoFilename = (quality) => {
                            if (filenameMode === 'custom') {
                                const applied = GrokUtils.applyFilenameTemplate(filenameTemplateVideo, {
                                    createTime: child.createTime, id: childId,
                                    prompt: child.originalPrompt || child.prompt, quality
                                });
                                return `${projectFolder}/${applied}.mp4`;
                            }
                            return `${projectFolder}/video_${quality}${childPromptSuffix}_${fileId}.mp4`;
                        };

                        if (hdPriority) {
                            // HD 優先模式：只下載一個版本（優先 1080p > HD(720p)）
                            const hasHd = !!(child.hd1080MediaUrl || child.hdMediaUrl);
                            const isNative720p = !hasHd && child.resolutionName === '720p';
                            const downloadUrl = child.hd1080MediaUrl || child.hdMediaUrl || child.mediaUrl;
                            const quality = (hasHd || isNative720p) ? 'hd' : 'sd';
                            const historyKey = `${childId}_${quality}`;

                            if (downloadUrl && !history.has(historyKey)) {
                                console.log(`  🎬 下載視頻 ${shortId} (${quality.toUpperCase()})...`);
                                await sendDownloadRequest(downloadUrl, buildChildVideoFilename(quality), false, hist.keyFor(historyKey));
                                await hist.add(historyKey);
                                videoDownloadCount++;
                            }
                        } else {
                            // 非 HD 優先模式：下載兩個版本（SD + HD）
                            const isChildNative720p = !(child.hd1080MediaUrl || child.hdMediaUrl) && child.resolutionName === '720p';

                            if (isChildNative720p) {
                                // 原生 720p：只有一個版本，以 HD 品質下載
                                if (child.mediaUrl && !history.has(`${childId}_hd`)) {
                                    console.log(`  🎬 下載視頻 ${shortId} (720p 原生 HD)...`);
                                    await sendDownloadRequest(child.mediaUrl, buildChildVideoFilename('hd'), false, hist.keyFor(`${childId}_hd`));
                                    await hist.add(`${childId}_hd`);
                                    videoDownloadCount++;
                                }
                            } else {
                                // 下載 SD 版本
                                if (child.mediaUrl && !history.has(`${childId}_sd`)) {
                                    console.log(`  🎬 下載視頻 ${shortId} (SD)...`);
                                    await sendDownloadRequest(child.mediaUrl, buildChildVideoFilename('sd'), false, hist.keyFor(`${childId}_sd`));
                                    await hist.add(`${childId}_sd`);
                                    videoDownloadCount++;
                                }

                                // 下載 HD 版本（如果有；優先 1080p）
                                const childHdUrl = child.hd1080MediaUrl || child.hdMediaUrl;
                                if (childHdUrl && !history.has(`${childId}_hd`)) {
                                    console.log(`  🎬 下載視頻 ${shortId} (HD)...`);
                                    await sendDownloadRequest(childHdUrl, buildChildVideoFilename('hd'), false, hist.keyFor(`${childId}_hd`));
                                    await hist.add(`${childId}_hd`);
                                    videoDownloadCount++;
                                }
                            }
                        }
                    }

                    await new Promise(resolve => setTimeout(resolve, 300));

                    // Burst-boundary breather: let Safe Browsing flush internal state
                    fileDownloadCount++;
                    if (fileDownloadCount % BURST_PAUSE_EVERY === 0) {
                        await new Promise(resolve => setTimeout(resolve, BURST_PAUSE_MS));
                    }

                    // Check rate limit after each video download
                    if (videoDownloadCount > 0 && videoDownloadCount % VIDEO_DOWNLOAD_RATE_LIMIT === 0) {
                        state.currentIndex = i;
                        await saveState(state);
                        await hist.flush();
                        const cooldownResult = await handleRateLimitPause(videoDownloadCount, failCount, 'projects');
                        if (cooldownResult === 'aborted') {
                            rateLimitHit = true;
                            break;
                        }
                        // cooldownResult === 'resume' → continue children loop
                    }
                }
            }

            // If abort was requested during cooldown, break project loop
            if (rateLimitHit) {
                await handleDownloadAbort(videoDownloadCount, failCount, 'projects');
                return;
            }

            // 3. 下載 metadata.json
            // 使用 parent.id + 過濾後的 children 數量作為 key
            const parentId = project.parent?.postId || project.parent?.id || project.folderName;
            const childrenCount = filteredChildren.length;
            const metadataKey = `project_${parentId}_c${childrenCount}`;

            if (!history.has(metadataKey)) {
                const metadata = GrokUtils.generateProjectMetadata(project);
                const metadataUrl = GrokUtils.generateJsonDataUrl(metadata);
                await sendDownloadRequest(metadataUrl, `${projectFolder}/metadata.json`, true, hist.keyFor(metadataKey));
                await hist.add(metadataKey);
            }

            // 記錄已下載的專案
            if (!state.downloadedProjects) state.downloadedProjects = [];
            if (!state.downloadedProjects.includes(project.folderName)) {
                state.downloadedProjects.push(project.folderName);
            }

            console.log('  ✓ 專案下載成功');
            successCount++;
            await SystemLogger.ok('Project downloaded', `[${i + 1}/${state.projects.length}] ${project.folderName}`);

            // 每 10 個項目或最後一個才寫入狀態和歷史
            state.currentIndex = i;
            if ((i + 1) % 10 === 0 || i === state.projects.length - 1) {
                await saveState(state);
                await hist.flush();
            }

            // 延遲以避免過快請求
            await new Promise(resolve => setTimeout(resolve, 500));

        } catch (error) {
            console.log('  ✗ 專案下載失敗:', error.message);
            state.failed.push({
                id: project.folderName,
                type: 'project',
                error: error.message
            });
            failCount++;
            await SystemLogger.fail('Project download failed', `${project.folderName} - ${error.message}`);
            // 錯誤時也按批次保存
            if ((i + 1) % 10 === 0 || i === state.projects.length - 1) {
                await saveState(state);
                await hist.flush();
            }
        }
    }

    console.log('');
    console.log('📊 專案下載完成');
    console.log(`  成功: ${successCount}/${state.projects.length}`);
    console.log(`  失敗: ${failCount}/${state.projects.length}`);
    console.log('');

    await SystemLogger.info('Project download completed', `Success: ${successCount}, Failed: ${failCount}`);

    await finishAllDownloads();
}

// 完成所有下載
// 處理下載中斷
async function handleDownloadAbort(successCount, failCount, phase) {
    // 中斷時確保歷史快取寫入 storage
    await flushHistory();
    await flushTagHistory();
    await flushConversationHistory(); // allmedia namespace too (was missing: abort could re-download up to 9 items)

    downloadInProgress = false;
    downloadAbortRequested = false;
    downloadCurrentProgress = { phase: 'idle', current: 0, total: 0, success: 0, fail: 0 };

    const state = await loadState();
    if (state) {
        state.completed = false;
        state.aborted = true;
        state.abortedAt = Date.now();
        await saveState(state);
    }

    console.log('');
    console.log('='.repeat(60));
    console.log('⚠️ 下載已中斷');
    console.log('='.repeat(60));
    console.log(`階段: ${phase}`);
    console.log(`成功: ${successCount}`);
    console.log(`失敗: ${failCount}`);
    console.log('');

    await SystemLogger.warn('Download cancelled by user', `Phase: ${phase}, Success: ${successCount}, Failed: ${failCount}`);

    // 通知 popup
    chrome.runtime.sendMessage({
        action: 'downloadProgress',
        status: 'aborted',
        phase: phase,
        success: successCount,
        fail: failCount
    });
}

async function handleRateLimitPause(successCount, failCount, phase) {
    // Rate limit pause: save progress and wait for cooldown before auto-resuming
    await flushHistory();
    await flushTagHistory();
    await flushConversationHistory(); // allmedia namespace too (was missing: abort could re-download up to 9 items)

    const state = await loadState();
    if (state) {
        state.completed = false;
        state.rateLimitPaused = true;
        state.rateLimitPausedAt = Date.now();
        await saveState(state);
    }

    // Read user-configured cooldown (default 3 minutes)
    const settings = await chrome.storage.sync.get(['rateLimitCooldown']);
    const cooldownMinutes = settings.rateLimitCooldown || 3;
    const cooldownSeconds = cooldownMinutes * 60;

    console.log('');
    console.log('='.repeat(60));
    console.log(`⏸️ Rate limit pause: ${successCount} videos downloaded`);
    console.log(`⏳ Auto-resume in ${cooldownMinutes} min...`);
    console.log('='.repeat(60));

    await SystemLogger.warn('Rate limit cooldown', `Phase: ${phase}, Downloaded: ${successCount}, Cooldown: ${cooldownMinutes}min`);

    // Countdown loop — notify popup every second, check abort flag
    for (let remaining = cooldownSeconds; remaining > 0; remaining--) {
        if (downloadAbortRequested) {
            console.log('⛔ Cooldown aborted by user');
            return 'aborted';
        }

        const mins = Math.floor(remaining / 60);
        const secs = remaining % 60;
        const timeStr = mins > 0 ? `${mins}:${String(secs).padStart(2, '0')}` : `${secs}s`;

        downloadCurrentProgress = {
            phase: 'cooldown',
            current: cooldownSeconds - remaining,
            total: cooldownSeconds,
            success: successCount,
            fail: failCount,
            cooldownRemaining: timeStr
        };

        // Notify popup with countdown
        chrome.runtime.sendMessage({
            action: 'downloadProgress',
            status: 'rateLimitCooldown',
            phase: phase,
            success: successCount,
            fail: failCount,
            limit: VIDEO_DOWNLOAD_RATE_LIMIT,
            cooldownRemaining: timeStr,
            cooldownTotal: cooldownMinutes
        });

        await new Promise(resolve => setTimeout(resolve, 1000));
    }

    // Final abort check after cooldown finishes
    if (downloadAbortRequested) {
        console.log('⛔ Cooldown finished but abort was requested');
        return 'aborted';
    }

    console.log('▶️ Cooldown finished, resuming download...');
    await SystemLogger.info('Rate limit cooldown finished', `Resuming ${phase} download`);

    // Clear rate limit flag
    const stateAfter = await loadState();
    if (stateAfter) {
        stateAfter.rateLimitPaused = false;
        await saveState(stateAfter);
    }

    return 'resume';
}

async function finishAllDownloads() {
    // 確保歷史快取寫入 storage
    await flushHistory();
    await flushTagHistory();
    await flushConversationHistory(); // allmedia namespace too (was missing: abort could re-download up to 9 items)

    // 重置下載狀態
    downloadInProgress = false;
    downloadAbortRequested = false;
    downloadCurrentProgress = { phase: 'idle', current: 0, total: 0, success: 0, fail: 0 };

    const state = await loadState();

    if (!state) {
        return;
    }

    console.log('');
    console.log('='.repeat(60));
    console.log('🎉 所有下載已完成！');
    console.log('='.repeat(60));
    console.log('');

    const duration = ((Date.now() - state.startTime) / 1000 / 60).toFixed(1);

    const totalItems = (state.images?.length || 0) + (state.videos?.length || 0);
    const totalDownloaded = (state.downloadedImages?.length || 0) + (state.downloadedVideos?.length || 0);

    console.log(`✓ 成功: ${totalDownloaded}/${totalItems}`);
    if (state.images?.length > 0) {
        console.log(`  🖼️  圖片: ${state.downloadedImages?.length || 0}/${state.images.length}`);
    }
    if (state.videos?.length > 0) {
        console.log(`  🎬 視頻: ${state.downloadedVideos?.length || 0}/${state.videos.length}`);
    }
    console.log(`✗ 失敗: ${state.failed.length}/${totalItems}`);
    console.log(`⏱️  耗時: ${duration} 分鐘`);
    console.log('');

    if (state.failed.length > 0) {
        console.log('失敗的項目:');
        state.failed.forEach(item => {
            const typeIcon = item.type === 'image' ? '🖼️' : '🎬';
            console.log(`  ${typeIcon} ${item.id}: ${item.error}`);
        });
        console.log('');
    }

    // 標記為完成
    state.completed = true;
    state.completedAt = Date.now();
    await saveState(state);

    await SystemLogger.info('Download completed', `Success: ${totalDownloaded}, Failed: ${state.failed.length}, Duration: ${duration} min`);

    console.log('下載完成，狀態保留直到使用者手動清除');
}

// 跳到下一個視頻

async function showStatus() {
    const state = await loadState();

    if (!state) {
        console.log('❌ 沒有進行中的任務');
        return state;
    }

    console.log('');
    console.log('='.repeat(60));
    console.log('📊 當前狀態');
    console.log('='.repeat(60));
    console.log('');
    console.log(`總視頻數: ${state.videos?.length || 0}`);
    console.log(`當前進度: ${(state.currentIndex || 0) + 1}/${state.videos?.length || 0}`);
    console.log(`已處理: ${state.downloaded?.length || 0}`);
    console.log(`失敗: ${state.failed?.length || 0}`);
    console.log('');

    return state;
}

// 匯出數據
async function exportData() {
    const state = await loadState();
    const history = await getDownloadHistory();
    // Batch D (Task D5): export all 3 independent history namespaces
    // (default/favorite, tag, conversation) so import can restore each intact.
    const tagHistory = await getTagDownloadHistory();
    const conversationHistory = await getConversationDownloadHistory();

    const exportData = {
        version: '1.1.0',
        exportTime: Date.now(),
        exportDate: new Date().toISOString(),
        history: history,
        tagHistory: tagHistory,
        conversationHistory: conversationHistory,
        currentState: state,
        statistics: {
            totalImages: state?.images?.length || 0,
            totalVideos: state?.videos?.length || 0,
            downloadedImages: state?.images?.filter(img => img.downloaded).length || 0,
            downloadedVideos: state?.videos?.filter(vid => vid.downloaded).length || 0,
            historyCount: history.length,
            tagHistoryCount: tagHistory.length,
            conversationHistoryCount: conversationHistory.length
        }
    };

    await SystemLogger.info('Data exported', `History: ${history.length}, Tag: ${tagHistory.length}, Conversation: ${conversationHistory.length}`);

    return exportData;
}

// 匯入數據
async function importData(data) {
    try {
        // Staged import: large files are written to storage by the popup to
        // avoid the 64MiB tabs.sendMessage limit. Read them back here and clear
        // the staging key regardless of merge outcome.
        if (!data) {
            const staged = await chrome.storage.local.get(IMPORT_STAGING_KEY);
            data = staged[IMPORT_STAGING_KEY];
            await chrome.storage.local.remove(IMPORT_STAGING_KEY);
        }

        // 驗證數據格式
        if (!data || !data.version || !data.history) {
            throw new Error('無效的數據格式');
        }

        // 合併歷史記錄（去重）
        const currentHistory = await getDownloadHistory();
        const mergedHistory = [...new Set([...currentHistory, ...data.history])];
        await chrome.storage.local.set({ [HISTORY_KEY]: mergedHistory });
        // 重建快取以反映合併後的歷史
        historyCache = new Set(mergedHistory);

        // 合併 Tag / Conversation 歷史記錄（去重）— Task D5。舊格式匯出檔案沒有
        // 這兩個欄位，用 Array.isArray 判斷是否存在以維持向後相容（不觸碰對應的
        // storage key，也不會清空既有的 tag/conversation 歷史）。
        let tagHistoryBefore = 0, tagHistoryAfter = 0;
        if (Array.isArray(data.tagHistory)) {
            const currentTagHistory = await getTagDownloadHistory();
            tagHistoryBefore = currentTagHistory.length;
            const mergedTagHistory = [...new Set([...currentTagHistory, ...data.tagHistory])];
            await chrome.storage.local.set({ [TAG_HISTORY_KEY]: mergedTagHistory });
            tagHistoryCache = new Set(mergedTagHistory);
            tagHistoryAfter = mergedTagHistory.length;
        }

        let conversationHistoryBefore = 0, conversationHistoryAfter = 0;
        if (Array.isArray(data.conversationHistory)) {
            const currentConversationHistory = await getConversationDownloadHistory();
            conversationHistoryBefore = currentConversationHistory.length;
            const mergedConversationHistory = [...new Set([...currentConversationHistory, ...data.conversationHistory])];
            await chrome.storage.local.set({ [CONVERSATION_HISTORY_KEY]: mergedConversationHistory });
            conversationHistoryCache = new Set(mergedConversationHistory);
            conversationHistoryAfter = mergedConversationHistory.length;
        }

        // 如果有當前狀態，合併匯入（絕不覆蓋現有進度）；先備份現有狀態
        if (data.currentState) {
            const existing = await loadState();
            if (existing) {
                await chrome.storage.local.set({
                    grok_video_downloader_backup: { savedAt: Date.now(), state: existing }
                });
            }
            await saveState(ContentUtils.mergeDownloadStates(existing, data.currentState));
        }

        console.log('✅ 數據匯入成功');
        console.log(`  歷史記錄: ${currentHistory.length} → ${mergedHistory.length}`);

        const newItems = mergedHistory.length - currentHistory.length;
        await SystemLogger.ok('Data imported', `History: ${currentHistory.length} → ${mergedHistory.length} (+${newItems}); Tag: ${tagHistoryBefore} → ${tagHistoryAfter}; Conversation: ${conversationHistoryBefore} → ${conversationHistoryAfter}`);

        return {
            success: true,
            merged: {
                historyBefore: currentHistory.length,
                historyAfter: mergedHistory.length,
                newItems: newItems,
                tagHistoryBefore,
                tagHistoryAfter,
                conversationHistoryBefore,
                conversationHistoryAfter
            }
        };
    } catch (error) {
        console.error('❌ 數據匯入失敗:', error);
        await SystemLogger.fail('Data import failed', error.message);
        return { success: false, error: error.message };
    }
}

// 批量移除收藏
async function removeFavorites(options = {}) {
    console.log('='.repeat(60));
    console.log('🗑️  批量移除收藏');
    console.log('='.repeat(60));
    console.log('');

    await SystemLogger.info('Remove favorites scan started', 'Scanning favorites...');

    const { removeAll = false, fromDate = null, toDate = null, hoursLimit = null } = options;

    const API_URL = 'https://grok.com/rest/media/post/list';
    const allPosts = [];
    let cursor = null;
    let scanError = null;

    // 1. 獲取所有收藏
    try {
        while (true) {
            const payload = {
                limit: 40,
                filter: GrokUtils.buildLikedFilter()
            };

            if (cursor) {
                payload.cursor = cursor;
            }

            const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                scanError = new Error(`HTTP ${response.status}`);
                console.error(`❌ 掃描中斷（HTTP ${response.status}），保留部分結果 (${allPosts.length} 個項目)`);
                await SystemLogger.warn(
                    'Remove favorites scan partial',
                    `HTTP ${response.status} — stopping with partial results (${allPosts.length} favorites scanned so far)`
                );
                break;
            }

            const data = await response.json();
            const posts = data.posts || [];

            if (posts.length === 0) break;

            allPosts.push(...posts);
            console.log(`  ✓ 已獲取 ${allPosts.length} 個項目`);

            if (!data.nextCursor) break;
            cursor = data.nextCursor;

            await new Promise(resolve => setTimeout(resolve, 300));
        }
    } catch (error) {
        console.error('❌ 獲取數據失敗:', error);
        return { success: false, error: error.message };
    }

    // 2. 過濾出要刪除的項目（根據日期範圍）
    let toRemove;
    if (removeAll) {
        // 移除全部
        toRemove = allPosts;
        console.log('📅 移除範圍: 全部');
    } else if (hoursLimit) {
        // 根據小時限制過濾
        const cutoffTime = Date.now() - (hoursLimit * 60 * 60 * 1000);
        toRemove = allPosts.filter(post => {
            if (!post.createTime) return false;
            return new Date(post.createTime).getTime() >= cutoffTime;
        });
        console.log(`🕐 移除範圍: 最近 ${hoursLimit} 小時`);
    } else {
        // 根據日期範圍過濾
        toRemove = allPosts.filter(post => {
            if (!post.createTime) return false;
            const itemTimestamp = new Date(post.createTime).getTime();

            // 檢查是否在日期範圍內
            if (fromDate && itemTimestamp < fromDate) return false;
            if (toDate && itemTimestamp > toDate) return false;

            return true;
        });

        const fromStr = fromDate ? new Date(fromDate).toLocaleDateString() : '∞';
        const toStr = toDate ? new Date(toDate).toLocaleDateString() : '∞';
        console.log(`📅 移除範圍: ${fromStr} ~ ${toStr}`);
    }

    console.log('');
    console.log(`📊 統計:`);
    console.log(`  總收藏數: ${allPosts.length}`);
    console.log(`  將移除: ${toRemove.length}`);
    console.log(`  保留: ${allPosts.length - toRemove.length}`);
    console.log('');

    if (toRemove.length === 0) {
        console.log('⊘ 沒有需要移除的收藏');
        return {
            success: true,
            toRemove: 0,
            total: allPosts.length,
            partial: !!scanError,
            scanError: scanError ? scanError.message : null
        };
    }

    // 3. 保存要移除的列表到狀態
    const removeState = {
        items: toRemove.map(item => ({
            id: item.id,
            type: item.mediaType === 'MEDIA_POST_TYPE_IMAGE' ? 'image' : 'video',
            createTime: item.createTime,
            detailUrl: `https://grok.com/imagine/post/${item.id}`
        })),
        currentIndex: 0,
        removed: [],
        failed: [],
        startTime: Date.now(),
        removeAll: removeAll,
        fromDate: fromDate,
        toDate: toDate,
        fromDateString: fromDate ? new Date(fromDate).toLocaleDateString() : null,
        toDateString: toDate ? new Date(toDate).toLocaleDateString() : null
    };

    await chrome.storage.local.set({ 'grok_remove_state': removeState });

    console.log('✅ 移除列表已生成');
    console.log('💡 請確認後開始移除操作');
    console.log('');

    await SystemLogger.ok('Remove favorites scan completed', `Found ${allPosts.length} favorites, ${toRemove.length} to remove`);

    return {
        success: true,
        toRemove: toRemove.length,
        total: allPosts.length,
        items: removeState.items,
        partial: !!scanError,
        scanError: scanError ? scanError.message : null
    };
}

// 開始移除收藏
async function startRemoveFavorites(deletePost = false) {
    const result = await chrome.storage.local.get('grok_remove_state');
    const state = result['grok_remove_state'];

    if (!state || !state.items || state.items.length === 0) {
        console.log('❌ 沒有移除列表');
        return { success: false, error: '沒有移除列表' };
    }

    // 保存選項
    state.deletePost = deletePost;

    console.log('='.repeat(60));
    console.log('🗑️  開始移除收藏 (API模式)');
    if (deletePost) {
        console.log('⚠️  同時刪除 POST');
    }
    console.log('='.repeat(60));
    console.log(`總數: ${state.items.length}`);
    console.log(`日期: ${state.beforeDateString} 之前`);
    console.log('');

    await SystemLogger.info('Remove favorites started', `Total: ${state.items.length}, Delete post: ${deletePost}`);

    // 重置進度
    state.currentIndex = 0;
    state.removed = [];
    state.failed = [];
    state.startTime = Date.now();
    await chrome.storage.local.set({ 'grok_remove_state': state });

    // 開始處理隊列 (不等待完成)
    processRemoveQueue();

    return { success: true };
}

// 處理移除隊列
async function processRemoveQueue() {
    const result = await chrome.storage.local.get('grok_remove_state');
    let state = result['grok_remove_state'];

    if (!state || !state.items || state.items.length === 0) {
        return;
    }

    const total = state.items.length;
    let successCount = 0;
    let failCount = 0;

    for (let i = state.currentIndex; i < total; i++) {
        const item = state.items[i];
        console.log(`[${i + 1}/${total}] 正在處理 ID: ${item.id}`);

        try {
            // 1. Unlike (取消收藏)
            const unlikeResp = await fetch('https://grok.com/rest/media/post/unlike', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: item.id })
            });

            if (unlikeResp.ok) {
                console.log('  ✓ 取消收藏成功');

                // 2. Delete Post (如果有勾選)
                if (state.deletePost) {
                    try {
                        const delResp = await fetch('https://grok.com/rest/media/post/delete', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ id: item.id })
                        });
                        if (delResp.ok) console.log('  ✓ Post 刪除成功');
                        else console.error('  ✗ Post 刪除失敗:', delResp.status);
                    } catch (e) {
                        console.error('  ✗ Post 刪除錯誤:', e);
                    }
                }

                state.removed.push(item.id);
                successCount++;
            } else {
                console.error(`  ✗ 取消收藏失敗: ${unlikeResp.status}`);
                state.failed.push(item.id);
                failCount++;
            }
        } catch (error) {
            console.error('  ✗ 請求錯誤:', error);
            state.failed.push(item.id);
            failCount++;
        }

        // 更新狀態
        state.currentIndex = i + 1;
        await chrome.storage.local.set({ 'grok_remove_state': state });

        // 發送進度更新給 popup
        chrome.runtime.sendMessage({
            action: 'removeProgress',
            current: i + 1,
            total: total,
            success: successCount,
            failed: failCount
        }).catch(() => {}); // 忽略錯誤（popup 可能已關閉）

        // 延遲以避免請求過於頻繁
        await new Promise(resolve => setTimeout(resolve, 500));
    }

    console.log('='.repeat(60));
    console.log('🎉 移除任務完成');
    console.log(`成功: ${successCount}, 失敗: ${failCount}`);
    console.log('='.repeat(60));

    await SystemLogger.info('Remove favorites completed', `Success: ${successCount}, Failed: ${failCount}`);

    // 發送完成消息
    chrome.runtime.sendMessage({
        action: 'removeComplete',
        success: successCount,
        failed: failCount,
        total: total
    }).catch(() => {});

    // 清除狀態
    await chrome.storage.local.remove('grok_remove_state');

    // 重新載入頁面以更新列表
    console.log('刷新頁面...');
    setTimeout(() => {
        window.location.reload();
    }, 1000);
}

// ==========================================
// Batch Add: Fetch Recent IMAGE Posts
// ==========================================
// fetchRecentImagePosts() extracted to src/recent-posts.js (GrokRecentPosts)
// so tests bind to the real production logic. See handler below.

// 暴露全局函數
window.grokDownloader = {
    generateMediaList,
    startAutoDownload,
    showStatus,
    clearState,
    exportData,
    importData,
    removeFavorites,
    startRemoveFavorites,
    // Exposed so tests can bind directly to the real implementation instead
    // of re-deriving the assignment/resolution rules as local test copies.
    assignConversationSubfolders,
    applyConversationPrompts,
    recoverConversationPrompts,
    generateMediaListFromTag,
    buildTagItemFromLegacyPost,
    resolveImageDownloadFilename,
    resolveVideoDownloadFilename,
    resolveVideoQualitiesWithProgress,
    getQualityStickyStore,
    clearQualityStickyStore,
    getPromptCache,
    clearPromptCache,
    backfillVideoPromptsFromSource,
    scanVideosForUpgrade
};

// 監聽來自 popup 的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // 定義此 listener 處理的 actions
    const handledActions = ['importSkipIds', 'clearSkipIds', 'getSkipIdsStatus', 
        'generateMedia', 'startDownload', 'getStatus', 'clearState', 'clearHistory',
        'getHistory', 'exportData', 'importData', 'removeFavorites', 'startRemoveFavorites',
        'getDownloadStatus', 'cancelDownload', 'getUpgradeStatus', 'cancelUpgrade',
        'scanFavoritesForUpgrade', 'upgradeFavoritesToHD', 'startStreamCapture', 'stopStreamCapture',
        'getCapturedImages', 'clearCapturedImages', 'enterBatchSelectMode', 'exitBatchSelectMode',
        'sendFrameToPage', 'captureVideo', 'findPageVideos', 'startVideoWatcher', 'stopVideoWatcher',
        'startQueue', 'pauseQueue', 'stopQueue', 'queueItemResult', 'queueResumeItem', 'queueProcessNext',
        'scanForDownload', 'fetchRecentImagePosts',
        'fetchTagList', 'clearTagHistory', 'clearConversationHistory', 'downloadInterrupted',
        'showStudioButtons', 'hideStudioButtons', 'checkStudioButtonsSupport',
        'processBatchUpload', 'checkVideoStatus'
    ];

    // triggerBatchUpload is type-keyed (legacy); handle before the action whitelist
    if (request.type === 'triggerBatchUpload') {
        console.log('[Content] Received triggerBatchUpload message, index:', request.batchIndex);
        batchUploadProcessed = false;
        setTimeout(runPendingChecks, 500);
        sendResponse({ success: true });
        return true;
    }

    // 如果不是此 listener 處理的 action，不返回 true，讓其他 listener 處理
    if (!handledActions.includes(request.action)) {
        return false;
    }

    (async () => {
        if (request.action === 'generateMedia') {
            // One generate at a time: the popup re-enables its button when its
            // watchdog fires, but this run may still be walking conversations.
            if (generateInProgress) {
                sendResponse({ success: false, error: 'generate_in_progress' });
                return;
            }
            generateInProgress = true;
            setGenerateProgress('starting', 0, null);
            // A previous Cancel (of a generate, or of a download that has since
            // finished) must not abort this fresh run. Never touch the flag
            // while a download is actually running — that would un-cancel it.
            if (!downloadInProgress) downloadAbortRequested = false;

            // 立即回應，避免消息通道超時
            sendResponse({ success: true, status: 'generating' });

            // 異步執行生成列表
            try {
                const result = await generateMediaList(request.options);
                const hdPriority = request.options?.hdPriority !== false;

                // 2026-10-24 patch: a Cancel during ANY generate phase (scan,
                // titles, prompts, resolving) used to fall through and report
                // success:true, partial:false — a watcher would then start a
                // download from a truncated list. Report it as cancelled.
                const cancelled = !!(downloadAbortRequested && !downloadInProgress) || !!(result && result.aborted);
                if (result && cancelled) {
                    await chrome.storage.local.set({
                        generateResult: {
                            success: false,
                            status: 'cancelled',
                            cancelled: true,
                            partial: true,
                            error: 'cancelled',
                            imageCount: result.images.length,
                            videoCount: result.videos.length,
                            scanError: result.scanError || null,
                            timestamp: Date.now()
                        }
                    });
                } else if (result) {
                    const videoCount = hdPriority
                        ? result.videos.length
                        : result.videos.reduce((acc, v) => acc + ((v.hd1080Url || v.hdUrl) ? 2 : 1), 0);

                    // 完成後存到 storage 通知 popup
                    await chrome.storage.local.set({
                        generateResult: {
                            success: true,
                            imageCount: result.images.length,
                            videoCount: videoCount,
                            partial: !!result.partial,
                            scanError: result.scanError || null,
                            timestamp: Date.now()
                        }
                    });
                } else {
                    await chrome.storage.local.set({
                        generateResult: {
                            success: false,
                            error: 'Generate failed',
                            timestamp: Date.now()
                        }
                    });
                }
            } catch (error) {
                console.error('generateMedia error:', error);
                await chrome.storage.local.set({
                    generateResult: {
                        success: false,
                        error: error.message,
                        timestamp: Date.now()
                    }
                });
            } finally {
                generateInProgress = false;
                if (generateProgress) generateProgress = { ...generateProgress, done: true, updatedAt: Date.now() };
            }
            return; // 已經 sendResponse 過了，直接返回
        } else if (request.action === 'startDownload') {
            const result = await startAutoDownload();
            sendResponse(result || { success: true });
        } else if (request.action === 'getStatus') {
            const state = await loadState();
            const statusHist = await getEffectiveHistory(state || {});
            const history = statusHist.toArray();

            let displayStats = null;
            if (state) {
                const historySet = { has: (key) => statusHist.has(key) };
                const displayImages = state.allImages || state.images || [];
                const displayVideos = state.allVideos || state.videos || [];
                const filteredImages = state.images || [];
                const filteredVideos = state.videos || [];
                const hdPriority = state.filterOptions?.hdPriority !== false;

                // Image stats
                const imageTotal = displayImages.length;
                const imageDownloaded = displayImages.filter(img => historySet.has(img.id)).length;

                // Video classification (HD includes 1080p for the "_hd" download slot —
                // downloads still land in one file. Task U3 additionally breaks out the
                // 1080p subset as its own headline count via GrokUtils.classifyVideoQuality,
                // so the popup can show how many videos are already at 1080p.)
                const sdVideos = displayVideos.filter(v => !(v.hd1080Url || v.hdUrl) && v.resolutionName !== '720p');
                const native720pVideos = displayVideos.filter(v => !(v.hd1080Url || v.hdUrl) && v.resolutionName === '720p');
                const hdVideos = displayVideos.filter(v => (v.hd1080Url || v.hdUrl));
                const video1080pVideos = displayVideos.filter(v => GrokUtils.classifyVideoQuality(v).tier === '1080p');
                const sdDownloaded = sdVideos.filter(v => historySet.has(`${v.id}_sd`) || historySet.has(v.id)).length;
                const v720pDownloaded = native720pVideos.filter(v => historySet.has(`${v.id}_hd`)).length;
                const hdDownloaded = hdVideos.filter(v => historySet.has(`${v.id}_hd`)).length;
                const video1080pDownloaded = video1080pVideos.filter(v => historySet.has(`${v.id}_hd`)).length;

                // Filtered need-download counts (matching actual download logic)
                const filteredImageNeed = ContentUtils.dropSkipped(filteredImages.filter(img => !historySet.has(img.id)), statusHist).length;
                const needDownloadVideos = ContentUtils.dropSkipped(GrokUtils.filterVideosForHdPriority(filteredVideos, history, hdPriority), statusHist);
                let filteredSdNeed, filtered720pNeed, filteredHdNeed;
                if (hdPriority) {
                    filteredHdNeed = needDownloadVideos.filter(v => (v.hd1080Url || v.hdUrl)).length;
                    filtered720pNeed = needDownloadVideos.filter(v => !(v.hd1080Url || v.hdUrl) && v.resolutionName === '720p').length;
                    filteredSdNeed = needDownloadVideos.length - filteredHdNeed - filtered720pNeed;
                } else {
                    filteredSdNeed = filteredVideos.filter(v => !(v.hd1080Url || v.hdUrl) && v.resolutionName !== '720p' && !historySet.has(`${v.id}_sd`) && !historySet.has(v.id)).length;
                    filtered720pNeed = filteredVideos.filter(v => !(v.hd1080Url || v.hdUrl) && v.resolutionName === '720p' && !historySet.has(`${v.id}_hd`)).length;
                    filteredHdNeed = filteredVideos.filter(v => (v.hd1080Url || v.hdUrl) && !historySet.has(`${v.id}_hd`)).length;
                }

                // Completed summary (downloaded counts)
                let doneImages = 0, doneSd = 0, done720p = 0, doneHd = 0;
                if (state.completed) {
                    doneImages = state.downloadedImages?.length || 0;
                    const doneVideoIds = new Set(state.downloadedVideos || []);
                    const doneVids = filteredVideos.filter(v => doneVideoIds.has(v.id));
                    if (hdPriority) {
                        doneHd = doneVids.filter(v => (v.hd1080Url || v.hdUrl)).length;
                        done720p = doneVids.filter(v => !(v.hd1080Url || v.hdUrl) && v.resolutionName === '720p').length;
                        doneSd = doneVids.length - doneHd - done720p;
                    } else {
                        doneSd = doneVids.length;
                    }
                }

                displayStats = {
                    imageTotal, imageDownloaded, imageNeed: imageTotal - imageDownloaded,
                    sdTotal: sdVideos.length, sdDownloaded, sdNeed: sdVideos.length - sdDownloaded,
                    v720pTotal: native720pVideos.length, v720pDownloaded, v720pNeed: native720pVideos.length - v720pDownloaded,
                    hdTotal: hdVideos.length, hdDownloaded, hdNeed: hdVideos.length - hdDownloaded,
                    v1080pTotal: video1080pVideos.length, v1080pDownloaded: video1080pDownloaded, v1080pNeed: video1080pVideos.length - video1080pDownloaded,
                    filteredImageNeed, filteredSdNeed, filtered720pNeed, filteredHdNeed,
                    filteredTotal: filteredImages.length + filteredVideos.length,
                    doneImages, doneSd, done720p, doneHd
                };
            }

            // Send lightweight state — strip large arrays to avoid Chrome message size limit
            const lightState = state ? {
                filterOptions: state.filterOptions,
                currentPhase: state.currentPhase,
                completed: state.completed,
                aborted: state.aborted,
                rateLimitPaused: state.rateLimitPaused,
                currentIndex: state.currentIndex,
                downloadedImages: state.downloadedImages,
                downloadedVideos: state.downloadedVideos,
                downloadedProjects: state.downloadedProjects,
                failed: state.failed,
                startTime: state.startTime,
                projectCount: state.projects?.length || state.projectCount || 0,
                hasImages: (state.images?.length || 0) > 0,
                hasVideos: (state.videos?.length || 0) > 0,
            } : null;

            const promptsProgress = generateProgress && generateProgress.phase === 'prompts'
                ? `prompts ${generateProgress.current}/${generateProgress.total}` : null;
            if (displayStats) {
                displayStats.generateProgress = generateProgress;
                displayStats.promptsProgress = promptsProgress;
            }
            sendResponse({
                state: lightState,
                displayStats,
                historyCount: history.length,
                downloadProgress: downloadInProgress ? downloadCurrentProgress : null,
                generateInProgress,
                generateProgress,
                promptsProgress
            });
        } else if (request.action === 'importSkipIds') {
            sendResponse(await importSkipIds(request.ids, { replace: request.replace === true }));
        } else if (request.action === 'clearSkipIds') {
            sendResponse(await clearSkipIds());
        } else if (request.action === 'getSkipIdsStatus') {
            sendResponse({ success: true, count: (await ensureSkipIdSet()).size });
        } else if (request.action === 'clearState') {
            await clearState();
            sendResponse({ success: true });
        } else if (request.action === 'clearHistory') {
            await clearHistory();
            sendResponse({ success: true });
        } else if (request.action === 'getHistory') {
            const history = await getDownloadHistory();
            sendResponse({ history, count: history.length });
        } else if (request.action === 'exportData') {
            // Export via Blob URL + DOM download to avoid 64MiB messaging limit
            const data = await exportData();
            const json = JSON.stringify(data, null, 2);
            const blob = new Blob([json], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            const date = new Date().toISOString().split('T')[0];
            a.download = `grok_media_export_${date}.json`;
            a.click();
            URL.revokeObjectURL(url);
            sendResponse({ success: true, historyCount: data.statistics.historyCount });
        } else if (request.action === 'importData') {
            const result = await importData(request.data);
            sendResponse(result);
        } else if (request.action === 'removeFavorites') {
            const result = await removeFavorites(request.options);
            sendResponse(result);
        } else if (request.action === 'startRemoveFavorites') {
            const result = await startRemoveFavorites(request.deletePost);
            sendResponse(result);
        } else if (request.action === 'getDownloadStatus') {
            sendResponse({
                inProgress: downloadInProgress,
                ...downloadCurrentProgress
            });
        } else if (request.action === 'cancelDownload') {
            // Also aborts a running generate: every generate phase (list scan,
            // prompt recovery, titles, quality resolution) polls this flag.
            if (downloadInProgress || generateInProgress) {
                downloadAbortRequested = true;
                console.log(generateInProgress && !downloadInProgress ? '⚠️ 收到取消生成請求' : '⚠️ 收到取消下載請求');
                sendResponse({ success: true, message: 'cancel_requested' });
            } else {
                sendResponse({ success: false, message: 'no_download_in_progress' });
            }
        } else if (request.action === 'getUpgradeStatus') {
            sendResponse({
                inProgress: upgradeInProgress,
                ...upgradeCurrentProgress
            });
        } else if (request.action === 'cancelUpgrade') {
            if (upgradeInProgress) {
                upgradeAbortRequested = true;
                console.log('⚠️ 收到取消升級請求');
                sendResponse({ success: true, message: 'cancel_requested' });
            } else {
                sendResponse({ success: false, message: 'no_upgrade_in_progress' });
            }
        } else if (request.action === 'scanFavoritesForUpgrade') {
            // Contract for the popup UI (both actions share it):
            //   popup -> { action: 'scanFavoritesForUpgrade' | 'upgradeFavoritesToHD',
            //              upgradeSource: 'favorite' | 'allmedia' (default 'favorite'),
            //              hoursLimit?, include1080p? }
            //   progress -> { action: 'upgradeProgress', status: 'scanning', count } and
            //               { action: 'upgradeProgress', status: 'resolving', current, total }
            //               (emitted by the allmedia scan path; favorite keeps its existing
            //               scanning/upgrading progress messages)
            const result = await scanVideosForUpgrade({ hoursLimit: request.hoursLimit, include1080p: request.include1080p, source: request.upgradeSource });
            sendResponse(result);
        } else if (request.action === 'upgradeFavoritesToHD') {
            const result = await upgradeFavoritesToHD({ hoursLimit: request.hoursLimit, include1080p: request.include1080p, source: request.upgradeSource });
            sendResponse(result);
        } else if (request.action === 'startStreamCapture') {
            startStreamCapture();
            sendResponse({ success: true });
        } else if (request.action === 'stopStreamCapture') {
            stopStreamCapture();
            sendResponse({ success: true });
        } else if (request.action === 'getCapturedImages') {
            // Count only: image data now lives in the background capture
            // queue (the old reply carried every base64 image and could blow
            // the ~64 MB message limit).
            sendResponse({
                success: true,
                count: streamCapturedCount,
                images: [],
                isCapturing: isCapturing
            });
        } else if (request.action === 'clearCapturedImages') {
            capturedImages = [];
            streamCapturedCount = 0;
            sendResponse({ success: true });
        }
        // Batch Select Delete handlers
        else if (request.action === 'enterBatchSelectMode') {
            const result = await enterBatchSelectMode();
            sendResponse(result);
        } else if (request.action === 'exitBatchSelectMode') {
            exitBatchSelectMode();
            sendResponse({ success: true });
        }
        // Video Studio handlers
        else if (request.action === 'sendFrameToPage') {
            // Download frame image for user to upload to Grok
            const result = await downloadFrameForUpload(request.dataUrl, request.filename);
            sendResponse(result);
        } else if (request.action === 'captureVideo') {
            // Capture video from page and store in IndexedDB
            const result = await captureVideoToStudio(request.videoUrl);
            sendResponse(result);
        } else if (request.action === 'findPageVideos') {
            // Find video elements on the page
            const videos = findPageVideos();
            sendResponse({
                success: true,
                videos: videos.map(v => ({
                    url: v.url,
                    width: v.width,
                    height: v.height,
                    duration: v.duration
                }))
            });
        } else if (request.action === 'startVideoWatcher') {
            startVideoWatcher();
            sendResponse({ success: true });
        } else if (request.action === 'stopVideoWatcher') {
            stopVideoWatcher();
            sendResponse({ success: true });
        }
        // ==========================================
        // Batch Add Recent Posts
        // ==========================================
        else if (request.action === 'fetchRecentImagePosts') {
            const result = await GrokRecentPosts.fetchRecentImagePosts(request.hoursLimit);
            sendResponse(result);
        }
        // ==========================================
        // Queue Processing Handlers
        // ==========================================
        else if (request.action === 'startQueue') {
            const result = await startQueueProcessing();
            sendResponse(result);
        } else if (request.action === 'pauseQueue') {
            pauseQueueProcessing();
            sendResponse({ success: true });
        } else if (request.action === 'stopQueue') {
            await stopQueueProcessing();
            sendResponse({ success: true });
        } else if (request.action === 'queueItemResult') {
            // Received from background.js after videoGenResult processing
            handleQueueItemResult(request);
            sendResponse({ success: true });
        } else if (request.action === 'queueResumeItem') {
            // Resume processing after error retry
            queueProcessingActive = true;
            await processQueueItem(request.queueItem, false);
            sendResponse({ success: true });
        } else if (request.action === 'queueProcessNext') {
            // Skip to next item after error skip
            if (request.nextItem) {
                await processQueueItem(request.nextItem, true);
            } else {
                queueProcessingActive = false;
                SystemLogger.info('Queue completed', 'All items processed');
                chrome.runtime.sendMessage({ action: 'queueProgressUpdate', allDone: true }).catch(() => {});
            }
            sendResponse({ success: true });
        } else if (request.action === 'scanForDownload') {
            const state = await loadState();
            const scanHist = await getEffectiveHistory(state);
            const hdPriority = state.filterOptions?.hdPriority !== false;
            const isProjectMode = state.filterOptions?.downloadMode === 'project';

            const totalImages = state.images?.length || 0;
            const needImages = ContentUtils.dropSkipped(state.images?.filter(img => !scanHist.has(img.id)) || [], scanHist).length;

            // Use the same logic as actual download: GrokUtils.filterVideosForHdPriority
            const historyArray = scanHist.toArray();
            const needDownloadVideos = ContentUtils.dropSkipped(GrokUtils.filterVideosForHdPriority(state.videos || [], historyArray, hdPriority), scanHist);

            // Quality tier breakdown (Task U3): count1080p/countHd/countSd via
            // GrokUtils.classifyVideoQuality (through ContentUtils.calculateVideoStats) —
            // exposed regardless of hdPriority mode so the popup can always show the
            // 1080p headline count.
            const tierCounts = ContentUtils.calculateVideoStats(state.videos || [], historyArray, hdPriority);

            let videoStats;
            if (hdPriority) {
                // HD priority: one file per video (HD if available, SD otherwise)
                const totalVideos = state.videos?.length || 0;
                const needVideos = needDownloadVideos.length;
                const needHd = needDownloadVideos.filter(v => (v.hd1080Url || v.hdUrl)).length;
                const need720p = needDownloadVideos.filter(v => !(v.hd1080Url || v.hdUrl) && v.resolutionName === '720p').length;
                const needSd = needVideos - needHd - need720p;
                const doneVideos = totalVideos - needVideos;
                videoStats = {
                    hdPriority: true,
                    total: totalVideos,
                    need: needVideos,
                    done: doneVideos,
                    needHd,
                    need720p,
                    needSd,
                    count1080p: tierCounts.count1080p,
                    countHd: tierCounts.countHd,
                    countSd: tierCounts.countSd
                };
            } else {
                // Non-HD priority: SD + 720p + HD separately
                const allVideos = state.videos || [];
                const sdVideos = allVideos.filter(v => !(v.hd1080Url || v.hdUrl) && v.resolutionName !== '720p');
                const native720pVideos = allVideos.filter(v => !(v.hd1080Url || v.hdUrl) && v.resolutionName === '720p');
                const hdVideos = allVideos.filter(v => (v.hd1080Url || v.hdUrl));

                const totalSd = sdVideos.length;
                const needSd = sdVideos.filter(v => {
                    return !scanHist.has(`${v.id}_sd`) && !scanHist.has(v.id);
                }).length;
                const total720p = native720pVideos.length;
                const need720p = native720pVideos.filter(v => !scanHist.has(`${v.id}_hd`)).length;
                const totalHd = hdVideos.length;
                const needHd = hdVideos.filter(v => !scanHist.has(`${v.id}_hd`)).length;
                videoStats = {
                    hdPriority: false,
                    totalSd, needSd, doneSd: totalSd - needSd,
                    total720p, need720p, done720p: total720p - need720p,
                    totalHd, needHd, doneHd: totalHd - needHd,
                    count1080p: tierCounts.count1080p,
                    countHd: tierCounts.countHd,
                    countSd: tierCounts.countSd
                };
            }

            const totalProjects = state.projects?.length || 0;
            // 用 per-file history 計算實際需要下載的專案數（不依賴 downloadedProjects 陣列）
            const scanHistWrapper = { has: (key) => scanHist.has(key) };
            const needProjects = isProjectMode
                ? countProjectsNeedDownload(state.projects || [], scanHistWrapper, state.filterOptions)
                : 0;
            const doneProjects = totalProjects - needProjects;

            sendResponse({
                success: true,
                mode: isProjectMode ? 'project' : 'standard',
                images: { total: totalImages, need: needImages, done: totalImages - needImages },
                videos: videoStats,
                projects: { total: totalProjects, need: needProjects, done: doneProjects }
            });
        } else if (request.action === 'fetchTagList') {
            const result = await fetchTagList();
            sendResponse(result);
        } else if (request.action === 'clearTagHistory') {
            await clearTagHistory();
            sendResponse({ success: true });
        } else if (request.action === 'clearConversationHistory') {
            await clearConversationHistory();
            sendResponse({ success: true });
        } else if (request.action === 'downloadInterrupted') {
            const key = request.historyKey;
            if (historyCache) historyCache.delete(key);
            if (tagHistoryCache) tagHistoryCache.delete(key);
            if (conversationHistoryCache) conversationHistoryCache.delete(key);
            SystemLogger.warn('Download interrupted — removed from history', `${request.filename} (${key})`);
            sendResponse({ success: true });
        } else if (request.action === 'showStudioButtons') {
            if (isStudioButtonsPage()) {
                showStudioButtons();
                sendResponse({ success: true });
            } else {
                sendResponse({ success: false, reason: 'Not on supported page' });
            }
        } else if (request.action === 'hideStudioButtons') {
            hideStudioButtons();
            sendResponse({ success: true });
        } else if (request.action === 'checkStudioButtonsSupport') {
            sendResponse({
                supported: isStudioButtonsPage(),
                active: studioButtonsActive
            });
        } else if (request.action === 'processBatchUpload') {
            // Handle batch upload request from sidepanel
            try {
                const result = await processBatchUploadRequest(request.frameData);
                sendResponse(result);
            } catch (error) {
                console.error('[Content] Batch upload error:', error);
                sendResponse({ success: false, error: error.message });
            }
        } else if (request.action === 'checkVideoStatus') {
            // Check video generation status
            try {
                const result = await checkVideoGenerationStatus(request.postId);
                sendResponse(result);
            } catch (error) {
                console.error('[Content] Check status error:', error);
                sendResponse({ success: false, error: error.message });
            }
        }
    })().catch((e) => {
        console.error('[Content] Unhandled message handler error:', e);
        try { sendResponse({ success: false, error: e && e.message ? e.message : String(e) }); } catch (_) {}
    });
    return true; // 保持消息通道開啟
});

// ==========================================
// Grok Video Studio - Video Capture & Frame Handling
// ==========================================

/**
 * Download a frame image for user to manually upload to Grok
 * @param {string} dataUrl - Base64 data URL of the frame
 * @param {string} filename - Suggested filename
 */
async function downloadFrameForUpload(dataUrl, filename = 'grok_frame.png') {
    try {
        const paths = await GrokUtils.getDownloadPaths();
        await sendDownloadRequest(dataUrl, `${paths.frames}/${filename}`);
        console.log(`[VideoStudio] Frame downloaded: ${filename}`);
        return { success: true, filename };
    } catch (error) {
        console.error('[VideoStudio] Failed to download frame:', error);
        return { success: false, error: error.message };
    }
}

/**
 * Watch for new video elements on the page (MutationObserver)
 * Used to detect when Grok generates a new video
 */
let videoWatcher = null;
let watchedVideos = new Set();

function startVideoWatcher() {
    if (videoWatcher) return;

    console.log('[VideoStudio] Starting video watcher...');

    const callback = (mutationsList) => {
        for (const mutation of mutationsList) {
            if (mutation.type === 'childList') {
                mutation.addedNodes.forEach(node => {
                    if (node.nodeType === 1) {
                        checkForNewVideos(node);
                    }
                });
            }
        }
    };

    videoWatcher = new MutationObserver(callback);
    videoWatcher.observe(document.body, {
        childList: true,
        subtree: true
    });

    // Initial scan
    document.querySelectorAll('video').forEach(video => {
        trackVideoElement(video);
    });
}

function stopVideoWatcher() {
    if (videoWatcher) {
        videoWatcher.disconnect();
        videoWatcher = null;
        watchedVideos.clear();
        console.log('[VideoStudio] Video watcher stopped');
    }
}

function checkForNewVideos(node) {
    if (node.tagName === 'VIDEO') {
        trackVideoElement(node);
    }
    if (node.querySelectorAll) {
        node.querySelectorAll('video').forEach(trackVideoElement);
    }
}

function trackVideoElement(video) {
    const src = video.src || video.querySelector('source')?.src;
    if (!src || watchedVideos.has(src)) return;

    watchedVideos.add(src);
    console.log('[VideoStudio] New video detected:', src.substring(0, 100) + '...');

    // Notify background/sidepanel about new video
    chrome.runtime.sendMessage({
        action: 'newVideoDetected',
        videoUrl: src,
        timestamp: Date.now()
    }).catch(() => {});
}

/**
 * Capture a video from the current page and send to IndexedDB via background
 * @param {string} videoUrl - URL of the video to capture
 * @returns {Promise<{success: boolean, videoId?: string, error?: string}>}
 */
async function captureVideoToStudio(videoUrl) {
    console.log('[VideoStudio] Capturing video:', videoUrl.substring(0, 100) + '...');

    try {
        // Let background fetch and store the video directly (avoids 64MB message limit)
        const result = await chrome.runtime.sendMessage({
            action: 'captureVideoFromUrl',
            videoUrl: videoUrl,
            metadata: {
                sourceUrl: videoUrl,
                capturedAt: Date.now()
            }
        });

        if (result.success) {
            console.log(`[VideoStudio] Video stored with ID: ${result.videoId}, Size: ${result.size}`);
            await SystemLogger.ok('Video captured to studio', `ID: ${result.videoId}, Size: ${result.size}`);

            // Auto-extract last frame after capture
            chrome.runtime.sendMessage({
                action: 'extractFrameFromVideo',
                videoId: result.videoId,
                position: 'last'
            }).catch(() => {});

            return { success: true, videoId: result.videoId };
        } else {
            throw new Error(result.error || 'Failed to store video');
        }
    } catch (error) {
        console.error('[VideoStudio] Video capture failed:', error);
        await SystemLogger.fail('Video capture failed', error.message);
        return { success: false, error: error.message };
    }
}

/**
 * Find video elements on the current page
 * @returns {Array<{url: string, element: HTMLVideoElement}>}
 */
function findPageVideos() {
    const videos = [];
    document.querySelectorAll('video').forEach(video => {
        const src = video.src || video.querySelector('source')?.src;
        if (src) {
            videos.push({
                url: src,
                width: video.videoWidth,
                height: video.videoHeight,
                duration: video.duration,
                element: video
            });
        }
    });
    return videos;
}

// ==========================================
// Stream Capture Logic
// ==========================================
let streamObserver = null;
let capturedImages = []; // kept for message compatibility; holds NO image data now
let isCapturing = false;
// Stream Capture v2: every final image is handed to the background capture
// queue (IndexedDB, auto-download, saved on completion). No in-page cap, no
// alert(), nothing held in this tab's memory.
const STREAM_CAPTURE_ENABLED_KEY = 'streamCaptureEnabled';
const streamRenditions = new WeakMap(); // img -> { src, changedAt, timer }
const streamSessionKeys = new Set();    // dedupe within this tab (sha / id)
let streamCapturedCount = 0;
let streamHeartbeatTimer = null;

function startStreamCapture() {
    if (isCapturing) return;

    console.log('👀 開始串流擷取模式...');
    isCapturing = true;
    SystemLogger.info('Stream capture started', 'Watching for new images (auto-save)...');

    const callback = function (mutationsList) {
        for (const mutation of mutationsList) {
            if (mutation.type === 'childList') {
                mutation.addedNodes.forEach(node => {
                    if (node.nodeType === 1) checkForStreamImages(node);
                });
            } else if (mutation.type === 'attributes' && mutation.attributeName === 'src') {
                checkForStreamImages(mutation.target);
            }
        }
    };

    streamObserver = new MutationObserver(callback);
    streamObserver.observe(document.body, {
        attributes: true,
        childList: true,
        subtree: true,
        attributeFilter: ['src']
    });

    // 初始掃描
    document.querySelectorAll('img').forEach(checkForStreamImages);

    const beat = () => chrome.runtime.sendMessage({ action: 'captureHeartbeat' }).catch(() => {});
    beat();
    streamHeartbeatTimer = setInterval(beat, 30000);
}

function stopStreamCapture() {
    if (!isCapturing) return;

    console.log('🛑 停止串流擷取模式');
    SystemLogger.info('Stream capture stopped', `Captured ${streamCapturedCount} images this session`);
    if (streamObserver) {
        streamObserver.disconnect();
        streamObserver = null;
    }
    if (streamHeartbeatTimer) {
        clearInterval(streamHeartbeatTimer);
        streamHeartbeatTimer = null;
    }
    isCapturing = false;
}

function checkForStreamImages(node) {
    if (node.tagName === 'IMG') {
        processStreamImage(node);
    }

    if (node.querySelectorAll) {
        const images = node.querySelectorAll('img');
        images.forEach(processStreamImage);
    }
}

// Wait for the FINAL rendition: Grok swaps preview -> medium -> final on the
// same <img>. Re-arm a timer on every src change and only capture once the
// src has been stable for STABLE_MS, the image has loaded, and it is
// full-size (replaces the old fixed 120 KB size filter).
function processStreamImage(img) {
    if (!isCapturing) return;
    const src = img.src;
    if (!src || !src.startsWith('data:image/')) return;

    const C = GrokCaptureCore.CAPTURE;
    const prev = streamRenditions.get(img);
    if (prev && prev.src === src && prev.done) return;
    if (prev && prev.timer) clearTimeout(prev.timer);
    const rec = { src, changedAt: Date.now(), timer: null, done: false };
    streamRenditions.set(img, rec);

    const check = () => {
        rec.timer = null;
        if (!isCapturing || streamRenditions.get(img) !== rec) return;
        const ok = GrokCaptureCore.isFinalRendition({
            src: img.src, lastSrc: rec.src, changedAt: rec.changedAt, now: Date.now(),
            naturalWidth: img.naturalWidth, naturalHeight: img.naturalHeight, complete: img.complete
        });
        if (ok) {
            rec.done = true;
            captureFinalImage(img, rec.src).catch((e) => console.warn('[Stream] capture failed:', e && e.message));
        } else if (img.src === rec.src && Date.now() - rec.changedAt < 60000) {
            rec.timer = setTimeout(check, C.STABLE_MS); // not loaded / still small: look again
        }
    };
    rec.timer = setTimeout(check, C.STABLE_MS);
}

// Best-effort media id from the surrounding card (post links carry the id).
function streamMediaIdFor(img) {
    const fromAttr = (el) => el && (el.getAttribute('data-asset-id') || el.getAttribute('data-post-id') || el.getAttribute('data-id'));
    let el = img;
    for (let i = 0; i < 6 && el; i++, el = el.parentElement) {
        const v = fromAttr(el);
        if (v && GrokCaptureCore.UUID_RE.test(v)) return GrokCaptureCore.normId(v);
        const a = el.tagName === 'A' ? el : (el.querySelector && el.querySelector('a[href*="/imagine/post/"]'));
        const id = a && GrokCaptureCore.mediaIdFromUrl(a.getAttribute('href'));
        if (id) return id;
    }
    return null;
}

async function sha256OfDataUrl(dataUrl) {
    const b64 = dataUrl.slice(dataUrl.indexOf(',') + 1);
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function captureFinalImage(img, src) {
    const mediaId = streamMediaIdFor(img);
    const sha256 = await sha256OfDataUrl(src);
    const key = GrokCaptureCore.dedupeKey({ mediaId, sha256 });
    if (!key || streamSessionKeys.has(key) || streamSessionKeys.has('sha:' + sha256)) return;
    streamSessionKeys.add(key);
    streamSessionKeys.add('sha:' + sha256);
    const res = await chrome.runtime.sendMessage({
        action: 'captureItem',
        item: { kind: 'image', dataUrl: src, sha256, mediaId, source: 'dom', mime: src.slice(5, src.indexOf(';')) }
    }).catch((e) => ({ accepted: false, error: e && e.message }));
    if (res && res.accepted) {
        streamCapturedCount++;
        console.log(`📸 [Stream] queued final image ${key} (${img.naturalWidth}x${img.naturalHeight})`);
        chrome.runtime.sendMessage({ action: 'streamImageCaptured', count: streamCapturedCount }).catch(() => { });
    } else if (res && res.error) {
        streamSessionKeys.delete(key); // background unreachable: allow a later retry
    }
}

// Persisted toggle: auto-start in every /imagine tab, follow changes live.
(async () => {
    try {
        const r = await chrome.storage.local.get(STREAM_CAPTURE_ENABLED_KEY);
        if (r[STREAM_CAPTURE_ENABLED_KEY] === true) startStreamCapture();
    } catch (e) { /* storage unavailable */ }
})();
chrome.storage.onChanged.addListener((changes, area) => {
    // Skip list written from another tab or extension page: drop the cache.
    if (area === 'local' && changes[SKIP_IDS_KEY]) skipIdSetCache = null;
    if (area !== 'local' || !changes[STREAM_CAPTURE_ENABLED_KEY]) return;
    if (changes[STREAM_CAPTURE_ENABLED_KEY].newValue === true) startStreamCapture();
    else stopStreamCapture();
});

// Answer the background's SPA-injection ping so it doesn't inject twice.
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request && request.action === 'gmdPing') { sendResponse({ ok: true }); return false; }
    return false;
});

console.log('');
console.log('='.repeat(60));
console.log('🎬 Grok 視頻下載器 - Chrome Extension');
console.log('='.repeat(60));
console.log('');
console.log('💡 點擊擴展圖標打開控制面板');
console.log('');

// Legacy autoRun removed — video downloads now use batch mode via
// startVideoDownload() → background.js, no page navigation needed.

// ==========================================
// Auto-upload frame to Grok Imagine
// ==========================================

/**
 * Check if we're on grok.com/imagine and have a pending frame to upload
 */
async function checkPendingFrameUpload() {
    const currentUrl = window.location.href;

    // Only run on grok.com/imagine (not on post detail pages)
    if (!currentUrl.includes('grok.com/imagine') || currentUrl.includes('/imagine/post/')) {
        return;
    }

    console.log('[Content] Checking for pending frame upload...');

    try {
        // Check if this is a batch request (has #batch=N in URL)
        const hashMatch = window.location.hash.match(/batch=(\d+)/);
        const batchIndex = hashMatch ? parseInt(hashMatch[1]) : null;

        // Determine which storage key to use
        let storageKey = 'pendingFrameUpload';
        let batchStateKey = 'batchGenerationState';

        if (batchIndex !== null) {
            storageKey = `pendingFrameUpload_${batchIndex}`;
            batchStateKey = `batchGenerationState_${batchIndex}`;
            console.log(`[Content] Batch mode detected, index: ${batchIndex}`);
        }

        const result = await chrome.storage.local.get([storageKey, batchStateKey]);
        const frameData = result[storageKey];

        if (!frameData || !frameData.dataUrl) {
            console.log('[Content] No pending frame upload found');
            return;
        }

        // Check if the frame is recent (within 60 seconds for batch mode)
        const maxAge = batchIndex !== null ? 60000 : 30000;
        const age = Date.now() - frameData.timestamp;
        if (age > maxAge) {
            console.log('[Content] Pending frame is too old, clearing...');
            await chrome.storage.local.remove([storageKey, batchStateKey]);
            return;
        }

        console.log('[Content] Found pending frame upload, uploading via API...');

        // Small delay to ensure page is ready
        await new Promise(r => setTimeout(r, 1000));

        // Upload the frame via API
        await uploadFrameToGrok(frameData);

        // Clear the pending upload
        await chrome.storage.local.remove(storageKey);
        console.log('[Content] Frame upload completed, cleared pending data');

    } catch (error) {
        console.error('[Content] Error checking pending frame upload:', error);
    }
}

/**
 * Wait for an element to appear in the DOM
 */
function waitForElement(selector, timeout = 10000) {
    return new Promise((resolve, reject) => {
        const element = document.querySelector(selector);
        if (element) {
            resolve(element);
            return;
        }

        const observer = new MutationObserver((mutations, obs) => {
            const el = document.querySelector(selector);
            if (el) {
                obs.disconnect();
                resolve(el);
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        setTimeout(() => {
            observer.disconnect();
            reject(new Error(`Timeout waiting for element: ${selector}`));
        }, timeout);
    });
}

/**
 * Wait for the attach button to appear (using text content search)
 */
function waitForAttachButton(timeout = 15000) {
    return new Promise((resolve, reject) => {
        const checkButton = () => {
            // Try multiple ways to find the attach button
            const button = findButtonByText('附加') ||
                          findButtonByText('Attach') ||
                          document.querySelector('button[aria-label="附加"]') ||
                          document.querySelector('button[aria-label="Attach"]');
            return button;
        };

        const button = checkButton();
        if (button) {
            console.log('[Content] Attach button found immediately');
            resolve(button);
            return;
        }

        const observer = new MutationObserver((mutations, obs) => {
            const btn = checkButton();
            if (btn) {
                obs.disconnect();
                console.log('[Content] Attach button found via observer');
                resolve(btn);
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        setTimeout(() => {
            observer.disconnect();
            // One final check
            const btn = checkButton();
            if (btn) {
                resolve(btn);
            } else {
                reject(new Error('Timeout waiting for attach button'));
            }
        }, timeout);
    });
}

/**
 * Convert data URL to File object
 */
function dataURLtoFile(dataUrl, filename) {
    const arr = dataUrl.split(',');
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
}

/**
 * Upload frame to Grok Imagine page via API
 */
async function uploadFrameToGrok(frameData) {
    console.log('[Content] Starting frame upload to Grok via API...');

    try {
        // Extract base64 content from data URL
        const base64Content = frameData.dataUrl.split(',')[1];

        const payload = {
            fileName: frameData.filename,
            fileMimeType: 'image/png',
            content: base64Content
        };

        console.log('[Content] Uploading file:', payload.fileName);

        const response = await fetch('https://grok.com/rest/app-chat/upload-file', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'include',
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            throw new Error(`Upload failed: HTTP ${response.status}`);
        }

        const result = await response.json();
        console.log('[Content] Upload response:', result);

        if (result.fileMetadataId) {
            console.log('[Content] ✅ Frame uploaded successfully! fileMetadataId:', result.fileMetadataId);

            // Get userId from cookie
            const userId = document.cookie.match(/x-userid=([^;]+)/)?.[1];
            const mediaUrl = `https://assets.grok.com/users/${userId}/${result.fileMetadataId}/content`;

            // Create media post
            console.log('[Content] Creating media post...');
            const createResponse = await fetch('https://grok.com/rest/media/post/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'include',
                body: JSON.stringify({
                    mediaType: 'MEDIA_POST_TYPE_IMAGE',
                    mediaUrl: mediaUrl
                })
            });

            const createResult = await createResponse.json();
            console.log('[Content] Create post response:', createResult);

            // Get the postId from the response
            const postId = createResult.postId || createResult.id || result.fileMetadataId;

            // Trigger video generation if prompt is provided or non-custom mode selected
            if (frameData.prompt || (frameData.videoMode && frameData.videoMode !== 'custom')) {
                console.log('[Content] Triggering video generation with prompt:', frameData.prompt, 'videoMode:', frameData.videoMode);
                triggerVideoGeneration(postId, mediaUrl, frameData.prompt || '', frameData.mode || 'custom', frameData.batchIndex, frameData.videoMode || 'custom', frameData.videoLength, frameData.resolutionName);
            }

            // Like the post (don't wait for video generation)
            console.log('[Content] Liking post...');
            const likeResponse = await fetch('https://grok.com/rest/media/post/like', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'include',
                body: JSON.stringify({
                    id: postId
                })
            });

            const likeResult = await likeResponse.json();
            console.log('[Content] Like post response:', likeResult);

            // Store the file metadata for use in the prompt
            await chrome.storage.local.set({
                uploadedFrameMetadata: {
                    fileMetadataId: result.fileMetadataId,
                    postId: postId,
                    mediaUrl: mediaUrl,
                    fileName: frameData.filename,
                    prompt: frameData.prompt,
                    timestamp: Date.now()
                }
            });

            // Show success notification (only for non-batch mode, batch will show after submit)
            if (frameData.mode !== 'batch') {
                const notifyMsg = frameData.prompt
                    ? '✅ Uploaded & Video Generation Started!'
                    : '✅ Uploaded! Post ID: ' + postId;
                showUploadNotification(notifyMsg, false, postId);
            }
            // Note: batchUploadComplete will be sent after prompt is submitted on post page
        }

        return result;

    } catch (error) {
        console.error('[Content] Error uploading frame:', error);
        showUploadNotification('❌ Upload failed: ' + error.message, true);
        return null;
    }
}

/**
 * Show a notification on the page
 */
function showUploadNotification(message, isError = false, fileMetadataId = null) {
    // Remove existing notification
    const existing = document.getElementById('grok-upload-notification');
    if (existing) existing.remove();

    const notification = document.createElement('div');
    notification.id = 'grok-upload-notification';
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 12px 20px;
        background: ${isError ? '#ef4444' : '#22c55e'};
        color: white;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        z-index: 999999;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        animation: slideIn 0.3s ease;
        max-width: 400px;
        word-break: break-all;
    `;

    if (fileMetadataId) {
        notification.innerHTML = `
            <div>✅ Frame uploaded successfully!</div>
            <div style="font-size: 12px; margin-top: 8px; opacity: 0.9;">
                ID: <code style="background: rgba(0,0,0,0.2); padding: 2px 6px; border-radius: 4px; cursor: pointer;" onclick="navigator.clipboard.writeText('${fileMetadataId}'); this.textContent='Copied!'; setTimeout(() => this.textContent='${fileMetadataId}', 1000);">${fileMetadataId}</code>
            </div>
            <div style="font-size: 11px; margin-top: 6px; opacity: 0.7;">Click ID to copy</div>
        `;
    } else {
        notification.textContent = message;
    }

    // Add animation style
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
    `;
    document.head.appendChild(style);

    document.body.appendChild(notification);

    // Auto-remove after 10 seconds (longer to allow copying)
    setTimeout(() => {
        notification.style.animation = 'slideIn 0.3s ease reverse';
        setTimeout(() => notification.remove(), 300);
    }, 10000);
}

/**
 * Find a button by its text content
 */
function findButtonByText(text) {
    const buttons = document.querySelectorAll('button');
    for (const button of buttons) {
        if (button.textContent.includes(text) || button.getAttribute('aria-label')?.includes(text)) {
            return button;
        }
    }
    return null;
}

/**
 * Find a menu item by its text content
 */
function findMenuItemByText(text) {
    // Try menuitem role first
    const menuItems = document.querySelectorAll('[role="menuitem"]');
    for (const item of menuItems) {
        if (item.textContent.includes(text)) {
            return item;
        }
    }

    // Try any clickable element in a menu
    const menuElements = document.querySelectorAll('[role="menu"] *');
    for (const el of menuElements) {
        if (el.textContent.includes(text) && (el.tagName === 'BUTTON' || el.tagName === 'DIV' || el.onclick)) {
            return el;
        }
    }

    return null;
}

// ==========================================
// Video Generation Helper (Manual Mode)
// ==========================================

/**
 * Show prompt notification for manual video generation
 * User needs to manually enter the prompt in Grok's input
 */
function showVideoGenPrompt(postId, prompt) {
    const existing = document.getElementById('grok-videogen-notification');
    if (existing) existing.remove();

    const notification = document.createElement('div');
    notification.id = 'grok-videogen-notification';
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        padding: 16px 20px;
        background: linear-gradient(135deg, #2196F3, #1976D2);
        color: white;
        border-radius: 12px;
        font-size: 14px;
        z-index: 999999;
        box-shadow: 0 4px 20px rgba(0,0,0,0.4);
        max-width: 380px;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    `;

    const promptText = prompt.length > 80 ? prompt.substring(0, 80) + '...' : prompt;

    notification.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <div style="font-weight: 600; font-size: 15px;">🎬 Ready for Video Generation</div>
            <button id="closeVideoGenNotif" style="background: none; border: none; color: white; font-size: 18px; cursor: pointer; opacity: 0.7;">&times;</button>
        </div>
        <div style="font-size: 12px; opacity: 0.9; margin-bottom: 10px;">
            Your frame has been uploaded. Copy the prompt below and paste it in Grok's input:
        </div>
        <div style="background: rgba(0,0,0,0.2); padding: 10px 12px; border-radius: 8px; margin-bottom: 10px;">
            <div style="font-size: 12px; word-break: break-word; line-height: 1.4;">${promptText}</div>
        </div>
        <button id="copyPromptBtn" style="
            width: 100%;
            padding: 10px;
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 6px;
            color: white;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            transition: background 0.2s;
        ">📋 Copy Prompt</button>
    `;

    document.body.appendChild(notification);

    // Copy button handler
    document.getElementById('copyPromptBtn').addEventListener('click', () => {
        navigator.clipboard.writeText(prompt).then(() => {
            const btn = document.getElementById('copyPromptBtn');
            btn.textContent = '✅ Copied!';
            btn.style.background = 'rgba(76, 175, 80, 0.4)';
            setTimeout(() => {
                btn.textContent = '📋 Copy Prompt';
                btn.style.background = 'rgba(255,255,255,0.2)';
            }, 2000);
        });
    });

    // Close button handler
    document.getElementById('closeVideoGenNotif').addEventListener('click', () => {
        notification.remove();
    });

    // Auto-remove after 60 seconds
    setTimeout(() => {
        if (document.getElementById('grok-videogen-notification')) {
            notification.style.opacity = '0';
            notification.style.transition = 'opacity 0.3s';
            setTimeout(() => notification.remove(), 300);
        }
    }, 60000);
}

/**
 * Called after upload to navigate to post page and fill prompt
 */
async function triggerVideoGeneration(postId, mediaUrl, prompt, mode, batchIndex, videoMode = 'custom', videoLength, resolutionName) {
    console.log('[Content] Navigating to post page...');
    console.log('[Content] Post ID:', postId);
    console.log('[Content] Prompt:', prompt);
    console.log('[Content] Mode:', mode, 'Batch Index:', batchIndex, 'Video Mode:', videoMode);

    // Store prompt for the post page to pick up
    await chrome.storage.local.set({
        pendingVideoPrompt: {
            postId: postId,
            prompt: prompt,
            timestamp: Date.now(),
            mode: mode,
            batchIndex: batchIndex,    // Pass batch info to post page
            videoMode: videoMode,      // Video generation mode (custom/normal/fun/spicy)
            videoLength: videoLength,   // Duration override (6 or 10)
            resolutionName: resolutionName // Resolution override (480p or 720p)
        }
    });

    // Navigate to the post page
    window.location.href = `https://grok.com/imagine/post/${postId}`;
}

/**
 * Check for pending prompt and fill it into the input box
 */
async function checkPendingPrompt() {
    const currentUrl = window.location.href;

    // Only run on post detail pages
    if (!currentUrl.includes('/imagine/post/')) {
        return;
    }

    console.log('[Content] On post page, checking for pending prompt...');

    try {
        const result = await chrome.storage.local.get('pendingVideoPrompt');
        const promptData = result.pendingVideoPrompt;

        if (!promptData || (!promptData.prompt && (!promptData.videoMode || promptData.videoMode === 'custom'))) {
            console.log('[Content] No pending prompt found');
            return;
        }

        // Check if the prompt is recent (within 60 seconds)
        const age = Date.now() - promptData.timestamp;
        if (age > 60000) {
            console.log('[Content] Pending prompt is too old, clearing...');
            await chrome.storage.local.remove('pendingVideoPrompt');
            return;
        }

        // Check if we're on the correct post page
        if (!currentUrl.includes(promptData.postId)) {
            console.log('[Content] Post ID mismatch, skipping...');
            return;
        }

        console.log('[Content] Found pending prompt:', promptData.prompt);
        console.log('[Content] Mode:', promptData.mode, 'Batch Index:', promptData.batchIndex, 'Video Mode:', promptData.videoMode);

        // Check if this is batch mode (from promptData, not separate storage)
        const isBatchMode = promptData.mode === 'batch' && promptData.batchIndex !== undefined;
        const videoMode = promptData.videoMode || 'custom';

        // Wait for the input to be ready and submit
        await waitForInputAndFill(promptData.prompt || '', isBatchMode, promptData.batchIndex, promptData.postId, videoMode, promptData.videoLength, promptData.resolutionName);

        // Clear the pending prompt
        await chrome.storage.local.remove('pendingVideoPrompt');
        console.log('[Content] Prompt filled and cleared');

        // If batch mode, start watching for video generation completion
        if (isBatchMode) {
            console.log('[Content] Batch mode active, watching for video completion...');
            watchForVideoCompletion(promptData.batchIndex);
        }

    } catch (error) {
        console.error('[Content] Error checking pending prompt:', error);
    }
}

/**
 * Wait for input element and fill with prompt
 * Handles both V1 (textarea) and V2 (contenteditable/TipTap) UI versions,
 * mirroring the same logic as queueFillAndSubmit().
 * @param {string} prompt - The prompt to fill
 * @param {boolean} isBatchMode - Whether this is batch mode
 * @param {number} batchIndex - The batch candidate index
 * @param {string} postId - The post ID
 */
async function waitForInputAndFill(prompt, isBatchMode = false, batchIndex = null, postId = null, videoMode = 'custom', videoLength, resolutionName) {
    try {
        // Helper to find prompt input (textarea for V1, contenteditable for V2)
        const findInput = () => {
            const candidates = Array.from(document.querySelectorAll('textarea[placeholder], input[placeholder*="Enter"], input[placeholder*="輸入"], [contenteditable="true"], textarea'))
                .filter(el => el.id !== 'grok-queue-prompt' && !el.closest('#grok-queue-fab'));
            return candidates.length > 0 ? candidates[0] : null;
        };

        // Wait initial delay for page load
        await new Promise(r => setTimeout(r, 1500));

        // Wait for input to appear (quick check first, 5s)
        let input = null;
        for (let attempt = 0; attempt < 10; attempt++) {
            input = findInput();
            if (input) break;
            await new Promise(r => setTimeout(r, 500));
        }

        // V2: If no input found yet, page might be in Image mode (no contenteditable).
        // Try switching to Video mode first, then re-search.
        if (!input) {
            console.log('[Story] No input found — page may be in Image mode, attempting mode switch...');
            await new Promise(r => setTimeout(r, 1000));
            await switchToVideoModeIfNeeded();
            await new Promise(r => setTimeout(r, 1500));
            for (let attempt = 0; attempt < 10; attempt++) {
                input = findInput();
                if (input) break;
                await new Promise(r => setTimeout(r, 500));
            }
        }

        if (!input) {
            console.log('[Story] Could not find input element, showing prompt notification instead');
            showVideoGenPrompt(null, prompt);
            if (isBatchMode && batchIndex !== null) {
                chrome.runtime.sendMessage({
                    type: 'batchUploadComplete',
                    batchIndex: batchIndex,
                    postId: postId,
                    success: false
                }).catch(err => console.log('[Story] Could not send batchUploadComplete:', err));
            }
            return false;
        }

        const isV2 = input.tagName !== 'TEXTAREA' && input.tagName !== 'INPUT';
        console.log(`[Story] Found input element (${isV2 ? 'V2 contenteditable' : 'V1 ' + input.tagName}), filling prompt...`);

        // V2: Ensure video mode + apply settings via UI (same as Queue)
        if (isV2) {
            console.log('[Story] V2 detected, waiting for hydration...');
            await new Promise(r => setTimeout(r, 2000));
            await switchToVideoModeIfNeeded();

            // Find settings button near contenteditable
            const settingsBtn = (() => {
                const eds = Array.from(document.querySelectorAll('[contenteditable="true"]'))
                    .filter(el => el.id !== 'grok-queue-prompt' && !el.closest('#grok-queue-fab'));
                if (eds.length === 0) return null;
                let p = eds[0].parentElement;
                for (let i = 0; i < 8 && p; i++) {
                    const btn = p.querySelector('button[aria-haspopup="menu"]');
                    if (btn) return btn;
                    p = p.parentElement;
                }
                return null;
            })();
            await applyVideoSettingsV2(settingsBtn, videoLength, resolutionName, videoMode);

            // Re-find input after mode switch (contenteditable may have been recreated)
            const freshInput = findInput();
            if (freshInput && freshInput !== input) {
                input = freshInput;
                console.log('[Story] Re-acquired input after mode switch');
            }
        }

        // Fill the prompt (for non-custom modes with empty prompt, use a space to enable submit)
        const fillText = prompt || (videoMode !== 'custom' ? ' ' : '');
        input.focus();

        if (!isV2) {
            // V1: Use native setter to trigger React state update (same as Queue)
            const proto = input.tagName === 'TEXTAREA'
                ? window.HTMLTextAreaElement.prototype
                : window.HTMLInputElement.prototype;
            const nativeSetter = Object.getOwnPropertyDescriptor(proto, 'value').set;
            nativeSetter.call(input, fillText);
            input.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
            // V2: Use fillContentEditable (TipTap API via MAIN world, same as Queue)
            await fillContentEditable(input, fillText);
        }

        // Set video overrides via DOM data attributes for intercept.js
        GrokVideoMode.applyVideoOverrides(videoMode, videoLength, resolutionName);
        // Pass prompt to intercept.js as safety net
        document.documentElement.dataset.grokQueuePrompt = fillText; document.documentElement.dataset.grokQueueSetAt = String(Date.now());
        console.log(`[Story] Video overrides set: mode=${videoMode}, duration=${videoLength || 6}s, resolution=${resolutionName || '480p'}`);

        // Wait for framework to process the input
        await new Promise(r => setTimeout(r, 500));

        // Show notification (only for non-batch mode)
        if (!isBatchMode) {
            showPromptFilledNotification();
        }

        // Find the submit button with retry (same strategy as Queue)
        let submitBtn = null;
        for (let btnAttempt = 0; btnAttempt < 10; btnAttempt++) {
            // Strategy 1: aria-label (V2 submit button)
            submitBtn = document.querySelector(ContentUtils.GROK_SELECTORS.SUBMIT_VIDEO_BUTTON);
            // Strategy 2: V1 button class
            if (!submitBtn) {
                submitBtn = document.querySelector('button[data-slot="button"][class*="bg-button-filled"]');
            }
            // Strategy 3: SVG arrow-up path near input area
            if (!submitBtn) {
                const inputArea = document.querySelector('[contenteditable="true"]') || document.querySelector('textarea[placeholder]');
                const inputContainer = inputArea?.closest('[class*="flex"]')?.parentElement?.parentElement;
                const searchScope = inputContainer || document;
                const allButtons = Array.from(searchScope.querySelectorAll('button'));
                submitBtn = allButtons.find(b => {
                    const paths = b.querySelectorAll('svg path');
                    for (const p of paths) {
                        if ((p.getAttribute('d') || '').includes('M12 5V19')) return true;
                    }
                    return false;
                }) || null;
            }
            if (submitBtn) break;
            console.log(`[Story] Submit button not found, retrying (${btnAttempt + 1}/10)...`);
            await new Promise(r => setTimeout(r, 500));
        }

        if (submitBtn) {
            // Wait for button to become enabled
            if (submitBtn.disabled) {
                console.log('[Story] Submit button found but disabled, waiting for enable...');
                for (let i = 0; i < 10; i++) {
                    await new Promise(r => setTimeout(r, 500));
                    if (!submitBtn.disabled) break;
                    // After 3s, try re-filling the contenteditable (framework may not have registered)
                    if (i === 5 && isV2) {
                        console.log('[Story] Button still disabled after 3s, re-filling contenteditable...');
                        await fillContentEditable(input, fillText);
                    }
                }
            }

            if (!submitBtn.disabled) {
                console.log('[Story] Submitting prompt...');

                let submitted = false;
                // V2: Submit via Enter key in MAIN world (most reliable, same as Queue)
                if (isV2) {
                    console.log('[Story] V2: submitting via Enter key in MAIN world...');
                    const enterResult = await new Promise((resolve) => {
                        const timeout = setTimeout(() => {
                            window.removeEventListener('message', handler);
                            resolve({ success: false, error: 'timeout' });
                        }, 2000);
                        function handler(event) {
                            if (event.source !== window || event.data?.type !== 'GROK_SUBMIT_EDITOR_RESULT') return;
                            clearTimeout(timeout);
                            window.removeEventListener('message', handler);
                            resolve(event.data.payload);
                        }
                        window.addEventListener('message', handler);
                        window.postMessage({ type: 'GROK_SUBMIT_EDITOR', payload: {} }, '*');
                    });
                    if (enterResult.success) {
                        console.log('[Story] V2: Submitted via Enter key in MAIN world');
                        submitted = true;
                    } else {
                        console.warn(`[Story] V2: Enter key submit failed: ${enterResult.error}, falling back to button click`);
                    }
                }

                // V1 or V2 fallback: Button click with full pointer event sequence
                if (!submitted) {
                    const evtOpts = { bubbles: true, cancelable: true, view: window };
                    submitBtn.dispatchEvent(new PointerEvent('pointerdown', { ...evtOpts, pointerId: 1 }));
                    submitBtn.dispatchEvent(new MouseEvent('mousedown', evtOpts));
                    submitBtn.dispatchEvent(new PointerEvent('pointerup', { ...evtOpts, pointerId: 1 }));
                    submitBtn.dispatchEvent(new MouseEvent('mouseup', evtOpts));
                    submitBtn.dispatchEvent(new MouseEvent('click', evtOpts));
                }
            } else {
                console.warn('[Story] Submit button still disabled after waiting, dispatching Enter key fallback...');
                const enterEvent = new KeyboardEvent('keydown', {
                    key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
                    bubbles: true, cancelable: true
                });
                input.dispatchEvent(enterEvent);
            }
        } else {
            console.warn('[Story] Submit button not found, dispatching Enter key fallback...');
            const enterEvent = new KeyboardEvent('keydown', {
                key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
                bubbles: true, cancelable: true
            });
            input.dispatchEvent(enterEvent);
        }

        // If batch mode, notify sidepanel
        if (isBatchMode && batchIndex !== null) {
            console.log(`[Story] Batch ${batchIndex}: Prompt submitted, notifying sidepanel...`);
            await new Promise(r => setTimeout(r, 500));
            chrome.runtime.sendMessage({
                type: 'batchUploadComplete',
                batchIndex: batchIndex,
                postId: postId,
                success: true
            }).catch(err => console.log('[Story] Could not send batchUploadComplete:', err));
        }

        return true;

    } catch (error) {
        console.error('[Story] Error in waitForInputAndFill:', error);

        // Notify sidepanel on failure
        if (isBatchMode && batchIndex !== null) {
            chrome.runtime.sendMessage({
                type: 'batchUploadComplete',
                batchIndex: batchIndex,
                postId: postId,
                success: false
            }).catch(err => console.log('[Story] Could not send batchUploadComplete:', err));
        }

        return false;
    }
}

/**
 * Watch for video generation completion on post detail page
 * Uses MutationObserver to detect when video appears
 */
function watchForVideoCompletion(candidateIndex) {
    console.log('[Content] Starting video completion watcher for candidate:', candidateIndex);

    let videoFound = false;
    let checkCount = 0;
    const maxChecks = 180; // 3 minutes at 1 check per second

    const checkForVideo = () => {
        checkCount++;

        // Look for video element on the page
        const videoElements = document.querySelectorAll('video');
        for (const video of videoElements) {
            const src = video.src || video.querySelector('source')?.src;
            if (src && src.includes('generated') && !videoFound) {
                videoFound = true;
                console.log('[Content] Video found for batch candidate:', candidateIndex, src);

                // Notify sidepanel
                chrome.runtime.sendMessage({
                    action: 'batchVideoReady',
                    candidateIndex: candidateIndex,
                    videoUrl: src
                });

                // Clear batch state
                chrome.storage.local.remove('batchGenerationState');

                // Show success notification
                showBatchVideoReadyNotification(candidateIndex);
                return;
            }
        }

        // Also check for video in any data attributes or links
        const videoLinks = document.querySelectorAll('a[href*=".mp4"], a[href*="video"]');
        for (const link of videoLinks) {
            if (!videoFound && link.href.includes('generated')) {
                videoFound = true;
                console.log('[Content] Video link found for batch candidate:', candidateIndex, link.href);

                chrome.runtime.sendMessage({
                    action: 'batchVideoReady',
                    candidateIndex: candidateIndex,
                    videoUrl: link.href
                });

                chrome.storage.local.remove('batchGenerationState');
                showBatchVideoReadyNotification(candidateIndex);
                return;
            }
        }

        // Continue checking
        if (checkCount < maxChecks && !videoFound) {
            setTimeout(checkForVideo, 1000);
        } else if (!videoFound) {
            console.log('[Content] Timeout waiting for video generation');
            chrome.runtime.sendMessage({
                action: 'batchVideoReady',
                candidateIndex: candidateIndex,
                videoUrl: null,
                error: 'Timeout'
            });
            chrome.storage.local.remove('batchGenerationState');
        }
    };

    // Also use MutationObserver for faster detection
    const observer = new MutationObserver((mutations) => {
        if (videoFound) {
            observer.disconnect();
            return;
        }

        for (const mutation of mutations) {
            if (mutation.type === 'childList') {
                const videos = document.querySelectorAll('video[src*="generated"]');
                if (videos.length > 0 && !videoFound) {
                    const video = videos[0];
                    videoFound = true;
                    observer.disconnect();

                    console.log('[Content] MutationObserver detected video:', video.src);

                    chrome.runtime.sendMessage({
                        action: 'batchVideoReady',
                        candidateIndex: candidateIndex,
                        videoUrl: video.src
                    });

                    chrome.storage.local.remove('batchGenerationState');
                    showBatchVideoReadyNotification(candidateIndex);
                    return;
                }
            }
        }
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    // Start periodic checking as backup
    setTimeout(checkForVideo, 2000);
}

/**
 * Show notification when batch video is ready
 */
function showBatchVideoReadyNotification(candidateIndex) {
    const existing = document.getElementById('grok-batch-ready-notification');
    if (existing) existing.remove();

    const notification = document.createElement('div');
    notification.id = 'grok-batch-ready-notification';
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 16px 24px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 12px;
        font-size: 14px;
        font-weight: 600;
        z-index: 999999;
        box-shadow: 0 4px 20px rgba(102, 126, 234, 0.4);
        animation: slideIn 0.3s ease;
    `;
    notification.innerHTML = `
        <div>✅ Candidate #${candidateIndex + 1} Ready!</div>
        <div style="font-size: 12px; margin-top: 4px; opacity: 0.9;">Video generated successfully</div>
    `;

    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

/**
 * Show notification that prompt was filled
 */
function showPromptFilledNotification() {
    const existing = document.getElementById('grok-prompt-filled-notification');
    if (existing) existing.remove();

    const notification = document.createElement('div');
    notification.id = 'grok-prompt-filled-notification';
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 12px 20px;
        background: #4CAF50;
        color: white;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        z-index: 999999;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        display: flex;
        align-items: center;
        gap: 8px;
    `;
    notification.innerHTML = `
        <span>✅</span>
        <span>Prompt filled! Click send to generate video.</span>
    `;

    document.body.appendChild(notification);

    // Auto-remove after 5 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transition = 'opacity 0.3s';
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

// Check for pending frame upload when page loads
// Track if we've already processed this batch upload. Declared here (outside the
// URL-gated block below) so the main chrome.runtime.onMessage listener above —
// which handles the legacy `triggerBatchUpload` message — can reference the same
// binding via closure.
let batchUploadProcessed = false;

const runPendingChecks = () => {
    if (!batchUploadProcessed || !window.location.hash.includes('batch=')) {
        checkPendingFrameUpload().then(() => {
            if (window.location.hash.includes('batch=')) {
                batchUploadProcessed = true;
            }
        });
    }
    checkPendingPrompt();
};

if (window.location.href.includes('grok.com/imagine')) {
    console.log('[Content] On Grok Imagine page...');

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(runPendingChecks, 2000);
        });
    } else {
        setTimeout(runPendingChecks, 2000);
    }

    // For background tabs: check when tab becomes visible
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible' && window.location.hash.includes('batch=')) {
            console.log('[Content] Tab became visible, checking for pending batch upload...');
            setTimeout(runPendingChecks, 500);
        }
    });
}

// ==========================================
// Video Drag Handler for Side Panel
// Intercept drag events to include actual video URL
// ==========================================

function setupVideoDragHandler() {
    console.log('[Content] Setting up video drag handler...');

    // Handle dragstart on video elements
    document.addEventListener('dragstart', (e) => {
        const video = e.target.closest('video') || (e.target.tagName === 'VIDEO' ? e.target : null);

        if (video && video.src) {
            console.log('[Content] Video drag started, src:', video.src.substring(0, 100));

            // Pre-fetch immediately while the URL is still fresh (prevents 403 from
            // short-lived signed CDN URLs that expire between dragstart and drop).
            // Only do this when Story Mode sidepanel is open to avoid wasted bandwidth.
            if (storyModeActive) {
                chrome.runtime.sendMessage({ action: 'preFetchVideoForDrop', url: video.src });
            }

            // Set the video URL as text data
            e.dataTransfer.setData('text/plain', video.src);
            e.dataTransfer.setData('text/uri-list', video.src);

            // Also set as HTML for more context
            const html = `<video src="${video.src}"></video>`;
            e.dataTransfer.setData('text/html', html);

            // Set effect
            e.dataTransfer.effectAllowed = 'copy';

            console.log('[Content] Video URL set in dataTransfer:', video.src.substring(0, 80));
        }
    }, true);

    // Also handle videos that might be loaded dynamically
    // Make videos draggable if they aren't already
    const makeVideosDraggable = () => {
        document.querySelectorAll('video[src]').forEach(video => {
            if (!video.hasAttribute('draggable')) {
                video.setAttribute('draggable', 'true');
                video.style.cursor = 'grab';
                console.log('[Content] Made video draggable:', video.src.substring(0, 60));
            }
        });
    };

    // Run initially and observe for new videos
    makeVideosDraggable();

    const observer = new MutationObserver((mutations) => {
        let hasNewVideos = false;
        for (const mutation of mutations) {
            if (mutation.addedNodes.length) {
                for (const node of mutation.addedNodes) {
                    if (node.nodeType === 1) {
                        if (node.tagName === 'VIDEO' || node.querySelector?.('video')) {
                            hasNewVideos = true;
                            break;
                        }
                    }
                }
            }
        }
        if (hasNewVideos) {
            setTimeout(makeVideosDraggable, 100);
        }
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    console.log('[Content] Video drag handler ready');
}

// Initialize drag handler on Grok pages
if (window.location.href.includes('grok.com')) {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setupVideoDragHandler);
    } else {
        setupVideoDragHandler();
    }
}

// ==========================================
// Favorites Page: Add to Studio Button
// ==========================================

let favoritesVideoCache = new Map(); // Cache video URLs by post ID

async function setupFavoritesPageButtons() {
    if (!window.location.href.includes('grok.com/imagine/saved')) {
        return;
    }

    console.log('[Content] Setting up Favorites page buttons...');

    // Fetch favorites data to get video URLs
    await fetchAndCacheFavoritesData();

    // Wait a bit for DOM to be ready
    await new Promise(resolve => setTimeout(resolve, 500));

    // Add buttons to existing video cards
    if (studioButtonsActive) {
        addStudioButtonsToCards();
    }

    // Watch for new cards being added (with debounce)
    if (studioButtonsObserver) {
        studioButtonsObserver.disconnect();
    }

    let debounceTimer = null;
    studioButtonsObserver = new MutationObserver(() => {
        // Only add buttons if still active
        if (!studioButtonsActive) return;

        // Debounce to prevent too many calls
        if (debounceTimer) clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
            if (studioButtonsActive) {
                addStudioButtonsToCards();
            }
        }, 300);
    });

    studioButtonsObserver.observe(document.body, {
        childList: true,
        subtree: true
    });
}

async function fetchAndCacheFavoritesData() {
    try {
        console.log('[Content] Fetching favorites data for caching...');

        const API_URL = 'https://grok.com/rest/media/post/list';
        let cursor = null;
        let totalVideos = 0;

        do {
            const payload = {
                limit: 40,
                filter: GrokUtils.buildLikedFilter()
            };

            if (cursor) {
                payload.cursor = cursor;
            }

            const response = await fetch(API_URL, {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                console.error('[Content] API error:', response.status);
                break;
            }

            const data = await response.json();
            const posts = data.posts || [];

            if (posts.length === 0) break;

            // Process posts recursively (including child posts)
            const processPost = (post) => {
                if (post.mediaType === 'MEDIA_POST_TYPE_VIDEO' && post.mediaUrl) {
                    favoritesVideoCache.set(post.id, {
                        url: post.mediaUrl,
                        hdUrl: post.hdMediaUrl || null
                    });
                    totalVideos++;
                }
                // Also check child posts
                if (post.childPosts && post.childPosts.length > 0) {
                    post.childPosts.forEach(processPost);
                }
            };

            posts.forEach(processPost);

            cursor = data.nextCursor;
            if (!cursor) break;

            // Small delay between requests
            await new Promise(resolve => setTimeout(resolve, 100));
        } while (true);

        console.log(`[Content] Cached ${totalVideos} video URLs`);
        // Debug: show cached IDs
        console.log('[Content] Cached post IDs:', Array.from(favoritesVideoCache.keys()).slice(0, 10));
        await SystemLogger.info('Favorites cache built', `Cached ${totalVideos} videos from favorites API`);

    } catch (error) {
        console.error('[Content] Failed to fetch favorites:', error);
        await SystemLogger.fail('Favorites cache failed', `Error: ${error.message}`);
    }
}

function addStudioButtonsToCards() {
    // Try multiple selectors to find video cards
    let postLinks = document.querySelectorAll('a[href*="/imagine/post/"]');

    // If no links found, try other selectors
    if (postLinks.length === 0) {
        // Try finding by poster image URLs (which contain the post ID structure)
        const videoElements = document.querySelectorAll('video[poster], img[src*="assets.grok.com"]');
        console.log(`[Content] Found ${videoElements.length} video/img elements`);

        // Try finding grid items or cards
        const gridItems = document.querySelectorAll('[class*="grid"] > div, [class*="card"], [class*="relative"][class*="aspect"]');
        console.log(`[Content] Found ${gridItems.length} grid/card items`);
    }

    console.log(`[Content] Found ${postLinks.length} post links, cache has ${favoritesVideoCache.size} videos`);

    // Count how many posts have video data vs skipped
    let matchedCount = 0;
    let skippedNoVideo = 0;
    postLinks.forEach(link => {
        const m = link.href.match(/\/imagine\/post\/([^/?]+)/);
        if (m && favoritesVideoCache.has(m[1])) matchedCount++;
        else if (m) skippedNoVideo++;
    });
    SystemLogger.info('Studio buttons scan', `${postLinks.length} post links on page, ${matchedCount} have video data, ${skippedNoVideo} image-only (no button)`);

    // If still no links, try to match by video/image URLs in the DOM
    if (postLinks.length === 0 && favoritesVideoCache.size > 0) {
        console.log('[Content] No post links found, trying to match by media URLs...');
        addButtonsByMediaUrl();
        return;
    }

    // Debug: show first few post IDs from page
    if (postLinks.length > 0 && favoritesVideoCache.size > 0) {
        const pagePostIds = Array.from(postLinks).slice(0, 5).map(link => {
            const match = link.href.match(/\/imagine\/post\/([^/?]+)/);
            return match ? match[1] : 'no-match';
        });
        console.log('[Content] Page post IDs (first 5):', pagePostIds);
    }

    postLinks.forEach(link => {
        // Skip if already has button
        if (link.querySelector('.grok-studio-btn')) return;
        // Also check parent elements for button
        if (link.closest('div')?.querySelector('.grok-studio-btn')) return;

        // Get post ID from href
        const match = link.href.match(/\/imagine\/post\/([^/?]+)/);
        if (!match) return;

        const postId = match[1];

        // Check if we have video data for this post
        const videoData = favoritesVideoCache.get(postId);
        if (!videoData) {
            return;
        }

        console.log(`[Content] Adding button for post ${postId}`);

        // Find a good position for the button (look for the card container)
        const card = link.closest('div[class*="relative"]') || link;

        // Create the button
        const btn = document.createElement('button');
        btn.className = 'grok-studio-btn';
        btn.innerHTML = '📥';
        btn.title = chrome.i18n.getMessage('storyModeAddToStory') || 'Add to Story Mode';
        btn.style.cssText = `
            position: absolute;
            bottom: 8px;
            right: 8px;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: rgba(76, 175, 80, 0.9);
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 100;
            transition: transform 0.2s, background 0.2s;
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        `;

        btn.addEventListener('mouseenter', () => {
            btn.style.transform = 'scale(1.1)';
            btn.style.background = 'rgba(76, 175, 80, 1)';
        });

        btn.addEventListener('mouseleave', () => {
            btn.style.transform = 'scale(1)';
            btn.style.background = 'rgba(76, 175, 80, 0.9)';
        });

        btn.addEventListener('click', async (e) => {
            e.preventDefault();
            e.stopPropagation();

            // Use HD URL if available, otherwise regular URL
            const videoUrl = videoData.hdUrl || videoData.url;

            console.log('[Content] Adding video to studio:', videoUrl.substring(0, 80));

            // Show loading state
            btn.innerHTML = '⏳';
            btn.style.pointerEvents = 'none';

            try {
                // Send to side panel via background
                const result = await chrome.runtime.sendMessage({
                    action: 'fetchAndStoreVideo',
                    url: videoUrl,
                    isMaster: false
                });

                if (result.success) {
                    btn.innerHTML = '✅';
                    btn.style.background = 'rgba(76, 175, 80, 1)';

                    // Show success notification
                    showStudioAddedNotification(postId);

                    // Reset after 2 seconds
                    setTimeout(() => {
                        btn.innerHTML = '📥';
                        btn.style.pointerEvents = 'auto';
                    }, 2000);
                } else {
                    throw new Error(result.error || 'Failed to add video');
                }

            } catch (error) {
                console.error('[Content] Failed to add video:', error);
                btn.innerHTML = '❌';
                btn.style.background = 'rgba(244, 67, 54, 0.9)';

                setTimeout(() => {
                    btn.innerHTML = '📥';
                    btn.style.background = 'rgba(76, 175, 80, 0.9)';
                    btn.style.pointerEvents = 'auto';
                }, 2000);
            }
        });

        // Make sure parent has relative positioning
        if (card !== link) {
            const computedStyle = window.getComputedStyle(card);
            if (computedStyle.position === 'static') {
                card.style.position = 'relative';
            }
            card.appendChild(btn);
        } else {
            link.style.position = 'relative';
            link.appendChild(btn);
        }
    });
}

// Alternative method: add buttons by matching media URLs
function addButtonsByMediaUrl() {
    // Build a reverse lookup from media URL patterns to post data
    const urlToPostId = new Map();
    for (const [postId, data] of favoritesVideoCache.entries()) {
        // Extract the unique part from the URL (usually the UUID)
        if (data.url) {
            // URL format: https://assets.grok.com/users/{userId}/generated/{postId}/generated_video.mp4
            const match = data.url.match(/\/generated\/([^/]+)\//);
            if (match) {
                urlToPostId.set(match[1], { postId, ...data });
            }
            // Also try to match by full URL
            urlToPostId.set(GrokUtils.removeQueryString(data.url), { postId, ...data });
        }
    }

    console.log(`[Content] Built URL lookup with ${urlToPostId.size} entries`);

    // Find all video elements and images that might be thumbnails
    const mediaElements = document.querySelectorAll('video, img[src*="assets.grok.com"]');
    let buttonsAdded = 0;

    mediaElements.forEach(el => {
        const container = el.closest('div[class*="relative"]') || el.closest('div[class*="aspect"]') || el.parentElement;
        if (!container || container.querySelector('.grok-studio-btn')) return;

        // Get the src URL
        const src = el.tagName === 'VIDEO' ? (el.src || el.poster) : el.src;
        if (!src) return;

        // Try to find matching post data
        let postData = null;

        // Method 1: Direct URL match
        const cleanSrc = GrokUtils.removeQueryString(src);
        if (urlToPostId.has(cleanSrc)) {
            postData = urlToPostId.get(cleanSrc);
        }

        // Method 2: Extract UUID from URL and match
        if (!postData) {
            const uuidMatch = src.match(/\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\//i);
            if (uuidMatch) {
                const uuid = uuidMatch[1];
                // Check if this UUID is in our cache
                if (favoritesVideoCache.has(uuid)) {
                    postData = { postId: uuid, ...favoritesVideoCache.get(uuid) };
                }
                // Or check in the URL lookup
                if (!postData && urlToPostId.has(uuid)) {
                    postData = urlToPostId.get(uuid);
                }
            }
        }

        if (!postData) return;

        console.log(`[Content] Adding button for media element, post: ${postData.postId}`);
        buttonsAdded++;

        // Create and add the button
        const btn = createStudioButton(postData);
        container.style.position = 'relative';
        container.appendChild(btn);
    });

    console.log(`[Content] Added ${buttonsAdded} buttons via media URL matching`);
}

function createStudioButton(postData) {
    const btn = document.createElement('button');
    btn.className = 'grok-studio-btn';
    btn.innerHTML = '📥';
    btn.title = 'Add to Story Mode';
    btn.style.cssText = `
        position: absolute;
        bottom: 8px;
        left: 8px;
        width: 32px;
        height: 32px;
        border-radius: 50%;
        background: rgba(76, 175, 80, 0.9);
        color: white;
        border: none;
        cursor: pointer;
        font-size: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 100;
        transition: transform 0.2s, background 0.2s;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    `;

    btn.addEventListener('mouseenter', () => {
        btn.style.transform = 'scale(1.1)';
        btn.style.background = 'rgba(76, 175, 80, 1)';
    });

    btn.addEventListener('mouseleave', () => {
        btn.style.transform = 'scale(1)';
        btn.style.background = 'rgba(76, 175, 80, 0.9)';
    });

    btn.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();

        const videoUrl = postData.hdUrl || postData.url;
        console.log('[Content] Adding video to studio:', videoUrl.substring(0, 80));

        btn.innerHTML = '⏳';
        btn.style.pointerEvents = 'none';

        try {
            // Store video in IndexedDB
            const result = await chrome.runtime.sendMessage({
                action: 'fetchAndStoreVideo',
                url: videoUrl,
                isMaster: false
            });

            if (!result.success) {
                throw new Error(result.error || 'Failed to add video');
            }

            // Notify Side Panel to add this video to storyboard
            await chrome.runtime.sendMessage({
                action: 'videoAddedFromFavorites',
                videoId: result.videoId,
                videoUrl: videoUrl,
                postId: postData.postId
            });

            btn.innerHTML = '✅';
            btn.style.background = 'rgba(76, 175, 80, 1)';
            showStudioAddedNotification(postData.postId);

            setTimeout(() => {
                btn.innerHTML = '📥';
                btn.style.pointerEvents = 'auto';
            }, 2000);

        } catch (error) {
            console.error('[Content] Failed to add video:', error);
            btn.innerHTML = '❌';
            btn.style.background = 'rgba(244, 67, 54, 0.9)';

            setTimeout(() => {
                btn.innerHTML = '📥';
                btn.style.background = 'rgba(76, 175, 80, 0.9)';
                btn.style.pointerEvents = 'auto';
            }, 2000);
        }
    });

    return btn;
}

function showStudioAddedNotification(postId) {
    const existing = document.getElementById('grok-studio-added-notification');
    if (existing) existing.remove();

    const notification = document.createElement('div');
    notification.id = 'grok-studio-added-notification';
    notification.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 12px 20px;
        background: #4CAF50;
        color: white;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        z-index: 999999;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        display: flex;
        align-items: center;
        gap: 8px;
    `;
    notification.innerHTML = `
        <span>✅</span>
        <span>Video added to Studio! Open Side Panel to manage.</span>
    `;

    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transition = 'opacity 0.3s';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Initialize on Favorites page - but only when Side Panel requests it
let studioButtonsActive = false;
let studioButtonsObserver = null;
let lastStudioButtonsUrl = null;

function showStudioButtons() {
    const currentUrl = window.location.href;

    // If URL changed, reset and re-setup
    if (studioButtonsActive && lastStudioButtonsUrl && lastStudioButtonsUrl !== currentUrl) {
        console.log('[Content] URL changed, resetting studio buttons');
        hideStudioButtons();
    }

    if (studioButtonsActive) return;
    studioButtonsActive = true;
    lastStudioButtonsUrl = currentUrl;

    console.log('[Content] Showing studio buttons, URL:', currentUrl);
    SystemLogger.info('Studio buttons show', `storyModeActive: ${storyModeActive}, URL: ${currentUrl.substring(0, 80)}`);

    if (currentUrl.includes('/imagine/post/')) {
        console.log('[Content] Detected: Post Detail page');
        setupPostDetailStudioButton();
    } else if (currentUrl.includes('grok.com/imagine/saved')) {
        console.log('[Content] Detected: Favorites page');
        setupFavoritesPageButtons();
    } else {
        console.log('[Content] Detected: Unknown page, no buttons');
        SystemLogger.warn('Studio buttons: unknown page', `URL does not match post or favorites: ${currentUrl.substring(0, 80)}`);
    }
}

// Monitor URL changes for SPA navigation
let lastCheckedUrl = window.location.href;
setInterval(() => {
    if (window.location.href !== lastCheckedUrl) {
        console.log('[Content] SPA navigation detected:', window.location.href);
        lastCheckedUrl = window.location.href;

        // If studio buttons were active, re-setup for new page
        if (studioButtonsActive) {
            hideStudioButtons();
            showStudioButtons();
        }

        // Re-inject queue UI on SPA navigation (only if queue sidepanel is open)
        const oldQueueInject = document.getElementById('grok-queue-inject');
        if (oldQueueInject) oldQueueInject.remove();
        setTimeout(() => {
            if (queueModeActive) {
                injectAddToQueueUI();
            }
            checkQueueProcessingOnLoad();
        }, 500);
    }
}, 500);

function hideStudioButtons() {
    if (!studioButtonsActive) return;
    studioButtonsActive = false;
    console.log('[Content] Hiding studio buttons...');

    // Remove all studio buttons
    document.querySelectorAll('.grok-studio-btn').forEach(btn => btn.remove());

    // Stop the observers if they exist
    if (studioButtonsObserver) {
        studioButtonsObserver.disconnect();
        studioButtonsObserver = null;
    }

    // Clear post detail polling
    if (postDetailPollInterval) {
        clearInterval(postDetailPollInterval);
        postDetailPollInterval = null;
    }
    currentPostDetailVideoUrl = null;
}

// ==========================================
// Post Detail Page: Dynamic Studio Button
// ==========================================

let currentPostDetailVideoUrl = null;
let postDetailPollInterval = null;

function getCurrentVideoUrl() {
    const hdVideo = document.querySelector('#hd-video');
    const sdVideo = document.querySelector('#sd-video');

    // Debug: log both videos
    console.log('[Content] HD video src:', hdVideo?.src?.substring(0, 80) || 'none');
    console.log('[Content] HD video style:', hdVideo?.getAttribute('style'));
    console.log('[Content] SD video src:', sdVideo?.src?.substring(0, 80) || 'none');
    console.log('[Content] SD video style:', sdVideo?.getAttribute('style'));

    // Priority 1: #hd-video with src (HD version if available and visible)
    if (hdVideo && hdVideo.src && hdVideo.src.includes('.mp4')) {
        const style = hdVideo.getAttribute('style') || '';
        if (!style.includes('visibility: hidden')) {
            return hdVideo.src;
        }
    }

    // Priority 2: #sd-video with src (SD version)
    if (sdVideo && sdVideo.src && sdVideo.src.includes('.mp4')) {
        const style = sdVideo.getAttribute('style') || '';
        if (!style.includes('visibility: hidden')) {
            return sdVideo.src;
        }
    }

    return null;
}

function setupPostDetailStudioButton() {
    console.log('[Content] Setting up Post Detail page studio button...');

    // Clear any existing poll interval
    if (postDetailPollInterval) {
        clearInterval(postDetailPollInterval);
        postDetailPollInterval = null;
    }

    // Wait for video to be ready
    let retryCount = 0;
    const trySetup = () => {
        retryCount++;
        const videoUrl = getCurrentVideoUrl();

        if (!videoUrl) {
            if (retryCount < 20) {
                setTimeout(trySetup, 500);
            }
            return;
        }

        console.log('[Content] Found video URL:', videoUrl.substring(0, 60));

        // Find a container for the button (use the video's parent)
        const video = document.querySelector('#sd-video') || document.querySelector('#hd-video');
        const videoContainer = video?.closest('div[class*="relative"]') ||
                              video?.closest('div[class*="aspect"]') ||
                              video?.parentElement;

        if (!videoContainer) {
            console.log('[Content] No video container found');
            return;
        }

        // Create the button
        addOrUpdatePostDetailButton(videoContainer, videoUrl);

        // Use polling to detect video changes (when user clicks left/right arrows)
        postDetailPollInterval = setInterval(() => {
            if (!studioButtonsActive) {
                clearInterval(postDetailPollInterval);
                postDetailPollInterval = null;
                return;
            }

            const newVideoUrl = getCurrentVideoUrl();
            if (!newVideoUrl) return;

            if (newVideoUrl !== currentPostDetailVideoUrl) {
                console.log('[Content] Video changed to:', newVideoUrl.substring(0, 60));

                const video = document.querySelector('#sd-video') || document.querySelector('#hd-video');
                const container = video?.closest('div[class*="relative"]') ||
                                 video?.closest('div[class*="aspect"]') ||
                                 video?.parentElement;

                if (container) {
                    addOrUpdatePostDetailButton(container, newVideoUrl);
                }
            }
        }, 300);
    };

    trySetup();
}

function addOrUpdatePostDetailButton(container, videoUrl) {
    if (!videoUrl) return;

    currentPostDetailVideoUrl = videoUrl;

    // Remove existing button
    const existingBtn = container.querySelector('.grok-studio-btn');
    if (existingBtn) {
        existingBtn.remove();
    }

    // Create new button with current video URL
    const postData = {
        postId: extractPostIdFromUrl(videoUrl) || 'unknown',
        url: videoUrl,
        hdUrl: null  // We use the current video src directly
    };

    const btn = createStudioButton(postData);

    // Position the button
    container.style.position = 'relative';
    btn.style.bottom = '60px';  // Higher position to avoid player controls
    btn.style.left = '8px';

    container.appendChild(btn);
    console.log('[Content] Studio button added/updated for:', videoUrl.substring(0, 80));
}

function extractPostIdFromUrl(url) {
    // Try to extract post ID from URL like:
    // https://assets.grok.com/users/{userId}/generated/{postId}/generated_video.mp4
    const match = url.match(/\/generated\/([^/]+)\//);
    return match ? match[1] : null;
}

// Check if current page supports studio buttons
function isStudioButtonsPage() {
    const url = window.location.href;
    return url.includes('grok.com/imagine/saved') || url.includes('/imagine/post/');
}

// Listen for port connections from Side Panel
chrome.runtime.onConnect.addListener((port) => {
    if (port.name === 'sidepanel-studio') {
        console.log('[Content] Side Panel connected');
        SystemLogger.info('Studio Side Panel connected', `URL: ${window.location.href.substring(0, 80)}`);
        storyModeActive = true;

        // Listen for messages on this port
        port.onMessage.addListener((message) => {
            if (message.action === 'showStudioButtons') {
                if (isStudioButtonsPage()) {
                    showStudioButtons();
                }
            }
        });

        // On post detail pages, detect available video presets and notify sidepanel
        if (window.location.href.includes('/imagine/post/')) {
            setTimeout(async () => {
                const modes = await detectAvailablePresets();
                if (modes) {
                    chrome.runtime.sendMessage({
                        action: 'availablePresetsDetected',
                        modes: modes
                    }).catch(() => {});
                    console.log('[Content] Sent available presets to sidepanel:', modes);
                }
            }, 2500);
        }

        // When port disconnects (Side Panel closed), hide buttons
        port.onDisconnect.addListener(() => {
            console.log('[Content] Side Panel disconnected, hiding buttons');
            SystemLogger.info('Studio Side Panel disconnected', 'Hiding studio buttons');
            storyModeActive = false;
            hideStudioButtons();
        });
    }

    if (port.name === 'sidepanel-queue') {
        console.log('[Content] Queue Side Panel connected');
        SystemLogger.info('Queue Side Panel connected', `URL: ${window.location.href.substring(0, 80)}`);
        queueModeActive = true;

        port.onMessage.addListener((message) => {
            if (message.action === 'showQueueButtons') {
                if (window.location.href.includes('/imagine/post/')) {
                    injectAddToQueueUI();
                }
            }
        });

        port.onDisconnect.addListener(() => {
            console.log('[Content] Queue Side Panel disconnected, hiding queue UI');
            SystemLogger.info('Queue Side Panel disconnected', 'Hiding queue UI');
            queueModeActive = false;
            removeAddToQueueUI();
        });
    }
});

// ==========================================
// Batch Generation API Functions
// ==========================================

/**
 * Process a batch upload request - upload frame and trigger video generation
 */
async function processBatchUploadRequest(frameData) {
    console.log('[Content] Processing batch upload request:', frameData.batchIndex);

    try {
        const base64Content = frameData.dataUrl.split(',')[1];

        // Step 1: Upload the frame
        const uploadResponse = await fetch('https://grok.com/rest/app-chat/upload-file', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({
                fileName: frameData.filename,
                fileMimeType: 'image/png',
                content: base64Content
            })
        });

        if (!uploadResponse.ok) {
            throw new Error(`Upload failed: HTTP ${uploadResponse.status}`);
        }

        const uploadResult = await uploadResponse.json();
        console.log('[Content] Batch upload result:', uploadResult);

        if (!uploadResult.fileMetadataId) {
            throw new Error('No fileMetadataId in response');
        }

        // Step 2: Get userId and construct mediaUrl
        const userId = document.cookie.match(/x-userid=([^;]+)/)?.[1];
        if (!userId) {
            throw new Error('User not logged in');
        }

        const mediaUrl = `https://assets.grok.com/users/${userId}/${uploadResult.fileMetadataId}/content`;

        // Step 3: Create media post
        const createResponse = await fetch('https://grok.com/rest/media/post/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({
                mediaType: 'MEDIA_POST_TYPE_IMAGE',
                mediaUrl: mediaUrl
            })
        });

        const createResult = await createResponse.json();
        console.log('[Content] Batch create post result:', createResult);

        const postId = createResult.postId || createResult.id || uploadResult.fileMetadataId;

        // Step 4: Like the post to add to favorites (optional, helps with tracking)
        await fetch('https://grok.com/rest/media/post/like', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ id: postId })
        });

        // Step 5: Navigate to post page and submit prompt (trigger video generation)
        // For batch mode, we'll use the API approach if available, or store for later
        if (frameData.prompt) {
            // Store the prompt request for the post detail page
            await chrome.storage.local.set({
                pendingVideoPrompt: {
                    postId: postId,
                    prompt: frameData.prompt,
                    batchIndex: frameData.batchIndex,
                    timestamp: Date.now()
                }
            });

            // Open post detail page in background to trigger video generation
            // The page will detect pendingVideoPrompt and auto-fill
            console.log('[Content] Triggering video generation for batch candidate', frameData.batchIndex);

            // Use the triggerVideoGeneration function if we're not already on the post page
            // For now, just return the postId and let polling handle the rest
        }

        return {
            success: true,
            postId: postId,
            fileMetadataId: uploadResult.fileMetadataId,
            mediaUrl: mediaUrl
        };

    } catch (error) {
        console.error('[Content] Batch upload error:', error);
        return { success: false, error: error.message };
    }
}

/**
 * Check if a video has been generated for a post
 */
async function checkVideoGenerationStatus(postId) {
    console.log('[Content] Checking video status for post:', postId);

    try {
        // Use POST method with proper payload (same as existing code)
        const response = await fetch('https://grok.com/rest/media/post/list', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({
                limit: 50,
                filter: GrokUtils.buildLikedFilter()
            })
        });

        if (!response.ok) {
            throw new Error(`Failed to fetch posts: HTTP ${response.status}`);
        }

        const result = await response.json();
        const posts = result.posts || result.results || [];

        // Find our post
        const post = posts.find(p => p.postId === postId || p.id === postId);

        if (post && post.videoUrl) {
            console.log('[Content] Video found for post:', postId, post.videoUrl);
            return {
                success: true,
                videoUrl: post.videoUrl,
                status: 'ready'
            };
        }

        // Video not ready yet
        return {
            success: true,
            videoUrl: null,
            status: 'generating'
        };

    } catch (error) {
        console.error('[Content] Check status error:', error);
        return { success: false, error: error.message };
    }
}

// showStudioButtons / hideStudioButtons / checkStudioButtonsSupport / processBatchUpload /
// checkVideoStatus are handled by the single whitelisted listener above.

// ==========================================
// Batch Select Delete Mode
// ==========================================

let batchSelectModeActive = false;
let selectedPosts = new Set();
let batchSelectToolbar = null;
let batchSelectStyles = null;
let batchSelectCache = null; // Cache for API data and URL mappings
const BATCH_SELECT_STORAGE_KEY = 'grokBatchSelectedPosts';

/**
 * Save selected posts to chrome.storage.local
 */
async function saveSelectedPostsToStorage() {
    try {
        await chrome.storage.local.set({
            [BATCH_SELECT_STORAGE_KEY]: {
                posts: Array.from(selectedPosts),
                timestamp: Date.now(),
                url: window.location.href
            }
        });
    } catch (e) {
        console.error('[BatchSelect] Failed to save selections:', e);
    }
}

/**
 * Load selected posts from chrome.storage.local
 */
async function loadSelectedPostsFromStorage() {
    try {
        const result = await chrome.storage.local.get(BATCH_SELECT_STORAGE_KEY);
        const data = result[BATCH_SELECT_STORAGE_KEY];

        // Only restore if saved within the last 30 minutes and on same base page
        if (data && data.posts && data.timestamp) {
            const isRecent = (Date.now() - data.timestamp) < 30 * 60 * 1000; // 30 minutes
            const isSamePage = data.url && data.url.includes('/saved');

            if (isRecent && isSamePage) {
                console.log(`[BatchSelect] Restoring ${data.posts.length} selections from storage`);
                return new Set(data.posts);
            }
        }
    } catch (e) {
        console.error('[BatchSelect] Failed to load selections:', e);
    }
    return new Set();
}

/**
 * Clear selected posts from storage
 */
async function clearSelectedPostsFromStorage() {
    try {
        await chrome.storage.local.remove(BATCH_SELECT_STORAGE_KEY);
    } catch (e) {
        console.error('[BatchSelect] Failed to clear selections:', e);
    }
}

/**
 * Enter batch select mode - show checkboxes on each post
 */
async function enterBatchSelectMode() {
    // Check if we're "in mode" but the UI was removed (e.g., SPA navigation)
    if (batchSelectModeActive) {
        const toolbarExists = batchSelectToolbar && document.body.contains(batchSelectToolbar);
        if (toolbarExists) {
            return { success: true, message: 'Already in selection mode' };
        }
        // UI was removed, reset the mode and re-enter
        console.log('[BatchSelect] Mode was active but UI gone, re-entering...');
        batchSelectModeActive = false;
        batchSelectToolbar = null;
        batchSelectStyles = null;
        batchSelectCache = null;
    }

    console.log('[BatchSelect] Entering batch select mode...');
    await SystemLogger.info('Batch select mode entered', 'Scanning posts...');

    // Load previously saved selections from storage
    const savedSelections = await loadSelectedPostsFromStorage();

    // Inject styles
    injectBatchSelectStyles();

    // Find all post cards on the favorites page
    const postCards = await findPostCards();
    if (postCards.length === 0) {
        return { success: false, error: 'No posts found on page' };
    }

    console.log(`[BatchSelect] Found ${postCards.length} posts`);

    // Mark mode as active first
    batchSelectModeActive = true;
    selectedPosts = savedSelections; // Restore saved selections

    // Add checkboxes to each post (will auto-check if in selectedPosts)
    postCards.forEach(card => {
        addCheckboxToPost(card);
    });

    // Create floating toolbar
    createBatchSelectToolbar();
    updateToolbarCount(); // Update count with restored selections

    // Set up mutation observer to handle dynamically loaded posts
    setupBatchSelectObserver();

    return { success: true, postCount: postCards.length, restoredSelections: savedSelections.size };
}

/**
 * Exit batch select mode
 */
async function exitBatchSelectMode() {
    if (!batchSelectModeActive) return;

    console.log('[BatchSelect] Exiting batch select mode...');
    await SystemLogger.info('Batch select mode exited', `${selectedPosts.size} posts were selected`);

    // Clear saved selections from storage
    await clearSelectedPostsFromStorage();

    // Remove all checkboxes
    document.querySelectorAll('.grok-batch-checkbox').forEach(cb => cb.remove());

    // Remove toolbar
    if (batchSelectToolbar) {
        batchSelectToolbar.remove();
        batchSelectToolbar = null;
    }

    // Remove styles
    if (batchSelectStyles) {
        batchSelectStyles.remove();
        batchSelectStyles = null;
    }

    // Stop observer
    if (batchSelectObserver) {
        batchSelectObserver.disconnect();
        batchSelectObserver = null;
    }

    batchSelectModeActive = false;
    selectedPosts.clear();
    batchSelectCache = null;
}

/**
 * Find post cards on the favorites page
 * Uses API data + DOM matching (similar to Story Mode approach)
 * @param {boolean} useCache - If true, use cached data instead of fetching from API
 */
async function findPostCards(useCache = false) {
    const cards = [];
    const seenPostIds = new Set();

    // Method 1: Try links first (fastest)
    const postLinks = document.querySelectorAll('a[href*="/imagine/post/"]');

    if (postLinks.length > 0) {
        console.log(`[BatchSelect] Found ${postLinks.length} post links`);
        postLinks.forEach(link => {
            const href = link.getAttribute('href');
            const match = href.match(/\/imagine\/post\/([^/?]+)/);
            if (!match) return;

            const postId = match[1];
            if (seenPostIds.has(postId)) return;
            seenPostIds.add(postId);

            const container = findCardContainerFromLink(link);
            if (container) {
                cards.push({ element: container, postId: postId });
            }
        });
        return cards;
    }

    // Method 2: Use API + media URL matching
    let postDataMap, urlToPostId;

    if (useCache && batchSelectCache) {
        // Use cached data
        postDataMap = batchSelectCache.postDataMap;
        urlToPostId = batchSelectCache.urlToPostId;
    } else {
        // Fetch from API
        console.log('[BatchSelect] Fetching from API...');
        postDataMap = await fetchFavoritesForBatchSelect();
        console.log(`[BatchSelect] API returned ${postDataMap.size} posts`);

        // Build URL to postId lookup
        urlToPostId = new Map();
        for (const [postId, data] of postDataMap.entries()) {
            if (data.mediaUrl) {
                const url = data.mediaUrl;

                // Pattern 1: UUID format
                const uuidMatch = url.match(/\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\//i);
                if (uuidMatch) {
                    urlToPostId.set(uuidMatch[1].toLowerCase(), postId);
                }

                // Pattern 2: /generated/{id}/ format
                const generatedMatch = url.match(/\/generated\/([^/]+)\//);
                if (generatedMatch) {
                    urlToPostId.set(generatedMatch[1], postId);
                }

                // Pattern 3: Store the post ID itself
                urlToPostId.set(postId, postId);

                // Pattern 4: Clean URL
                urlToPostId.set(GrokUtils.removeQueryString(url), postId);
            }
        }

        // Cache the data
        batchSelectCache = { postDataMap, urlToPostId };
        console.log(`[BatchSelect] Built ${urlToPostId.size} URL mappings`);

        // Debug: show sample API mediaUrls
        const sampleApiUrls = Array.from(postDataMap.entries()).slice(0, 2).map(([id, data]) => ({
            postId: id,
            mediaUrl: data.mediaUrl?.substring(0, 80)
        }));
        console.log(`[BatchSelect] Sample API data:`, sampleApiUrls);
    }

    if (postDataMap.size === 0) {
        return cards;
    }

    // Find media elements
    const mediaElements = document.querySelectorAll('video, img[src*="grok"], img[src*="x.ai"]');
    let matchedCount = 0;
    let unmatchedUrls = [];

    mediaElements.forEach(el => {
        const src = el.tagName === 'VIDEO' ? (el.src || el.poster) : el.src;
        if (!src) return;

        // Skip non-post images (profile pictures, icons, etc.)
        if (src.includes('profile-picture') || src.includes('avatar') || src.includes('icon')) {
            return;
        }

        let postId = null;

        // Method 1: Extract /generated/{postId}/ from URL (same as Story Mode)
        const generatedMatch = src.match(/\/generated\/([^/]+)\//);
        if (generatedMatch) {
            const extractedId = generatedMatch[1];
            if (postDataMap.has(extractedId)) {
                postId = extractedId;
            } else if (urlToPostId.has(extractedId)) {
                postId = urlToPostId.get(extractedId);
            }
        }

        // Method 2: Try UUID match anywhere in URL
        if (!postId) {
            const uuidMatches = src.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi);
            if (uuidMatches) {
                for (const uuid of uuidMatches) {
                    // Check both original case and lowercase
                    if (postDataMap.has(uuid)) {
                        postId = uuid;
                        break;
                    }
                    const lowerUuid = uuid.toLowerCase();
                    if (postDataMap.has(lowerUuid)) {
                        postId = lowerUuid;
                        break;
                    }
                    if (urlToPostId.has(uuid)) {
                        postId = urlToPostId.get(uuid);
                        break;
                    }
                    if (urlToPostId.has(lowerUuid)) {
                        postId = urlToPostId.get(lowerUuid);
                        break;
                    }
                }
            }
        }

        // Method 3: Try matching any postId found in the URL
        if (!postId) {
            for (const [key] of postDataMap.entries()) {
                if (src.includes(key)) {
                    postId = key;
                    break;
                }
            }
        }

        if (postId && !seenPostIds.has(postId)) {
            seenPostIds.add(postId);
            matchedCount++;
            const container = findCardContainerFromMedia(el);
            if (container) {
                // Make sure we don't reuse the same container
                const existingCard = cards.find(c => c.element === container);
                if (existingCard) {
                    console.log(`[BatchSelect] Container reused! PostId ${postId} same container as ${existingCard.postId}`);
                } else {
                    cards.push({ element: container, postId: postId });
                }
            }
        } else if (!postId) {
            // Track unmatched URLs for debugging
            unmatchedUrls.push(src.substring(0, 100));
        }
    });

    console.log(`[BatchSelect] Matched: ${matchedCount}, Unmatched: ${unmatchedUrls.length}`);
    if (unmatchedUrls.length > 0 && unmatchedUrls.length <= 5) {
        console.log(`[BatchSelect] Unmatched URLs:`, unmatchedUrls);
    } else if (unmatchedUrls.length > 5) {
        console.log(`[BatchSelect] Sample unmatched URLs:`, unmatchedUrls.slice(0, 3));
    }
    console.log(`[BatchSelect] Total cards found: ${cards.length}`);
    return cards;
}

/**
 * Fetch favorites data for batch select
 */
async function fetchFavoritesForBatchSelect() {
    const postDataMap = new Map();

    try {
        const API_URL = 'https://grok.com/rest/media/post/list';
        let cursor = null;

        do {
            const payload = {
                limit: 40,
                filter: GrokUtils.buildLikedFilter()
            };
            if (cursor) payload.cursor = cursor;

            const response = await fetch(API_URL, {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!response.ok) break;

            const data = await response.json();
            const posts = data.posts || [];
            if (posts.length === 0) break;

            // Process posts (including child posts)
            const processPost = (post) => {
                postDataMap.set(post.id, {
                    mediaUrl: post.mediaUrl,
                    mediaType: post.mediaType
                });
                if (post.childPosts) {
                    post.childPosts.forEach(processPost);
                }
            };
            posts.forEach(processPost);

            cursor = data.nextCursor;
            if (!cursor) break;

            await new Promise(r => setTimeout(r, 100));
        } while (true);

    } catch (error) {
        console.error('[BatchSelect] API fetch error:', error);
    }

    return postDataMap;
}

/**
 * Find card container from a link element
 */
function findCardContainerFromLink(link) {
    let container = link;
    for (let i = 0; i < 10; i++) {
        const parent = container.parentElement;
        if (!parent || parent.tagName === 'MAIN' || parent.tagName === 'BODY') break;

        const grandparentStyle = parent.parentElement ? window.getComputedStyle(parent.parentElement) : null;
        if (grandparentStyle && grandparentStyle.display === 'grid') {
            return parent;
        }
        container = parent;
    }
    return link.closest('div[class*="relative"]') || link;
}

/**
 * Find card container from a media element
 * Each media element should have its own unique container
 */
function findCardContainerFromMedia(el) {
    // Strategy: Each post card should have its own <a> link or be in its own grid cell

    // First try: Find the closest <a> tag - each post has its own link
    const closestLink = el.closest('a');
    if (closestLink) {
        // Use the link's parent as the container (for proper positioning)
        const linkParent = closestLink.parentElement;
        if (linkParent && linkParent.children.length === 1) {
            // If the link is the only child, use the parent
            return linkParent;
        }
        return closestLink;
    }

    // Second try: Walk up until we find an element that's a direct grid child
    let current = el;
    while (current && current !== document.body) {
        const parent = current.parentElement;
        if (!parent) break;

        const parentStyle = window.getComputedStyle(parent);
        if (parentStyle.display === 'grid') {
            return current;
        }
        current = parent;
    }

    // Fallback: use the media element's immediate parent
    return el.parentElement;
}

/**
 * Extract post ID from an element (kept for compatibility)
 */
function extractPostId(element) {
    // Check href attribute
    const href = element.getAttribute('href') || element.querySelector('a')?.getAttribute('href');
    if (href) {
        const match = href.match(/\/imagine\/post\/([a-zA-Z0-9_-]+)/);
        if (match) return match[1];
    }

    // Check data attributes
    const dataId = element.getAttribute('data-post-id') || element.getAttribute('data-id');
    if (dataId) return dataId;

    return null;
}

/**
 * Find the appropriate card container element (kept for compatibility)
 */
function findCardContainer(element) {
    let current = element;
    for (let i = 0; i < 5; i++) {
        if (!current?.parentElement) break;
        const grandparentStyle = window.getComputedStyle(current.parentElement);
        if (grandparentStyle.display === 'grid') {
            return current;
        }
        current = current.parentElement;
    }
    return element.closest('a')?.parentElement || element.parentElement || element;
}

/**
 * Add checkbox to a post card
 */
function addCheckboxToPost(cardInfo) {
    const { element, postId } = cardInfo;

    // Check if already has checkbox
    if (element.querySelector('.grok-batch-checkbox')) return;

    // Check if this post was previously selected
    const isAlreadySelected = selectedPosts.has(postId);

    // Create checkbox container
    const checkboxContainer = document.createElement('div');
    checkboxContainer.className = 'grok-batch-checkbox';
    checkboxContainer.setAttribute('data-post-id', postId);

    if (isAlreadySelected) {
        checkboxContainer.classList.add('selected');
    }

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = isAlreadySelected; // Restore previous selection state

    checkbox.addEventListener('change', (e) => {
        e.stopPropagation();
        if (checkbox.checked) {
            selectedPosts.add(postId);
            checkboxContainer.classList.add('selected');
        } else {
            selectedPosts.delete(postId);
            checkboxContainer.classList.remove('selected');
        }
        updateToolbarCount();
        saveSelectedPostsToStorage(); // Persist to storage
    });

    // Prevent click from propagating to parent link (but allow checkbox to toggle)
    checkbox.addEventListener('click', (e) => {
        e.stopPropagation();
    });

    // Also handle mousedown to prevent link activation
    checkbox.addEventListener('mousedown', (e) => {
        e.stopPropagation();
    });

    // Handle container clicks to toggle checkbox
    checkboxContainer.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        // If the click is on the container but not directly on checkbox, toggle it
        if (e.target === checkboxContainer) {
            checkbox.checked = !checkbox.checked;
            checkbox.dispatchEvent(new Event('change'));
        }
    });

    checkboxContainer.addEventListener('mousedown', (e) => {
        e.stopPropagation();
    });

    checkboxContainer.appendChild(checkbox);

    // Make the card position relative if needed
    const computedStyle = window.getComputedStyle(element);
    if (computedStyle.position === 'static') {
        element.style.position = 'relative';
    }

    element.appendChild(checkboxContainer);
}

/**
 * Inject CSS styles for batch select mode
 */
function injectBatchSelectStyles() {
    if (batchSelectStyles) return;

    batchSelectStyles = document.createElement('style');
    batchSelectStyles.id = 'grok-batch-select-styles';
    batchSelectStyles.textContent = `
        .grok-batch-checkbox {
            position: absolute;
            top: 4px;
            left: 4px;
            z-index: 100;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 8px;
            padding: 10px;
            cursor: pointer;
            transition: all 0.2s;
            /* Larger click area */
            min-width: 40px;
            min-height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .grok-batch-checkbox:hover {
            background: rgba(0, 0, 0, 0.9);
            transform: scale(1.1);
        }

        .grok-batch-checkbox.selected {
            background: rgba(102, 126, 234, 0.9);
        }

        .grok-batch-checkbox input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
            accent-color: #667eea;
        }

        .grok-batch-toolbar {
            position: fixed;
            top: 16px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 10000;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            border-radius: 12px;
            padding: 12px 20px;
            display: flex;
            align-items: center;
            gap: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .grok-batch-toolbar-count {
            color: #fff;
            font-size: 14px;
            font-weight: 600;
            min-width: 120px;
        }

        .grok-batch-toolbar-btn {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }

        .grok-batch-toolbar-btn:hover {
            transform: translateY(-1px);
        }

        .grok-batch-toolbar-btn.select-all {
            background: #4a5568;
            color: #fff;
        }

        .grok-batch-toolbar-btn.select-all:hover {
            background: #5a6578;
        }

        .grok-batch-toolbar-btn.delete {
            background: #e53e3e;
            color: #fff;
        }

        .grok-batch-toolbar-btn.delete:hover {
            background: #c53030;
        }

        .grok-batch-toolbar-btn.delete:disabled {
            background: #666;
            cursor: not-allowed;
            opacity: 0.5;
        }

        .grok-batch-toolbar-btn.cancel {
            background: transparent;
            color: #a0aec0;
            border: 1px solid #4a5568;
        }

        .grok-batch-toolbar-btn.cancel:hover {
            background: #4a5568;
            color: #fff;
        }

        /* Confirmation Modal */
        .grok-batch-modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            z-index: 10001;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .grok-batch-modal {
            background: #1a1a2e;
            border-radius: 16px;
            padding: 24px;
            max-width: 400px;
            width: 90%;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .grok-batch-modal h3 {
            color: #fff;
            font-size: 18px;
            margin: 0 0 16px 0;
        }

        .grok-batch-modal p {
            color: #a0aec0;
            font-size: 14px;
            margin: 0 0 20px 0;
            line-height: 1.5;
        }

        .grok-batch-modal-options {
            margin-bottom: 20px;
        }

        .grok-batch-modal-option {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            padding: 12px;
            margin-bottom: 8px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.2s;
        }

        .grok-batch-modal-option:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .grok-batch-modal-option input[type="radio"] {
            margin-top: 2px;
            accent-color: #667eea;
        }

        .grok-batch-modal-option-content {
            flex: 1;
        }

        .grok-batch-modal-option-title {
            color: #fff;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 4px;
        }

        .grok-batch-modal-option-desc {
            color: #718096;
            font-size: 12px;
        }

        .grok-batch-modal-warning {
            color: #fc8181;
            font-size: 12px;
            margin-top: 4px;
        }

        .grok-batch-modal-actions {
            display: flex;
            gap: 12px;
            justify-content: flex-end;
        }

        .grok-batch-modal-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }

        .grok-batch-modal-btn.cancel {
            background: #4a5568;
            color: #fff;
        }

        .grok-batch-modal-btn.confirm {
            background: #e53e3e;
            color: #fff;
        }

        .grok-batch-modal-btn:hover {
            opacity: 0.9;
            transform: translateY(-1px);
        }

        /* Progress indicator */
        .grok-batch-progress {
            color: #a0aec0;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .grok-batch-progress-spinner {
            width: 16px;
            height: 16px;
            border: 2px solid #4a5568;
            border-top-color: #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    `;
    document.head.appendChild(batchSelectStyles);
}

/**
 * Create the floating toolbar
 */
function createBatchSelectToolbar() {
    if (batchSelectToolbar) return;

    const selectAllText = chrome.i18n.getMessage('batchSelectSelectAll') || 'Select All';
    const deleteText = chrome.i18n.getMessage('batchSelectDelete') || '🗑️ Delete';
    const cancelText = chrome.i18n.getMessage('batchDeleteCancel') || 'Cancel';

    batchSelectToolbar = document.createElement('div');
    batchSelectToolbar.className = 'grok-batch-toolbar';
    batchSelectToolbar.innerHTML = `
        <span class="grok-batch-toolbar-count">Selected: 0</span>
        <button class="grok-batch-toolbar-btn select-all">${selectAllText}</button>
        <button class="grok-batch-toolbar-btn delete" disabled>${deleteText}</button>
        <button class="grok-batch-toolbar-btn cancel">${cancelText}</button>
    `;

    // Event listeners
    const selectAllBtn = batchSelectToolbar.querySelector('.select-all');
    const deleteBtn = batchSelectToolbar.querySelector('.delete');
    const cancelBtn = batchSelectToolbar.querySelector('.cancel');

    selectAllBtn.addEventListener('click', toggleSelectAll);
    deleteBtn.addEventListener('click', showDeleteConfirmation);
    cancelBtn.addEventListener('click', exitBatchSelectMode);

    document.body.appendChild(batchSelectToolbar);
}

/**
 * Update the selected count in toolbar
 */
function updateToolbarCount() {
    if (!batchSelectToolbar) return;

    const countSpan = batchSelectToolbar.querySelector('.grok-batch-toolbar-count');
    const deleteBtn = batchSelectToolbar.querySelector('.delete');
    const selectAllBtn = batchSelectToolbar.querySelector('.select-all');

    const count = selectedPosts.size;
    const totalPosts = batchSelectCache?.postDataMap?.size || 0;

    // Show selected count and total from API
    const selectedText = totalPosts > 0
        ? (chrome.i18n.getMessage('batchSelectSelected', [String(count), String(totalPosts)]) || `Selected: ${count} / ${totalPosts}`)
        : `Selected: ${count}`;
    countSpan.textContent = selectedText;
    deleteBtn.disabled = count === 0;

    // Update select all button text (based on total from API, not just visible)
    const selectAllText = chrome.i18n.getMessage('batchSelectSelectAll') || 'Select All';
    const deselectAllText = chrome.i18n.getMessage('batchSelectDeselectAll') || 'Deselect All';
    selectAllBtn.textContent = (totalPosts > 0 && count === totalPosts) ? deselectAllText : selectAllText;
}

/**
 * Toggle select all / deselect all
 * Uses API cache to select ALL posts, not just visible ones
 */
function toggleSelectAll() {
    // Get total posts from cache (includes non-visible ones)
    const totalPosts = batchSelectCache?.postDataMap?.size || 0;
    const allPostIds = batchSelectCache?.postDataMap ? Array.from(batchSelectCache.postDataMap.keys()) : [];

    // Check if all are selected (comparing against total from API, not just visible)
    const allSelected = totalPosts > 0 && selectedPosts.size === totalPosts;

    if (allSelected) {
        // Deselect all
        selectedPosts.clear();
    } else {
        // Select all (including non-visible ones)
        allPostIds.forEach(postId => {
            selectedPosts.add(postId);
        });
    }

    // Update visible checkboxes to reflect the selection state
    const checkboxes = document.querySelectorAll('.grok-batch-checkbox input[type="checkbox"]');
    checkboxes.forEach(cb => {
        const container = cb.closest('.grok-batch-checkbox');
        const postId = container.getAttribute('data-post-id');
        const isSelected = selectedPosts.has(postId);

        cb.checked = isSelected;
        if (isSelected) {
            container.classList.add('selected');
        } else {
            container.classList.remove('selected');
        }
    });

    updateToolbarCount();
    saveSelectedPostsToStorage(); // Persist to storage
}

/**
 * Show delete confirmation modal
 */
function showDeleteConfirmation() {
    if (selectedPosts.size === 0) return;

    const i18n = (key, ...args) => {
        const msg = chrome.i18n.getMessage(key, args);
        return msg || key; // Fallback to key if message not found
    };

    const overlay = document.createElement('div');
    overlay.className = 'grok-batch-modal-overlay';
    overlay.innerHTML = `
        <div class="grok-batch-modal">
            <h3>${i18n('batchDeleteConfirmTitle')}</h3>
            <p>${i18n('batchDeleteConfirmMsg', String(selectedPosts.size))}</p>

            <div class="grok-batch-modal-options">
                <label class="grok-batch-modal-option">
                    <input type="radio" name="deleteOption" value="unfavorite" checked>
                    <div class="grok-batch-modal-option-content">
                        <div class="grok-batch-modal-option-title">${i18n('batchDeleteOptionUnfavorite')}</div>
                        <div class="grok-batch-modal-option-desc">${i18n('batchDeleteOptionUnfavoriteDesc')}</div>
                    </div>
                </label>
                <label class="grok-batch-modal-option">
                    <input type="radio" name="deleteOption" value="delete">
                    <div class="grok-batch-modal-option-content">
                        <div class="grok-batch-modal-option-title">${i18n('batchDeleteOptionDelete')}</div>
                        <div class="grok-batch-modal-option-desc">${i18n('batchDeleteOptionDeleteDesc')}</div>
                        <div class="grok-batch-modal-warning">${i18n('batchDeleteWarning')}</div>
                    </div>
                </label>
            </div>

            <div class="grok-batch-modal-actions">
                <button class="grok-batch-modal-btn cancel">${i18n('batchDeleteCancel')}</button>
                <button class="grok-batch-modal-btn confirm">${i18n('batchDeleteConfirm')}</button>
            </div>
        </div>
    `;

    const cancelBtn = overlay.querySelector('.grok-batch-modal-btn.cancel');
    const confirmBtn = overlay.querySelector('.grok-batch-modal-btn.confirm');

    cancelBtn.addEventListener('click', () => overlay.remove());

    confirmBtn.addEventListener('click', async () => {
        const deleteOption = overlay.querySelector('input[name="deleteOption"]:checked').value;
        const deletePost = deleteOption === 'delete';

        // Show progress in toolbar
        showDeleteProgress();

        overlay.remove();

        // Execute deletion
        await executeBatchDelete(Array.from(selectedPosts), deletePost);
    });

    // Close on overlay click
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) overlay.remove();
    });

    document.body.appendChild(overlay);
}

/**
 * Show delete progress in toolbar
 */
function showDeleteProgress() {
    if (!batchSelectToolbar) return;

    const progressMsg = chrome.i18n.getMessage('batchDeleteProgress', ['0', String(selectedPosts.size)]) || `Deleting... 0/${selectedPosts.size}`;
    const waitMsg = chrome.i18n.getMessage('batchDeletePleaseWait') || 'Please wait...';

    const toolbar = batchSelectToolbar;
    toolbar.innerHTML = `
        <div class="grok-batch-progress">
            <div class="grok-batch-progress-spinner"></div>
            <span>${progressMsg}</span>
        </div>
        <button class="grok-batch-toolbar-btn cancel" disabled>${waitMsg}</button>
    `;
}

/**
 * Update delete progress
 */
function updateDeleteProgress(current, total) {
    const progressText = batchSelectToolbar?.querySelector('.grok-batch-progress span');
    if (progressText) {
        const msg = chrome.i18n.getMessage('batchDeleteProgress', [String(current), String(total)]) || `Deleting... ${current}/${total}`;
        progressText.textContent = msg;
    }
}

/**
 * Execute batch deletion
 */
async function executeBatchDelete(postIds, deletePost = false) {
    console.log(`[BatchSelect] Starting batch delete: ${postIds.length} posts, deletePost: ${deletePost}`);
    await SystemLogger.info('Batch delete started', `Total: ${postIds.length}, Delete post: ${deletePost}`);

    const total = postIds.length;
    let successCount = 0;
    let failCount = 0;

    for (let i = 0; i < postIds.length; i++) {
        const postId = postIds[i];
        updateDeleteProgress(i + 1, total);

        try {
            // Step 1: Unfavorite the post
            const unfavResult = await unfavoritePost(postId);
            if (!unfavResult.success) {
                console.error(`[BatchSelect] Failed to unfavorite ${postId}:`, unfavResult.error);
                failCount++;
                continue;
            }

            // Step 2: Delete post if requested
            if (deletePost) {
                const deleteResult = await deletePostById(postId);
                if (!deleteResult.success) {
                    console.error(`[BatchSelect] Failed to delete ${postId}:`, deleteResult.error);
                    // Still count as partial success since unfavorite worked
                }
            }

            successCount++;

            // Remove the post element from DOM
            removePostFromDOM(postId);

            // Small delay between API calls
            await new Promise(r => setTimeout(r, 200));

        } catch (error) {
            console.error(`[BatchSelect] Error processing ${postId}:`, error);
            failCount++;
        }
    }

    console.log(`[BatchSelect] Batch delete complete: ${successCount} success, ${failCount} failed`);
    await SystemLogger.info('Batch delete completed', `Success: ${successCount}, Failed: ${failCount}`);

    // Show completion message and exit
    showDeleteComplete(successCount, failCount, total);
}

/**
 * Unfavorite a post via API (same as Bulk Remove)
 */
async function unfavoritePost(postId) {
    try {
        const response = await fetch('https://grok.com/rest/media/post/unlike', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ id: postId })
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        return { success: true };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

/**
 * Delete a post via API (same as Bulk Remove)
 */
async function deletePostById(postId) {
    try {
        const response = await fetch('https://grok.com/rest/media/post/delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ id: postId })
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        return { success: true };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

/**
 * Remove a post element from the DOM
 */
function removePostFromDOM(postId) {
    const checkbox = document.querySelector(`.grok-batch-checkbox[data-post-id="${postId}"]`);
    if (checkbox) {
        const card = checkbox.parentElement;
        if (card) {
            card.style.transition = 'opacity 0.3s, transform 0.3s';
            card.style.opacity = '0';
            card.style.transform = 'scale(0.8)';
            setTimeout(() => card.remove(), 300);
        }
    }
}

/**
 * Show deletion complete message
 */
function showDeleteComplete(success, failed, total) {
    if (!batchSelectToolbar) return;

    const message = failed > 0
        ? (chrome.i18n.getMessage('batchDeleteCompleteWithFail', [String(success), String(failed)]) || `✅ Completed: ${success} deleted, ${failed} failed`)
        : (chrome.i18n.getMessage('batchDeleteComplete', [String(success)]) || `✅ Successfully deleted ${success} items`);

    const closeText = chrome.i18n.getMessage('batchDeleteClose') || 'Close';

    batchSelectToolbar.innerHTML = `
        <span class="grok-batch-toolbar-count">${message}</span>
        <button class="grok-batch-toolbar-btn cancel">${closeText}</button>
    `;

    const closeBtn = batchSelectToolbar.querySelector('.cancel');
    closeBtn.addEventListener('click', exitBatchSelectMode);

    // Auto close after 3 seconds
    setTimeout(exitBatchSelectMode, 3000);
}

/**
 * MutationObserver for dynamically loaded posts
 */
let batchSelectObserver = null;

function setupBatchSelectObserver() {
    if (batchSelectObserver) return;

    let debounceTimer = null;

    batchSelectObserver = new MutationObserver((mutations) => {
        if (!batchSelectModeActive) return;

        // Debounce to avoid too many calls
        if (debounceTimer) clearTimeout(debounceTimer);
        debounceTimer = setTimeout(async () => {
            if (!batchSelectModeActive) return;

            // Find new cards using cached data (don't refetch from API)
            const newCards = await findPostCards(true);
            newCards.forEach(card => {
                if (!card.element.querySelector('.grok-batch-checkbox')) {
                    addCheckboxToPost(card);
                }
            });
        }, 1000); // Longer debounce to reduce API calls
    });

    batchSelectObserver.observe(document.body, {
        childList: true,
        subtree: true
    });
}

// ==========================================
// Video Gen Queue - Processing Logic (DOM-based)
// ==========================================

/**
 * Fallback listener for video generation results via postMessage.
 * If the normal relay chain (intercept → bridge → background → content.js)
 * fails to deliver queueItemResult within 5 seconds, this fallback
 * checks the DB state directly and continues queue processing.
 */
window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    if (!event.data || event.data.type !== 'GROK_VIDEO_GEN_RESULT') return;
    if (!queueProcessingActive) return;

    const moderated = event.data.payload?.moderated === true;
    _queueResultPending = true;
    queueWaitingForResult = false; // Result received, allow new actions
    if (window._queueSubmitTimeout) { clearTimeout(window._queueSubmitTimeout); window._queueSubmitTimeout = null; }

    // Wait 5s for the normal handleQueueItemResult to fire (via bridge → background → content)
    setTimeout(async () => {
        if (!_queueResultPending) return; // Normal chain handled it
        _queueResultPending = false;

        console.log('[Queue] Fallback: normal relay chain timeout, re-sending result to background...');
        SystemLogger.warn('Queue fallback triggered', `moderated: ${moderated}, resultId: ${event.data.payload?.resultId}`);

        try {
            // Re-send the SAME result through the canonical background handler.
            // background dedupes on resultId, enforces the usage limit, updates the
            // DB once, and relays queueItemResult back to this tab — so the normal
            // handleQueueItemResult flow takes over from here.
            const p = event.data.payload || {};
            const resp = await chrome.runtime.sendMessage({
                action: 'videoGenResult',
                resultId: p.resultId,
                parentPostId: p.parentPostId,
                videoPostId: p.videoPostId,
                moderated: p.moderated === true,
                videoPrompt: p.videoPrompt || ''
            });

            if (resp && resp.success && !resp.queued) {
                if (resp.nextItem) {
                    SystemLogger.info('Queue fallback: moving to next', `PostId: ${resp.nextItem.postId}`);
                    await processQueueItem(resp.nextItem, true);
                } else {
                    // No active item and nothing pending — queue finished or was cleared.
                    queueProcessingActive = false;
                    chrome.storage.local.set({
                        queueProcessingState: { isProcessing: false, currentItemId: null }
                    });
                    SystemLogger.info('Queue fallback: no active item', 'Stopping processing');
                }
            }
        } catch (error) {
            console.error('[Queue] Fallback error:', error);
            SystemLogger.fail('Queue fallback error', error.message);
        }
    }, 5000);
});

/**
 * Listen for 429 rate limit from intercept.js — stop queue and notify user
 */
window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    if (!event.data || event.data.type !== 'GROK_RATE_LIMITED') return;
    if (!queueProcessingActive) return;

    console.warn('[Queue] 429 Rate Limited — stopping queue');
    SystemLogger.fail('Queue rate limited', '429 Too Many Requests — queue stopped');

    queueProcessingActive = false;
    queueWaitingForResult = false;
    chrome.storage.local.set({
        queueProcessingState: { isProcessing: false, currentItemId: null }
    });

    // Set current active item to error status with rate limit message
    (async () => {
        const resp = await chrome.runtime.sendMessage({ action: 'getActiveQueueItem' });
        if (resp.success && resp.item) {
            await chrome.runtime.sendMessage({
                action: 'updateQueueItem',
                id: resp.item.id,
                updates: {
                    status: 'error',
                    errorMessage: chrome.i18n.getMessage('queueRateLimited') || '429 Too Many Requests — please wait and try again'
                }
            });
        }
        // Notify sidepanel
        chrome.runtime.sendMessage({
            action: 'queueItemError',
            error: chrome.i18n.getMessage('queueRateLimited') || '429 Too Many Requests — please wait and try again'
        }).catch(() => {});
    })();
});

/**
 * Start queue processing: get next pending item and begin
 */
async function startQueueProcessing() {
    try {
        // Rescue items stranded in 'active' by a crash/tab-close (>10 min stale).
        // A live generation bumps updatedAt on every result, so it never goes
        // 10 min without an update — this can't yank an item out from under an
        // actively-processing tab. A crashed run becomes recoverable instead of
        // stuck forever. After this, the resume-active branch below only ever
        // sees FRESH active items (a legitimately in-flight run), which is
        // exactly when resuming is correct.
        await chrome.runtime.sendMessage({ action: 'reconcileQueueActive' }).catch(() => {});

        // Check usage limit before starting
        const usage = await chrome.runtime.sendMessage({ action: 'getQueueUsage' });
        if (usage.success && !usage.isPro && usage.count >= usage.limit) {
            return { success: false, error: chrome.i18n.getMessage('queueUsageLimitReached') || 'Free usage limit reached (50). Upgrade to Pro for unlimited use.' };
        }

        const resp = await chrome.runtime.sendMessage({ action: 'getNextPendingItem' });
        if (!resp.success || !resp.item) {
            // Check if there's an active item to resume
            const activeResp = await chrome.runtime.sendMessage({ action: 'getActiveQueueItem' });
            if (activeResp.success && activeResp.item) {
                queueProcessingActive = true;
                SystemLogger.info('Queue resumed', `Resuming item: ${activeResp.item.postId}`);
                await processQueueItem(activeResp.item, false);
                return { success: true };
            }
            return { success: false, error: 'No pending items in queue' };
        }

        queueProcessingActive = true;

        // Count total pending
        const allResp = await chrome.runtime.sendMessage({ action: 'getAllQueueItems' });
        const pendingCount = (allResp.items || []).filter(i => i.status === 'pending').length;
        SystemLogger.info('Queue started', `Items: ${pendingCount}`);

        await processQueueItem(resp.item, true);
        return { success: true };
    } catch (error) {
        console.error('[Queue] Failed to start:', error);
        return { success: false, error: error.message };
    }
}

/**
 * Process a single queue item — navigate to post page and fill prompt
 * @param {Object} item - Queue item to process
 * @param {boolean} navigate - Whether to navigate to the post page
 */
async function processQueueItem(item, navigate = true) {
    if (!queueProcessingActive) return;

    try {
        // Set item to active
        await chrome.runtime.sendMessage({
            action: 'updateQueueItem',
            id: item.id,
            updates: { status: 'active' }
        });

        const targetUrl = `https://grok.com/imagine/post/${item.postId}`;
        // Force navigate if current page doesn't match the target post detail page
        const onCorrectPage = window.location.pathname.includes(`/imagine/post/${item.postId}`);
        if (!navigate && !onCorrectPage) {
            console.log(`[Queue] Not on correct page (${window.location.pathname}), forcing navigation`);
            navigate = true;
        }
        SystemLogger.info('Queue item processing', `PostId: ${item.postId}, Navigate: ${navigate}, Prompt: "${item.prompt.substring(0, 50)}...", Target URL: ${targetUrl}`);

        if (navigate) {
            // Store queue processing state for cross-page resumption
            // redirectCount is reset on each new navigation so Grok-redirect loop detection
            // starts fresh for every queue item.
            await chrome.storage.local.set({
                queueProcessingState: {
                    isProcessing: true,
                    currentItemId: item.id,
                    navigateTimestamp: Date.now(),
                    redirectCount: 0
                }
            });

            // Navigate to the post page
            SystemLogger.info('Queue navigating', `Navigating to: ${targetUrl}`);
            window.location.href = targetUrl;
        } else {
            // Already on the page — fill and submit
            await queueFillAndSubmit(item);
        }
    } catch (error) {
        console.error('[Queue] Error processing item:', error);
        SystemLogger.fail('Queue item error', `PostId: ${item.postId}, Error: ${error.message}`);
        await chrome.runtime.sendMessage({
            action: 'queueItemError',
            error: error.message
        });
        // Auto-advance to next item instead of stopping
        autoAdvanceQueue();
    }
}

/**
 * Auto-advance queue to the next pending item after an error.
 * Instead of stopping the queue, mark error and continue processing.
 */
async function autoAdvanceQueue(delayMs = 3000) {
    if (!queueProcessingActive) return;

    await new Promise(r => setTimeout(r, delayMs));

    if (!queueProcessingActive) return; // User may have paused/stopped during delay

    try {
        const resp = await chrome.runtime.sendMessage({ action: 'getNextPendingItem' });
        if (resp.success && resp.item) {
            SystemLogger.info('Queue auto-advancing', `Next PostId: ${resp.item.postId}`);
            await processQueueItem(resp.item, true);
        } else {
            // No more items
            queueProcessingActive = false;
            chrome.storage.local.set({
                queueProcessingState: { isProcessing: false, currentItemId: null }
            });
            SystemLogger.info('Queue completed', 'All items processed (after error)');
            chrome.runtime.sendMessage({ action: 'queueProgressUpdate', allDone: true }).catch(() => {});
        }
    } catch (error) {
        console.error('[Queue] Auto-advance failed:', error);
        queueProcessingActive = false;
    }
}

/**
 * V2 UI: Switch from image mode to video mode if needed.
 * Scenarios:
 *   A) Already on video post → submit "Make video" enabled → no-op
 *   B) On post with Video/Image toggle (has video child) → click "Video" toggle
 *   C) On fresh image post (no video yet) → Settings dropdown → "Make Video" menuitem
 */
async function switchToVideoModeIfNeeded() {
    // Check if already in video mode:
    // - Submit button has aria-label="Make video" (may still be disabled during hydration)
    // - OR contenteditable exists (V2 video mode always has one)
    const findSubmitBtn = () => Array.from(document.querySelectorAll('button')).find(b => {
        const paths = b.querySelectorAll('svg path');
        for (const p of paths) {
            if ((p.getAttribute('d') || '').includes('M12 5V19')) return true;
        }
        return false;
    });

    const svgBtn = findSubmitBtn();
    const svgLabel = svgBtn?.getAttribute('aria-label') || '';
    // Check button text content as fallback (some labels are in textContent, not aria-label)
    const svgText = svgBtn?.textContent?.trim() || '';

    // Only skip mode switch if we're SURE we're in video mode.
    // Check both aria-label and textContent for "make video" (case-insensitive, any language).
    // "video" keyword appears in video mode labels across languages but not in edit/image mode.
    const isVideoLabel = /video|影片|ビデオ|비디오/i.test(svgLabel + ' ' + svgText);
    if (svgBtn && isVideoLabel) {
        if (!svgBtn.disabled) {
            console.log(`[Queue] Already in video mode and enabled (label="${svgLabel}"), no switch needed`);
            return;
        }

        // Button is in video mode but disabled — this happens on video post pages where Grok
        // redirected us from an image post. On these pages, clicking a mode preset (Normal/Fun)
        // alone does NOT enable the button. We need to click "重做" (Redo) which prepares a
        // fresh generation context and immediately enables the button.
        console.log(`[Queue] Video mode button disabled — looking for 重做 (Redo) in settings menu...`);

        const evtOpts = { bubbles: true, cancelable: true, view: window };
        const simulateClickLocal = (el) => {
            el.dispatchEvent(new PointerEvent('pointerdown', { ...evtOpts, pointerId: 1 }));
            el.dispatchEvent(new MouseEvent('mousedown', evtOpts));
            el.dispatchEvent(new PointerEvent('pointerup', { ...evtOpts, pointerId: 1 }));
            el.dispatchEvent(new MouseEvent('mouseup', evtOpts));
            el.dispatchEvent(new MouseEvent('click', evtOpts));
        };

        // Find settings button near contenteditable
        const editables = Array.from(document.querySelectorAll('[contenteditable="true"]'))
            .filter(el => el.id !== 'grok-queue-prompt' && !el.closest('#grok-queue-fab'));
        let settingsBtnForRedo = null;
        if (editables.length > 0) {
            let parent = editables[0].parentElement;
            for (let i = 0; i < 8 && parent; i++) {
                settingsBtnForRedo = parent.querySelector('button[aria-haspopup="menu"]');
                if (settingsBtnForRedo) break;
                parent = parent.parentElement;
            }
        }

        if (settingsBtnForRedo) {
            let menu = null;
            for (let attempt = 0; attempt < 3 && !menu; attempt++) {
                simulateClickLocal(settingsBtnForRedo);
                await new Promise(r => setTimeout(r, 600));
                menu = document.querySelector('[role="menu"]');
            }
            if (menu) {
                const redoItem = Array.from(menu.querySelectorAll('[role="menuitem"]'))
                    .find(el => /^(重做|Redo|やり直し|다시 하기)/i.test(el.innerText?.trim()));
                if (redoItem) {
                    console.log('[Queue] Found 重做 — clicking to enable button...');
                    redoItem.click();
                    // Wait for Grok SPA to navigate to the redo context (new postId)
                    await new Promise(r => setTimeout(r, 2000));
                    console.log('[Queue] 重做 clicked — redo context ready, new URL:', window.location.href.split('/').pop());
                } else {
                    console.log('[Queue] No 重做 found in menu, closing menu');
                    simulateClickLocal(settingsBtnForRedo);
                }
            }
        }
        return;
    }

    // For any other label (Edit/編輯/Submit/unknown), attempt mode switch.
    // If already in video mode with an unrecognized label, the switch function
    // will find no "Make Video" menuitem and return gracefully.
    console.log(`[Queue] V2: Attempting to switch to video mode (label="${svgLabel}", text="${svgText}")...`);

    // Strategy 1: Click "Video" toggle in Media type selection (post already has video child)
    const mediaSelection = document.querySelector('[aria-label="Media type selection"]');
    if (mediaSelection) {
        const videoToggle = Array.from(mediaSelection.querySelectorAll('button'))
            .find(b => b.textContent?.trim() === 'Video');
        if (videoToggle) {
            console.log('[Queue] V2: Found Video/Image toggle, clicking "Video"...');
            videoToggle.click();
            await new Promise(r => setTimeout(r, 1500));
            // Verify switch worked
            const btn = findSubmitBtn();
            if (btn && !btn.disabled && btn.getAttribute('aria-label') === 'Make video') {
                console.log('[Queue] V2: Switched to video mode via toggle');
                return;
            }
            console.log('[Queue] V2: Video toggle clicked but submit not ready, trying Settings dropdown...');
        }
    }

    // Strategy 2: Settings dropdown → "Make Video" menuitem (fresh image post, no video yet)
    let settingsBtn = null;
    const editables = Array.from(document.querySelectorAll('[contenteditable="true"]'))
        .filter(el => el.id !== 'grok-queue-prompt' && !el.closest('#grok-queue-fab'));
    if (editables.length > 0) {
        let parent = editables[0].parentElement;
        for (let i = 0; i < 8 && parent; i++) {
            settingsBtn = parent.querySelector('button[aria-haspopup="menu"]');
            if (settingsBtn) break;
            parent = parent.parentElement;
        }
    }

    if (!settingsBtn) {
        console.log('[Queue] V2: Settings button not found, skipping mode switch');
        return;
    }

    // Try multiple click strategies with retry (page may still be hydrating)
    const evtOpts = { bubbles: true, cancelable: true, view: window };
    const simulateClick = (el) => {
        el.dispatchEvent(new PointerEvent('pointerdown', { ...evtOpts, pointerId: 1 }));
        el.dispatchEvent(new MouseEvent('mousedown', evtOpts));
        el.dispatchEvent(new PointerEvent('pointerup', { ...evtOpts, pointerId: 1 }));
        el.dispatchEvent(new MouseEvent('mouseup', evtOpts));
        el.dispatchEvent(new MouseEvent('click', evtOpts));
    };

    let menu = null;
    for (let clickAttempt = 0; clickAttempt < 5; clickAttempt++) {
        if (clickAttempt === 0) {
            settingsBtn.click();
        } else if (clickAttempt === 1) {
            simulateClick(settingsBtn);
        } else {
            settingsBtn.focus();
            settingsBtn.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true }));
            settingsBtn.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', bubbles: true }));
        }

        await new Promise(r => setTimeout(r, 600));
        menu = document.querySelector('[role="menu"]');
        if (menu) break;
        console.log(`[Queue] V2: Menu not open, retrying (${clickAttempt + 1}/5)...`);
    }

    if (!menu) {
        console.log('[Queue] V2: Menu did not open after 5 attempts');
        return;
    }

    // Look for "Make Video" menuitem
    const items = menu.querySelectorAll('[role="menuitem"]');
    let makeVideoItem = null;
    for (const item of items) {
        const text = item.innerText?.trim();
        if (text && (text.startsWith('Make Video') || text.startsWith('製作影片'))) {
            makeVideoItem = item;
            break;
        }
    }

    if (makeVideoItem) {
        console.log('[Queue] V2: Found "Make Video" menuitem, clicking to switch mode...');
        makeVideoItem.click();
        await new Promise(r => setTimeout(r, 1000));
        console.log('[Queue] V2: Switched to video mode via Settings');
    } else {
        // No "Make Video" found — already in video mode (presets shown instead)
        console.log('[Queue] V2: "Make Video" not found in menu, already in video mode');
        // Close dropdown by clicking Settings button again (Escape navigates the page away!)
        settingsBtn.click();
        await new Promise(r => setTimeout(r, 200));
    }
}

/**
 * V2 UI: Apply video settings (duration, resolution, mode) by clicking the UI controls.
 * More reliable than relying solely on intercept.js request body patching.
 * Opens Settings dropdown, clicks the correct buttons/menuitems, then closes.
 */
async function applyVideoSettingsV2(settingsBtn, videoLength, resolutionName, mode) {
    if (!settingsBtn) return;

    const targetDuration = String(videoLength || 6) + 's'; // "6s" or "10s"
    const targetResolution = resolutionName || '480p';      // "480p" or "720p"

    // Mode → preset name mapping (reverse of PRESET_TO_MODE)
    const MODE_TO_PRESET = {
        'extremely-spicy-or-crazy': 'Spicy',
        'extremely-crazy': 'Fun',
        'normal': 'Normal'
    };
    const targetPreset = MODE_TO_PRESET[mode] || null; // null for 'custom' — no preset to click

    // Open Settings dropdown using full pointer event sequence (Radix needs pointer events, not just .click())
    const evtOpts = { bubbles: true, cancelable: true, view: window };
    const simulateClickFn = (el) => {
        el.dispatchEvent(new PointerEvent('pointerdown', { ...evtOpts, pointerId: 1 }));
        el.dispatchEvent(new MouseEvent('mousedown', evtOpts));
        el.dispatchEvent(new PointerEvent('pointerup', { ...evtOpts, pointerId: 1 }));
        el.dispatchEvent(new MouseEvent('mouseup', evtOpts));
        el.dispatchEvent(new MouseEvent('click', evtOpts));
    };

    let menu = null;
    for (let attempt = 0; attempt < 3; attempt++) {
        menu = document.querySelector('[role="menu"]');
        if (menu) break;
        simulateClickFn(settingsBtn);
        await new Promise(r => setTimeout(r, 600));
        menu = document.querySelector('[role="menu"]');
        if (menu) break;
        console.log(`[Queue] V2: Settings menu not open, retrying (${attempt + 1}/3)...`);
        await new Promise(r => setTimeout(r, 300));
    }
    if (!menu) {
        console.log('[Queue] V2: Could not open Settings to apply video settings');
        return;
    }

    // Click duration/resolution buttons
    const buttons = menu.querySelectorAll('button');
    let appliedDuration = false;
    let appliedResolution = false;

    for (const btn of buttons) {
        const text = btn.textContent?.trim();
        if (text === targetDuration && !appliedDuration) {
            btn.click();
            appliedDuration = true;
        }
        if (text === targetResolution && !appliedResolution) {
            btn.click();
            appliedResolution = true;
        }
    }

    // Click mode preset menuitem (Spicy/Fun/Normal) — skip for 'custom'
    let appliedMode = false;
    if (targetPreset) {
        const items = menu.querySelectorAll('[role="menuitem"]');
        for (const item of items) {
            const text = item.innerText?.trim();
            if (text && (text === targetPreset || text.startsWith(targetPreset + '\n') || text.startsWith(targetPreset + ' '))) {
                item.click();
                appliedMode = true;
                break;
            }
        }
    }

    // Close dropdown by clicking Settings button again (Escape navigates the page away!)
    // Must use simulateClickFn — Radix dropdowns ignore plain .click() from content scripts
    await new Promise(r => setTimeout(r, 200));
    const menuStillOpen = document.querySelector('[role="menu"]');
    if (menuStillOpen && settingsBtn) {
        simulateClickFn(settingsBtn);
        await new Promise(r => setTimeout(r, 300));
        // Verify closed
        if (document.querySelector('[role="menu"]')) {
            console.warn('[Queue] V2: Settings dropdown still open after close attempt, trying again...');
            simulateClickFn(settingsBtn);
            await new Promise(r => setTimeout(r, 300));
        }
    }

    console.log(`[Queue] V2: Applied settings — duration: ${appliedDuration ? targetDuration : 'skip'}, resolution: ${appliedResolution ? targetResolution : 'skip'}, mode: ${appliedMode ? targetPreset : (mode === 'custom' ? 'custom(no preset)' : 'not found')}`);
}

/**
 * Fill a contenteditable element with text.
 * ProseMirror/TipTap doesn't recognize execCommand or innerHTML from content scripts (ISOLATED world).
 * Uses MAIN world message passing to access TipTap's editor API (el.editor.commands.insertContent).
 */
async function fillContentEditable(el, text) {
    // Strategy 1: Use MAIN world TipTap API via intercept.js message handler
    // This is the only reliable way — content script can't access el.editor (page JS property)
    console.log(`[Queue] fillContentEditable: requesting MAIN world fill via postMessage (${text.length} chars)`);

    const fillResult = await new Promise((resolve) => {
        const timeout = setTimeout(() => {
            window.removeEventListener('message', handler);
            resolve({ success: false, error: 'timeout' });
        }, 3000);

        function handler(event) {
            if (event.source !== window || event.data?.type !== 'GROK_FILL_EDITOR_RESULT') return;
            clearTimeout(timeout);
            window.removeEventListener('message', handler);
            resolve(event.data.payload);
        }
        window.addEventListener('message', handler);

        window.postMessage({
            type: 'GROK_FILL_EDITOR',
            payload: { text }
        }, '*');
    });

    if (fillResult.success) {
        console.log(`[Queue] ✅ contenteditable filled via TipTap API (${fillResult.length} chars)`);
        return;
    }
    console.warn(`[Queue] MAIN world fill failed: ${fillResult.error}, falling back to execCommand`);

    // Strategy 2: execCommand fallback (fills DOM but may not update ProseMirror state)
    el.click();
    await new Promise(r => setTimeout(r, 100));
    el.focus();
    await new Promise(r => setTimeout(r, 200));

    // Clear existing content
    const sel = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(el);
    sel.removeAllRanges();
    sel.addRange(range);
    if (el.textContent?.trim()) {
        document.execCommand('delete', false);
        await new Promise(r => setTimeout(r, 100));
    }

    document.execCommand('insertText', false, text);
    await new Promise(r => setTimeout(r, 300));

    const filled = el.textContent?.trim();
    console.log(`[Queue] contenteditable filled via execCommand (${filled?.length || 0} chars, ProseMirror may not see it)`);
    // Set prompt as data attribute so intercept.js can patch the API request body as safety net
    document.documentElement.dataset.grokQueuePrompt = text; document.documentElement.dataset.grokQueueSetAt = String(Date.now());
}

/**
 * Fill prompt and submit for queue item on current page
 */
async function queueFillAndSubmit(item) {
    try {
        // Verify we're on a post detail page (URL may differ if post has edits/variants)
        if (!window.location.pathname.includes(`/imagine/post/${item.postId}`)) {
            if (window.location.pathname.includes('/imagine/post/')) {
                console.warn(`[Queue] URL redirected: expected /imagine/post/${item.postId}, got ${window.location.pathname} — continuing (post may have variants)`);
            } else {
                throw new Error(`Wrong page: expected /imagine/post/${item.postId}, got ${window.location.pathname}`);
            }
        }

        SystemLogger.info('Queue prompt submitted', `PostId: ${item.postId}, Attempt: ${item.totalAttempts + 1}/${item.maxRetries}`);

        // Helper to find prompt input (textarea for V1, contenteditable for V2)
        const findInput = () => {
            const candidates = Array.from(document.querySelectorAll('textarea[placeholder], input[placeholder*="Enter"], [contenteditable="true"]'))
                .filter(el => el.id !== 'grok-queue-prompt' && !el.closest('#grok-queue-fab'));
            return candidates.length > 0 ? candidates[0] : null;
        };

        // Wait for input to appear (quick check first, 5s)
        let input = null;
        for (let attempt = 0; attempt < 10; attempt++) {
            input = findInput();
            if (input) break;
            await new Promise(r => setTimeout(r, 500));
        }

        // V2: If no input found yet, page might be in Image mode (no contenteditable).
        // Try switching to Video mode first, then re-search.
        if (!input) {
            console.log('[Queue] V2: No input found — page may be in Image mode, attempting mode switch...');
            await new Promise(r => setTimeout(r, 1000));
            await switchToVideoModeIfNeeded();
            await new Promise(r => setTimeout(r, 1500));
            // Re-search after mode switch
            for (let attempt = 0; attempt < 10; attempt++) {
                input = findInput();
                if (input) break;
                await new Promise(r => setTimeout(r, 500));
            }
        }

        if (!input) {
            const pageTitle = document.title;
            const bodyText = document.body?.innerText?.substring(0, 200) || '(empty)';
            SystemLogger.fail('Queue input not found', `Page title: "${pageTitle}", Body preview: "${bodyText.substring(0, 100)}..."`);
            throw new Error('Could not find prompt input on page');
        }

        SystemLogger.info('Queue input found', `Tag: ${input.tagName}, Placeholder: "${input.placeholder || 'none'}", Page: ${window.location.href.substring(0, 80)}`);

        // V2: Ensure video mode + apply settings
        // settingsBtn2 declared here so it's accessible in the disabled-button retry loop below
        let settingsBtn2 = null;
        if (input.tagName !== 'TEXTAREA') {
            // Wait extra time for React hydration before trying to interact with UI
            console.log('[Queue] V2 detected (contenteditable), waiting for hydration...');
            await new Promise(r => setTimeout(r, 2000));
            await switchToVideoModeIfNeeded();

            // V2: Apply duration/resolution/mode via UI buttons
            settingsBtn2 = (() => {
                const eds = Array.from(document.querySelectorAll('[contenteditable="true"]'))
                    .filter(el => el.id !== 'grok-queue-prompt' && !el.closest('#grok-queue-fab'));
                if (eds.length === 0) return null;
                let p = eds[0].parentElement;
                for (let i = 0; i < 8 && p; i++) {
                    const btn = p.querySelector('button[aria-haspopup="menu"]');
                    if (btn) return btn;
                    p = p.parentElement;
                }
                return null;
            })();
            console.log(`[Queue] Settings button (for mode/res): ${settingsBtn2 ? 'found' : 'NOT FOUND — mode will not be applied'}`);
            await applyVideoSettingsV2(settingsBtn2, item.videoLength, item.resolutionName, item.mode);

            // Clear stale preset cache (mode switch changes available presets)
            _cachedAvailablePresets = null;

            // Re-find input after mode switch (contenteditable may have been recreated)
            const freshInput = findInput();
            if (freshInput && freshInput !== input) {
                input = freshInput;
                console.log('[Queue] Re-acquired input after mode switch');
            }
        }

        // Fill the prompt using native setter to trigger React state update
        input.focus();
        if (input.tagName === 'TEXTAREA') {
            const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
            nativeSetter.call(input, item.prompt);
            input.dispatchEvent(new Event('input', { bubbles: true }));
        } else if (input.tagName === 'INPUT') {
            const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
            nativeSetter.call(input, item.prompt);
            input.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
            // V2 UI: contenteditable — try multiple strategies to fill text.
            // For non-custom modes (Normal/Fun/Spicy) with no prompt, skip the fill.
            // Inserting an empty string into TipTap triggers a React state update that
            // disables the "Make video" button, overriding the mode preset's enabled state.
            const isCustomMode = !item.mode || item.mode === 'custom';
            if (item.prompt || isCustomMode) {
                await fillContentEditable(input, item.prompt);
            }
        }

        // Wait for React to process the input
        await new Promise(r => setTimeout(r, 500));

        // Set video generation overrides via DOM data attributes (read by intercept.js in MAIN world)
        // Always set — use item values or defaults for items created before this feature
        const videoLength = item.videoLength || 6;
        const resolutionName = item.resolutionName || '480p';
        const mode = item.mode || 'custom';
        GrokVideoMode.applyVideoOverrides(mode, videoLength, resolutionName);
        // Always pass prompt to intercept.js as safety net (in case contenteditable fill didn't register with framework)
        document.documentElement.dataset.grokQueuePrompt = item.prompt; document.documentElement.dataset.grokQueueSetAt = String(Date.now());
        console.log(`[Queue] Video overrides set: ${videoLength}s, ${resolutionName}, mode=${mode}, prompt=${item.prompt.substring(0, 30)}...`);

        // Find the "Make Video" button with retry (page may still be rendering)
        // Strategy 1: aria-label match (most reliable, language-aware)
        // Strategy 2: button with bg-button-filled class (V1 UI)
        // Strategy 3: SVG arrow-up path near input area (filter out Video toggle etc.)
        let submitBtn = null;
        for (let btnAttempt = 0; btnAttempt < 10; btnAttempt++) {
            // Strategy 1: aria-label (V2 submit button always has this)
            submitBtn = document.querySelector(ContentUtils.GROK_SELECTORS.SUBMIT_VIDEO_BUTTON);
            // Strategy 2: V1 button class
            if (!submitBtn) {
                submitBtn = document.querySelector('button[data-slot="button"][class*="bg-button-filled"]');
            }
            // Strategy 3: SVG arrow-up path, but only near the input/contenteditable area
            if (!submitBtn) {
                const inputArea = document.querySelector('[contenteditable="true"]') || document.querySelector('textarea[placeholder]');
                const inputContainer = inputArea?.closest('[class*="flex"]')?.parentElement?.parentElement;
                const searchScope = inputContainer || document;
                const allButtons = Array.from(searchScope.querySelectorAll('button'));
                submitBtn = allButtons.find(b => {
                    const paths = b.querySelectorAll('svg path');
                    for (const p of paths) {
                        if ((p.getAttribute('d') || '').includes('M12 5V19')) return true;
                    }
                    return false;
                }) || null;
            }
            if (submitBtn) break;
            console.log(`[Queue] Submit button not found, retrying (${btnAttempt + 1}/10)...`);
            await new Promise(r => setTimeout(r, 500));
        }

        if (submitBtn) {
            // Wait for button to become enabled (after text input is processed)
            if (submitBtn.disabled) {
                console.log('[Queue] Submit button found but disabled, waiting for enable...');
                const isCustomMode2 = !item.mode || item.mode === 'custom';
                for (let i = 0; i < 20; i++) {
                    await new Promise(r => setTimeout(r, 500));
                    if (!submitBtn.disabled) break;
                    // After 2s, re-fill (custom mode only) or re-apply mode settings (non-custom)
                    if (i === 3 && input.tagName !== 'TEXTAREA' && input.tagName !== 'INPUT') {
                        if (item.prompt || isCustomMode2) {
                            console.log('[Queue] Button still disabled after 2s, re-filling contenteditable (attempt 1)...');
                            await fillContentEditable(input, item.prompt);
                        } else {
                            console.log('[Queue] Button still disabled after 2s, re-applying mode settings for non-custom mode...');
                            await applyVideoSettingsV2(settingsBtn2, item.videoLength, item.resolutionName, item.mode);
                        }
                    }
                    // After 6s, try again
                    if (i === 11 && input.tagName !== 'TEXTAREA' && input.tagName !== 'INPUT') {
                        if (item.prompt || isCustomMode2) {
                            console.log('[Queue] Button still disabled after 6s, re-filling contenteditable (attempt 2)...');
                            await fillContentEditable(input, item.prompt);
                        } else {
                            console.log('[Queue] Button still disabled after 6s, re-applying mode settings again...');
                            await applyVideoSettingsV2(settingsBtn2, item.videoLength, item.resolutionName, item.mode);
                        }
                    }
                }
            }

            if (!submitBtn.disabled) {
                SystemLogger.info('Queue submit button found', `Text: "${submitBtn.textContent?.trim()}", AriaLabel: "${submitBtn.getAttribute('aria-label') || 'none'}", Class: "${submitBtn.className?.substring(0, 60)}"`);

                // V2 (contenteditable): Submit via Enter key in MAIN world — most reliable
                // V1 (textarea): Use button click with simulateClick
                let submitted = false;
                if (input.tagName !== 'TEXTAREA' && input.tagName !== 'INPUT') {
                    console.log('[Queue] V2: submitting via Enter key in MAIN world...');
                    const enterResult = await new Promise((resolve) => {
                        const timeout = setTimeout(() => {
                            window.removeEventListener('message', handler);
                            resolve({ success: false, error: 'timeout' });
                        }, 2000);
                        function handler(event) {
                            if (event.source !== window || event.data?.type !== 'GROK_SUBMIT_EDITOR_RESULT') return;
                            clearTimeout(timeout);
                            window.removeEventListener('message', handler);
                            resolve(event.data.payload);
                        }
                        window.addEventListener('message', handler);
                        window.postMessage({ type: 'GROK_SUBMIT_EDITOR', payload: {} }, '*');
                    });
                    if (enterResult.success) {
                        console.log('[Queue] ✅ Submitted via Enter key in MAIN world');
                        submitted = true;
                    } else {
                        console.warn(`[Queue] Enter key submit failed: ${enterResult.error}, falling back to button click`);
                    }
                }

                if (!submitted) {
                    // Button click with full pointer event sequence
                    const evtOpts = { bubbles: true, cancelable: true, view: window };
                    submitBtn.dispatchEvent(new PointerEvent('pointerdown', { ...evtOpts, pointerId: 1 }));
                    submitBtn.dispatchEvent(new MouseEvent('mousedown', evtOpts));
                    submitBtn.dispatchEvent(new PointerEvent('pointerup', { ...evtOpts, pointerId: 1 }));
                    submitBtn.dispatchEvent(new MouseEvent('mouseup', evtOpts));
                    submitBtn.dispatchEvent(new MouseEvent('click', evtOpts));
                    console.log('[Queue] Submitted via button click (simulateClick)');
                }

                queueWaitingForResult = true;
            } else {
                SystemLogger.fail('Queue submit button disabled', `Text: "${submitBtn.textContent?.trim()}", waited 5s`);
                throw new Error('Video generation button found but remained disabled');
            }
        } else {
            const allButtons = document.querySelectorAll('button');
            const btnInfo = Array.from(allButtons).slice(0, 10).map(b => `"${b.textContent?.trim().substring(0, 30)}" disabled=${b.disabled}`).join(', ');
            SystemLogger.fail('Queue submit button not found', `Buttons on page: [${btnInfo}]`);
            throw new Error('Could not find the video generation button');
        }

        console.log('[Queue] Prompt submitted, waiting for result...');

        // Timeout: if no result within configured window, treat as failure and auto-advance
        const { queueGenerationTimeoutSec } = await chrome.storage.sync.get('queueGenerationTimeoutSec');
        let timeoutSec = parseInt(queueGenerationTimeoutSec, 10);
        if (!Number.isFinite(timeoutSec) || timeoutSec < 30) timeoutSec = 180;
        if (timeoutSec > 600) timeoutSec = 600;
        const timeoutMs = timeoutSec * 1000;
        const submitTimeout = setTimeout(() => {
            if (!queueWaitingForResult) return; // Result already received
            console.warn(`[Queue] Timeout: no video gen result after ${timeoutSec}s`);
            SystemLogger.fail('Queue submit timeout', `PostId: ${item.postId}, no result after ${timeoutSec}s`);
            queueWaitingForResult = false;
            chrome.runtime.sendMessage({
                action: 'queueItemError',
                error: `Timeout: no video generation result after ${timeoutSec}s`
            });
            autoAdvanceQueue();
        }, timeoutMs);

        // Store timeout ID so it can be cleared when result arrives
        window._queueSubmitTimeout = submitTimeout;
    } catch (error) {
        console.error('[Queue] Fill and submit error:', error);
        SystemLogger.fail('Queue fill & submit error', `PostId: ${item.postId}, Error: ${error.message}, URL: ${window.location.href.substring(0, 80)}`);
        queueWaitingForResult = false;
        await chrome.runtime.sendMessage({
            action: 'queueItemError',
            error: error.message
        });
        // Auto-advance to next item instead of stopping
        autoAdvanceQueue();
    }
}

/**
 * Handle result from background.js after video generation
 * (triggered by interceptor → bridge → background → queueItemResult)
 */
function handleQueueItemResult(data) {
    _queueResultPending = false; // Mark as handled by normal relay chain
    queueWaitingForResult = false; // Allow new submissions
    if (window._queueSubmitTimeout) { clearTimeout(window._queueSubmitTimeout); window._queueSubmitTimeout = null; }
    console.log('[Queue] handleQueueItemResult called:', { queueProcessingActive, shouldRetry: data.shouldRetry, shouldMoveNext: data.shouldMoveNext, moderated: data.moderated });
    SystemLogger.info('Queue result received', `moderated: ${data.moderated}, shouldRetry: ${data.shouldRetry}, shouldMoveNext: ${data.shouldMoveNext}, PostId: ${data.queueItem?.postId}`);

    if (!queueProcessingActive) {
        SystemLogger.warn('Queue result ignored', 'queueProcessingActive is false');
        return;
    }

    const { queueItem, moderated, shouldRetry, shouldMoveNext, nextItem, usageLimitReached } = data;

    if (usageLimitReached) {
        // Usage limit reached — stop queue
        queueProcessingActive = false;
        chrome.storage.local.set({
            queueProcessingState: { isProcessing: false, currentItemId: null }
        });
        SystemLogger.fail('Queue stopped', 'Free usage limit reached (50)');
        chrome.runtime.sendMessage({ action: 'queueProgressUpdate', usageLimitReached: true }).catch(() => {});
        return;
    }

    if (shouldRetry) {
        // Wait then refill and resubmit on the same page
        const reason = moderated ? 'Moderated' : 'Success but target not reached';
        SystemLogger.info('Queue retrying', `${reason}, retrying in 2s...`);
        setTimeout(async () => {
            if (!queueProcessingActive) {
                console.log('[Queue] Retry cancelled: queueProcessingActive became false');
                return;
            }
            // Guard the double-relay double-submission window: a slow normal
            // relay plus the fallback's re-relay (see the GROK_VIDEO_GEN_RESULT
            // listener above) can each invoke handleQueueItemResult for the same
            // result, and each schedules its own 2s retry here. If a submit is
            // already in flight — queueWaitingForResult back to true, meaning
            // another retry (or the original submit) beat us to it — skip this
            // one instead of resubmitting and triggering an extra generation.
            // This narrows but does not fully eliminate the race: it only helps
            // once the other retry has reached the point of actually clicking
            // submit; two retries whose async getQueueItem calls both resolve
            // before either sets the flag can still both proceed.
            if (queueWaitingForResult) {
                console.log('[Queue] Retry skipped: another submit already in flight (queueWaitingForResult=true)');
                return;
            }
            try {
                // Refetch latest item state
                const resp = await chrome.runtime.sendMessage({ action: 'getQueueItem', id: queueItem.id });
                if (queueWaitingForResult) {
                    console.log('[Queue] Retry skipped: another submit started while awaiting getQueueItem');
                    return;
                }
                if (resp.success && resp.item && resp.item.status === 'active') {
                    console.log('[Queue] Retry: calling queueFillAndSubmit...');
                    await queueFillAndSubmit(resp.item);
                } else {
                    console.log('[Queue] Retry skipped: item not active', resp);
                }
            } catch (error) {
                console.error('[Queue] Retry error:', error);
                SystemLogger.fail('Queue retry error', error.message);
            }
        }, 2000);
    } else if (shouldMoveNext) {
        if (nextItem) {
            // Navigate to next item's post page
            SystemLogger.info('Queue moving to next', `PostId: ${nextItem.postId}`);
            processQueueItem(nextItem, true);
        } else {
            // All done
            queueProcessingActive = false;
            chrome.storage.local.set({
                queueProcessingState: { isProcessing: false, currentItemId: null }
            });
            SystemLogger.info('Queue completed', 'All items processed');
            chrome.runtime.sendMessage({ action: 'queueProgressUpdate', allDone: true }).catch(() => {});
        }
    }
}

/**
 * Pause queue processing
 */
function pauseQueueProcessing() {
    queueProcessingActive = false;
    queueWaitingForResult = false;
    GrokVideoMode.clearVideoOverrides(); // never leak queue overrides into a manual generation
    chrome.storage.local.set({
        queueProcessingState: { isProcessing: false, currentItemId: null }
    });
    SystemLogger.warn('Queue paused', 'By user');
}

/**
 * Stop queue processing and reset active item to pending
 */
async function stopQueueProcessing() {
    queueProcessingActive = false;
    queueWaitingForResult = false;
    GrokVideoMode.clearVideoOverrides();

    // Reset active item to pending — but only demote it if it's still
    // 'active' at write time. Between this read and the write, a concurrent
    // videoGenResult can transition the item to completed/failed/error; a
    // conditional (compare-and-set) write avoids clobbering that outcome
    // with a stale 'pending' from the user's stop request.
    const resp = await chrome.runtime.sendMessage({ action: 'getActiveQueueItem' });
    if (resp.success && resp.item) {
        await chrome.runtime.sendMessage({
            action: 'updateQueueItemIf',
            id: resp.item.id,
            expectedStatus: 'active',
            updates: { status: 'pending' }
        });
    }

    await chrome.storage.local.set({
        queueProcessingState: { isProcessing: false, currentItemId: null }
    });
    SystemLogger.warn('Queue stopped', 'By user');
}

/**
 * Check for queue processing state on page load (resume after navigation)
 */
let _queueResumeInProgress = false;
async function checkQueueProcessingOnLoad() {
    const currentUrl = window.location.href;
    if (!currentUrl.includes('/imagine/post/')) return;

    // If we already submitted and are waiting for the interceptor result, don't re-submit
    if (queueWaitingForResult) {
        console.log('[Queue] checkQueueProcessingOnLoad skipped: waiting for video gen result');
        return;
    }

    // Prevent duplicate concurrent execution (called from both setTimeout and setInterval)
    if (_queueResumeInProgress) {
        console.log('[Queue] checkQueueProcessingOnLoad skipped: already in progress');
        return;
    }
    _queueResumeInProgress = true;

    try {
        const result = await chrome.storage.local.get('queueProcessingState');
        const state = result.queueProcessingState;

        if (!state || !state.isProcessing || !state.currentItemId) {
            console.log('[Queue] checkQueueProcessingOnLoad: no active processing state');
            return;
        }

        // Guard: only resume if the queue was actively processing recently.
        // If the state is stale (e.g., browser crash or tab close left isProcessing=true),
        // don't auto-resume — this prevents unintended auto-submission when users
        // manually navigate to post pages.
        const stateAge = state.navigateTimestamp ? Date.now() - state.navigateTimestamp : Infinity;
        const MAX_RESUME_AGE_MS = 60000; // 1 minute - queue navigations should resume within this window
        if (stateAge > MAX_RESUME_AGE_MS) {
            console.log(`[Queue] checkQueueProcessingOnLoad: stale state (${Math.round(stateAge / 1000)}s old), clearing`);
            await chrome.storage.local.remove('queueProcessingState');
            // Fire-and-forget: also rescue any item stranded in 'active' by the
            // same crash/tab-close (>10 min stale) that left this state behind.
            chrome.runtime.sendMessage({ action: 'reconcileQueueActive' }).catch(() => {});
            SystemLogger.info('Queue stale state cleared', `State was ${Math.round(stateAge / 1000)}s old, threshold ${MAX_RESUME_AGE_MS / 1000}s`);
            return;
        }

        SystemLogger.info('Queue resume check', `State: isProcessing=${state.isProcessing}, itemId=${state.currentItemId}, age=${Math.round(stateAge / 1000)}s, URL: ${currentUrl.substring(0, 80)}`);

        // Get the current item to check if we're on the correct post page
        const resp = await chrome.runtime.sendMessage({ action: 'getQueueItem', id: state.currentItemId });
        if (!resp.success || !resp.item || resp.item.status !== 'active') {
            SystemLogger.warn('Queue resume skipped', `Item not found or not active: success=${resp.success}, status=${resp.item?.status}`);
            return;
        }

        // Check if we're on the correct post page for the active item
        const urlMatch = currentUrl.includes(resp.item.postId);
        if (!urlMatch) {
            const elapsed = state.navigateTimestamp ? Date.now() - state.navigateTimestamp : Infinity;
            const redirectCount = state.redirectCount || 0;

            // Grok-redirect loop detection: if we've already been redirected back once and
            // Grok still lands us on a different post page, Grok will always redirect away
            // from the original postId (e.g. image post → its generated video post).
            // Stop redirecting and attempt fill+submit on the current page as-is.
            // queueFillAndSubmit tolerates postId mismatches and will error-out if the page
            // doesn't support generation, allowing the queue to auto-advance gracefully.
            const currentPostId = currentUrl.match(/\/imagine\/post\/([^/?#]+)/)?.[1];
            if (redirectCount >= 1 && currentPostId) {
                SystemLogger.warn('Queue Grok-redirect loop detected', `Grok keeps redirecting ${resp.item.postId} → ${currentPostId} (attempt #${redirectCount + 1}). Proceeding on current page without updating postId.`);
                await chrome.storage.local.set({ queueProcessingState: { ...state, redirectCount: 0 } });
                queueProcessingActive = true;
                await new Promise(r => setTimeout(r, 1500));
                await queueFillAndSubmit(resp.item);
                return;
            }

            // First mismatch: check if Grok redirected us to a video post page.
            // If the page already has a video submit button + contenteditable, skip the
            // redirect-back and proceed here — switchToVideoModeIfNeeded will click 重做.
            const hasVideoSubmitBtn = !!document.querySelector(ContentUtils.GROK_SELECTORS.SUBMIT_VIDEO_BUTTON);
            const hasContenteditable = !!document.querySelector(ContentUtils.GROK_SELECTORS.PROMPT_CONTENTEDITABLE);
            if (currentPostId && hasVideoSubmitBtn && hasContenteditable) {
                SystemLogger.warn('Queue Grok-redirect to video page — skipping bounce', `Expected "${resp.item.postId}" but Grok redirected to video page "${currentPostId}". Proceeding directly.`);
                await chrome.storage.local.set({ queueProcessingState: { ...state, redirectCount: 0 } });
                queueProcessingActive = true;
                await new Promise(r => setTimeout(r, 1500));
                await queueFillAndSubmit(resp.item);
                return;
            }

            // Plain URL mismatch (not a video post page): redirect back and increment counter
            await chrome.storage.local.set({ queueProcessingState: { ...state, redirectCount: redirectCount + 1 } });
            SystemLogger.warn('Queue resume URL mismatch — redirecting', `Expected "${resp.item.postId}" but got "${currentUrl.substring(0, 80)}" (${Math.round(elapsed / 1000)}s ago, attempt #${redirectCount + 1})`);
            window.location.href = `https://grok.com/imagine/post/${resp.item.postId}`;
            return;
        }

        SystemLogger.info('Queue resuming on page load', `PostId: ${resp.item.postId}, Prompt: "${resp.item.prompt?.substring(0, 50)}..."`);
        queueProcessingActive = true;

        // Wait for page to load then fill and submit
        await new Promise(r => setTimeout(r, 1500));
        await queueFillAndSubmit(resp.item);
    } catch (error) {
        console.error('[Queue] Error resuming queue on load:', error);
    } finally {
        _queueResumeInProgress = false;
    }
}

// ==========================================
// Video Gen Queue - "Add to Queue" UI
// ==========================================

// getToggleValue(), setToggleActive(), updatePromptHint() extracted to
// src/video-mode-utils.js (GrokVideoMode)

// Cache + lock to prevent race condition between duplicate detection calls
let _cachedAvailablePresets = null;
let _detectPresetsPromise = null;

/**
 * Detect available video generation presets from the Video Options dropdown.
 * Opens the dropdown invisibly, reads menuitem labels, maps to mode values, closes.
 * Results are cached. Concurrent calls share the same promise (no race condition).
 */
async function detectAvailablePresets() {
    if (_cachedAvailablePresets) {
        console.log('[Queue] Using cached presets:', _cachedAvailablePresets);
        return _cachedAvailablePresets;
    }

    // If another call is already running, wait for it instead of opening dropdown again
    if (_detectPresetsPromise) {
        console.log('[Queue] Waiting for in-progress preset detection...');
        return _detectPresetsPromise;
    }

    _detectPresetsPromise = _detectAvailablePresetsImpl();
    try {
        const result = await _detectPresetsPromise;
        return result;
    } finally {
        _detectPresetsPromise = null;
    }
}

async function _detectAvailablePresetsImpl() {
    // Label→mode mapping (GrokVideoMode.PRESET_TO_MODE / computeAvailableModes,
    // extracted to src/video-mode-utils.js) always available even on early return.
    let availableModes = ['custom'];

    try {
        // Find Video Options / Settings button
        // V1: <textarea> parent has button[aria-haspopup="menu"]
        // V2: no textarea, uses <p contenteditable="true">; button is in a broader ancestor
        let videoOptsBtn = null;

        // V1 approach: find textarea → find button in its parent
        const textareas = Array.from(document.querySelectorAll('textarea[placeholder]'))
            .filter(t => t.id !== 'grok-queue-prompt' && !t.closest('#grok-queue-fab'));
        if (textareas.length > 0) {
            videoOptsBtn = textareas[0].parentElement?.querySelector('button[aria-haspopup="menu"]');
        }

        // V2 approach: find contenteditable, walk up ancestors to find button
        if (!videoOptsBtn) {
            const editables = Array.from(document.querySelectorAll('[contenteditable="true"]'))
                .filter(el => el.id !== 'grok-queue-prompt' && !el.closest('#grok-queue-fab'));
            if (editables.length > 0) {
                let parent = editables[0].parentElement;
                for (let i = 0; i < 8 && parent; i++) {
                    videoOptsBtn = parent.querySelector('button[aria-haspopup="menu"]');
                    if (videoOptsBtn) break;
                    parent = parent.parentElement;
                }
            }
        }

        if (!videoOptsBtn) {
            console.log('[Queue] Video Options/Settings button not found, showing all modes');
            return null;
        }

        // Hide the menu while we read it to avoid visual flash
        const hideStyle = document.createElement('style');
        hideStyle.textContent = '[role="menu"] { opacity: 0 !important; pointer-events: none !important; }';
        document.head.appendChild(hideStyle);

        // Radix requires full pointer event sequence, simple .click() won't work
        const evtOpts = { bubbles: true, cancelable: true, view: window };
        const simulateClick = (el) => {
            el.dispatchEvent(new PointerEvent('pointerdown', { ...evtOpts, pointerId: 1 }));
            el.dispatchEvent(new MouseEvent('mousedown', evtOpts));
            el.dispatchEvent(new PointerEvent('pointerup', { ...evtOpts, pointerId: 1 }));
            el.dispatchEvent(new MouseEvent('mouseup', evtOpts));
            el.dispatchEvent(new MouseEvent('click', evtOpts));
        };

        // Open dropdown
        simulateClick(videoOptsBtn);
        await new Promise(r => setTimeout(r, 500));

        // Read preset menuitems — universal approach for both V1 and V2:
        // V1: leaf items (no children), innerText = "Fun", "Normal"
        // V2: items with children (img+text), innerText = "Fun\nHilarious results", "Spicy\nMight be NSFW"
        // Use innerText (respects block elements, adds \n) instead of textContent (concatenates without separator)
        const menu = document.querySelector('[role="menu"]');
        if (menu) {
            const items = menu.querySelectorAll('[role="menuitem"]');
            const menuItemTexts = Array.from(items).map(item => item.innerText?.trim());
            availableModes = GrokVideoMode.computeAvailableModes(menuItemTexts);
        }

        // Close dropdown
        simulateClick(videoOptsBtn);
        await new Promise(r => setTimeout(r, 100));

        // Remove hiding style
        hideStyle.remove();

        console.log('[Queue] Detected available presets:', availableModes);
    } catch (e) {
        console.warn('[Queue] Failed to detect available presets:', e);
        return null;
    }

    _cachedAvailablePresets = availableModes;
    return availableModes;
}

/**
 * Inject "Add to Queue" button on post detail pages
 */
function injectAddToQueueUI() {
    const currentUrl = window.location.href;
    console.log('[Queue] injectAddToQueueUI called, URL:', currentUrl);
    if (!currentUrl.includes('/imagine/post/')) {
        console.log('[Queue] Not a post detail page, skipping');
        return;
    }

    // Don't inject if already exists
    if (document.getElementById('grok-queue-inject')) {
        console.log('[Queue] Queue inject already exists, skipping');
        return;
    }

    // Extract postId from URL
    const postIdMatch = currentUrl.match(/\/imagine\/post\/([^/?#]+)/);
    if (!postIdMatch) {
        console.log('[Queue] Could not extract postId from URL');
        SystemLogger.warn('Queue UI inject failed', `Could not extract postId from URL: ${currentUrl.substring(0, 80)}`);
        return;
    }
    const postId = postIdMatch[1];
    console.log('[Queue] Injecting Add to Queue UI for postId:', postId);

    // Create floating button
    const container = document.createElement('div');
    container.id = 'grok-queue-inject';
    container.innerHTML = `
        <style>
            #grok-queue-inject {
                position: fixed;
                bottom: 80px;
                right: 20px;
                z-index: 99999;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                touch-action: none;
            }
            #grok-queue-fab {
                width: 48px;
                height: 48px;
                border-radius: 50%;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border: none;
                color: white;
                font-size: 20px;
                cursor: grab;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                display: flex;
                align-items: center;
                justify-content: center;
                transition: box-shadow 0.2s;
            }
            #grok-queue-fab:hover {
                box-shadow: 0 6px 16px rgba(0,0,0,0.4);
            }
            #grok-queue-fab.dragging {
                cursor: grabbing;
                box-shadow: 0 8px 24px rgba(0,0,0,0.5);
                opacity: 0.85;
            }
            #grok-queue-panel {
                display: none;
                position: absolute;
                bottom: 56px;
                right: 0;
                width: 280px;
                background: #1a1a1a;
                border: 1px solid #333;
                border-radius: 12px;
                padding: 16px;
                box-shadow: 0 8px 24px rgba(0,0,0,0.5);
                color: #e0e0e0;
            }
            #grok-queue-panel.open { display: block; }
            #grok-queue-panel h3 {
                margin: 0 0 12px 0;
                font-size: 14px;
                color: #fff;
            }
            #grok-queue-panel label {
                font-size: 12px;
                color: #aaa;
                display: block;
                margin-bottom: 4px;
            }
            #grok-queue-panel input[type="number"],
            #grok-queue-panel textarea {
                width: 100%;
                padding: 8px;
                border: 1px solid #444;
                border-radius: 6px;
                background: #222;
                color: #e0e0e0;
                font-size: 13px;
                margin-bottom: 10px;
                box-sizing: border-box;
            }
            #grok-queue-panel textarea {
                resize: vertical;
                min-height: 60px;
            }
            .grok-queue-row {
                display: flex;
                gap: 8px;
                margin-bottom: 10px;
            }
            .grok-queue-row > div { flex: 1; }
            .grok-queue-toggle-row {
                display: flex;
                gap: 4px;
                margin-bottom: 10px;
            }
            .grok-queue-toggle-btn {
                flex: 1;
                padding: 6px 8px;
                border: 1px solid #444;
                border-radius: 6px;
                background: #222;
                color: #888;
                font-size: 12px;
                cursor: pointer;
                transition: all 0.2s;
                text-align: center;
            }
            .grok-queue-toggle-btn.active {
                background: #333;
                color: #fff;
                border-color: #667eea;
            }
            #grok-queue-add-btn {
                width: 100%;
                padding: 10px;
                border: none;
                border-radius: 6px;
                background: #4CAF50;
                color: white;
                font-size: 13px;
                font-weight: 600;
                cursor: pointer;
                transition: background 0.2s;
            }
            #grok-queue-add-btn:hover { background: #388E3C; }
            #grok-queue-add-btn:disabled { opacity: 0.5; cursor: not-allowed; }
            #grok-queue-status {
                font-size: 11px;
                text-align: center;
                margin-top: 8px;
                min-height: 16px;
            }
        </style>
        <div id="grok-queue-panel">
            <h3>🎯 Add to Queue</h3>
            <label>Prompt</label>
            <textarea id="grok-queue-prompt" placeholder="Enter video generation prompt..."></textarea>
            <div class="grok-queue-row">
                <div>
                    <label>Target Success</label>
                    <input type="number" id="grok-queue-target" min="1" max="100" value="1">
                </div>
                <div>
                    <label>Max Retries</label>
                    <input type="number" id="grok-queue-retries" min="1" max="100" value="5">
                </div>
            </div>
            <label>Mode</label>
            <div class="grok-queue-toggle-row" id="grok-queue-mode-row">
                <button type="button" class="grok-queue-toggle-btn active" data-value="custom">Custom</button>
                <button type="button" class="grok-queue-toggle-btn" data-value="normal">Normal</button>
                <button type="button" class="grok-queue-toggle-btn" data-value="extremely-crazy">Fun</button>
                <button type="button" class="grok-queue-toggle-btn" data-value="extremely-spicy-or-crazy">Spicy ⚡</button>
            </div>
            <label>Duration</label>
            <div class="grok-queue-toggle-row" id="grok-queue-duration-row">
                <button type="button" class="grok-queue-toggle-btn active" data-value="6">6s</button>
                <button type="button" class="grok-queue-toggle-btn" data-value="10">10s ⚡</button>
            </div>
            <label>Resolution</label>
            <div class="grok-queue-toggle-row" id="grok-queue-resolution-row">
                <button type="button" class="grok-queue-toggle-btn active" data-value="480p">480p</button>
                <button type="button" class="grok-queue-toggle-btn" data-value="720p">720p ⚡</button>
            </div>
            <div style="font-size:10px;color:#888;margin:-6px 0 10px 0;">⚡ = Requests override — require Super Grok. Wrong override may be flagged by Grok if ineligible.</div>
            <button id="grok-queue-add-btn">Add to Queue</button>
            <div id="grok-queue-status"></div>
        </div>
        <button id="grok-queue-fab" title="Video Gen Queue">🎯</button>
    `;

    if (!document.body) {
        console.warn('[Queue] document.body not available, retrying in 500ms');
        setTimeout(injectAddToQueueUI, 500);
        return;
    }
    document.body.appendChild(container);
    console.log('[Queue] FAB button injected successfully, postId:', postId);

    // FAB drag-to-reposition
    const fab = document.getElementById('grok-queue-fab');
    let dragState = null;
    fab.addEventListener('pointerdown', (e) => {
        dragState = { startX: e.clientX, startY: e.clientY, moved: false,
            origBottom: parseInt(getComputedStyle(container).bottom),
            origRight: parseInt(getComputedStyle(container).right) };
        fab.setPointerCapture(e.pointerId);
        fab.classList.add('dragging');
    });
    fab.addEventListener('pointermove', (e) => {
        if (!dragState) return;
        const dx = e.clientX - dragState.startX;
        const dy = e.clientY - dragState.startY;
        if (Math.abs(dx) > 3 || Math.abs(dy) > 3) dragState.moved = true;
        if (!dragState.moved) return;
        container.style.bottom = Math.max(0, dragState.origBottom - dy) + 'px';
        container.style.right = Math.max(0, dragState.origRight - dx) + 'px';
    });
    let fabDragOccurred = false;
    fab.addEventListener('pointerup', () => {
        fab.classList.remove('dragging');
        fabDragOccurred = !!(dragState && dragState.moved);
        dragState = null;
    });

    // Load defaults from settings
    chrome.storage.sync.get(['queueDefaultTarget', 'queueDefaultMaxRetries', 'queueDefaultVideoLength', 'queueDefaultResolution', 'queueDefaultMode'], (result) => {
        // Guard: elements may have been removed by page navigation before callback fires
        GrokVideoMode.applyQueueDefaults(result);
    });

    // Detect available presets from Video Options dropdown and filter mode buttons
    // Delay to ensure page is fully rendered (Video Options button must exist)
    setTimeout(async () => {
        const modes = await detectAvailablePresets();
        if (!modes) return; // null = detection failed, show all
        const modeRow = document.getElementById('grok-queue-mode-row');
        if (!modeRow) return;
        let hasActiveHidden = false;
        modeRow.querySelectorAll('.grok-queue-toggle-btn').forEach(btn => {
            if (!modes.includes(btn.dataset.value)) {
                if (btn.classList.contains('active')) hasActiveHidden = true;
                btn.style.display = 'none';
            }
        });
        // If the active mode was hidden, fall back to 'custom'
        if (hasActiveHidden) {
            GrokVideoMode.setToggleActive('grok-queue-mode-row', 'custom');
            GrokVideoMode.updatePromptHint('custom');
        }
    }, 2000);

    // Toggle button handlers for duration, resolution, and mode
    container.querySelectorAll('.grok-queue-toggle-row').forEach(row => {
        row.addEventListener('click', (e) => {
            const btn = e.target.closest('.grok-queue-toggle-btn');
            if (!btn) return;
            row.querySelectorAll('.grok-queue-toggle-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            // Update prompt hint when mode changes
            if (row.id === 'grok-queue-mode-row') {
                GrokVideoMode.updatePromptHint(btn.dataset.value);
            }
        });
    });

    // Try to read prompt from page input (V1: textarea, V2: contenteditable)
    const getPageInputValue = () => {
        const ta = document.querySelector('textarea[placeholder], textarea');
        if (ta && ta.value) return ta.value;
        const editables = Array.from(document.querySelectorAll('[contenteditable="true"]'))
            .filter(el => el.id !== 'grok-queue-prompt' && !el.closest('#grok-queue-fab'));
        if (editables.length > 0 && editables[0].textContent?.trim()) return editables[0].textContent.trim();
        return '';
    };

    setTimeout(() => {
        const queuePromptEl = document.getElementById('grok-queue-prompt');
        const val = getPageInputValue();
        if (queuePromptEl && val) {
            queuePromptEl.value = val;
        }
    }, 1000);

    // Toggle panel (skip if FAB was just dragged)
    document.getElementById('grok-queue-fab').addEventListener('click', () => {
        if (fabDragOccurred) { fabDragOccurred = false; return; }
        const panel = document.getElementById('grok-queue-panel');
        if (panel) panel.classList.toggle('open');
        // Try to read prompt from page input again
        const queuePromptEl = document.getElementById('grok-queue-prompt');
        const val = getPageInputValue();
        if (queuePromptEl && val && !queuePromptEl.value) {
            queuePromptEl.value = val;
        }
    });

    // Add to queue
    document.getElementById('grok-queue-add-btn').addEventListener('click', async () => {
        const prompt = document.getElementById('grok-queue-prompt').value.trim();
        const target = parseInt(document.getElementById('grok-queue-target').value) || 1;
        const retries = parseInt(document.getElementById('grok-queue-retries').value) || 5;
        const videoLength = parseInt(GrokVideoMode.getToggleValue('grok-queue-duration-row')) || 6;
        const resolutionName = GrokVideoMode.getToggleValue('grok-queue-resolution-row') || '480p';
        const mode = GrokVideoMode.getToggleValue('grok-queue-mode-row') || 'custom';
        const statusEl = document.getElementById('grok-queue-status');

        if (!prompt && mode === 'custom') {
            statusEl.textContent = '❌ Please enter a prompt';
            statusEl.style.color = '#f44336';
            return;
        }

        const addBtn = document.getElementById('grok-queue-add-btn');
        addBtn.disabled = true;

        try {
            const resp = await chrome.runtime.sendMessage({
                action: 'addQueueItem',
                item: { postId, prompt, targetSuccess: target, maxRetries: retries, videoLength, resolutionName, mode }
            });

            if (resp.success) {
                statusEl.textContent = '✅ Added to queue!';
                statusEl.style.color = '#4CAF50';
                setTimeout(() => {
                    statusEl.textContent = '';
                    document.getElementById('grok-queue-panel').classList.remove('open');
                }, 1500);
            } else {
                statusEl.textContent = '❌ ' + (resp.error || 'Failed');
                statusEl.style.color = '#f44336';
            }
        } catch (error) {
            statusEl.textContent = '❌ ' + error.message;
            statusEl.style.color = '#f44336';
        } finally {
            addBtn.disabled = false;
        }
    });
}

/**
 * Remove "Add to Queue" UI from page
 */
function removeAddToQueueUI() {
    const el = document.getElementById('grok-queue-inject');
    if (el) {
        el.remove();
        console.log('[Queue] Removed Add to Queue UI');
    }
}

// Check queue processing state on page load (queue processing works independently of sidepanel)
setTimeout(() => {
    checkQueueProcessingOnLoad();
}, 1000);

} // End of guard: window.__grokVideoDownloaderLoaded
