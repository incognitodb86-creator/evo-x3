/**
 * Batch Add: Fetch Recent IMAGE Posts
 *
 * Extracted from content.js so tests bind to the REAL production logic
 * (dual-export pattern, matches src/queue-logic.js / src/utils.js style).
 */

async function fetchRecentImagePosts(hoursLimit = 24) {
    console.log('='.repeat(60));
    console.log('📥 Fetch Recent Image Posts for Queue');
    console.log(`   Time range: last ${hoursLimit} hours`);
    console.log('='.repeat(60));

    const API_URL = 'https://grok.com/rest/media/post/list';
    const cutoffTime = Date.now() - (hoursLimit * 60 * 60 * 1000);
    const imagePosts = [];
    let cursor = null;
    let totalScanned = 0;

    try {
        while (true) {
            const payload = {
                limit: 40,
                filter: GrokUtils.buildLikedFilter()
            };

            if (cursor) {
                payload.cursor = cursor;
            }

            const response = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                throw new Error(`API returned HTTP ${response.status}`);
            }

            const data = await response.json();
            const posts = data.posts || [];

            if (posts.length === 0) break;

            let postsInRange = 0;

            for (const post of posts) {
                totalScanned++;

                if (!post.createTime) continue;
                const postTime = new Date(post.createTime).getTime();

                // Skip posts outside the time range (API may not return in strict chronological order)
                if (postTime < cutoffTime) continue;

                postsInRange++;

                // Only include top-level IMAGE posts (not children)
                // Child post IDs may redirect to parent page, causing URL mismatch in queue
                if (post.mediaType === 'MEDIA_POST_TYPE_IMAGE') {
                    imagePosts.push({ postId: post.id });
                }
            }

            console.log(`  ✓ Scanned ${totalScanned} posts, ${postsInRange} in range, found ${imagePosts.length} images so far`);

            // Stop if no posts in this batch were within range (all older than cutoff)
            if (postsInRange === 0) {
                console.log(`  ⏹ No posts in range in this batch, stopping scan`);
                break;
            }

            if (!data.nextCursor) break;
            cursor = data.nextCursor;

            await new Promise(resolve => setTimeout(resolve, 300));
        }
    } catch (error) {
        console.error('❌ fetchRecentImagePosts failed:', error);
        return { success: false, error: error.message };
    }

    console.log(`📊 Result: ${imagePosts.length} image posts from last ${hoursLimit}h (scanned ${totalScanned} total)`);

    return {
        success: true,
        posts: imagePosts,
        totalScanned
    };
}

const GrokRecentPosts = { fetchRecentImagePosts };

if (typeof module !== 'undefined' && module.exports) { module.exports = GrokRecentPosts; }
if (typeof window !== 'undefined') { window.GrokRecentPosts = GrokRecentPosts; }
if (typeof globalThis !== 'undefined') { globalThis.GrokRecentPosts = GrokRecentPosts; }
