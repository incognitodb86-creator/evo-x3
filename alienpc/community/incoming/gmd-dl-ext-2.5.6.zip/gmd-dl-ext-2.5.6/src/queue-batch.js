/**
 * Pure batch-add-to-queue logic — shared by sidepanel/queue.js.
 * Extracted so the dedup + payload-building + form validation used by
 * batchAddRecentPosts() is unit-testable against the REAL rules (Task 30).
 *
 * batchAddRecentPosts() itself stays in sidepanel/queue.js: it owns the
 * DOM/progress-UI orchestration (reading form inputs, updating
 * #batchAddProgress, sending one chrome.runtime.sendMessage per queue item,
 * calling sendToContentScript/showFormStatus/refreshQueueList) which is not
 * pure and not meaningfully unit-testable outside a DOM + chrome mock.
 */
const GrokQueueBatch = {
    /**
     * Validate the batch-add form before doing any work.
     * Mirrors sidepanel/queue.js:594-598 (same error string).
     *
     * @param {{prompt: string, mode: string}} form
     * @returns {{valid: boolean, error?: string}}
     */
    validateBatchForm({ prompt, mode }) {
        if (!prompt && mode === 'custom') {
            return { valid: false, error: 'Prompt required for Custom mode' };
        }
        return { valid: true };
    },

    /**
     * Given fetched posts, the postIds already in the queue, and the shared
     * item template (prompt/targetSuccess/maxRetries/videoLength/
     * resolutionName/mode from the batch-add form), compute which posts are
     * new vs. duplicates and build the queue-item payload for each new post.
     * Mirrors the dedup + payload loop in sidepanel/queue.js:635-660,
     * including in-batch dedup (a postId repeated within `posts` is only
     * added once).
     *
     * @param {Array<{postId: string}>} posts
     * @param {Set<string>|Array<string>} existingPostIds
     * @param {{prompt, targetSuccess, maxRetries, videoLength, resolutionName, mode}} itemTemplate
     * @returns {{
     *   toAdd: Array<object>,        // queue-item payloads to add, in order
     *   added: number,
     *   skipped: number,
     *   perPost: Array<object|null>  // parallel to `posts`; payload if added, null if skipped
     * }}
     */
    computeBatchQueueAdditions(posts, existingPostIds, itemTemplate) {
        const seen = existingPostIds instanceof Set
            ? new Set(existingPostIds)
            : new Set(existingPostIds || []);
        const { prompt, targetSuccess, maxRetries, videoLength, resolutionName, mode } = itemTemplate;

        const toAdd = [];
        const perPost = [];
        let added = 0;
        let skipped = 0;

        for (const post of posts) {
            if (seen.has(post.postId)) {
                skipped++;
                perPost.push(null);
            } else {
                const item = { postId: post.postId, prompt, targetSuccess, maxRetries, videoLength, resolutionName, mode };
                toAdd.push(item);
                perPost.push(item);
                added++;
                seen.add(post.postId);
            }
        }

        return { toAdd, added, skipped, perPost };
    }
};

if (typeof module !== 'undefined' && module.exports) { module.exports = GrokQueueBatch; }
if (typeof globalThis !== 'undefined') { globalThis.GrokQueueBatch = GrokQueueBatch; }
