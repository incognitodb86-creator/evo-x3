/**
 * 429 rate-limit detection — extracted from src/intercept.js so the
 * predicate is shared between production code and tests (dual-export
 * pattern, matches src/queue-logic.js / src/recent-posts.js style).
 *
 * intercept.js runs in the MAIN world and cannot use require(), so this
 * file is also loaded there directly (see manifest.json content_scripts)
 * and exposes itself as `window.GrokRateLimit` / `globalThis.GrokRateLimit`.
 */

/**
 * Returns the GROK_RATE_LIMITED postMessage payload for a 429 response,
 * or null for any other status. Callers must preserve this exact shape —
 * content.js's listener and the post-stats-bridge relay expect it verbatim.
 */
function buildRateLimitMessage(status, url) {
    if (status === 429) {
        return {
            type: 'GROK_RATE_LIMITED',
            payload: { status: 429, url }
        };
    }
    return null;
}

const GrokRateLimit = { buildRateLimitMessage };

if (typeof module !== 'undefined' && module.exports) { module.exports = GrokRateLimit; }
if (typeof window !== 'undefined') { window.GrokRateLimit = GrokRateLimit; }
if (typeof globalThis !== 'undefined') { globalThis.GrokRateLimit = GrokRateLimit; }
