/**
 * Filename router for chrome.downloads.onDeterminingFilename.
 * The old map was keyed by URL, so two pending downloads with the same URL
 * (identical data: URLs, HD==SD URL) collided and one fell back to Chrome's
 * default name. Entries now queue FIFO per URL and are bound to the download
 * id as soon as chrome.downloads.download() returns it; the listener looks
 * up by id first, then by URL.
 */
(function (root, factory) {
    const api = factory();
    if (typeof module === 'object' && module.exports) module.exports = api;
    else root.GrokDownloadRouter = api;
}(typeof self !== 'undefined' ? self : this, function () {
    'use strict';
    function createRouter() {
        const byUrl = new Map();        // url -> FIFO [{ filename, overwrite }]
        const byId = new Map();         // downloadId -> { filename, overwrite }
        const resolvedIds = new Set();  // ids the listener already served from the URL queue
        function expect(url, opts) {
            if (!byUrl.has(url)) byUrl.set(url, []);
            byUrl.get(url).push({ ...opts });
        }
        function shift(url) {
            const q = byUrl.get(url);
            if (!q || !q.length) return null;
            const e = q.shift();
            if (!q.length) byUrl.delete(url);
            return e;
        }
        // chrome.downloads.download() callback for a successful start.
        function bind(url, downloadId) {
            if (resolvedIds.delete(downloadId)) return; // listener ran first and consumed its entry
            const e = shift(url);
            if (e) byId.set(downloadId, e);
        }
        // download() failed to start: drop its entry.
        function cancel(url) { shift(url); }
        // onDeterminingFilename: suggestion for this item, or null if not ours.
        function resolve(item) {
            if (byId.has(item.id)) { const e = byId.get(item.id); byId.delete(item.id); return e; }
            const e = shift(item.url);
            if (e) { resolvedIds.add(item.id); return e; }
            return null;
        }
        const size = () => byId.size + [...byUrl.values()].reduce((a, q) => a + q.length, 0);
        return { expect, bind, cancel, resolve, size };
    }
    return { createRouter };
}));
