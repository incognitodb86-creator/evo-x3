/**
 * GMD capture manager — background-side owner of the capture queue.
 *
 * Every capture (DOM image, network result, finished video) lands here,
 * is deduped against the single ledger in GrokCaptureDB (key = media id,
 * or SHA-256 of the bytes when no id is known), downloaded right away, and
 * marked `saved` only when chrome.downloads reports `complete`.
 * Failures retry with backoff (403/404/410/timeouts; videos re-resolve their
 * URL); anything the server marked blocked/moderated is recorded and never
 * fetched. All dependencies are injected so this is testable in Node.
 */
(function (root, factory) {
    const api = factory();
    if (typeof module === 'object' && module.exports) module.exports = api;
    else root.GrokCaptureManager = api;
}(typeof self !== 'undefined' ? self : this, function () {
    'use strict';

    const HEALTH_KEY = 'grok_capture_health';
    const ENABLED_KEY = 'streamCaptureEnabled';
    const ALARM = 'gmdCaptureRetry';

    function createCaptureManager(deps) {
        const { db, core, chromeApi, fetchImpl, resolveVideo, readBlobAsDataUrl, router = null } = deps;
        const now = deps.now || (() => Date.now());
        const log = deps.log || { info() {}, ok() {}, warn() {}, fail() {} };
        const setTimer = deps.setTimer || ((fn, ms) => setTimeout(fn, ms));
        const getBasePath = deps.getBasePath || (async () => 'grok_downloads/stream');
        const FETCH_TIMEOUT_MS = { image: 60000, video: 180000 };

        // ---- health (serialized read-modify-write) ----------------------------
        let healthChain = Promise.resolve();
        function updateHealth(fn) {
            healthChain = healthChain.then(async () => {
                const cur = (await chromeApi.storage.local.get(HEALTH_KEY))[HEALTH_KEY] || {};
                const next = { ...cur, ...fn(cur) };
                await chromeApi.storage.local.set({ [HEALTH_KEY]: next });
                return next;
            }).catch(() => {});
            return healthChain;
        }
        const bump = (field, extra = {}) => updateHealth((h) => ({ [field]: (h[field] || 0) + 1, ...extra }));

        // ---- serial work queue -------------------------------------------------
        let work = Promise.resolve();
        const enqueue = (fn) => { work = work.then(fn).catch((e) => log.warn('Capture worker error', e && e.message)); return work; };

        async function handleItem(item, { tabId = null } = {}) {
            if (!item || typeof item !== 'object') return { accepted: false, reason: 'invalid' };
            const kind = item.kind === 'video' ? 'video' : 'image';
            const mediaId = core.normId(item.mediaId) || core.mediaIdFromUrl(item.url) || null;
            const key = core.dedupeKey({ mediaId, sha256: item.sha256 });
            if (!key) return { accepted: false, reason: 'no-key' };
            if (item.blocked === true || item.moderated === true) {
                // Record once so the health line can show it; never fetch.
                const r = await db.insertIfAbsent({ key, mediaId, kind, source: item.source || 'net', status: 'blocked' });
                if (r.inserted) { await bump('blocked'); log.info('Capture skipped (blocked/moderated)', key); }
                return { accepted: false, blocked: true, key };
            }
            if (item.url && !core.MEDIA_HOST_RE.test(item.url)) return { accepted: false, reason: 'host' };
            if (item.dataUrl && !/^data:(image|video)\//.test(item.dataUrl)) return { accepted: false, reason: 'data' };
            if (!item.url && !item.dataUrl && kind !== 'video') return { accepted: false, reason: 'no-media' };
            const createdAt = now();
            const filename = core.stableFilename({ basePath: await getBasePath(), mediaId, sha256: item.sha256, kind, mime: item.mime || (item.dataUrl ? item.dataUrl.slice(5, item.dataUrl.indexOf(';')) : null), url: item.url, createdAt });
            const r = await db.insertIfAbsent({
                key, mediaId, sha256: item.sha256 || null, kind, source: item.source || 'dom',
                url: item.url || null, dataUrl: item.dataUrl || null, mime: item.mime || null,
                filename, status: 'pending', attempts: 0, nextAttemptAt: 0, tabId, createdAt
            });
            if (!r.inserted) {
                // Same media seen again. Upgrade a pending row that has no payload yet.
                if (r.row.status !== 'saved' && !r.row.dataUrl && !r.row.url && (item.dataUrl || item.url)) {
                    await db.update(key, { dataUrl: item.dataUrl || null, url: item.url || null });
                }
                await bump('duplicates');
                return { accepted: false, duplicate: true, key, status: r.row.status };
            }
            await updateHealth((h) => ({ lastCaptureAt: createdAt, captured: (h.captured || 0) + 1 }));
            log.info('Capture queued', `${kind} ${key} (${item.source || 'dom'})`);
            enqueue(() => processKey(key));
            return { accepted: true, key };
        }

        async function fetchToDataUrl(url, kind) {
            const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
            let timedOut = false;
            const t = setTimer(() => { timedOut = true; if (ctrl) ctrl.abort(); }, FETCH_TIMEOUT_MS[kind] || 60000);
            try {
                const res = await fetchImpl(url, { credentials: 'include', signal: ctrl ? ctrl.signal : undefined });
                if (!res.ok) return { ok: false, status: res.status };
                const blob = await res.blob();
                return { ok: true, dataUrl: await readBlobAsDataUrl(blob), mime: blob.type || null };
            } catch (e) {
                return { ok: false, timeout: timedOut, error: e && e.message };
            } finally {
                if (typeof clearTimeout === 'function') clearTimeout(t);
            }
        }

        function download(url, filename) {
            return new Promise((resolve) => {
                if (router) router.expect(url, { filename, overwrite: false });
                chromeApi.downloads.download({ url, filename, conflictAction: 'uniquify', saveAs: false }, (id) => {
                    const err = chromeApi.runtime.lastError;
                    if (err || id === undefined) { if (router) router.cancel(url); resolve({ ok: false, error: (err && err.message) || 'download failed' }); }
                    else { if (router) router.bind(url, id); resolve({ ok: true, downloadId: id }); }
                });
            });
        }

        async function processKey(key) {
            const row = await db.get(key);
            if (!row || !['pending', 'retry'].includes(row.status)) return;
            if (row.nextAttemptAt && row.nextAttemptAt > now()) return;
            await db.update(key, { status: 'downloading' });
            let url = row.dataUrl || null;
            if (!url) {
                let src = row.url;
                if (!src && row.kind === 'video' && row.mediaId) {
                    const resolved = await resolveVideo(row.mediaId).catch(() => null);
                    if (resolved && resolved.blocked) return markBlocked(row);
                    src = resolved && resolved.url;
                    if (src) await db.update(key, { url: src });
                }
                if (!src) return fail(row, { status: null, error: 'video URL not ready' });
                const f = await fetchToDataUrl(src, row.kind);
                if (!f.ok) return fail(row, { status: f.status ?? null, timeout: f.timeout, error: f.error || `HTTP ${f.status}` });
                url = f.dataUrl;
            }
            const d = await download(url, row.filename);
            if (!d.ok) return fail(row, { status: null, error: d.error });
            await db.update(key, { downloadId: d.downloadId });
        }

        async function markBlocked(row) {
            await db.update(row.key, { status: 'blocked', dataUrl: null });
            await bump('blocked');
        }

        async function fail(row, { status = null, interrupt = null, timeout = false, error = null }) {
            const attempts = (row.attempts || 0) + 1;
            const plan = core.nextRetry({ attempts, status, interrupt, timeout });
            if (plan.retry) {
                const when = now() + plan.delayMs;
                await db.update(row.key, {
                    status: 'retry', attempts, nextAttemptAt: when, downloadId: null, lastError: error || interrupt || String(status),
                    url: (plan.reresolve && row.kind === 'video') ? null : row.url
                });
                schedule(when, row.key);
                log.warn('Capture retry scheduled', `${row.key} attempt ${attempts} in ${Math.round(plan.delayMs / 1000)}s (${error || interrupt || status})`);
            } else {
                await db.update(row.key, { status: 'failed', attempts, downloadId: null, lastError: error || interrupt || String(status) });
                await bump('failed', { lastFailedAt: now(), lastError: String(error || interrupt || status).slice(0, 200) });
                log.fail('Capture failed', `${row.key}: ${error || interrupt || status} (${plan.reason})`);
            }
        }

        function schedule(when, key) {
            const delay = Math.max(0, when - now());
            if (chromeApi.alarms && chromeApi.alarms.create) chromeApi.alarms.create(ALARM, { when: Math.max(when, now() + 30000) });
            if (delay <= 30000) setTimer(() => enqueue(() => processKey(key)), delay);
        }

        async function onDownloadChanged(delta) {
            const state = delta && delta.state && delta.state.current;
            if (state !== 'complete' && state !== 'interrupted') return false;
            const row = await db.getByDownloadId(delta.id);
            if (!row || row.status !== 'downloading') return false;
            if (state === 'complete') {
                await db.update(row.key, { status: 'saved', savedAt: now(), dataUrl: null, downloadId: null, lastError: null });
                await updateHealth((h) => ({ saved: (h.saved || 0) + 1, lastSavedAt: now() }));
                log.ok('Capture saved', `${row.key} -> ${row.filename}`);
            } else {
                const interrupt = delta.error && delta.error.current;
                await fail(row, { interrupt: interrupt || 'INTERRUPTED', error: interrupt });
            }
            return true;
        }

        async function runDue() {
            const t = now();
            const rows = [...await db.listByStatus('pending'), ...await db.listByStatus('retry'), ...await db.listByStatus('downloading')];
            let soonest = null;
            for (const r of rows) {
                if (r.status === 'downloading') {
                    // SW died mid-attempt: no download id after 10 min -> retry it.
                    if (!r.downloadId && t - (r.updatedAt || 0) > 10 * 60e3) await db.update(r.key, { status: 'retry', nextAttemptAt: t });
                    else continue;
                }
                if (!r.nextAttemptAt || r.nextAttemptAt <= t) enqueue(() => processKey(r.key));
                else soonest = Math.min(soonest ?? Infinity, r.nextAttemptAt);
            }
            if (soonest) schedule(soonest, null);
            return work;
        }

        async function retryFailed() {
            const rows = await db.listByStatus('failed');
            for (const r of rows) {
                await db.update(r.key, { status: 'retry', attempts: 0, nextAttemptAt: 0 });
                enqueue(() => processKey(r.key));
            }
            await updateHealth(() => ({ failed: 0 }));
            return rows.length;
        }

        async function prune() {
            const rows = await db.all();
            const p = core.selectPrunable(rows, now());
            if (p.delete.length) await db.remove(p.delete);
            for (const k of p.stripPayload) await db.update(k, { dataUrl: null });
            return p;
        }

        async function heartbeat(tabId) {
            await updateHealth(() => ({ lastHeartbeatAt: now(), lastHeartbeatTab: tabId ?? null }));
        }
        async function noteParseError(n = 1) {
            await updateHealth((h) => ({ parseErrors: (h.parseErrors || 0) + n }));
        }
        async function status() {
            const counts = await db.counts();
            const health = (await chromeApi.storage.local.get(HEALTH_KEY))[HEALTH_KEY] || {};
            const enabled = (await chromeApi.storage.local.get(ENABLED_KEY))[ENABLED_KEY] === true;
            const h = { ...health, enabled, pending: counts.pending + counts.retry + counts.downloading, failed: counts.failed, saved: counts.saved, blocked: counts.blocked };
            return { counts, health: h, line: core.formatHealth(h, now()) };
        }

        return { handleItem, processKey, onDownloadChanged, runDue, retryFailed, prune, heartbeat, noteParseError, status, idle: () => work, ALARM };
    }

    return { createCaptureManager, HEALTH_KEY, ENABLED_KEY, ALARM };
}));
