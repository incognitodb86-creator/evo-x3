/**
 * Video Mode Selection (Custom/Normal/Fun/Spicy) — queue & story-mode helpers.
 * Extracted from content.js so tests bind to the REAL production logic
 * (dual-export pattern, matches src/queue-logic.js / src/recent-posts.js style).
 */

/** Update prompt textarea placeholder based on selected mode. (content.js) */
function updatePromptHint(mode) {
    const promptEl = document.getElementById('grok-queue-prompt');
    if (!promptEl) return;
    if (mode === 'custom') {
        promptEl.placeholder = 'Enter video generation prompt...';
    } else {
        promptEl.placeholder = 'Optional — AI generates if empty';
    }
}

/** Get active toggle value from a toggle row. (content.js) */
function getToggleValue(rowId) {
    const active = document.querySelector(`#${rowId} .grok-queue-toggle-btn.active`);
    return active ? active.dataset.value : null;
}

/** Set active toggle button by value. (content.js) */
function setToggleActive(rowId, value) {
    const row = document.getElementById(rowId);
    if (!row) return;
    row.querySelectorAll('.grok-queue-toggle-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.value === value);
    });
}

/**
 * Apply saved queueDefault* settings (chrome.storage.sync) to the "Add to
 * Queue" FAB panel DOM. Every lookup is guarded because the panel's elements
 * may have already been removed by page navigation before the
 * chrome.storage.sync.get callback fires. (content.js injectAddToQueueUI)
 */
function applyQueueDefaults(result) {
    if (result.queueDefaultTarget) {
        const el = document.getElementById('grok-queue-target');
        if (el) el.value = result.queueDefaultTarget;
    }
    if (result.queueDefaultMaxRetries) {
        const el = document.getElementById('grok-queue-retries');
        if (el) el.value = result.queueDefaultMaxRetries;
    }
    if (result.queueDefaultVideoLength) {
        setToggleActive('grok-queue-duration-row', String(result.queueDefaultVideoLength));
    }
    if (result.queueDefaultResolution) {
        setToggleActive('grok-queue-resolution-row', result.queueDefaultResolution);
    }
    if (result.queueDefaultMode) {
        setToggleActive('grok-queue-mode-row', result.queueDefaultMode);
        updatePromptHint(result.queueDefaultMode);
    }
}

/**
 * Set the DOM data attributes that intercept.js (MAIN world) reads to
 * override mode/videoLength/resolutionName in the outgoing video-gen
 * request. Always writes all three, substituting the same "no override"
 * defaults intercept.js itself would otherwise use (custom / 6s / 480p) —
 * both call sites (content.js waitForInputAndFill and queueFillAndSubmit)
 * do this unconditionally, never skipping a write for default values.
 */
function applyVideoOverrides(mode, videoLength, resolutionName) {
    document.documentElement.dataset.grokQueueVideoLength = String(videoLength || 6);
    document.documentElement.dataset.grokQueueResolution = resolutionName || '480p';
    document.documentElement.dataset.grokQueueMode = mode || 'custom';
    // TTL marker: intercept.js ignores (and clears) overrides older than
    // QUEUE_OVERRIDE_TTL_MS so a submit that never happened can't leak them
    // into the next manual generation.
    document.documentElement.dataset.grokQueueSetAt = String(Date.now());
}

/** Remove every queue override (queue stop/pause). */
function clearVideoOverrides() {
    const ds = document.documentElement.dataset;
    delete ds.grokQueueVideoLength;
    delete ds.grokQueueResolution;
    delete ds.grokQueueMode;
    delete ds.grokQueuePrompt;
    delete ds.grokQueueSetAt;
}

/** Preset menuitem label → --mode= value. (content.js _detectAvailablePresetsImpl) */
const PRESET_TO_MODE = {
    'Spicy': 'extremely-spicy-or-crazy',
    'Fun': 'extremely-crazy',
    'Normal': 'normal'
};

/**
 * Pure label→mode mapping extracted from _detectAvailablePresetsImpl's menu
 * item loop. Given the (already-trimmed) innerText of each `[role="menuitem"]`
 * found in the opened Video Options / Settings dropdown, returns the list of
 * available mode values — always including 'custom'. A preset matches on an
 * exact label (V1 leaf items, e.g. "Fun") or the label followed by a space or
 * newline (V2 items render as "Fun\nHilarious results" via innerText).
 * (content.js _detectAvailablePresetsImpl)
 */
function computeAvailableModes(menuItemTexts) {
    const availableModes = ['custom']; // Custom is always available
    for (const text of menuItemTexts) {
        if (!text) continue;
        for (const [presetName, modeValue] of Object.entries(PRESET_TO_MODE)) {
            if (text === presetName || text.startsWith(presetName + ' ') || text.startsWith(presetName + '\n')) {
                availableModes.push(modeValue);
                break;
            }
        }
    }
    return availableModes;
}

const GrokVideoMode = {
    updatePromptHint,
    getToggleValue,
    setToggleActive,
    applyQueueDefaults,
    applyVideoOverrides,
    clearVideoOverrides,
    PRESET_TO_MODE,
    computeAvailableModes
};

if (typeof module !== 'undefined' && module.exports) { module.exports = GrokVideoMode; }
if (typeof window !== 'undefined') { window.GrokVideoMode = GrokVideoMode; }
if (typeof globalThis !== 'undefined') { globalThis.GrokVideoMode = GrokVideoMode; }
