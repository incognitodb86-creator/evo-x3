/**
 * MAIN World Fetch Interceptor
 * Intercepts Grok streaming conversation API to detect video generation results.
 * Runs at document_start in MAIN world on grok.com/*
 */

if (!window.__grokInterceptLoaded) {
    window.__grokInterceptLoaded = true;

    const originalFetch = window.fetch;
    // Captured at load so a page script can't swap it later.
    const Core = window.GrokCaptureCore || null;
    const QUEUE_OVERRIDE_TTL_MS = 120000;
    const CONV_RE = /\/rest\/app-chat\/conversations\//;

    // ---- passive media capture (log-only on parse failures) -------------
    let parseErrors = 0;
    let parseErrorTimer = null;
    function noteParseError() {
        parseErrors++;
        if (parseErrorTimer) return;
        parseErrorTimer = setTimeout(() => {
            window.postMessage({ type: 'GROK_CAPTURE_PARSE_ERROR', payload: { count: parseErrors } }, window.location.origin);
            parseErrors = 0;
            parseErrorTimer = null;
        }, 5000);
    }
    // queueSignal: only the fetch path (as before this patch) feeds the Video
    // Gen Queue's result counting; XHR/WS/EventSource taps only capture media,
    // so a duplicated transport can never double-count a queue result.
    function inspectJson(data, queueSignal = false) {
        if (queueSignal) { try { checkForVideoGenResult(data); } catch (e) { /* never throw into the page */ } }
        if (!Core) return;
        try {
            const items = Core.extractMediaResults(data).map((r) => ({
                kind: r.kind, mediaId: r.mediaId || null, url: r.url || null,
                dataBase64: r.dataBase64 || null, mime: r.mime || null, blocked: r.blocked === true
            }));
            if (items.length) window.postMessage({ type: 'GROK_MEDIA_CAPTURE', payload: { items } }, window.location.origin);
        } catch (e) {
            noteParseError();
        }
    }
    function inspectLine(line, queueSignal = false) {
        const parsed = Core ? Core.parseEventLine(line) : (() => { try { return JSON.parse(String(line).trim().replace(/^data:\s*/, '')); } catch (e) { return undefined; } })();
        if (parsed === null) { noteParseError(); return; }
        if (parsed !== undefined) inspectJson(parsed, queueSignal);
    }
    function inspectText(text) {
        if (typeof text !== 'string' || !text) return;
        const lines = text.split('\n');
        if (lines.length === 1) { inspectLine(text); return; }
        for (const l of lines) inspectLine(l);
    }
    async function inspectStream(stream) {
        try {
            const reader = stream.getReader();
            const decoder = new TextDecoder();
            let buffer = '';
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop();
                for (const line of lines) inspectLine(line, true);
            }
            if (buffer.trim()) inspectLine(buffer, true);
        } catch (e) {
            // Stream may be cancelled by the page — that's OK
        }
    }

    // Queue overrides -> patched body string, or null when nothing applies.
    function patchBody(bodyStr) {
        const el = document.documentElement;
        const setAt = Number(el.dataset.grokQueueSetAt || 0);
        const clear = () => {
            delete el.dataset.grokQueueVideoLength;
            delete el.dataset.grokQueueResolution;
            delete el.dataset.grokQueueMode;
            delete el.dataset.grokQueuePrompt;
            delete el.dataset.grokQueueSetAt;
        };
        const overrideLength = el.dataset.grokQueueVideoLength;
        const overrideRes = el.dataset.grokQueueResolution;
        const overrideMode = el.dataset.grokQueueMode;
        const overridePrompt = el.dataset.grokQueuePrompt;
        if (!(overrideLength || overrideRes || overrideMode || overridePrompt)) return null;
        if (setAt && Date.now() - setAt > QUEUE_OVERRIDE_TTL_MS) {
            console.warn('[GrokIntercept] Stale queue overrides ignored (TTL)');
            clear();
            return null;
        }
        const bodyData = JSON.parse(bodyStr);
        let patched = false;
        const config = bodyData?.responseMetadata?.modelConfigOverride?.modelMap?.videoGenModelConfig;
        if (config) {
            const origLength = config.videoLength;
            const origRes = config.resolutionName;
            if (overrideLength) config.videoLength = parseInt(overrideLength);
            if (overrideRes) config.resolutionName = overrideRes;
            console.log(`[GrokIntercept] ✅ Patched videoGenModelConfig: videoLength ${origLength} → ${config.videoLength}, resolution ${origRes} → ${config.resolutionName}`);
            patched = true;
        } else if (overrideLength || overrideRes) {
            console.warn('[GrokIntercept] ⚠️ Queue overrides found but no videoGenModelConfig in request body');
        }
        // Ensure prompt is in the message (ProseMirror may not see content script's fill)
        if (overridePrompt && bodyData.message !== undefined) {
            const currentMsg = (bodyData.message || '').trim();
            if (!currentMsg || !currentMsg.includes(overridePrompt.substring(0, 20))) {
                const imageUrlMatch = currentMsg.match(/^(https:\/\/imagine-public\.x\.ai\/\S+)\s*/);
                bodyData.message = imageUrlMatch ? `${imageUrlMatch[1]} ${overridePrompt}` : overridePrompt;
                console.log('[GrokIntercept] ✅ Patched message with queue prompt');
                patched = true;
            }
        }
        if (overrideMode && bodyData.message) {
            if (/--mode=\S+/.test(bodyData.message)) bodyData.message = bodyData.message.replace(/--mode=\S+/, `--mode=${overrideMode}`);
            else bodyData.message = bodyData.message.trimEnd() + ` --mode=${overrideMode}`;
            console.log(`[GrokIntercept] ✅ Patched mode in message: "--mode=${overrideMode}"`);
            patched = true;
        }
        clear(); // overrides are single-use
        return patched ? JSON.stringify(bodyData) : null;
    }

    window.fetch = async function (...args) {
        let [resource, init] = args;
        const isRequest = typeof Request !== 'undefined' && resource instanceof Request;
        const url = typeof resource === 'string' ? resource : (resource instanceof URL ? resource.href : resource?.url || '');

        // Only intercept conversation API calls
        if (!CONV_RE.test(url)) {
            return originalFetch.apply(this, args);
        }

        // POST only — read the method from init OR from a Request object
        // (fetch(Request) used to be treated as GET and skipped).
        const method = (init?.method || (isRequest ? resource.method : 'GET') || 'GET').toUpperCase();
        if (method !== 'POST') {
            return originalFetch.apply(this, args);
        }

        try {
            if (init?.body && typeof init.body === 'string') {
                const nb = patchBody(init.body);
                if (nb) init = { ...init, body: nb };
            } else if (isRequest && !init?.body) {
                const el = document.documentElement;
                if (el.dataset.grokQueueVideoLength || el.dataset.grokQueuePrompt || el.dataset.grokQueueMode || el.dataset.grokQueueResolution) {
                    const bodyStr = await resource.clone().text();
                    const nb = bodyStr ? patchBody(bodyStr) : null;
                    if (nb) resource = new Request(resource, { body: nb });
                }
            }
        } catch (e) {
            console.warn('[GrokIntercept] Failed to patch request body:', e);
        }

        const response = await originalFetch.call(this, resource, init);

        // Detect 429 Too Many Requests — notify content script to stop queue
        const rateLimitMsg = GrokRateLimit.buildRateLimitMessage(response.status, url);
        if (rateLimitMsg) {
            console.warn('[GrokIntercept] ⚠️ 429 Too Many Requests — rate limited');
            window.postMessage(rateLimitMsg, '*');
            return response;
        }

        // Inspect a CLONE; the page gets the original response untouched
        // (the old tee + new Response() dropped url/redirected/type).
        try {
            if (response.body) inspectStream(response.clone().body);
        } catch (e) {
            console.warn('[GrokIntercept] Failed to clone stream:', e);
        }
        return response;
    };

    // ---- XHR (passive) ----------------------------------------------------
    try {
        const XHR = window.XMLHttpRequest && window.XMLHttpRequest.prototype;
        if (XHR && !XHR.__gmdTapped) {
            XHR.__gmdTapped = true;
            const origOpen = XHR.open;
            const origSend = XHR.send;
            XHR.open = function (method, url) {
                try { this.__gmdTap = { method: String(method || 'GET').toUpperCase(), url: String(url || '') }; } catch (e) { /* ignore */ }
                return origOpen.apply(this, arguments);
            };
            XHR.send = function () {
                try {
                    const tap = this.__gmdTap;
                    if (tap && tap.method === 'POST' && CONV_RE.test(tap.url)) {
                        this.addEventListener('load', () => {
                            try {
                                if (this.responseType === '' || this.responseType === 'text') inspectText(this.responseText);
                                else if (this.responseType === 'json' && this.response) inspectJson(this.response);
                            } catch (e) { noteParseError(); }
                        });
                    }
                } catch (e) { /* never break the page */ }
                return origSend.apply(this, arguments);
            };
        }
    } catch (e) { console.warn('[GrokIntercept] XHR tap unavailable:', e); }

    // ---- WebSocket / EventSource (passive listeners only) -----------------
    const tappedCtors = new WeakSet();
    function tapConstructor(name, match) {
        try {
            const Orig = window[name];
            if (typeof Orig !== 'function' || tappedCtors.has(Orig)) return;
            const Tapped = new Proxy(Orig, {
                construct(target, cargs, newTarget) {
                    const inst = Reflect.construct(target, cargs, newTarget);
                    try {
                        const u = String(cargs[0] && (cargs[0].href || cargs[0]) || '');
                        if (match(u)) {
                            inst.addEventListener('message', (ev) => {
                                try { if (typeof ev.data === 'string') inspectText(ev.data); } catch (e) { noteParseError(); }
                            });
                        }
                    } catch (e) { /* ignore */ }
                    return inst;
                }
            });
            tappedCtors.add(Tapped);
            window[name] = Tapped;
        } catch (e) { console.warn(`[GrokIntercept] ${name} tap unavailable:`, e); }
    }
    tapConstructor('WebSocket', (u) => /^wss?:\/\/([a-z0-9-]+\.)?grok\.com\/ws\//i.test(u) || u.startsWith('/ws/'));
    tapConstructor('EventSource', (u) => CONV_RE.test(u) || /\/rest\/(app-chat|imagine|media)\//.test(u));

    function checkForVideoGenResult(data) {
        // Look for streamingVideoGenerationResponse
        const videoGenResp = data?.result?.response?.streamingVideoGenerationResponse
            || data?.streamingVideoGenerationResponse;

        if (!videoGenResp) return;

        // Log first progress event to verify resolution/dimensions
        if (videoGenResp.progress === 1) {
            console.log(`[GrokIntercept] 📹 Video gen started — resolution: ${videoGenResp.resolutionName}, ${videoGenResp.width}x${videoGenResp.height}`);
        }

        if (videoGenResp.progress !== 100) return;

        const moderated = videoGenResp.moderated === true;
        const videoPostId = videoGenResp.postId || null;
        const parentPostId = videoGenResp.parentPostId || null;
        const videoPrompt = videoGenResp.prompt || '';

        console.log(`[GrokIntercept] Video generation complete — moderated: ${moderated}, parentPostId: ${parentPostId}, videoPostId: ${videoPostId}`);

        const resultId = `${videoPostId || parentPostId || 'r'}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

        // Post to ISOLATED world via window.postMessage
        window.postMessage({
            type: 'GROK_VIDEO_GEN_RESULT',
            payload: {
                resultId,
                parentPostId,
                videoPostId,
                moderated,
                videoPrompt
            }
        }, '*');
    }

    // Listen for GROK_FILL_EDITOR messages from content script (ISOLATED world)
    // Content scripts cannot access TipTap's editor instance on DOM elements,
    // so we handle it here in MAIN world where el.editor is accessible.
    window.addEventListener('message', (event) => {
        if (event.source !== window || event.data?.type !== 'GROK_FILL_EDITOR') return;
        if (typeof event.data.payload?.text !== 'string') return;

        const { text } = event.data.payload;
        if (!text) return;

        try {
            const el = document.querySelector('[contenteditable="true"]');
            if (!el) {
                console.warn('[GrokIntercept] FILL_EDITOR: no contenteditable found');
                window.postMessage({ type: 'GROK_FILL_EDITOR_RESULT', payload: { success: false, error: 'no contenteditable' } }, '*');
                return;
            }

            const editor = el.editor;
            if (!editor || !editor.commands?.insertContent) {
                console.warn('[GrokIntercept] FILL_EDITOR: no TipTap editor instance found');
                window.postMessage({ type: 'GROK_FILL_EDITOR_RESULT', payload: { success: false, error: 'no editor instance' } }, '*');
                return;
            }

            // Clear existing content and insert new text
            editor.commands.setContent('');
            editor.commands.insertContent(text);
            const filled = editor.getText?.() || '';
            console.log(`[GrokIntercept] ✅ FILL_EDITOR: inserted ${filled.length} chars via TipTap API`);
            window.postMessage({ type: 'GROK_FILL_EDITOR_RESULT', payload: { success: true, length: filled.length } }, '*');
        } catch (e) {
            console.warn('[GrokIntercept] FILL_EDITOR error:', e);
            window.postMessage({ type: 'GROK_FILL_EDITOR_RESULT', payload: { success: false, error: e.message } }, '*');
        }
    });

    // Listen for GROK_SUBMIT_EDITOR — press Enter in TipTap to submit the form
    // This is more reliable than clicking the submit button from content script
    window.addEventListener('message', (event) => {
        if (event.source !== window || event.data?.type !== 'GROK_SUBMIT_EDITOR') return;
        if (!event.data.payload || typeof event.data.payload !== 'object') return;

        try {
            const el = document.querySelector('[contenteditable="true"]');
            if (!el) {
                window.postMessage({ type: 'GROK_SUBMIT_EDITOR_RESULT', payload: { success: false, error: 'no contenteditable' } }, '*');
                return;
            }

            el.focus();
            // Dispatch Enter key — Grok's TipTap setup treats Enter as submit (not new line)
            const enterOpts = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
            el.dispatchEvent(new KeyboardEvent('keydown', enterOpts));
            el.dispatchEvent(new KeyboardEvent('keypress', enterOpts));
            el.dispatchEvent(new KeyboardEvent('keyup', enterOpts));
            console.log('[GrokIntercept] ✅ SUBMIT_EDITOR: dispatched Enter key');
            window.postMessage({ type: 'GROK_SUBMIT_EDITOR_RESULT', payload: { success: true } }, '*');
        } catch (e) {
            console.warn('[GrokIntercept] SUBMIT_EDITOR error:', e);
            window.postMessage({ type: 'GROK_SUBMIT_EDITOR_RESULT', payload: { success: false, error: e.message } }, '*');
        }
    });

    console.log('[GrokIntercept] Fetch interceptor loaded');
}
