/**
 * Pure queue decision logic — shared by background.js (canonical handler).
 * Extracted so the state machine is unit-testable against the REAL rules.
 *
 * NOTE: this deliberately pins `updates.status = 'active'` in the retry
 * branch (neither completed nor failed). updateQueueItem merges over the
 * row's CURRENT state, and a concurrent reconcileStaleActiveItems pass may
 * have demoted the item to 'pending' between the read that produced `item`
 * and the write that applies these `updates`. Re-asserting 'active' here
 * prevents that race from stalling the queue (see Task 7).
 */
const QueueLogic = {
    computeQueueResultUpdates(item, moderated, resultId = null) {
        const updates = {
            totalAttempts: item.totalAttempts + 1,
            lastResultId: resultId
        };
        if (moderated) {
            updates.currentFailure = item.currentFailure + 1;
        } else {
            updates.currentSuccess = item.currentSuccess + 1;
        }

        const newSuccess = updates.currentSuccess !== undefined ? updates.currentSuccess : item.currentSuccess;
        const newFailure = updates.currentFailure !== undefined ? updates.currentFailure : item.currentFailure;

        let shouldRetry = false;
        let shouldMoveNext = false;
        if (newSuccess >= item.targetSuccess) {
            updates.status = 'completed';
            shouldMoveNext = true;
        } else if (newFailure >= item.maxRetries) {
            updates.status = 'failed';
            shouldMoveNext = true;
        } else {
            updates.status = 'active';
            shouldRetry = true;
        }
        return { updates, shouldRetry, shouldMoveNext };
    }
};

if (typeof module !== 'undefined' && module.exports) { module.exports = QueueLogic; }
if (typeof globalThis !== 'undefined') { globalThis.QueueLogic = QueueLogic; }
