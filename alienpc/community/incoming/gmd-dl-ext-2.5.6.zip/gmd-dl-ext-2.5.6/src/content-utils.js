/**
 * Grok Video Downloader - Content Utilities
 * Pure functions extracted from content.js for testing
 */

(function(root, factory) {
    if (typeof module === 'object' && module.exports) {
        // Node.js/CommonJS
        const GrokUtils = require('./utils');
        module.exports = factory(GrokUtils);
    } else if (typeof define === 'function' && define.amd) {
        // AMD
        define(['GrokUtils'], factory);
    } else {
        // Browser globals
        root.ContentUtils = factory(root.GrokUtils);
    }
}(typeof self !== 'undefined' ? self : this, function(GrokUtils) {
    'use strict';

    /**
     * Check if a timestamp is within a date range
     * @param {number} itemTimestamp - The timestamp to check (ms)
     * @param {number|null} fromTimestamp - Start of range (ms), null means no lower bound
     * @param {number|null} toTimestamp - End of range (ms), null means no upper bound
     * @returns {boolean}
     */
    function isInDateRange(itemTimestamp, fromTimestamp, toTimestamp) {
        if (fromTimestamp && itemTimestamp < fromTimestamp) return false;
        if (toTimestamp && itemTimestamp > toTimestamp) return false;
        return true;
    }

    /**
     * Filter items by date range based on createTime field
     * @param {Array} items - Array of items with createTime field
     * @param {number|null} fromDate - Start timestamp (ms)
     * @param {number|null} toDate - End timestamp (ms)
     * @returns {{filtered: Array, excluded: Array}}
     */
    function filterByDateRange(items, fromDate, toDate) {
        const filtered = [];
        const excluded = [];

        for (const item of items) {
            if (!item.createTime) {
                excluded.push({ item, reason: 'missing_createTime' });
                continue;
            }
            const itemTimestamp = new Date(item.createTime).getTime();
            if (isInDateRange(itemTimestamp, fromDate, toDate)) {
                filtered.push(item);
            } else {
                excluded.push({ item, reason: 'out_of_range' });
            }
        }

        return { filtered, excluded };
    }

    /**
     * Map raw image post data to download data format
     * @param {Object} img - Raw image post from API
     * @param {Object} options - Options including promptAsFilename
     * @returns {Object} - Formatted image download data
     */
    function mapImageToDownloadData(img, options = {}) {
        const ext = GrokUtils.getExtFromMediaUrl(img.mediaUrl, 'png');

        let filename;
        const filenameMode = options.filenameMode || (options.promptAsFilename ? 'prompt' : 'native');
        if (filenameMode === 'custom') {
            const applied = GrokUtils.applyFilenameTemplate(options.filenameTemplateImage, {
                createTime: img.createTime,
                id: img.id,
                prompt: img.originalPrompt || img.prompt,
                quality: ''
            });
            filename = `${applied || img.id}.${ext}`;
        } else if (filenameMode === 'prompt') {
            const dateTimeStr = GrokUtils.formatDateWithTime(img.createTime);
            const effectivePrompt = img.originalPrompt || img.prompt;
            const sanitizedPrompt = GrokUtils.sanitizePromptForFilename(effectivePrompt, 120, img.id);
            filename = `img_${dateTimeStr}_${sanitizedPrompt}.${ext}`;
        } else {
            const dateStr = GrokUtils.formatDateYYYYMMDD(img.createTime);
            filename = `grok_image_${dateStr}_${img.id}.${ext}`;
        }

        return {
            id: img.id,
            type: 'image',
            url: img.mediaUrl,
            filename: filename,
            userId: img.userId,
            createTime: img.createTime,
            prompt: img.prompt,
            originalPrompt: img.originalPrompt,
            downloaded: false,
            downloadedAt: null
        };
    }

    /**
     * Map raw video post data to download data format
     * @param {Object} video - Raw video post from API
     * @param {Object} options - Options (reserved for future use)
     * @returns {Object} - Formatted video download data
     */
    function mapVideoToDownloadData(video, options = {}) {
        if (!video.mediaUrl) {
            console.warn('[mapVideoToDownloadData] No mediaUrl for video', video.id, '— raw keys:', Object.keys(video));
        }
        return {
            id: video.id,
            type: 'video',
            url: video.mediaUrl,
            hdUrl: video.hdMediaUrl || null,
            hd1080Url: video.hd1080MediaUrl || null,
            resolutionName: video.resolutionName || null,
            detailUrl: `https://grok.com/imagine/post/${video.id}`,
            userId: video.userId,
            createTime: video.createTime,
            prompt: video.prompt,
            originalPrompt: video.originalPrompt,
            downloaded: false,
            downloadedAt: null
        };
    }

    /**
     * Build the download filename for an asset-sourced item (image or video),
     * honoring the same `filenameMode` contract used across the codebase
     * ('native'|'prompt'|'custom'). Extracted out of mapAssetToDownloadData
     * so the allmedia video-prompt backfill (content.js
     * backfillVideoPromptsFromSource) can re-derive a video's filename after
     * borrowing its source image's prompt, without duplicating this logic.
     * @param {Object} params
     * @param {string} params.assetId
     * @param {string} params.ext
     * @param {boolean} params.isVideo
     * @param {?string} params.createTime
     * @param {string} params.prompt - '' when the asset has no prompt of its own
     * @param {string} [params.filenameMode] - 'native' (default) | 'prompt' | 'custom'
     * @param {string} [params.filenameTemplateImage]
     * @param {string} [params.filenameTemplateVideo]
     * @returns {string} filename
     */
    function buildAssetFilename({ assetId, ext, isVideo, createTime, prompt, filenameMode, filenameTemplateImage, filenameTemplateVideo }) {
        const mode = filenameMode || 'native';
        const safePrompt = prompt || '';

        if (mode === 'custom') {
            const template = isVideo ? filenameTemplateVideo : filenameTemplateImage;
            const applied = GrokUtils.applyFilenameTemplate(template, {
                createTime,
                id: assetId,
                prompt: safePrompt,
                quality: ''
            });
            return `${applied || assetId}.${ext}`;
        }

        if (mode === 'prompt') {
            const dateTimeStr = GrokUtils.formatDateWithTime(createTime);
            if (safePrompt.trim()) {
                // Real prompt: append the short assetId too, since a batch
                // sharing the same prompt+second would otherwise collide.
                const sanitizedPrompt = GrokUtils.sanitizePromptForFilename(safePrompt, 100, assetId);
                const shortId = assetId.slice(-8);
                return `${isVideo ? 'vid' : 'img'}_${dateTimeStr}_${sanitizedPrompt}_${shortId}.${ext}`;
            }
            // No prompt available — the full assetId is already unique,
            // so no redundant short-id suffix.
            return `${isVideo ? 'vid' : 'img'}_${dateTimeStr}_${assetId}.${ext}`;
        }

        // native — match the documented "Grok Native" convention
        // (grok_image_YYYYMMDD_id.jpg), same as the favorite path's
        // mapImageToDownloadData, instead of a bare asset GUID.
        const dateStr = GrokUtils.formatDateYYYYMMDD(createTime);
        return `grok_${isVideo ? 'video' : 'image'}_${dateStr}_${assetId}.${ext}`;
    }

    /**
     * Map an asset from GrokAssets (the /rest/assets "all generated media"
     * source) to a download item compatible with the images[]/videos[]
     * shape produced by mapImageToDownloadData/mapVideoToDownloadData.
     *
     * Video quality fields (hdUrl/hd1080Url/resolutionName) start out null —
     * the caller resolves them via GrokAssets.resolveVideoQuality before
     * download; until then GrokUtils.pickVideoUrl() falls back to `url`
     * (the base `assets.grok.com/{key}` URL), which is always populated.
     * Filename honors the same `options.filenameMode` contract as
     * mapImageToDownloadData/mapVideoToDownloadData ('native'|'prompt'|'custom'),
     * via buildAssetFilename (above), reusing the same GrokUtils
     * date/template/sanitize helpers. Most assets DO carry a prompt (surfaced
     * via GrokAssets.listGeneratedAssets from the raw asset's `mediaGenInput`);
     * an imageToVideo asset has no prompt of its own, in which case 'prompt'
     * mode degrades to the sanitizePromptForFilename fallback (asset id) —
     * same graceful degradation the other mappers use when a post has no
     * prompt. (content.js's backfillVideoPromptsFromSource fixes this up for
     * imageToVideo assets whose source image is also in the same scan, by
     * borrowing that image's prompt and re-deriving the filename via
     * buildAssetFilename.)
     * @param {Object} asset - Asset metadata from GrokAssets (assetId, mimeType, key, previewImageKey, width, height, sourceConversationId, sourceAssetId, createTime, ...)
     * @param {Object} options - Options including filenameMode/filenameTemplateImage/filenameTemplateVideo
     * @returns {Object} - Formatted download item (image or video)
     */
    function mapAssetToDownloadData(asset, options = {}) {
        const isVideo = !!(asset.mimeType && asset.mimeType.startsWith('video'));
        const url = `https://assets.grok.com/${asset.key}`;
        const ext = GrokUtils.getExtFromMediaUrl(url, isVideo ? 'mp4' : 'jpg');
        const createTime = asset.createTime || null;
        // Real prompt when GrokAssets surfaced one (mediaGenInput.<mode>.prompt);
        // '' for assets with no prompt of their own (e.g. imageToVideo) — the
        // sanitizePromptForFilename/applyFilenameTemplate calls below fall back
        // to the asset id when the prompt is empty.
        const prompt = asset.prompt || '';

        const filenameMode = options.filenameMode || (options.promptAsFilename ? 'prompt' : 'native');
        const filename = buildAssetFilename({
            assetId: asset.assetId,
            ext,
            isVideo,
            createTime,
            prompt,
            filenameMode,
            filenameTemplateImage: options.filenameTemplateImage,
            filenameTemplateVideo: options.filenameTemplateVideo
        });

        const item = {
            id: asset.assetId,
            type: isVideo ? 'video' : 'image',
            url: url,
            filename: filename,
            mimeType: asset.mimeType,
            previewUrl: asset.previewImageKey ? `https://assets.grok.com/${asset.previewImageKey}` : null,
            width: asset.width,
            height: asset.height,
            sourceConversationId: asset.sourceConversationId,
            // Fallback conversation id for prompt recovery (content.js
            // recoverConversationPrompts) when sourceConversationId is absent.
            currentConversationId: asset.currentConversationId,
            userId: asset.userId || null,
            sourceAssetId: asset.sourceAssetId || null,
            createTime,
            prompt,
            originalPrompt: prompt,
            downloaded: false,
            downloadedAt: null
        };

        if (isVideo) {
            item.hdUrl = null;
            item.hd1080Url = null;
            item.resolutionName = null;
        }

        return item;
    }

    // ---- Skip-on-disk (imported media id list) -----------------------------
    // An optional list of media ids that already exist on disk (e.g. built
    // from a folder listing). Entries may be bare ids or file names/paths:
    // a UUID inside the entry wins; otherwise the basename without extension
    // and without a trailing _hd/_sd is used. Names only — files are never
    // opened.
    const UUID_RE = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;
    function normalizeSkipIds(list) {
        const out = new Set();
        for (const raw of Array.isArray(list) ? list : []) {
            if (typeof raw !== 'string') continue;
            const t = raw.trim();
            if (!t) continue;
            const m = t.match(UUID_RE);
            if (m) { out.add(m[0].toLowerCase()); continue; }
            const base = t.split(/[\\/]/).pop().replace(/\.[A-Za-z0-9]{1,5}$/, '').replace(/_(hd|sd)$/i, '');
            if (/^[A-Za-z0-9_-]{6,}$/.test(base)) out.add(base);
        }
        return [...out];
    }

    // History key -> media id: `${id}`, `${id}_hd`, `${id}_sd`. Other keys
    // (e.g. project_<id>_c<n> metadata markers) are returned unchanged and so
    // never match a media id.
    function historyKeyMediaId(key) {
        return typeof key === 'string' ? key.replace(/_(hd|sd)$/, '') : key;
    }

    // Wrap a history adapter ({has,...}) so has() is also true for any key
    // whose media id is in skipIds. add/flush/toArray are left untouched, so
    // the real download history is never polluted by the imported list.
    function withSkipIds(hist, skipIds) {
        if (!hist || !skipIds || !skipIds.size) return hist;
        const hasSkip = (key) => {
            const id = historyKeyMediaId(key);
            return skipIds.has(id) || (typeof id === 'string' && skipIds.has(id.toLowerCase()));
        };
        const skipHasItem = (item) => mediaIdCandidates(item).some(hasSkip);
        return { ...hist, has: (key) => hist.has(key) || hasSkip(key), skipHas: hasSkip, skipHasItem };
    }

    // Every id that names THIS media file: the record id, assetId/mediaId if
    // present, UUIDs in the media URL paths (/users/<userId>/generated/<id>/…,
    // /users/<userId>/<id>/content, share-videos/<id>.mp4) and the UUID in a
    // baked filename (grok_video_YYYYMMDD_<id>.mp4, built from record id at
    // buildAssetFilename). Deliberately EXCLUDES sourceAssetId (the parent image
    // a video was animated from / an edit's source), userId and conversation
    // ids: those name a different file, and matching them would skip videos
    // that are not on disk just because their source image is.
    const UUID_RE_G = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/ig;
    function mediaIdCandidates(item) {
        if (!item || typeof item !== 'object') return [];
        const out = new Set();
        const foreign = new Set([item.userId, item.sourceAssetId, item.sourceConversationId, item.currentConversationId, item.conversationId]
            .filter(x => typeof x === 'string' && x).map(x => x.toLowerCase()));
        for (const k of ['id', 'assetId', 'mediaId']) {
            if (typeof item[k] === 'string' && item[k]) out.add(item[k]);
        }
        for (const k of ['url', 'hdUrl', 'hd1080Url', 'mediaUrl', 'filename']) {
            const v = item[k];
            if (typeof v !== 'string' || !v) continue;
            const path = k === 'filename' ? v.split(/[\\/]/).pop() : v.replace(/[?#].*$/, '');
            for (const m of path.match(UUID_RE_G) || []) {
                const id = m.toLowerCase();
                if (!foreign.has(id)) out.add(id);
            }
        }
        return [...out];
    }

    // Drop items whose media id is on the skip list. Needed wherever a caller
    // filters through hist.toArray() (e.g. GrokUtils.filterVideosForHdPriority),
    // because toArray() is the real history only and never sees skip ids.
    function dropSkipped(items, hist) {
        if (!Array.isArray(items)) return [];
        if (!hist || typeof hist.skipHas !== 'function') return items;
        const hit = typeof hist.skipHasItem === 'function'
            ? (it) => hist.skipHasItem(it)
            : (it) => !!(it && it.id && hist.skipHas(it.id));
        return items.filter(it => !(it && hit(it)));
    }

    /**
     * Calculate image download statistics
     * @param {Array} imageData - Array of image download data
     * @param {Array} history - Array of downloaded IDs
     * @returns {Object} - Statistics object
     */
    function calculateImageStats(imageData, history) {
        const historySet = Array.isArray(history) ? new Set(history) : history;
        const alreadyDownloaded = imageData.filter(img => historySet.has(img.id));
        const needDownload = imageData.filter(img => !historySet.has(img.id));

        return {
            total: imageData.length,
            alreadyDownloaded: alreadyDownloaded.length,
            needDownload: needDownload.length,
            alreadyDownloadedItems: alreadyDownloaded,
            needDownloadItems: needDownload
        };
    }

    /**
     * Calculate video download statistics
     * @param {Array} videoData - Array of video download data
     * @param {Array} history - Array of downloaded IDs
     * @param {boolean} hdPriority - Whether HD priority mode is enabled
     * @returns {Object} - Statistics object
     */
    function calculateVideoStats(videoData, history, hdPriority = true) {
        // Convert history to Set for O(1) lookups (accepts both Array and Set)
        const historySet = Array.isArray(history) ? new Set(history) : history;

        // Helper: does the video have a distinct HD-tier variant (1080p or 720p HD)?
        const hasHdVariant = (v) => !!(v.hd1080Url || v.hdUrl);
        // Helper: determine if video is effectively HD (has an HD variant or is native 720p)
        const isEffectivelyHd = (v) => hasHdVariant(v) || v.resolutionName === '720p';

        // Calculate file count (depends on HD priority)
        const fileCount = hdPriority
            ? videoData.length  // HD priority: one file per video
            : videoData.reduce((acc, v) => acc + (hasHdVariant(v) ? 2 : 1), 0);  // Both SD and HD (native 720p only has 1 file)

        // Calculate already downloaded file count
        const alreadyDownloadedFiles = videoData.reduce((acc, v) => {
            if (hdPriority) {
                const targetKey = isEffectivelyHd(v) ? `${v.id}_hd` : `${v.id}_sd`;
                return acc + (historySet.has(targetKey) ? 1 : 0);
            } else {
                let count = 0;
                if (historySet.has(v.id) || historySet.has(`${v.id}_sd`)) count++;
                if (hasHdVariant(v) && historySet.has(`${v.id}_hd`)) count++;
                return acc + count;
            }
        }, 0);

        // Videos fully downloaded (both SD and HD if available)
        const fullyDownloadedVideos = videoData.filter(v => {
            if (isEffectivelyHd(v) && !hasHdVariant(v)) {
                // Native 720p: only one file, saved as _hd
                return historySet.has(`${v.id}_hd`);
            }
            const sdDownloaded = historySet.has(v.id) || historySet.has(`${v.id}_sd`);
            const hdDownloaded = hasHdVariant(v) ? historySet.has(`${v.id}_hd`) : true;
            return sdDownloaded && hdDownloaded;
        });

        // Videos needing download (missing SD or HD)
        const needDownloadVideos = videoData.filter(v => {
            if (hdPriority) {
                const targetKey = isEffectivelyHd(v) ? `${v.id}_hd` : `${v.id}_sd`;
                return !historySet.has(targetKey);
            } else {
                if (isEffectivelyHd(v) && !hasHdVariant(v)) {
                    // Native 720p: only one file
                    return !historySet.has(`${v.id}_hd`);
                }
                const sdMissing = !historySet.has(v.id) && !historySet.has(`${v.id}_sd`);
                const hdMissing = hasHdVariant(v) ? !historySet.has(`${v.id}_hd`) : false;
                return sdMissing || hdMissing;
            }
        });

        // Quality tier breakdown (Task U3): break out 1080p as its own category rather
        // than lumping it into the generic "HD" bucket. Tier decisions always go through
        // GrokUtils.classifyVideoQuality — never re-derive tier logic here.
        let count1080p = 0, countHd = 0, countSd = 0;
        for (const v of videoData) {
            const tier = GrokUtils.classifyVideoQuality(v).tier;
            if (tier === '1080p') count1080p++;
            else if (tier === 'hd') countHd++;
            else countSd++;
        }

        return {
            totalVideos: videoData.length,
            totalFiles: fileCount,
            alreadyDownloadedFiles: alreadyDownloadedFiles,
            needDownloadFiles: fileCount - alreadyDownloadedFiles,
            fullyDownloadedVideos: fullyDownloadedVideos.length,
            needDownloadVideos: needDownloadVideos.length,
            fullyDownloadedItems: fullyDownloadedVideos,
            needDownloadItems: needDownloadVideos,
            count1080p,
            countHd,
            countSd
        };
    }

    /**
     * Extract post ID from a Grok post URL
     * @param {string} url - URL like "https://grok.com/imagine/post/abc-123"
     * @returns {string|null} - Post ID or null if not found
     */
    function extractPostIdFromUrl(url) {
        if (!url || typeof url !== 'string') return null;
        const match = url.match(/\/post\/([a-f0-9-]+)/i);
        return match ? match[1] : null;
    }

    /**
     * Create initial download state object
     * @param {Array} imageData - Array of image download data
     * @param {Array} videoData - Array of video download data
     * @param {Object} options - Generation options
     * @returns {Object} - Initial state object
     */
    function createDownloadState(imageData, videoData, options = {}) {
        return {
            images: imageData,
            videos: videoData,
            currentPhase: 'images',
            currentIndex: 0,
            downloadedImages: [],
            downloadedVideos: [],
            failed: [],
            startTime: Date.now(),
            skipDownloaded: true,
            completed: false,
            filterOptions: {
                includeImages: options.includeImages !== false,
                includeVideos: options.includeVideos !== false,
                fromDate: options.fromDate || null,
                fromDateString: options.fromDate ? new Date(options.fromDate).toLocaleDateString() : null,
                toDate: options.toDate || null,
                toDateString: options.toDate ? new Date(options.toDate).toLocaleDateString() : null,
                hdPriority: options.hdPriority !== false,
                saveMetadata: options.saveMetadata === true,
                promptAsFilename: options.promptAsFilename === true
            }
        };
    }

    /**
     * Separate posts by media type
     * @param {Array} posts - Flattened posts array
     * @returns {Object} - { images: Array, videos: Array }
     */
    function separateByMediaType(posts) {
        const images = posts.filter(p => p.mediaType === 'MEDIA_POST_TYPE_IMAGE');
        const videos = posts.filter(p => p.mediaType === 'MEDIA_POST_TYPE_VIDEO');
        return { images, videos };
    }

    /**
     * Calculate download duration in minutes
     * @param {number} startTime - Start timestamp (ms)
     * @param {number} endTime - End timestamp (ms), defaults to now
     * @returns {string} - Duration in minutes with 1 decimal place
     */
    function calculateDuration(startTime, endTime = Date.now()) {
        return ((endTime - startTime) / 1000 / 60).toFixed(1);
    }

    /**
     * Create download summary statistics
     * @param {Object} state - Download state object
     * @returns {Object} - Summary stats
     */
    function createDownloadSummary(state) {
        const totalItems = (state.images?.length || 0) + (state.videos?.length || 0);
        const totalDownloaded = (state.downloadedImages?.length || 0) + (state.downloadedVideos?.length || 0);
        const duration = calculateDuration(state.startTime, state.completedAt || Date.now());

        return {
            totalItems,
            totalDownloaded,
            failedCount: state.failed?.length || 0,
            imageStats: {
                total: state.images?.length || 0,
                downloaded: state.downloadedImages?.length || 0
            },
            videoStats: {
                total: state.videos?.length || 0,
                downloaded: state.downloadedVideos?.length || 0
            },
            duration,
            completed: state.completed || false
        };
    }

    /**
     * Merge an imported download state into the existing one (union by item id).
     * Existing entries win field-by-field, but downloaded=true from either side
     * is preserved — an import must never un-download or drop current items.
     * @param {Object|null} existing - Current download state, or null if none
     * @param {Object} imported - Imported download state
     * @returns {Object} - Merged download state
     */
    function mergeDownloadStates(existing, imported) {
        if (!existing) return imported;

        const mergeItems = (currentArr = [], importedArr = []) => {
            const byId = new Map();
            for (const item of importedArr) {
                if (item && item.id != null) byId.set(item.id, item);
            }
            for (const item of currentArr) {
                if (!item || item.id == null) continue;
                const other = byId.get(item.id);
                byId.set(item.id, other
                    ? { ...other, ...item, downloaded: !!(item.downloaded || other.downloaded) }
                    : item);
            }
            return [...byId.values()];
        };
        const unionIds = (a = [], b = []) => [...new Set([...a, ...b])];

        return {
            ...imported,
            ...existing,
            images: mergeItems(existing.images, imported.images),
            videos: mergeItems(existing.videos, imported.videos),
            downloadedImages: unionIds(existing.downloadedImages, imported.downloadedImages),
            downloadedVideos: unionIds(existing.downloadedVideos, imported.downloadedVideos),
            downloadedProjects: unionIds(existing.downloadedProjects, imported.downloadedProjects),
            failed: unionIds(existing.failed, imported.failed)
        };
    }

    /**
     * Validate import data structure
     * @param {Object} data - Data to validate
     * @returns {{valid: boolean, errors: Array<string>}}
     */
    function validateImportData(data) {
        const errors = [];

        if (!data || typeof data !== 'object') {
            return { valid: false, errors: ['Data must be an object'] };
        }

        // Check for at least one valid field
        const validFields = ['state', 'history', 'settings'];
        const hasValidField = validFields.some(field => data[field] !== undefined);

        if (!hasValidField) {
            errors.push('Data must contain at least one of: state, history, settings');
        }

        // Validate history if present
        if (data.history !== undefined && !Array.isArray(data.history)) {
            errors.push('history must be an array');
        }

        // Validate settings if present
        if (data.settings !== undefined && typeof data.settings !== 'object') {
            errors.push('settings must be an object');
        }

        return {
            valid: errors.length === 0,
            errors
        };
    }

    /**
     * Centralized selectors for Grok's UI. Grok ships localized aria-labels and
     * has two UI generations (V1 textarea / V2 contenteditable) — when Grok
     * changes its UI, update HERE, not at call sites.
     */
    const GROK_SELECTORS = {
        SUBMIT_VIDEO_BUTTON: [
            'button[aria-label="Make video"]',
            'button[aria-label="製作影片"]',
            'button[aria-label="制作视频"]',
            'button[aria-label="ビデオを作成"]',
            'button[aria-label="비디오 만들기"]'
        ].join(', '),
        PROMPT_CONTENTEDITABLE: '[contenteditable="true"]:not([id="grok-queue-prompt"])'
    };

    // Public API
    const ContentUtils = {
        // Date filtering
        isInDateRange,
        filterByDateRange,

        // Data mapping
        mapImageToDownloadData,
        mapVideoToDownloadData,
        mapAssetToDownloadData,
        buildAssetFilename,
        separateByMediaType,

        // Skip-on-disk
        normalizeSkipIds,
        historyKeyMediaId,
        withSkipIds,
        dropSkipped,
        mediaIdCandidates,

        // Statistics
        calculateImageStats,
        calculateVideoStats,
        createDownloadSummary,
        calculateDuration,

        // URL parsing
        extractPostIdFromUrl,

        // State management
        createDownloadState,
        mergeDownloadStates,

        // Validation
        validateImportData,

        // DOM Selectors
        GROK_SELECTORS
    };

    return ContentUtils;
}));
