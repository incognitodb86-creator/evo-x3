/**
 * Grok Imagine "all generated media" listing — the COMPLETE asset library.
 *
 * Supersedes src/grok-conversations.js (conversation-model traversal), which
 * was measured to cover only ~772/3346 assets (~23%). This module instead
 * pages the single `/rest/assets?workspaceKind=WORKSPACE_KIND_IMAGINE_ALL`
 * endpoint directly, which returns every generated asset. Deliberately does
 * NOT construct download URLs (that `https://assets.grok.com/{key}` mapping
 * belongs to the mapper module) — callers get back the raw `key` field.
 *
 * Aggressive paging against this endpoint returns HTTP 429, so the
 * orchestrator throttles between page fetches and backs off (with limited
 * retries) on error before giving up gracefully.
 *
 * Dual-export pattern (matches src/queue-logic.js / src/recent-posts.js):
 * `fetchImpl` is injectable (defaults to global `fetch`) so tests can bind
 * to this REAL production logic without touching the network.
 */

const ASSETS_API_BASE = 'https://grok.com/rest/assets';
const MEDIA_POST_GET_URL = 'https://grok.com/rest/media/post/get';
const CONVERSATIONS_API_BASE = 'https://grok.com/rest/app-chat/conversations';
const CONVERSATIONS_MANY_API_BASE = 'https://grok.com/rest/app-chat/conversations-many';

// Normalizes an ISO string / ms epoch number / Date into a ms epoch number.
// Falsy input (null/undefined/0/'') -> null (treated as "no bound").
// Unparseable input -> null as well, so a bad bound never breaks filtering.
function normalizeDateBound(value) {
    if (!value) return null;
    const ms = new Date(value).getTime();
    return Number.isNaN(ms) ? null : ms;
}

// Parses an asset's createTime into a ms epoch number, or null when missing/
// unparseable — callers treat null as "always in range" rather than crashing.
function parseCreateTimeMs(createTime) {
    if (!createTime) return null;
    const ms = new Date(createTime).getTime();
    return Number.isNaN(ms) ? null : ms;
}

// Extracts the generation prompt from a raw asset's `mediaGenInput`. That
// field is keyed by generation mode (e.g. `textToImage`, `imageToVideo`) —
// only some modes carry a `prompt` string (imageToVideo, for instance, only
// has `inputAssets`, since a video-from-image generation has no text prompt
// of its own). Returns the first non-blank prompt found, or '' when none of
// the mode sub-objects have one (or mediaGenInput itself is missing/invalid).
function extractAssetPrompt(mediaGenInput) {
    if (!mediaGenInput || typeof mediaGenInput !== 'object') return '';
    for (const v of Object.values(mediaGenInput)) {
        if (v && typeof v.prompt === 'string' && v.prompt.trim()) return v.prompt;
    }
    return '';
}

// Extracts a video asset's SOURCE image asset id from `mediaGenInput`. A
// video generated from an image (imageToVideo mode) has no prompt of its own
// (see extractAssetPrompt above) — only `inputAssets: [sourceImageAssetId]`.
// Returns the first non-empty `inputAssets[0]` found among the mode
// sub-objects, or null when none of them carry one (or mediaGenInput itself
// is missing/invalid) — callers treat null as "no known source image".
function extractSourceAssetId(mediaGenInput) {
    if (!mediaGenInput || typeof mediaGenInput !== 'object') return null;
    for (const v of Object.values(mediaGenInput)) {
        if (v && Array.isArray(v.inputAssets) && v.inputAssets.length) return v.inputAssets[0];
    }
    return null;
}

// Base pause between /rest/assets page fetches. The endpoint rate-limits by
// request count (~30 requests at the old 600ms pace -> 429; 36 pages at 900ms
// were all 200), so 1200ms keeps a full-library scan under the limit.
const ASSET_PAGE_THROTTLE_MS = 1200;
const ASSET_PAGE_MAX_THROTTLE_MS = 5000;
// Retry schedule for ONE failed page (same cursor). Long enough to clear a
// rate-limit window; a larger Retry-After from a 429 wins (capped).
const ASSET_PAGE_RETRY_BACKOFF_MS = [15000, 30000, 60000, 120000, 180000];
const ASSET_PAGE_RETRY_AFTER_CAP_MS = 300000;

// Retry-After header -> ms (delta-seconds or HTTP-date), null if absent/invalid.
function parseRetryAfterMs(value) {
    if (value == null || value === '') return null;
    const secs = Number(value);
    if (Number.isFinite(secs)) return secs >= 0 ? secs * 1000 : null;
    const at = new Date(value).getTime();
    if (Number.isNaN(at)) return null;
    return Math.max(0, at - Date.now());
}

// Union of two item lists by `id` (or `assetId`). Fresh items win; stored
// items missing from the fresh (partial) list are appended, so a partial
// rescan can never shrink a previously complete list.
function mergeAssetListsById(storedItems, freshItems) {
    const keyOf = (it) => it && (it.id || it.assetId);
    const out = [];
    const seen = new Set();
    for (const it of freshItems || []) {
        const k = keyOf(it);
        if (k && seen.has(k)) continue;
        if (k) seen.add(k);
        out.push(it);
    }
    let added = 0;
    for (const it of storedItems || []) {
        const k = keyOf(it);
        if (!k || seen.has(k)) continue;
        seen.add(k);
        out.push(it);
        added++;
    }
    return { items: out, added };
}

// Partial-scan guard for the stored allmedia list. When a scan came back
// partial, union the fresh lists with the previously stored ones (same
// source + date scope only) so a failed page can never shrink the list.
// Pure: takes the stored state, returns the lists to save.
function mergePartialWithStored(prevState, { images, videos, scope = {}, includeImages = true, includeVideos = true }) {
    const norm = (v) => (v == null || v === '' ? null : v);
    const pf = prevState && prevState.filterOptions;
    const sameScope = !!pf && pf.source === 'allmedia'
        && norm(pf.fromDate) === norm(scope.fromDate)
        && norm(pf.toDate) === norm(scope.toDate)
        && norm(pf.hoursLimit) === norm(scope.hoursLimit);
    const prevCount = prevState ? ((prevState.allImages || []).length + (prevState.allVideos || []).length) : 0;
    const newCount = (images || []).length + (videos || []).length;
    if (!sameScope || prevCount === 0) {
        return { images, videos, merged: false, sameScope, prevCount, newCount, addedImages: 0, addedVideos: 0 };
    }
    const mi = includeImages ? mergeAssetListsById(prevState.allImages, images) : { items: images, added: 0 };
    const mv = includeVideos ? mergeAssetListsById(prevState.allVideos, videos) : { items: videos, added: 0 };
    // 2.5.6: stored items keep only the prompts their own run recovered. If
    // that run used a narrower promptScope, report it so the caller can save
    // the narrower scope and the popup still asks to regenerate.
    return { images: mi.items, videos: mv.items, merged: true, sameScope, prevCount, newCount, addedImages: mi.added, addedVideos: mv.added, prevPromptScope: pf.promptScope };
}

// Resume checkpoint for the allmedia scan (stored by content.js under
// ALLMEDIA_SCAN_CHECKPOINT_KEY). Decide whether a stored checkpoint can be
// resumed for this scope: same date filters, not finished, has a cursor, and
// not older than maxAgeMs (page cursors are not guaranteed to live forever).
const SCAN_CHECKPOINT_VERSION = 1;
const SCAN_CHECKPOINT_MAX_AGE_MS = 24 * 3600 * 1000;

function buildScanCheckpoint(scope, { pageToken, pageCount, assetIds }, now = Date.now()) {
    const norm = (v) => (v == null || v === '' ? null : v);
    return {
        v: SCAN_CHECKPOINT_VERSION,
        scope: { fromDate: norm(scope && scope.fromDate), toDate: norm(scope && scope.toDate), hoursLimit: norm(scope && scope.hoursLimit) },
        pageToken: pageToken || null,
        pageCount: pageCount || 0,
        assetIds: Array.isArray(assetIds) ? assetIds : [],
        updatedAt: now
    };
}

function planScanResume(checkpoint, scope, { now = Date.now(), maxAgeMs = SCAN_CHECKPOINT_MAX_AGE_MS } = {}) {
    const no = (reason) => ({ resume: false, reason });
    if (!checkpoint || typeof checkpoint !== 'object') return no('none');
    if (checkpoint.v !== SCAN_CHECKPOINT_VERSION) return no('version');
    if (!checkpoint.pageToken) return no('no-cursor');
    if (!Array.isArray(checkpoint.assetIds) || checkpoint.assetIds.length === 0) return no('no-ids');
    if (!(now - (checkpoint.updatedAt || 0) <= maxAgeMs)) return no('stale');
    const want = buildScanCheckpoint(scope, {}, now).scope;
    const have = checkpoint.scope || {};
    for (const k of ['fromDate', 'toDate', 'hoursLimit']) {
        if ((have[k] == null ? null : have[k]) !== want[k]) return no('scope');
    }
    // A lastHours window moves with the clock; resuming it would mix windows.
    if (want.hoursLimit != null) return no('relative-window');
    return { resume: true, pageToken: checkpoint.pageToken, pageCount: checkpoint.pageCount || 0, assetIds: checkpoint.assetIds.slice() };
}

async function listGeneratedAssets(fetchImpl = fetch, { pageToken = null, pageSize = 100, modelGeneratedOnly = true } = {}) {
    let url = `${ASSETS_API_BASE}?pageSize=${pageSize}&orderBy=ORDER_BY_CREATE_TIME&workspaceKind=WORKSPACE_KIND_IMAGINE_ALL`;
    if (pageToken) {
        url += `&pageToken=${encodeURIComponent(pageToken)}`;
    }

    const res = await fetchImpl(url);
    if (!res.ok) {
        throw Object.assign(new Error('HTTP ' + res.status), {
            status: res.status,
            retryAfterMs: parseRetryAfterMs(res.headers && typeof res.headers.get === 'function' ? res.headers.get('Retry-After') : null)
        });
    }

    const data = await res.json();
    const rawAssets = data.assets || [];

    const filtered = rawAssets.filter((asset) => {
        if (asset.isDeleted === true) return false;
        if (modelGeneratedOnly && asset.isModelGenerated === false) return false;
        return true;
    });

    return {
        assets: filtered.map(mapRawAsset),
        nextPageToken: data.nextPageToken || null
    };
}

/**
 * Normalise a raw /rest/assets row into the shape the rest of the extension
 * consumes. Shared by the whole-library paging path and the by-id batch lookup
 * used for collection (tag) downloads, so both feed an identical item shape
 * into ContentUtils.mapAssetToDownloadData.
 */
function mapRawAsset(asset) {
    return {
        assetId: asset.assetId,
        mimeType: asset.mimeType,
        name: asset.name,
        key: asset.key,
        previewImageKey: asset.previewImageKey,
        width: asset.width,
        height: asset.height,
        sourceConversationId: asset.sourceConversationId,
        // Fallback conversation id for prompt recovery (see
        // fetchConversationAssetMetadata): some rows carry only this one.
        currentConversationId: asset.currentConversationId,
        // Asset rows expose the owner as ownerUserId; the favorite path's
        // items carry userId, and metadata.json expects that name.
        userId: asset.ownerUserId || null,
        fileSource: asset.fileSource,
        isModelGenerated: asset.isModelGenerated,
        createTime: asset.createTime,
        prompt: extractAssetPrompt(asset.mediaGenInput),
        sourceAssetId: extractSourceAssetId(asset.mediaGenInput)
    };
}

async function listAllGeneratedAssets(fetchImpl = fetch, {
    onProgress = null,
    maxPages = Infinity,
    signalAborted = null,
    throttleMs = ASSET_PAGE_THROTTLE_MS,
    maxThrottleMs = ASSET_PAGE_MAX_THROTTLE_MS,
    retryBackoffMs = ASSET_PAGE_RETRY_BACKOFF_MS,
    modelGeneratedOnly = true,
    sleepImpl = null,
    fromDate = null,
    toDate = null,
    // Resume checkpoint support (see planScanResume / content.js):
    //   startPageToken  - cursor to continue from (null = page 1)
    //   startPageCount  - pages already done in the earlier run
    //   resumeAssetIds  - ids collected by the earlier run; seeded into the
    //                     dedupe set and into every checkpoint
    //   onCheckpoint    - awaited after each good page with
    //                     { pageToken, pageCount, assetIds, done }
    //   stopAtKnownIds  - Set: stop after the first page that contains one of
    //                     these ids (head refresh on resume)
    startPageToken = null,
    startPageCount = 0,
    resumeAssetIds = null,
    onCheckpoint = null,
    stopAtKnownIds = null
} = {}) {
    const sleep = sleepImpl || ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));

    // Assets page newest-first (orderBy=ORDER_BY_CREATE_TIME). That ordering
    // lets a lower bound (fromDate) early-stop paging entirely: once an asset
    // is older than fromDate, every asset on every subsequent page is too.
    const fromMs = normalizeDateBound(fromDate);
    const toMs = normalizeDateBound(toDate);

    const seenAssetIds = new Set();
    const assets = [];
    let pageCount = 0;
    let errors = 0;        // pages that failed after ALL retries (0 or 1)
    let retryErrors = 0;   // every failed attempt, including ones later retried OK
    let partial = false;
    let lastError = null;
    let aborted = false;
    let completed = false;
    let pageToken = startPageToken || null;
    const checkpointIds = [];
    for (const id of resumeAssetIds || []) {
        if (!id || seenAssetIds.has(id)) continue;
        seenAssetIds.add(id);
        checkpointIds.push(id);
    }
    const emitCheckpoint = async (done) => {
        if (!onCheckpoint) return;
        try {
            await onCheckpoint({ pageToken, pageCount: startPageCount + pageCount, assetIds: checkpointIds.slice(), done });
        } catch (e) { /* a failing checkpoint write must never break the scan */ }
    };

    // Adaptive cadence: starts at throttleMs but only ever ratchets UP (never
    // back down) once a page trips the rate limit, so a large library that
    // hits a 429 self-tunes to a gentler pace for the REST of the scan
    // instead of hammering the endpoint at the same fixed interval forever.
    let currentThrottle = throttleMs;

    while (true) {
        if (pageCount >= maxPages) break;
        if (signalAborted && signalAborted()) { aborted = true; break; }

        if (pageCount > 0) {
            await sleep(currentThrottle);
        }

        // Retry the SAME pageToken with long backoff (rate-limit window is
        // request-count based). Only after every retry fails is the scan
        // marked partial and stopped.
        let page = null;
        let attempt = 0;
        const maxRetries = retryBackoffMs.length;
        while (true) {
            try {
                page = await listGeneratedAssets(fetchImpl, { pageToken, modelGeneratedOnly });
                break;
            } catch (error) {
                retryErrors++;
                lastError = error;
                if (attempt >= maxRetries || (signalAborted && signalAborted())) {
                    page = null;
                    break;
                }
                let waitMs = retryBackoffMs[attempt];
                if (error && error.retryAfterMs != null) {
                    waitMs = Math.max(waitMs, Math.min(error.retryAfterMs, ASSET_PAGE_RETRY_AFTER_CAP_MS));
                }
                attempt++;
                await sleep(waitMs);
                // Permanently slow the page-to-page cadence too.
                currentThrottle = Math.min(Math.round(currentThrottle * 1.5), maxThrottleMs);
            }
        }

        if (!page) {
            errors++;
            partial = true;
            break;
        }

        let hitLowerBound = false;
        let hitKnown = false;
        for (const asset of page.assets) {
            if (stopAtKnownIds && stopAtKnownIds.has(asset.assetId)) hitKnown = true;
            if (seenAssetIds.has(asset.assetId)) continue;

            // Unparseable/missing createTime -> ct is null -> treated as
            // in-range (included) rather than crashing or being dropped.
            const ct = parseCreateTimeMs(asset.createTime);

            if (ct !== null && toMs !== null && ct > toMs) {
                // Newer than the upper bound: skip this one asset, keep paging.
                seenAssetIds.add(asset.assetId);
                continue;
            }

            if (ct !== null && fromMs !== null && ct < fromMs) {
                // Older than the lower bound: since assets are newest-first,
                // this and everything after it (this page and all later
                // pages) is also out of range. Stop accumulating and paging.
                hitLowerBound = true;
                break;
            }

            seenAssetIds.add(asset.assetId);
            assets.push(asset);
            checkpointIds.push(asset.assetId);
        }

        pageCount++;
        if (onProgress) {
            onProgress({ assetCount: assets.length, pageCount });
        }

        if (hitLowerBound || hitKnown || !page.nextPageToken) {
            completed = true;
            await emitCheckpoint(true);
            break;
        }
        // Checkpoint = the NEXT cursor + everything collected so far, so a
        // later run resumes at the first page not yet fetched.
        pageToken = page.nextPageToken;
        await emitCheckpoint(false);
    }

    return {
        assets, pageCount, errors, retryErrors, partial, aborted, completed,
        nextPageToken: completed ? null : pageToken,
        lastError: lastError ? (lastError.status ? 'HTTP ' + lastError.status : String(lastError.message || lastError)) : null
    };
}

/**
 * allmedia scan with a resume checkpoint. `store` is { load, save, clear }
 * (content.js backs it with chrome.storage.local). Each good page saves the
 * next cursor, the page count and every collected id. A stopped or partial
 * scan leaves the checkpoint behind; the next run with the same scope:
 *   1. head refresh: pages from page 1 until a page contains a known id
 *      (picks up anything generated since the checkpoint),
 *   2. tail: continues from the saved cursor (not page 1),
 *   3. re-reads rows for the ids collected earlier via getAssetsByIds
 *      (batched by id; the checkpoint stores ids only).
 * The checkpoint is cleared only on a healthy completion. Never throws.
 */
async function scanAllWithCheckpoint(fetchImpl = fetch, { store = null, scope = {}, now = Date.now(), getByIdsImpl = null, ...listOpts } = {}) {
    const safe = async (fn, fallback = null) => { try { return await fn(); } catch (e) { return fallback; } };
    const save = (cp) => store && store.save ? safe(() => store.save(buildScanCheckpoint(scope, cp))) : null;
    const clear = () => store && store.clear ? safe(() => store.clear()) : null;
    const checkpoint = store && store.load ? await safe(() => store.load()) : null;
    const plan = planScanResume(checkpoint, scope, { now });
    if (!plan.resume && plan.reason !== 'none') await clear();

    if (!plan.resume) {
        const r = await listAllGeneratedAssets(fetchImpl, { ...listOpts, onCheckpoint: (cp) => (cp.done ? null : save(cp)) });
        const healthy = r.completed && !r.partial && !r.aborted;
        if (healthy) await clear();
        return { ...r, resumed: false, resumeReason: plan.reason, checkpointCleared: healthy };
    }

    const known = new Set(plan.assetIds);
    const head = await listAllGeneratedAssets(fetchImpl, { ...listOpts, stopAtKnownIds: known });
    const headIds = head.assets.map((a) => a.assetId);
    // Ids found by the head refresh are seeded into the tail's checkpoints too.
    const seed = [...plan.assetIds, ...headIds.filter((id) => !known.has(id))];
    let tail = { assets: [], pageCount: 0, errors: 0, retryErrors: 0, partial: false, aborted: false, completed: false, lastError: null };
    if (!head.partial && !head.aborted) {
        tail = await listAllGeneratedAssets(fetchImpl, {
            ...listOpts,
            startPageToken: plan.pageToken,
            startPageCount: plan.pageCount,
            resumeAssetIds: seed,
            onCheckpoint: (cp) => (cp.done ? null : save(cp))
        });
    }
    const have = new Set([...headIds, ...tail.assets.map((a) => a.assetId)]);
    const needRows = plan.assetIds.filter((id) => !have.has(id));
    const getByIds = getByIdsImpl || getAssetsByIds;
    const rows = needRows.length
        ? await safe(() => getByIds(fetchImpl, needRows, { signalAborted: listOpts.signalAborted, sleepImpl: listOpts.sleepImpl, onProgress: listOpts.onByIdProgress || null }), { assets: [], errors: 1, missingIds: needRows })
        : { assets: [], errors: 0, missingIds: [] };

    const byId = new Map();
    for (const a of [...head.assets, ...rows.assets, ...tail.assets]) if (a && a.assetId && !byId.has(a.assetId)) byId.set(a.assetId, a);
    const ts = (a) => { const t = Date.parse(a.createTime || ''); return Number.isNaN(t) ? 0 : t; };
    const assets = [...byId.values()].sort((a, b) => ts(b) - ts(a));

    const partial = head.partial || tail.partial || (head.completed && !tail.completed && !tail.aborted && !head.aborted) || rows.errors > 0;
    const aborted = head.aborted || tail.aborted;
    const healthy = !partial && !aborted && tail.completed;
    if (healthy) await clear();
    return {
        assets,
        pageCount: head.pageCount + plan.pageCount + tail.pageCount,
        errors: head.errors + tail.errors + (rows.errors || 0),
        retryErrors: head.retryErrors + tail.retryErrors,
        partial, aborted, completed: healthy,
        lastError: tail.lastError || head.lastError,
        resumed: true,
        resumedFromPage: plan.pageCount + 1,
        headNew: headIds.filter((id) => !known.has(id)).length,
        recoveredRows: rows.assets.length,
        missingRows: (rows.missingIds || []).length,
        checkpointCleared: healthy
    };
}

/**
 * Resolve a video asset's best-quality download URL via `/rest/media/post/get`.
 * Assets from `/rest/assets` only carry the base `assets.grok.com/{key}` URL —
 * this looks up the corresponding post (assetId === post id) to read its
 * hd1080MediaUrl/hdMediaUrl/mediaUrl tiers.
 *
 * 429/5xx-aware retry: intended to run under bounded concurrency (see
 * GrokUtils.mapWithConcurrency), where a burst of parallel calls can legitimately
 * trip the endpoint's rate limit. A naive "any !res.ok -> null" would silently
 * misclassify a rate-limited video as SD (its quality tier can never be
 * determined), undercounting the HD/1080p stats. So 429/5xx and thrown network
 * errors are retried with exponential backoff (500, 1000, 2000, capped at
 * 4000ms) up to `maxRetries` times before giving up. A genuine 4xx other than
 * 429 (e.g. 404 - no such post) returns null immediately with no retry.
 *
 * Never throws: on a non-ok response, a fetch failure, or a response with no
 * `post`, returns `null` so the caller falls back to the asset's own base URL
 * (the `url` field already set by mapAssetToDownloadData).
 *
 * Full-jitter backoff: the wait before each retry is `random() * base`
 * (base = 500, 1000, 2000, 4000, 4000, ... capped at 4000ms) rather than a
 * fixed `base` — under concurrency (5 parallel workers, see
 * GrokUtils.mapWithConcurrency), a fixed backoff has every worker that got
 * 429'd on the same tick retry in lockstep on the next tick too (a
 * "thundering herd" that re-trips the rate limit). Jitter spreads retries out.
 * @param {Function} fetchImpl - Injectable fetch (defaults to global fetch)
 * @param {string} assetId - Asset/post id to resolve
 * @param {boolean} hdPriority - Prefer hd1080 > hd > base when true
 * @param {Object} [options]
 * @param {number} [options.maxRetries=5] - Max retries for 429/5xx/thrown errors
 * @param {Function|null} [options.sleepImpl] - Injectable sleep (defaults to real setTimeout)
 * @param {Function|null} [options.randomImpl] - Injectable RNG in [0,1) (defaults to Math.random), for deterministic jitter in tests
 * @returns {Promise<{url:string, hd1080Url:?string, hdUrl:?string, baseUrl:?string, resolutionName:?string}|null>}
 */
async function resolveVideoQuality(fetchImpl = fetch, assetId, hdPriority, { maxRetries = 5, sleepImpl = null, randomImpl = null } = {}) {
    const sleep = sleepImpl || ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
    const rand = randomImpl || Math.random;
    let retryCount = 0;

    while (true) {
        try {
            const res = await fetchImpl(MEDIA_POST_GET_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: assetId })
            });

            if (!res.ok) {
                const retryable = res.status === 429 || res.status >= 500;
                if (!retryable || retryCount >= maxRetries) return null;
                const base = Math.min(500 * Math.pow(2, retryCount), 4000);
                await sleep(Math.round(rand() * base));
                retryCount++;
                continue;
            }

            const data = await res.json();
            const post = data && data.post;
            if (!post) return null;

            const hd1080Url = post.hd1080MediaUrl || null;
            const hdUrl = post.hdMediaUrl || null;
            const baseUrl = post.mediaUrl || null;

            return {
                url: hdPriority ? (hd1080Url || hdUrl || baseUrl) : baseUrl,
                hd1080Url,
                hdUrl,
                baseUrl,
                resolutionName: post.resolutionName || null
            };
        } catch (error) {
            if (retryCount >= maxRetries) return null;
            const base = Math.min(500 * Math.pow(2, retryCount), 4000);
            await sleep(Math.round(rand() * base));
            retryCount++;
        }
    }
}

/**
 * Pages the conversations list, collecting a `{ conversationId: title }` map
 * used to name per-conversation download folders (Task D3 — images and
 * videos generated within the same conversation are downloaded TOGETHER
 * into a folder named after the conversation's title).
 *
 * Tolerant like `listAllGeneratedAssets`: a per-page failure (non-ok response
 * or a thrown fetch error) stops paging gracefully and returns whatever was
 * gathered so far rather than losing the whole map. Honors `signalAborted`
 * (checked before each page, including the first) and throttles between
 * page fetches to avoid 429s (`sleepImpl` injectable so tests avoid real
 * timers).
 * Also supports a BATCH mode: when `conversationIds` is a non-empty array,
 * this skips full-list pagination entirely and instead fetches titles only
 * for those specific conversations via `/rest/app-chat/conversations-many`
 * (chunked into `batchSize`-sized requests). This is what callers that
 * already know which conversations they need (e.g. a download set) should
 * use — it avoids paginating the user's ENTIRE conversation history just to
 * resolve a handful of folder names. Same tolerance guarantees as the
 * full-list path: a chunk that fails (non-ok response or thrown error) is
 * skipped (not the whole call aborted) and the adaptive throttle ratchets up.
 * @param {Function} fetchImpl - Injectable fetch (defaults to global fetch)
 * @param {Object} options
 * @param {Array<string>|null} options.conversationIds - When provided (non-empty), switches to BATCH mode against conversations-many instead of paginating the full list
 * @param {Function|null} options.onProgress - BATCH mode only; called as `onProgress(current, total)` after each chunk
 * @param {number} options.batchSize - BATCH mode only; ids per conversations-many request (default 60)
 * @param {Function|null} options.signalAborted - Checked before each page/chunk; true stops early
 * @param {number} options.throttleMs - Delay between page/chunk fetches (default 600ms)
 * @param {number} options.maxThrottleMs - Ceiling the adaptive cadence ratchets up to (default 2500ms)
 * @param {Function|null} options.sleepImpl - Injectable sleep (defaults to real setTimeout)
 * @returns {Promise<Object>} plain object map `{ [conversationId]: title }`
 */
async function fetchConversationTitles(fetchImpl = fetch, {
    conversationIds = null,
    onProgress = null,
    batchSize = 60,
    signalAborted = null,
    throttleMs = 600,
    maxThrottleMs = 2500,
    sleepImpl = null
} = {}) {
    const sleep = sleepImpl || ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));

    if (Array.isArray(conversationIds) && conversationIds.length) {
        const unique = [...new Set(conversationIds.filter(Boolean))];
        const titleMap = {};
        let currentThrottle = throttleMs;

        for (let i = 0; i < unique.length; i += batchSize) {
            if (signalAborted && signalAborted()) break;
            if (i > 0) {
                await sleep(currentThrottle);
            }

            const chunk = unique.slice(i, i + batchSize);
            const url = `${CONVERSATIONS_MANY_API_BASE}?` + chunk.map((c) => 'conversationIds=' + encodeURIComponent(c)).join('&');

            try {
                const res = await fetchImpl(url);
                if (!res.ok) {
                    currentThrottle = Math.min(Math.round(currentThrottle * 1.5), maxThrottleMs);
                    if (onProgress) onProgress(Math.min(i + chunk.length, unique.length), unique.length);
                    continue;
                }
                const data = await res.json();
                const conversations = (data && data.conversations) || [];
                for (const conv of conversations) {
                    if (conv && conv.conversationId) {
                        titleMap[conv.conversationId] = conv.title || '';
                    }
                }
            } catch (error) {
                currentThrottle = Math.min(Math.round(currentThrottle * 1.5), maxThrottleMs);
                if (onProgress) onProgress(Math.min(i + chunk.length, unique.length), unique.length);
                continue;
            }

            if (onProgress) onProgress(Math.min(i + chunk.length, unique.length), unique.length);
        }

        return titleMap;
    }

    const titleMap = {};
    let pageToken = null;
    let pageCount = 0;
    // Same adaptive-cadence pattern as listAllGeneratedAssets: ratchets up
    // (never down) after a page error, gentler default baseline.
    let currentThrottle = throttleMs;

    while (true) {
        if (signalAborted && signalAborted()) break;
        if (pageCount > 0) {
            await sleep(currentThrottle);
        }

        let url = `${CONVERSATIONS_API_BASE}?pageSize=100&kind=CONVERSATION_KIND_IMAGINE`;
        if (pageToken) {
            url += `&pageToken=${encodeURIComponent(pageToken)}`;
        }

        let data;
        try {
            const res = await fetchImpl(url);
            if (!res.ok) {
                // Tolerate: stop gracefully, keep what's gathered. Ratchet
                // the cadence up first (mirrors listAllGeneratedAssets) in
                // case a future caller retries with the returned state.
                currentThrottle = Math.min(Math.round(currentThrottle * 1.5), maxThrottleMs);
                break;
            }
            data = await res.json();
        } catch (error) {
            currentThrottle = Math.min(Math.round(currentThrottle * 1.5), maxThrottleMs);
            break; // network error: stop gracefully, keep what's gathered
        }

        // A 200 response can still parse to a malformed body (null/non-object)
        // — guard here rather than trusting `data.conversations`/`data.nextPageToken`
        // directly, so a bad body degrades to "no more pages" instead of throwing
        // out of the function (which would abort the caller's download start).
        const conversations = (data && data.conversations) || [];
        const nextPageToken = data && data.nextPageToken;

        for (const conv of conversations) {
            if (conv && conv.conversationId) {
                titleMap[conv.conversationId] = conv.title || '';
            }
        }

        pageCount++;
        if (!nextPageToken) break;
        pageToken = nextPageToken;
    }

    return titleMap;
}

// ===========================================================================
// Prompt recovery via /responses
//
// As of 2026-09 grok NO LONGER returns `mediaGenInput` on /rest/assets rows —
// neither the list nor GET /rest/assets/{id}, and not for old (Jan-2026)
// assets either (the field was still present on 2026-08-17). extractAssetPrompt
// on a list row therefore yields '' for everything, which silently degrades
// metadata.json, prompt-mode filenames, the video prompt backfill and the
// conversation-folder name fallback.
//
// grok's own UI, when opening an asset, calls
//   GET /rest/app-chat/conversations/{cid}/responses?conversationKind=CONVERSATION_KIND_IMAGINE
//   → { responses: [ { responseId, sender: 'human'|'ASSISTANT', message,
//                      fileAttachmentAssetMetadata: [ <FULL asset row> ], … } ] }
// and each fileAttachmentAssetMetadata[i] is the full asset row with the SAME
// keys the list used to have — including mediaGenInput — so asset → prompt is
// a direct map by assetId and the existing extractors apply unchanged. NOT
// paginated (pageSize/limit are ignored). A `human` response's `message` is
// the raw prompt with suffixes (" --mode=custom", "@<assetId>") — never use
// it; use fileAttachmentAssetMetadata.mediaGenInput.
// ===========================================================================

/**
 * Fetch the full asset rows embedded in each conversation's /responses body
 * and index them by assetId, so callers can restore `prompt` /
 * `sourceAssetId` on items whose /rest/assets row came back without
 * mediaGenInput.
 *
 * Sequential with the same adaptive throttle as listAllGeneratedAssets /
 * fetchConversationTitles (600ms baseline, ratchets up on 429/error, never
 * down). Each conversation is retried on 429 / 5xx / thrown fetch with the
 * same full-jitter exponential backoff as resolveVideoQuality (500ms base,
 * doubling, capped at 4000ms) before it is counted in `errors` and SKIPPED —
 * a single rate-limit blip must not lose a whole conversation's prompts for
 * the run. A non-retryable 4xx (e.g. 404) is counted immediately. Never
 * throws.
 *
 * Circuit breaker: `maxConsecutiveErrors` consecutive failed conversations
 * (after their retries) stop the walk with `stoppedEarly: true` rather than
 * grinding through every remaining id at the throttle ceiling while a
 * sustained 429 window recovers nothing. A successful conversation resets
 * the counter.
 *
 * @param {Function} fetchImpl - injectable fetch
 * @param {Array<string>} conversationIds - deduped internally; falsy skipped
 * @param {Object} options
 * @param {Function|null} options.signalAborted - checked before each conversation and before each retry
 * @param {number} options.throttleMs - delay between conversations (default 600ms)
 * @param {number} options.maxThrottleMs - adaptive ceiling (default 2500ms)
 * @param {Function|null} options.sleepImpl - injectable sleep
 * @param {Function|null} options.onProgress - (current, total) after each conversation
 * @param {number} options.maxConversations - safety cap (default Infinity)
 * @param {number} options.maxRetries - retries per conversation on 429/5xx/thrown (default 2)
 * @param {number} options.maxConsecutiveErrors - circuit breaker threshold (default 5)
 * @param {Function|null} options.randomImpl - injectable RNG in [0,1) for deterministic jitter in tests
 * @returns {Promise<{byAssetId: Map<string, {mediaGenInput: Object, prompt: string, sourceAssetId: ?string, mimeType: string, createTime: string}>, conversationsRequested: number, conversationsFetched: number, errors: number, stoppedEarly: boolean, aborted: boolean}>}
 */
async function fetchConversationAssetMetadata(fetchImpl = fetch, conversationIds = [], {
    signalAborted = null,
    throttleMs = 600,
    maxThrottleMs = 2500,
    sleepImpl = null,
    onProgress = null,
    maxConversations = Infinity,
    maxRetries = 2,
    maxConsecutiveErrors = 5,
    randomImpl = null,
    // 2026-10-24 patch: onConversation(cid, Map<assetId, entry>) after each
    // SUCCESSFUL conversation, so the caller can persist incrementally;
    // retryBaseMs/retryMaxMs tune the 429/5xx backoff (Retry-After honored).
    onConversation = null,
    retryBaseMs = 500,
    retryMaxMs = 4000,
    retryAfterCapMs = 60000
} = {}) {
    const sleep = sleepImpl || ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
    const rand = randomImpl || Math.random;
    const unique = [...new Set((Array.isArray(conversationIds) ? conversationIds : []).filter(Boolean))];
    const byAssetId = new Map();
    let conversationsFetched = 0;
    let errors = 0;
    let consecutiveErrors = 0;
    let stoppedEarly = false;
    let aborted = false;
    let currentThrottle = throttleMs;
    const limit = Math.min(unique.length, maxConversations);

    // One conversation: retry 429/5xx/thrown with full-jitter backoff.
    // Resolves { ok: true, data } or { ok: false } (failed for good / aborted).
    const fetchOne = async (url) => {
        let retryCount = 0;
        while (true) {
            let retryAfterMs = null;
            try {
                const res = await fetchImpl(url);
                if (!res.ok) {
                    const retryable = res.status === 429 || res.status >= 500;
                    if (!retryable || retryCount >= maxRetries) return { ok: false, status: res.status };
                    retryAfterMs = parseRetryAfterMs(res.headers && typeof res.headers.get === 'function' ? res.headers.get('Retry-After') : null);
                } else {
                    return { ok: true, data: await res.json() };
                }
            } catch (error) {
                if (retryCount >= maxRetries) return { ok: false };
            }
            if (signalAborted && signalAborted()) { aborted = true; return { ok: false }; }
            const base = Math.min(retryBaseMs * Math.pow(2, retryCount), retryMaxMs);
            let waitMs = Math.round(base / 2 + rand() * base / 2);
            if (retryAfterMs != null) waitMs = Math.max(waitMs, Math.min(retryAfterMs, retryAfterCapMs));
            await sleep(waitMs);
            retryCount++;
        }
    };

    for (let i = 0; i < limit; i++) {
        if (signalAborted && signalAborted()) { aborted = true; break; }
        if (i > 0) await sleep(currentThrottle);

        const cid = unique[i];
        const url = `${CONVERSATIONS_API_BASE}/${encodeURIComponent(cid)}/responses?conversationKind=CONVERSATION_KIND_IMAGINE`;

        const outcome = await fetchOne(url);
        if (aborted) break;
        if (!outcome.ok) {
            errors++;
            consecutiveErrors++;
            currentThrottle = Math.min(Math.round(currentThrottle * 1.5), maxThrottleMs);
            if (onProgress) onProgress(i + 1, unique.length);
            if (consecutiveErrors >= maxConsecutiveErrors) { stoppedEarly = true; break; }
            continue;
        }

        conversationsFetched++;
        consecutiveErrors = 0;
        const data = outcome.data;
        const responses = (data && Array.isArray(data.responses)) ? data.responses : [];
        const convEntries = new Map();
        for (const response of responses) {
            const rows = (response && Array.isArray(response.fileAttachmentAssetMetadata)) ? response.fileAttachmentAssetMetadata : [];
            for (const row of rows) {
                if (!row || !row.assetId) continue;
                const entry = {
                    mediaGenInput: row.mediaGenInput,
                    prompt: extractAssetPrompt(row.mediaGenInput),
                    sourceAssetId: extractSourceAssetId(row.mediaGenInput),
                    mimeType: row.mimeType,
                    createTime: row.createTime
                };
                // Same asset can be attached to several responses (e.g. an
                // edit or an imageToVideo turn referencing it). Merge per
                // field — the richer value wins — so a later bare row never
                // erases a prompt OR a sourceAssetId seen earlier, while a
                // later row that does carry a prompt still takes precedence.
                const prev = byAssetId.get(row.assetId);
                if (prev) {
                    entry.prompt = entry.prompt || prev.prompt;
                    entry.sourceAssetId = entry.sourceAssetId || prev.sourceAssetId;
                    entry.mediaGenInput = entry.mediaGenInput || prev.mediaGenInput;
                }
                byAssetId.set(row.assetId, entry);
                convEntries.set(row.assetId, entry);
            }
        }

        if (onConversation) {
            try { await onConversation(cid, convEntries); } catch (e) { /* persistence must never break the walk */ }
        }
        if (onProgress) onProgress(i + 1, unique.length);
    }

    return { byAssetId, conversationsRequested: unique.length, conversationsFetched, errors, stoppedEarly, aborted };
}

// ===========================================================================
// Collections = grok's CURRENT tag system (issue #12)
//
// Tags used to live under /rest/media/folder/* and were queried through the
// legacy post-list (`filter.folderId`). Grok has since rebuilt tags on the
// asset model as /rest/media/collection/*, and the two stores are NOT in sync:
// verified 2026-08-17 that a collection created 2026-08-15 was absent from
// folder/list, whose newest entry was 2026-03-28 — i.e. newly created tags are
// invisible to the old endpoint. The legacy tag-filtered post list also
// under-reports (one tag: 76 assets via collections vs 44 posts via post/list).
//
// Verified request contract:
//   POST /rest/media/collection/list        {limit}                -> { collections: [...], nextCursor? }
//   POST /rest/media/collection/assets/list {collectionId, limit}  -> { items: [{assetId,mimeType,addTime}], nextCursor? }
//     * The page-size field is `limit` (what grok's own client sends);
//       `pageSize` is IGNORED (asking for 1 still returns ~50). BOTH endpoints
//       paginate, so both must be walked or the result is silently truncated.
//     * paginate by sending the returned cursor back as `cursor` — sending it
//       as `nextCursor`/`pageToken` silently returns page 1 AGAIN (no error),
//       which would loop forever, so the field name matters.
// ===========================================================================
const COLLECTION_API_BASE = 'https://grok.com/rest/media/collection';

async function listCollections(fetchImpl = fetch, {
    limit = 100,
    maxPages = 50,
    sleepImpl = null,
    throttleMs = 200
} = {}) {
    // Paginated, like grok's own client: it posts {limit:100} here. Sending an
    // empty body relies on a server default and silently truncates the tag list
    // for anyone with more tags than that default — they'd simply never see
    // their older tags. `nextCursor` must be sent back as `cursor` (as
    // `nextCursor`/`pageToken` the server replays page 1 with HTTP 200).
    const sleep = sleepImpl || ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
    const collections = [];
    const seen = new Set();
    let cursor = null;
    let firstError = null;

    for (let pageCount = 0; pageCount < maxPages; pageCount++) {
        if (pageCount > 0) await sleep(throttleMs);

        const body = cursor ? { limit, cursor } : { limit };
        const res = await fetchImpl(`${COLLECTION_API_BASE}/list`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify(body)
        });
        if (!res.ok) {
            // Surface a first-page failure so the caller can fall back to the
            // legacy folder list; a later page failing still yields what we have.
            firstError = Object.assign(new Error('HTTP ' + res.status), { status: res.status });
            if (collections.length === 0) throw firstError;
            break;
        }

        const data = await res.json();
        const page = (data && data.collections) || [];
        if (page.length === 0) break;

        let fresh = 0;
        for (const c of page) {
            if (!c || !c.id || seen.has(c.id)) continue;
            seen.add(c.id);
            collections.push(c);
            fresh++;
        }
        // Same-page guard: a server that ignores the cursor would loop forever.
        if (fresh === 0) break;

        const next = data && data.nextCursor;
        if (!next) break;
        cursor = next;
    }

    return collections;
}

/**
 * All asset ids in a collection (tag), following `nextCursor` pagination.
 * Never throws: a failed page stops paging and returns what was gathered.
 */
async function listCollectionAssetIds(fetchImpl = fetch, collectionId, {
    signalAborted = null,
    throttleMs = 300,
    sleepImpl = null,
    maxPages = 500,
    limit = 100,
    onProgress = null
} = {}) {
    const sleep = sleepImpl || ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
    const items = [];
    const seen = new Set();
    let cursor = null;
    let pageCount = 0;
    let errors = 0;

    while (pageCount < maxPages) {
        if (signalAborted && signalAborted()) break;
        if (pageCount > 0) await sleep(throttleMs);

        // grok's own client posts {collectionId, limit:100} here; without a
        // limit the server falls back to a smaller default page.
        const body = cursor ? { collectionId, limit, cursor } : { collectionId, limit };
        let data;
        try {
            const res = await fetchImpl(`${COLLECTION_API_BASE}/assets/list`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify(body)
            });
            if (!res.ok) { errors++; break; }
            data = await res.json();
        } catch (error) {
            errors++;
            break;
        }

        const page = (data && data.items) || [];
        if (page.length === 0) break;

        // Guard against a server that ignores the cursor and replays a page:
        // without this an unchanged page would loop until maxPages.
        let fresh = 0;
        for (const item of page) {
            if (!item || !item.assetId || seen.has(item.assetId)) continue;
            seen.add(item.assetId);
            items.push(item);
            fresh++;
        }
        pageCount++;
        if (onProgress) onProgress({ count: items.length, pageCount });
        if (fresh === 0) break;

        const next = data && data.nextCursor;
        if (!next) break;
        cursor = next;
    }

    return { items, pageCount, errors };
}

/**
 * Full asset metadata for specific ids, via the batch `assetIds` query param.
 * NOTE: `workspaceKind` is REQUIRED — omitting it returns zero assets (verified).
 * Ids must be REPEATED params; a comma-separated list is rejected with HTTP 400.
 */
async function getAssetsByIds(fetchImpl = fetch, assetIds, {
    batchSize = 60,
    signalAborted = null,
    throttleMs = 300,
    sleepImpl = null,
    onProgress = null
} = {}) {
    const sleep = sleepImpl || ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
    const unique = [...new Set((assetIds || []).filter(Boolean))];
    const assets = [];
    const returned = new Set();
    let errors = 0;

    for (let i = 0; i < unique.length; i += batchSize) {
        if (signalAborted && signalAborted()) break;
        if (i > 0) await sleep(throttleMs);

        const chunk = unique.slice(i, i + batchSize);
        const url = `${ASSETS_API_BASE}?`
            + chunk.map((id) => 'assetIds=' + encodeURIComponent(id)).join('&')
            + '&workspaceKind=WORKSPACE_KIND_IMAGINE_ALL';
        try {
            // 2026-10-24 patch: retry 429/5xx with backoff (honoring Retry-After)
            // instead of dropping the batch — on a 31k-id resume ~55% of batches
            // came back 429 and were silently lost, making every resume partial.
            let res = null;
            for (let attempt = 0; ; attempt++) {
                res = await fetchImpl(url);
                const retryable = !res.ok && (res.status === 429 || res.status >= 500);
                if (!retryable || attempt >= 5 || (signalAborted && signalAborted())) break;
                const ra = parseRetryAfterMs(res.headers && typeof res.headers.get === 'function' ? res.headers.get('Retry-After') : null);
                const waitMs = Math.max(Math.min(2000 * Math.pow(2, attempt), 30000), ra != null ? Math.min(ra, 60000) : 0);
                throttleMs = Math.min(Math.round(throttleMs * 1.5), 2500);
                await sleep(waitMs);
            }
            if (!res.ok) { errors++; continue; }
            const data = await res.json();
            for (const raw of (data && data.assets) || []) {
                if (!raw || !raw.assetId) continue;
                returned.add(raw.assetId);
                if (raw.isDeleted !== true) assets.push(mapRawAsset(raw));
            }
        } catch (error) {
            errors++;
        }
        if (onProgress) onProgress({ count: assets.length, total: unique.length });
    }

    // Every requested id must have an outcome. An id the server simply omits
    // (rather than erroring) would otherwise vanish from the download list with
    // no trace — report it so a short list is diagnosable instead of mysterious.
    const missingIds = unique.filter((id) => !returned.has(id));
    return { assets, errors, requested: unique.length, missingIds };
}

// ===========================================================================
// Issue #13 — the collection migration is incomplete in BOTH directions.
//
// Measured live (full cursor walks of both stores, same account, same moment):
//   tag      collection/assets/list   legacy folder post/list (flattened)
//   Airo            2                      233
//   Hidden         20                      310
//   R18            76                      171
//   NSFW            5                       61
//   MyLove          5                        4
// Tags "Japanese"/"swimsuit" exist ONLY in folder/list; "Fantasy"/"Liked"
// ONLY in collection/list. For every tag present in both, collectionId ===
// folderId, and assetId === post.id — one id namespace. So neither store is
// authoritative: the tag list and a tag's contents are the UNION of both.
//
// Legacy contract (the favorite path's exact request shape):
//   POST /rest/media/folder/list {}  -> { folders: [{id,name,createTime}] }
//   POST /rest/media/post/list {limit, filter:{source:'MEDIA_POST_SOURCE_LIKED',
//        safeForWork:false, folderId}, cursor?} -> { posts:[…childPosts…], nextCursor? }
//   * `source` MUST be kept: without it folderId filtering is unreliable (two
//     different tags overlapped 53%). `safeForWork:false` MUST be kept or NSFW
//     items are dropped. The request cursor field is `cursor`.
// ===========================================================================
const LEGACY_FOLDER_LIST_URL = 'https://grok.com/rest/media/folder/list';
const LEGACY_POST_LIST_URL = 'https://grok.com/rest/media/post/list';

function flattenLegacyPosts(posts) {
    if (typeof GrokUtils !== 'undefined' && GrokUtils && typeof GrokUtils.flattenPosts === 'function') {
        return GrokUtils.flattenPosts(posts);
    }
    if (!Array.isArray(posts)) return [];
    const out = [];
    const stack = [...posts].reverse();
    while (stack.length) {
        const post = stack.pop();
        if (!post) continue;
        out.push(post);
        if (Array.isArray(post.childPosts) && post.childPosts.length) {
            for (let i = post.childPosts.length - 1; i >= 0; i--) stack.push(post.childPosts[i]);
        }
    }
    return out;
}

/**
 * Legacy tag list. Resolves to the folders array; a non-ok response resolves
 * to [] unless `throwOnError` is set (then it throws an Error with .status, as
 * listCollections does). A rejected fetch (network error) always propagates.
 */
async function listLegacyFolders(fetchImpl = fetch, { throwOnError = false } = {}) {
    const res = await fetchImpl(LEGACY_FOLDER_LIST_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: '{}'
    });
    if (!res.ok) {
        if (throwOnError) throw Object.assign(new Error('HTTP ' + res.status), { status: res.status });
        return [];
    }
    const data = await res.json();
    return (data && Array.isArray(data.folders)) ? data.folders : [];
}

/**
 * Every post id in a legacy folder (tag): full cursor walk of post/list with
 * the liked+nsfw+folderId filter, childPosts flattened, deduped by id, raw row
 * kept. Never throws — a failed page stops paging, keeps what was gathered
 * and counts the error.
 */
async function listLegacyFolderPostIds(fetchImpl = fetch, folderId, {
    signalAborted = null,
    throttleMs = 300,
    sleepImpl = null,
    maxPages = 200,
    limit = 100,
    onProgress = null
} = {}) {
    const sleep = sleepImpl || ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
    const items = [];
    const seen = new Set();
    let cursor = null;
    let pageCount = 0;
    let errors = 0;
    let prevPageKey = null;

    while (pageCount < maxPages) {
        if (signalAborted && signalAborted()) break;
        if (pageCount > 0) await sleep(throttleMs);

        const body = {
            limit,
            filter: { source: 'MEDIA_POST_SOURCE_LIKED', safeForWork: false, folderId }
        };
        if (cursor) body.cursor = cursor;

        let data;
        try {
            const res = await fetchImpl(LEGACY_POST_LIST_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify(body)
            });
            if (!res.ok) { errors++; break; }
            data = await res.json();
        } catch (error) {
            errors++;
            break;
        }

        const page = (data && data.posts) || [];
        if (page.length === 0) break;

        for (const post of flattenLegacyPosts(page)) {
            if (!post || !post.id || seen.has(post.id)) continue;
            seen.add(post.id);
            items.push({ id: post.id, post });
        }
        pageCount++;
        if (onProgress) onProgress({ count: items.length, pageCount });

        // Replay guard. Unlike listCollectionAssetIds (a flat feed, where a
        // page with no fresh ids IS a replayed page), post/list is NESTED: a
        // liked video can appear as a childPost of its parent on one page and
        // as a top-level post on a later one, so a page of only already-seen
        // ids must NOT end the walk (it would silently drop every later page).
        // Only an actual replay ends it: the server handing back the cursor it
        // was given, or the same top-level rows as the previous page.
        const next = data && data.nextCursor;
        if (!next) break;
        const pageKey = page.map((p) => (p && p.id) || '').join('\u0000');
        if (next === cursor || pageKey === prevPageKey) break;
        prevPageKey = pageKey;
        cursor = next;
    }

    return { items, pageCount, errors };
}

async function fetchBothTagStores(fetchImpl, opts = {}) {
    // Each store failing is tolerated independently: null = unavailable.
    const errors = [];
    let collections = null;
    let folders = null;
    try {
        collections = await listCollections(fetchImpl, opts);
    } catch (error) {
        errors.push('collection/list: ' + (error && error.message ? error.message : String(error)));
    }
    try {
        folders = await listLegacyFolders(fetchImpl, { throwOnError: true });
    } catch (error) {
        errors.push('folder/list: ' + (error && error.message ? error.message : String(error)));
    }
    return { collections, folders, errors };
}

/**
 * Tag list = collection/list ∪ folder/list. Entries are merged by id first
 * (verified: a migrated tag keeps its id across stores) and then by exact
 * name; `id` prefers the collectionId so download-history keys stay stable
 * (migrated tags: same id either way; collection-only: unchanged; folder-only:
 * the pre-v2.5.2 key). Throws only when BOTH stores fail.
 */
async function listTagsUnion(fetchImpl = fetch, opts = {}) {
    const { collections, folders, errors } = await fetchBothTagStores(fetchImpl, opts);
    if (collections === null && folders === null) {
        throw new Error('Both tag stores failed: ' + errors.join('; '));
    }

    const tags = [];
    const byId = new Map();
    const byName = new Map();
    for (const c of collections || []) {
        if (!c || !c.id) continue;
        const entry = {
            id: c.id,
            name: c.name,
            isDefault: c.isDefault === true,
            collectionId: c.id,
            folderId: null
        };
        tags.push(entry);
        byId.set(c.id, entry);
        if (typeof c.name === 'string' && !byName.has(c.name)) byName.set(c.name, entry);
    }
    for (const f of folders || []) {
        if (!f || !f.id) continue;
        const match = byId.get(f.id) || (typeof f.name === 'string' ? byName.get(f.name) : undefined);
        if (match) {
            if (!match.folderId) match.folderId = f.id;
            continue;
        }
        const entry = {
            id: f.id,
            name: f.name,
            isDefault: false,
            collectionId: null,
            folderId: f.id
        };
        tags.push(entry);
        byId.set(f.id, entry);
        if (typeof f.name === 'string' && !byName.has(f.name)) byName.set(f.name, entry);
    }

    return {
        tags,
        counts: { collection: (collections || []).length, legacy: (folders || []).length },
        errors
    };
}

/**
 * Resolve the popup's {tagId, tagName} to an id in EACH store: by id first,
 * then by exact name. If the collection list itself is unavailable the
 * selected id is still tried as a collectionId (it is the collectionId
 * whenever the tag has one, so a transient list failure must not block the
 * download). A folderId is never guessed: post/list with an unknown folderId
 * is unverified and could fall back to the whole liked feed.
 */
async function resolveTagSources(fetchImpl = fetch, { tagId, tagName } = {}, opts = {}) {
    const { collections, folders, errors } = await fetchBothTagStores(fetchImpl, opts);
    const findIn = (list) => {
        if (!Array.isArray(list)) return null;
        const byId = tagId ? list.find((x) => x && x.id === tagId) : null;
        if (byId) return byId.id;
        const byName = tagName ? list.find((x) => x && x.name === tagName) : null;
        return byName ? byName.id : null;
    };
    const collectionId = collections === null ? (tagId || null) : findIn(collections);
    const folderId = findIn(folders);
    return {
        collectionId,
        folderId,
        collectionsAvailable: collections !== null,
        foldersAvailable: folders !== null,
        errors
    };
}

/**
 * A tag's contents = collection asset ids ∪ legacy folder post ids (flattened,
 * deduped). Legacy rows are kept so the caller can build items for ids that
 * /rest/assets does not return. Either store may be null (skipped) or fail
 * (counted in `errors`); the other still contributes.
 */
async function listTagAssetIdsUnion(fetchImpl = fetch, { collectionId = null, folderId = null } = {}, {
    signalAborted = null,
    throttleMs = 300,
    sleepImpl = null,
    onProgress = null
} = {}) {
    const ids = [];
    const seen = new Set();
    const legacyRowsById = new Map();
    let collectionCount = 0;
    let legacyCount = 0;
    let collectionPages = 0;
    let legacyPages = 0;
    let errors = 0;

    if (collectionId) {
        const r = await listCollectionAssetIds(fetchImpl, collectionId, {
            signalAborted, throttleMs, sleepImpl,
            onProgress: onProgress ? (p) => onProgress({ count: p.count, pageCount: p.pageCount, source: 'collection' }) : null
        });
        for (const item of r.items) {
            if (seen.has(item.assetId)) continue;
            seen.add(item.assetId);
            ids.push(item.assetId);
        }
        collectionCount = r.items.length;
        collectionPages = r.pageCount;
        errors += r.errors;
    }

    if (folderId) {
        const r = await listLegacyFolderPostIds(fetchImpl, folderId, {
            signalAborted, throttleMs, sleepImpl,
            onProgress: onProgress ? (p) => onProgress({ count: collectionCount + p.count, pageCount: p.pageCount, source: 'legacy' }) : null
        });
        for (const item of r.items) {
            legacyRowsById.set(item.id, item.post);
            if (seen.has(item.id)) continue;
            seen.add(item.id);
            ids.push(item.id);
        }
        legacyCount = r.items.length;
        legacyPages = r.pageCount;
        errors += r.errors;
    }

    return {
        ids,
        legacyRowsById,
        collectionCount,
        legacyCount,
        unionCount: ids.length,
        collectionPages,
        legacyPages,
        errors
    };
}

/**
 * 2026-10-24 patch: throttled persistence for long walks (prompt recovery).
 * tick() after each unit of work flushes when `flushEvery` units have
 * accumulated OR `flushIntervalMs` has elapsed since the last flush;
 * finish() always flushes whatever is pending. flush errors are swallowed.
 */
function createIncrementalPersister({ flush, flushEvery = 50, flushIntervalMs = 30000, now = () => Date.now() } = {}) {
    let pending = 0;
    let last = now();
    let flushes = 0;
    const doFlush = async () => {
        pending = 0; last = now(); flushes++;
        try { await flush(); } catch (e) { /* non-fatal */ }
    };
    return {
        tick: async () => {
            pending++;
            if (pending >= flushEvery || now() - last >= flushIntervalMs) await doFlush();
        },
        finish: async () => { if (pending > 0) await doFlush(); },
        get flushes() { return flushes; },
        get pending() { return pending; }
    };
}

const GrokAssets = { createIncrementalPersister, ASSET_PAGE_THROTTLE_MS, ASSET_PAGE_RETRY_BACKOFF_MS, parseRetryAfterMs, mergeAssetListsById, mergePartialWithStored, buildScanCheckpoint, planScanResume, scanAllWithCheckpoint, listGeneratedAssets, listAllGeneratedAssets, resolveVideoQuality, fetchConversationTitles, fetchConversationAssetMetadata, extractAssetPrompt, extractSourceAssetId, mapRawAsset, listCollections, listCollectionAssetIds, getAssetsByIds, listLegacyFolders, listLegacyFolderPostIds, listTagsUnion, resolveTagSources, listTagAssetIdsUnion };

if (typeof module !== 'undefined' && module.exports) module.exports = GrokAssets;
if (typeof window !== 'undefined') window.GrokAssets = GrokAssets;
if (typeof globalThis !== 'undefined') globalThis.GrokAssets = GrokAssets;
