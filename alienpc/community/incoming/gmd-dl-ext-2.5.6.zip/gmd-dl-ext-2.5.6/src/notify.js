// Non-blocking replacement for alert() in extension pages (popup, side panel).
// alert() froze the popup until dismissed; this shows a dismissible toast.
(function (root) {
    'use strict';
    function gmdNotify(message, { timeoutMs = null } = {}) {
        const text = message == null ? '' : String(message);
        console.log('[notify]', text);
        if (typeof document === 'undefined' || !document.body) return;
        let host = document.getElementById('gmdNotifyHost');
        if (!host) {
            host = document.createElement('div');
            host.id = 'gmdNotifyHost';
            host.setAttribute('role', 'status');
            host.setAttribute('aria-live', 'polite');
            host.style.cssText = 'position:fixed;top:8px;left:8px;right:8px;z-index:2147483647;display:flex;flex-direction:column;gap:6px;pointer-events:none;';
            document.body.appendChild(host);
        }
        const box = document.createElement('div');
        box.style.cssText = 'pointer-events:auto;background:#263238;color:#fff;font-size:12px;line-height:1.4;padding:8px 28px 8px 10px;border-radius:6px;box-shadow:0 2px 8px rgba(0,0,0,.3);white-space:pre-wrap;position:relative;max-height:60vh;overflow:auto;';
        box.textContent = text;
        const close = document.createElement('button');
        close.textContent = '×';
        close.setAttribute('aria-label', 'Dismiss');
        close.style.cssText = 'position:absolute;top:2px;right:4px;background:none;border:none;color:#fff;font-size:16px;cursor:pointer;';
        close.addEventListener('click', () => box.remove());
        box.appendChild(close);
        host.appendChild(box);
        const ms = timeoutMs ?? Math.min(20000, 5000 + text.length * 40);
        setTimeout(() => box.remove(), ms);
    }
    root.gmdNotify = gmdNotify;
    if (typeof module === 'object' && module.exports) module.exports = { gmdNotify };
}(typeof self !== 'undefined' ? self : this));
