// Pure helper for the popup "Import on-disk IDs" button: accept either a bare
// array of ids/filenames or an object with an `ids` array (the format written
// by the on-disk filename scan). Normalisation happens in content.js.
(function (root) {
    'use strict';
    function extractIds(data) {
        const list = Array.isArray(data) ? data : (data && Array.isArray(data.ids) ? data.ids : []);
        return list.filter(x => typeof x === 'string' && x.trim());
    }
    root.PopupSkipIds = { extractIds };
    root.SKIP_IDS_PACKAGED_PATH = 'data/ondisk-media-ids.json';
    if (typeof module === 'object' && module.exports) module.exports = { extractIds, SKIP_IDS_PACKAGED_PATH: 'data/ondisk-media-ids.json' };
}(typeof self !== 'undefined' ? self : this));
