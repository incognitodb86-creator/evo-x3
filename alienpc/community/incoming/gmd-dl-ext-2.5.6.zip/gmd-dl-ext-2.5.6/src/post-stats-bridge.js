/**
 * ISOLATED World Relay Bridge
 * Listens for MAIN world postMessage events and forwards to chrome.runtime
 * Runs at document_start in ISOLATED world on grok.com/*
 */

if (!window.__grokBridgeLoaded) {
    window.__grokBridgeLoaded = true;

    window.addEventListener('message', (event) => {
        // Only accept messages from the same window (MAIN world)
        if (event.source !== window) return;
        if (!event.data || event.data.type !== 'GROK_VIDEO_GEN_RESULT') return;

        const payload = event.data.payload;
        if (!payload) return;

        // Validate payload shape before forwarding — reject malformed messages
        // (resultId: string, videoPostId/parentPostId: string|null, moderated: boolean)
        if (typeof payload.resultId !== 'string') {
            console.warn('[GrokBridge] Dropping videoGenResult with invalid resultId:', payload.resultId);
            return;
        }
        if (payload.videoPostId !== null && typeof payload.videoPostId !== 'string') {
            console.warn('[GrokBridge] Dropping videoGenResult with invalid videoPostId:', payload.videoPostId);
            return;
        }
        if (payload.parentPostId !== null && typeof payload.parentPostId !== 'string') {
            console.warn('[GrokBridge] Dropping videoGenResult with invalid parentPostId:', payload.parentPostId);
            return;
        }
        if (typeof payload.moderated !== 'boolean') {
            console.warn('[GrokBridge] Dropping videoGenResult with invalid moderated flag:', payload.moderated);
            return;
        }

        // Forward to background.js via chrome.runtime
        chrome.runtime.sendMessage({
            action: 'videoGenResult',
            resultId: payload.resultId,
            parentPostId: payload.parentPostId,
            videoPostId: payload.videoPostId,
            moderated: payload.moderated,
            videoPrompt: payload.videoPrompt
        }).catch(err => {
            console.warn('[GrokBridge] Failed to forward videoGenResult:', err);
        });
    });

    // ---- Stream Capture v2: network-level results from intercept.js ------
    // Forwarded only while Stream Capture is enabled. Each item is validated
    // here (the MAIN world is page-reachable); media the server marked
    // blocked/moderated is forwarded as `blocked` so the background records
    // it and never fetches it.
    const CAPTURE_ENABLED_KEY = 'streamCaptureEnabled';
    const MEDIA_HOST_RE = /^https:\/\/(assets\.grok\.com|imagine-public\.x\.ai|[a-z0-9-]+\.grok\.com|[a-z0-9-]+\.x\.ai)\//i;
    const ID_RE = /^[A-Za-z0-9_-]{6,64}$/;
    let captureEnabled = false;
    chrome.storage.local.get(CAPTURE_ENABLED_KEY).then((r) => { captureEnabled = r[CAPTURE_ENABLED_KEY] === true; }).catch(() => {});
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && changes[CAPTURE_ENABLED_KEY]) captureEnabled = changes[CAPTURE_ENABLED_KEY].newValue === true;
    });

    async function sha256OfBase64(b64) {
        const bin = atob(b64);
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        const d = await crypto.subtle.digest('SHA-256', bytes);
        return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, '0')).join('');
    }

    async function forwardCaptureItem(raw) {
        if (!raw || typeof raw !== 'object') return;
        const kind = raw.kind === 'video' ? 'video' : raw.kind === 'image' ? 'image' : null;
        if (!kind) return;
        const mediaId = typeof raw.mediaId === 'string' && ID_RE.test(raw.mediaId) ? raw.mediaId : null;
        const url = typeof raw.url === 'string' && raw.url.length < 4096 && MEDIA_HOST_RE.test(raw.url) ? raw.url : null;
        const item = { kind, mediaId, url, blocked: raw.blocked === true, source: 'net' };
        if (!url && typeof raw.dataBase64 === 'string' && /^[A-Za-z0-9+/=]+$/.test(raw.dataBase64.slice(0, 200))) {
            const mime = /^image\/(png|jpeg|webp)$/.test(raw.mime || '') ? raw.mime : 'image/jpeg';
            item.dataUrl = `data:${mime};base64,${raw.dataBase64}`;
            item.mime = mime;
            if (!mediaId) item.sha256 = await sha256OfBase64(raw.dataBase64);
        }
        if (!item.mediaId && !item.sha256 && !(kind === 'video' && item.blocked)) return; // no stable key
        if (!item.url && !item.dataUrl && !item.blocked && kind !== 'video') return;
        chrome.runtime.sendMessage({ action: 'captureItem', item }).catch(() => {});
    }

    window.addEventListener('message', (event) => {
        if (event.source !== window || !event.data) return;
        if (event.data.type === 'GROK_MEDIA_CAPTURE') {
            if (!captureEnabled) return;
            const items = event.data.payload && Array.isArray(event.data.payload.items) ? event.data.payload.items.slice(0, 50) : [];
            for (const it of items) forwardCaptureItem(it).catch((e) => console.warn('[GrokBridge] capture forward failed:', e && e.message));
        } else if (event.data.type === 'GROK_CAPTURE_PARSE_ERROR') {
            if (!captureEnabled) return;
            const count = Number(event.data.payload && event.data.payload.count) || 1;
            console.warn(`[GrokBridge] ${count} capture payload(s) could not be parsed (log-only)`);
            chrome.runtime.sendMessage({ action: 'captureParseError', count }).catch(() => {});
        }
    });

    console.log('[GrokBridge] Post stats bridge loaded');
}
