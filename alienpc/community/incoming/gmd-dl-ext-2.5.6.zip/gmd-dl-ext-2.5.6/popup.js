// Popup UI 邏輯

function buildMarketingUrl(path, content, campaign = 'pro_upgrade') {
    const base = 'https://grokmedia.kario-studio.com';
    const params = new URLSearchParams({
        utm_source: 'extension',
        utm_medium: 'referral',
        utm_campaign: campaign,
        utm_content: content
    });
    return `${base}/${path}?${params}`;
}

document.addEventListener('DOMContentLoaded', async () => {
    const generateBtn = document.getElementById('generateBtn');
    const startBtn = document.getElementById('startBtn');
    const clearBtn = document.getElementById('clearBtn');
    const clearHistoryBtn = document.getElementById('clearHistoryBtn');
    const exportBtn = document.getElementById('exportBtn');
    const importBtn = document.getElementById('importBtn');
    const importFile = document.getElementById('importFile');
    const fromDate = document.getElementById('fromDate');
    const toDate = document.getElementById('toDate');
    const message = document.getElementById('message');
    const filterWarning = document.getElementById('filterWarning');
    const storyModeHelperBtn = document.getElementById('storyModeHelperBtn');
    let messageTimeout = null;
    let wrongPageMessageShown = false;  // 追蹤錯誤頁面訊息是否已顯示
    let completionMessageShown = false; // 避免完成訊息重複顯示導致 scroll to top
    let rateLimitMessageShown = false; // 避免 rate limit paused 訊息重複顯示

    // ============================================
    // Task D4: per-source stats cache
    //
    // Each source (favorite/tag/allmedia) has its OWN dedup history (D1), so its
    // "already downloaded / need download" numbers are meaningful only for that
    // source. Without a cache, switching sources would either show stale numbers
    // from whichever source was last generated (misleading) or blank out entirely
    // once D6 makes getStatus source-aware. This cache keeps the last-seen stats
    // PER SOURCE so a switch always shows that source's own last-known numbers —
    // never another source's — without firing a new API scan.
    //
    // Keying: 'tag' caches only the LAST tag scanned (not sub-keyed by tagId) —
    // switching between two different tags without rescanning shows the
    // previous tag's numbers, which is an acceptable simplification for now.
    //
    // D6: the source is now read from the dedicated `downloadSource` radio
    // group (favorite/tag/allmedia), fully independent of the date-filter
    // radio group — see getCurrentSourceKey() below.
    // ============================================
    const STATS_CACHE_STORAGE_KEY = 'grok_stats_cache_by_source';
    let statsCacheBySource = {}; // { favorite: {displayStats, filterOptions}, tag: {...}, allmedia: {...} }

    // Maps a saved state's filterOptions to the source key that produced it.
    // Mirrors content.js's getEffectiveHistory() branch order (allmedia checked
    // before tagId) so the two stay in lockstep.
    function sourceKeyFromFilterOptions(filterOptions) {
        if (!filterOptions) return 'favorite';
        if (filterOptions.source === 'allmedia') return 'allmedia';
        if (filterOptions.tagId) return 'tag';
        return 'favorite';
    }

    // Reads the currently-selected source from the dedicated downloadSource
    // radio group (Task D6 — independent of the date-filter radio group).
    function getCurrentSourceKey() {
        const checked = document.querySelector('input[name="downloadSource"]:checked');
        const val = checked ? checked.value : 'favorite';
        if (val === 'tag') return 'tag';
        if (val === 'allmedia') return 'allmedia';
        return 'favorite';
    }

    // Loads any persisted per-source cache from a previous popup session.
    // Guards against a missing/corrupt entry — never lets a bad cache blow up
    // popup init.
    async function loadStatsCacheFromStorage() {
        try {
            const data = await chrome.storage.local.get(STATS_CACHE_STORAGE_KEY);
            const raw = data && data[STATS_CACHE_STORAGE_KEY];
            if (raw && typeof raw === 'object') statsCacheBySource = raw;
        } catch (e) {
            statsCacheBySource = {};
        }
    }

    // Stores the latest stats snapshot for a source (in-memory + persisted).
    // Persistence is fire-and-forget: a storage failure (quota, etc.) must not
    // block the UI from updating.
    function cacheStatsForSource(sourceKey, snapshot) {
        statsCacheBySource = { ...statsCacheBySource, [sourceKey]: snapshot };
        try {
            const result = chrome.storage.local.set({ [STATS_CACHE_STORAGE_KEY]: statsCacheBySource });
            if (result && typeof result.catch === 'function') result.catch(() => {});
        } catch (e) { /* ignore — cache stays in memory for this session */ }
    }

    function getCachedStatsForSource(sourceKey) {
        return statsCacheBySource[sourceKey] || null;
    }

    // Renders just the "already downloaded / need download" summary fields plus
    // the filter-info line — shared by the live (getStatus) path and the
    // per-source cache path so both stay pixel-identical. `snapshot` is
    // `{ displayStats, filterOptions }` or null/undefined for the empty/
    // "press scan" placeholder view.
    function renderStatsFields(snapshot) {
        const ds = (snapshot && snapshot.displayStats) || {};
        const filterOptions = (snapshot && snapshot.filterOptions) || null;

        const filterInfo = document.getElementById('filterInfo');
        const filterInfoText = document.getElementById('filterInfoText');
        if (filterInfo) {
            if (filterOptions) {
                filterInfo.style.display = 'block';
                const parts = [];
                if (filterOptions.tagId && filterOptions.tagName) {
                    parts.push((chrome.i18n.getMessage('filterInfoTag', [filterOptions.tagName]) || '🏷️ Tag: ' + filterOptions.tagName));
                } else if (filterOptions.hoursLimit) {
                    parts.push(chrome.i18n.getMessage('msgLastHours', [String(filterOptions.hoursLimit)]));
                } else if (filterOptions.fromDate || filterOptions.toDate) {
                    const fromStr = filterOptions.fromDateString || '∞';
                    const toStr = filterOptions.toDateString || '∞';
                    parts.push(chrome.i18n.getMessage('msgDateRange', [fromStr, toStr]));
                } else {
                    parts.push(chrome.i18n.getMessage('msgDateAll'));
                }
                if (filterInfoText) filterInfoText.textContent = parts.join(' | ');
            } else {
                filterInfo.style.display = 'none';
            }
        }

        document.getElementById('imageTotal').textContent = ds.imageTotal ?? '-';
        document.getElementById('imageDownloaded').textContent = ds.imageDownloaded ?? '-';
        document.getElementById('imageNeed').textContent = ds.imageNeed ?? '-';
        document.getElementById('sdVideoTotal').textContent = ds.sdTotal ?? '-';
        document.getElementById('sdVideoDownloaded').textContent = ds.sdDownloaded ?? '-';
        document.getElementById('sdVideoNeed').textContent = ds.sdNeed ?? '-';
        document.getElementById('v720pTotal').textContent = ds.v720pTotal ?? '-';
        document.getElementById('v720pDownloaded').textContent = ds.v720pDownloaded ?? '-';
        document.getElementById('v720pNeed').textContent = ds.v720pNeed ?? '-';
        document.getElementById('hdVideoTotal').textContent = ds.hdTotal ?? '-';
        document.getElementById('hdVideoDownloaded').textContent = ds.hdDownloaded ?? '-';
        document.getElementById('hdVideoNeed').textContent = ds.hdNeed ?? '-';
        document.getElementById('v1080pVideoTotal').textContent = ds.v1080pTotal ?? '-';
        document.getElementById('v1080pVideoDownloaded').textContent = ds.v1080pDownloaded ?? '-';
        document.getElementById('v1080pVideoNeed').textContent = ds.v1080pNeed ?? '-';
    }

    // Story Mode Helper button - opens Side Panel
    storyModeHelperBtn.addEventListener('click', async () => {
        try {
            // Get current tab to open side panel in context
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab) {
                // Ensure story mode sidepanel is set
                await chrome.runtime.sendMessage({
                    action: 'switchSidePanel',
                    path: 'sidepanel/sidepanel.html'
                });
                await chrome.sidePanel.open({ tabId: tab.id });
            }
            window.close(); // Close popup after opening side panel
        } catch (error) {
            console.error('Failed to open side panel:', error);
            // Fallback: try to set panel behavior and let user click extension icon again
            try {
                await chrome.sidePanel.setOptions({
                    tabId: (await chrome.tabs.query({ active: true, currentWindow: true }))[0]?.id,
                    path: 'sidepanel/sidepanel.html',
                    enabled: true
                });
                showMessage('Right-click extension icon and select "Open side panel"', 'info');
            } catch (e) {
                showMessage('Failed to open Story Mode Helper: ' + error.message, 'error');
            }
        }
    });

    // Queue Panel button - opens Queue sidepanel
    const queuePanelBtn = document.getElementById('queuePanelBtn');
    queuePanelBtn.addEventListener('click', async () => {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab) {
                await chrome.runtime.sendMessage({
                    action: 'switchSidePanel',
                    path: 'sidepanel/queue.html'
                });
                await chrome.sidePanel.open({ tabId: tab.id });
            }
            window.close();
        } catch (error) {
            console.error('Failed to open queue panel:', error);
            showMessage('Failed to open Queue panel: ' + error.message, 'error');
        }
    });

    // View Logs link - opens logs page in new tab
    const viewLogsLink = document.getElementById('viewLogsLink');
    if (viewLogsLink) {
        viewLogsLink.addEventListener('click', (e) => {
            e.preventDefault();
            chrome.tabs.create({ url: chrome.runtime.getURL('logs.html') });
        });
    }

    // Batch Select Delete button - enters selection mode on favorites page
    const batchSelectDeleteBtn = document.getElementById('batchSelectDeleteBtn');
    batchSelectDeleteBtn.addEventListener('click', async () => {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

            if (!tab.url.includes('grok.com/imagine/saved')) {
                showMessageWithLink(
                    chrome.i18n.getMessage('msgWrongPageFav'),
                    'https://grok.com/imagine/saved',
                    chrome.i18n.getMessage('msgWrongPageLink'),
                    'error'
                );
                return;
            }

            // Inject content script if needed
            try {
                await ensureContentScriptInjected(tab.id);
            } catch (e) {
                console.log('Content script may already exist:', e.message);
            }

            // Send message to enter batch select mode
            const response = await sendMessageToContentScript(tab.id, {
                action: 'enterBatchSelectMode'
            });

            if (response && response.success) {
                window.close(); // Close popup, user will interact with page
            } else {
                showMessage(chrome.i18n.getMessage('msgOperationFailed') || 'Failed to enter selection mode', 'error');
            }
        } catch (error) {
            console.error('Batch select failed:', error);
            showMessage(chrome.i18n.getMessage('msgOperationFailed') + ': ' + error.message, 'error');
        }
    });

    // 初始化國際化
    function localizeHtml() {
        // 替換 data-i18n
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            let msg = chrome.i18n.getMessage(key);

            if (key === 'footerVersion') {
                const version = chrome.runtime.getManifest().version;
                msg = chrome.i18n.getMessage(key, [version]);
            }

            if (msg) element.textContent = msg;
        });

        // 替換 data-i18n-placeholder
        document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
            const key = element.getAttribute('data-i18n-placeholder');
            const msg = chrome.i18n.getMessage(key);
            if (msg) element.placeholder = msg;
        });

        // 替換 data-i18n-title
        document.querySelectorAll('[data-i18n-title]').forEach(element => {
            const key = element.getAttribute('data-i18n-title');
            const msg = chrome.i18n.getMessage(key);
            if (msg) element.title = msg;
        });
    }

    localizeHtml();

    // 摺疊區塊狀態管理
    const collapsibleSections = document.querySelectorAll('.collapsible-section');

    // 載入已儲存的摺疊狀態
    async function loadCollapseState() {
        const result = await chrome.storage.local.get(['collapseState', 'isPro']);
        const state = result.collapseState || {};
        const isPro = result.isPro || false;

        collapsibleSections.forEach(section => {
            const id = section.id;
            // 如果未啟動授權，強制展開 License 區塊
            if (id === 'licenseDetailsSection' && !isPro) {
                section.open = true;
            } else if (id && state[id] !== undefined) {
                section.open = state[id];
            }
        });
    }

    // 儲存摺疊狀態
    async function saveCollapseState() {
        const result = await chrome.storage.sync.get(['isPro']);
        const isPro = result.isPro || false;

        const state = {};
        collapsibleSections.forEach(section => {
            if (section.id) {
                // 如果未啟動授權，不保存 License 區塊的折疊狀態（強制保持展開）
                if (section.id === 'licenseDetailsSection' && !isPro) {
                    state[section.id] = true; // 強制記錄為展開
                } else {
                    state[section.id] = section.open;
                }
            }
        });
        await chrome.storage.local.set({ collapseState: state });
    }

    // 監聽摺疊變更
    collapsibleSections.forEach(section => {
        section.addEventListener('toggle', async (e) => {
            // 如果是 License 區塊且未啟動授權，阻止折疊
            if (section.id === 'licenseDetailsSection') {
                const result = await chrome.storage.sync.get(['isPro']);
                if (!result.isPro && !section.open) {
                    // 用戶嘗試折疊，但未授權，強制重新展開
                    section.open = true;
                    return;
                }
            }
            saveCollapseState();
        });
    });

    // 初始化載入摺疊狀態
    loadCollapseState();

    // ==========================================
    // Compact Mode (精簡模式)
    // ==========================================
    const compactToggle = document.getElementById('compactToggle');
    const compactIcon = document.getElementById('compactIcon');
    const compactLabel = document.getElementById('compactLabel');

    // 載入精簡模式狀態
    async function loadCompactMode() {
        const result = await chrome.storage.local.get(['compactMode']);
        const proResult = await chrome.storage.sync.get(['isPro']);
        let isCompact = result.compactMode || false;

        // 如果未授權，強制關閉精簡模式（確保 License 區塊可見）
        if (!proResult.isPro && isCompact) {
            isCompact = false;
            await chrome.storage.local.set({ compactMode: false });
        }

        applyCompactMode(isCompact);
    }

    // 應用精簡模式
    function applyCompactMode(isCompact) {
        if (isCompact) {
            document.body.classList.add('compact-mode');
            compactToggle.classList.add('active');
            compactIcon.textContent = '📂';
            compactLabel.textContent = chrome.i18n.getMessage('btnExpand') || '全';
        } else {
            document.body.classList.remove('compact-mode');
            compactToggle.classList.remove('active');
            compactIcon.textContent = '📦';
            compactLabel.textContent = chrome.i18n.getMessage('btnCompact') || '簡';
        }
    }

    // 切換精簡模式
    compactToggle.addEventListener('click', async () => {
        const isCurrentlyCompact = document.body.classList.contains('compact-mode');
        const newState = !isCurrentlyCompact;

        // 如果未授權，不允許進入精簡模式（因為會隱藏 License 區塊）
        if (newState) {
            const result = await chrome.storage.sync.get(['isPro']);
            if (!result.isPro) {
                // 未授權，阻止進入精簡模式
                return;
            }
        }

        applyCompactMode(newState);
        await chrome.storage.local.set({ compactMode: newState });
    });

    // 初始化載入精簡模式
    loadCompactMode();

    // ============================================
    // Task D6: Download Source selector (favorite/tag/allmedia) — independent
    // of the date-filter radio group below. Shows/hides each source's own
    // sub-options: date filter (all/dateRange/lastHours) + download mode
    // (standard/project) for favorite; the tag dropdown for tag; date filter +
    // the conversation-library warning note for allmedia.
    // ============================================
    // Free tier: the whole-library source is usable (so everyone can get off the
    // broken legacy Favorite path) but capped to this recent window; the full
    // library + arbitrary date filters remain Pro. Kept in sync by
    // lock/unlockProFeatures, which are the single source of Pro state here.
    const FREE_ALLMEDIA_HOURS = 24 * 7; // 7 days
    let isProUser = false;

    // Re-apply the source-dependent hints when the Pro state changes (the
    // free-tier note depends on it, and license activation happens async).
    function refreshSourceHints() {
        const checked = document.querySelector('input[name="downloadSource"]:checked');
        if (checked) applySourceVisibility(checked.value);
        const upChecked = document.querySelector('input[name="upgradeSource"]:checked');
        const upFavHint = document.getElementById('upgradeFavoriteLegacyHint');
        if (upFavHint && upChecked) upFavHint.style.display = upChecked.value === 'favorite' ? '' : 'none';
    }

    function applySourceVisibility(source) {
        const tagConfig = document.getElementById('tagFilterConfig');
        if (tagConfig) tagConfig.style.display = source === 'tag' ? '' : 'none';

        const allMediaHint = document.getElementById('allMediaFilterHint');
        if (allMediaHint) allMediaHint.style.display = source === 'allmedia' ? '' : 'none';

        // The legacy Favorite source silently misses media generated after
        // grok's 2026-07 backend change — warn whenever it's selected.
        const favLegacyHint = document.getElementById('favoriteLegacyHint');
        if (favLegacyHint) favLegacyHint.style.display = source === 'favorite' ? '' : 'none';

        // Free tier is capped to a recent window on the whole-library source
        // (see FREE_ALLMEDIA_HOURS) — say so instead of silently truncating.
        const freeHint = document.getElementById('allMediaFreeTierHint');
        if (freeHint) freeHint.style.display = (source === 'allmedia' && !isProUser) ? '' : 'none';

        // Date filter (all/dateRange/lastHours) applies to favorite AND
        // allmedia; tag has no date filtering.
        const dateFilterGroup = document.getElementById('dateFilterGroup');
        if (dateFilterGroup) dateFilterGroup.style.display = source === 'tag' ? 'none' : '';

        // Download mode (standard/project) is favorite-only — project mode is
        // N/A for tag (no parent/child structure) and allmedia (always
        // per-conversation folders).
        const downloadModeGroup = document.getElementById('downloadModeGroup');
        if (downloadModeGroup) downloadModeGroup.style.display = source === 'favorite' ? '' : 'none';
    }

    document.querySelectorAll('input[name="downloadSource"]').forEach(radio => {
        radio.addEventListener('change', () => {
            const source = document.querySelector('input[name="downloadSource"]:checked').value;
            applySourceVisibility(source);

            // Auto-load tags when tag source is selected
            if (source === 'tag') {
                loadTagList();
            }

            // Persist selection
            chrome.storage.sync.set({ downloadSource: source });

            // Task D4: render the newly-selected source's CACHED stats immediately
            // (never blank/stale-cross-source) — do NOT fire a new API scan here;
            // only the existing generate/scan flow refreshes the cache.
            renderStatsFields(getCachedStatsForSource(getCurrentSourceKey()));
        });
    });

    // Handle download date filter radio buttons (all/dateRange/lastHours) —
    // applies to favorite and allmedia sources; hidden entirely for tag.
    document.querySelectorAll('input[name="downloadDateFilter"]').forEach(radio => {
        radio.addEventListener('change', () => {
            const val = document.querySelector('input[name="downloadDateFilter"]:checked').value;
            fromDate.disabled = val !== 'dateRange';
            toDate.disabled = val !== 'dateRange';
            document.getElementById('downloadHours').disabled = val !== 'lastHours';
            if (val !== 'dateRange') {
                fromDate.value = '';
                toDate.value = '';
            }
            // Persist selection
            chrome.storage.sync.set({ downloadDateFilter: val });

            // Task D4: render the newly-selected source's CACHED stats immediately
            // (never blank/stale-cross-source) — do NOT fire a new API scan here;
            // only the existing generate/scan flow refreshes the cache.
            renderStatsFields(getCachedStatsForSource(getCurrentSourceKey()));
        });
    });

    // Persist date range and hours inputs on change
    fromDate.addEventListener('change', () => {
        chrome.storage.sync.set({ downloadFromDate: fromDate.value });
    });
    toDate.addEventListener('change', () => {
        chrome.storage.sync.set({ downloadToDate: toDate.value });
    });
    document.getElementById('downloadHours').addEventListener('change', () => {
        chrome.storage.sync.set({ downloadHours: document.getElementById('downloadHours').value });
    });

    // Tag list loading — populates the tag selector dropdown from Grok API
    async function loadTagList() {
        const tagSel = document.getElementById('tagSelector');
        if (!tagSel) return;
        // Clear options and show loading state using safe DOM methods
        while (tagSel.options.length > 0) tagSel.remove(0);
        const loadingOpt = document.createElement('option');
        loadingOpt.value = '';
        loadingOpt.textContent = 'Loading...';
        tagSel.appendChild(loadingOpt);
        tagSel.disabled = true;
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            const response = await sendMessageToContentScript(tab.id, { action: 'fetchTagList' });
            // Clear loading option
            while (tagSel.options.length > 0) tagSel.remove(0);
            if (response && response.success && response.folders) {
                const placeholder = document.createElement('option');
                placeholder.value = '';
                placeholder.textContent = chrome.i18n.getMessage('tagSelectorPlaceholder') || '-- Select Tag --';
                tagSel.appendChild(placeholder);
                response.folders.forEach(folder => {
                    const option = document.createElement('option');
                    option.value = folder.id;
                    option.textContent = folder.name;
                    option.dataset.name = folder.name;
                    tagSel.appendChild(option);
                });
                // Restore previous selection
                const saved = await chrome.storage.sync.get(['selectedTagId']);
                if (saved.selectedTagId) tagSel.value = saved.selectedTagId;
            } else {
                const errOpt = document.createElement('option');
                errOpt.value = '';
                errOpt.textContent = chrome.i18n.getMessage('tagLoadFailed') || 'Failed to load';
                tagSel.appendChild(errOpt);
            }
        } catch (e) {
            while (tagSel.options.length > 0) tagSel.remove(0);
            const errOpt = document.createElement('option');
            errOpt.value = '';
            errOpt.textContent = chrome.i18n.getMessage('tagLoadFailed') || 'Error';
            tagSel.appendChild(errOpt);
        } finally {
            tagSel.disabled = false;
        }
    }

    // Tag selector change — auto-save
    const tagSelector = document.getElementById('tagSelector');
    if (tagSelector) {
        tagSelector.addEventListener('change', () => {
            const opt = tagSelector.options[tagSelector.selectedIndex];
            chrome.storage.sync.set({
                selectedTagId: tagSelector.value,
                selectedTagName: opt?.dataset?.name || opt?.textContent || ''
            });
        });
    }

    // Refresh tags button
    const refreshTagsBtn = document.getElementById('refreshTagsBtn');
    if (refreshTagsBtn) {
        refreshTagsBtn.addEventListener('click', () => loadTagList());
    }

    // Clamp hours inputs to 1-240 on blur
    ['downloadHours', 'hdUpgradeHours', 'removeHours'].forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('blur', () => {
                let v = parseInt(el.value);
                if (isNaN(v) || v < 1) v = 1;
                if (v > 240) v = 240;
                el.value = v;
            });
        }
    });

    // 更新狀態顯示
    async function updateStatus() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

            if (!tab.url.includes('grok.com/imagine')) {
                // 只在第一次顯示錯誤訊息，避免重複滾動到頂部
                if (!wrongPageMessageShown) {
                    wrongPageMessageShown = true;
                    showMessageWithLink(
                        chrome.i18n.getMessage('msgWrongPage'),
                        'https://grok.com/imagine/saved',
                        chrome.i18n.getMessage('msgWrongPageLink'),
                        'error'
                    );
                }
                generateBtn.disabled = true;
                startBtn.disabled = true;
                return;
            } else {
                wrongPageMessageShown = false;  // 重置標記，下次進入錯誤頁面時可再顯示
            }

            const response = await sendMessageToContentScript(tab.id, { action: 'getStatus' }, { silent: true });

            if (response && response.state) {
                const state = response.state;
                const ds = response.displayStats || {};

                if (!document.getElementById('filterInfo')) return; // DOM already torn down

                // Task D4: `state` here is whatever was LAST generated/scanned —
                // possibly for a DIFFERENT source than the one currently selected
                // in the UI (e.g. user switched the radio without regenerating).
                // Cache this source's fresh stats, then only render them live if
                // they actually belong to the currently-selected source; otherwise
                // fall back to that source's own last-known cached stats (or the
                // placeholder view) so numbers from one source never leak into
                // another's display.
                const liveSourceKey = sourceKeyFromFilterOptions(state.filterOptions);
                if (state.filterOptions) {
                    cacheStatsForSource(liveSourceKey, { displayStats: ds, filterOptions: state.filterOptions });
                }
                const currentSourceKey = getCurrentSourceKey();
                if (currentSourceKey === liveSourceKey) {
                    renderStatsFields({ displayStats: ds, filterOptions: state.filterOptions });
                } else {
                    renderStatsFields(getCachedStatsForSource(currentSourceKey));
                }

                const isProjectMode = state.filterOptions?.downloadMode === 'project';

                // Project count
                const projectCountEl = document.getElementById('projectCount');
                if (projectCountEl) {
                    const pCount = state.projectCount || 0;
                    projectCountEl.textContent = pCount > 0 ? pCount : '-';
                }

                // Use pre-computed filtered need counts
                const filteredImageNeed = ds.filteredImageNeed ?? 0;
                const filteredSdNeed = ds.filteredSdNeed ?? 0;
                const filtered720pNeed = ds.filtered720pNeed ?? 0;
                const filteredHdNeed = ds.filteredHdNeed ?? 0;

                // 顯示當前階段 (phase text with mode + progress)
                const totalItems = isProjectMode ?
                    (state.projectCount || 0) :
                    (ds.filteredTotal ?? 0);

                let phaseText = '-';
                const modeLabel = isProjectMode ?
                    chrome.i18n.getMessage('statusPhaseProject') :
                    chrome.i18n.getMessage('statusPhaseStandard');

                // Build filtered summary: 🖼️ N / 🎬 SD N / 🎥 720p N / ✨ HD N
                const summary = chrome.i18n.getMessage('statusPhaseSummary', [
                    String(filteredImageNeed), String(filteredSdNeed), String(filtered720pNeed), String(filteredHdNeed)
                ]);

                let showSummary = false;
                let summaryText = summary;
                if (state.completed) {
                    phaseText = modeLabel + ' — ' + chrome.i18n.getMessage('statusPhaseComplete');
                    // Show downloaded counts instead of need counts (which are 0 after completion)
                    summaryText = chrome.i18n.getMessage('statusPhaseSummary', [
                        String(ds.doneImages ?? 0), String(ds.doneSd ?? 0), String(ds.done720p ?? 0), String(ds.doneHd ?? 0)
                    ]);
                    showSummary = true;
                } else if (response.downloadProgress && response.downloadProgress.phase !== 'idle' && response.downloadProgress.phase !== 'starting') {
                    const dp = response.downloadProgress;
                    let progressText = '';
                    if (dp.phase === 'images') {
                        progressText = chrome.i18n.getMessage('statusDownloadingImages', [String(dp.current), String(dp.total)]);
                    } else if (dp.phase === 'videos') {
                        progressText = chrome.i18n.getMessage('statusDownloadingVideos', [String(dp.current), String(dp.total)]);
                    } else if (dp.phase === 'projects') {
                        progressText = chrome.i18n.getMessage('statusDownloadingProjects', [String(dp.current), String(dp.total)]);
                    } else if (dp.phase === 'cooldown') {
                        progressText = chrome.i18n.getMessage('statusCooldown', [dp.cooldownRemaining || '']);
                    }
                    phaseText = modeLabel + ' — ' + progressText;
                    showSummary = true;
                } else if (state.currentPhase) {
                    let progressText = '';
                    if (isProjectMode) {
                        const projectTotal = state.projectCount || 0;
                        const projectDownloaded = state.downloadedProjects?.length || 0;
                        progressText = chrome.i18n.getMessage('statusDownloadingProjects', [String(projectDownloaded), String(projectTotal)]);
                    } else if (state.currentPhase === 'images') {
                        const current = (state.currentIndex || 0) + 1;
                        progressText = chrome.i18n.getMessage('statusDownloadingImages', [String(current), String(filteredImageNeed)]);
                    } else if (state.currentPhase === 'videos') {
                        const current = (state.currentIndex || 0) + 1;
                        progressText = chrome.i18n.getMessage('statusDownloadingVideos', [String(current), String(filteredSdNeed + filteredHdNeed)]);
                    }
                    phaseText = modeLabel + ' — ' + progressText;
                    showSummary = true;
                } else if (totalItems > 0) {
                    phaseText = modeLabel + ' — ' + summary;
                }
                document.getElementById('currentPhase').textContent = phaseText;

                // Show/hide summary row below phase
                const summaryRow = document.getElementById('phaseSummaryRow');
                if (showSummary && summaryRow) {
                    summaryRow.style.display = '';
                    document.getElementById('phaseSummary').textContent = summaryText;
                } else if (summaryRow) {
                    summaryRow.style.display = 'none';
                }

                // 更新進度條 (based on need-download counts)
                const needTotal = isProjectMode
                    ? (state.projectCount || 0)
                    : (filteredImageNeed + filteredSdNeed + filtered720pNeed + filteredHdNeed);

                if (needTotal > 0 || state.completed) {
                    const progress = document.getElementById('progress');
                    const progressFill = document.getElementById('progressFill');
                    const progressText = document.getElementById('progressText');

                    progress.style.display = 'block';

                    let totalDownloaded, percentage;
                    if (state.completed) {
                        percentage = 100;
                    } else if (isProjectMode) {
                        totalDownloaded = state.downloadedProjects?.length || 0;
                        percentage = Math.round((totalDownloaded / needTotal) * 100);
                    } else {
                        totalDownloaded = (state.downloadedImages?.length || 0) + (state.downloadedVideos?.length || 0);
                        percentage = Math.round((totalDownloaded / needTotal) * 100);
                    }

                    progressFill.style.width = percentage + '%';
                    progressText.textContent = percentage + '%';
                } else {
                    document.getElementById('progress').style.display = 'none';
                }

                if (state.completed) {
                    generateBtn.disabled = false;
                    generateBtn.textContent = chrome.i18n.getMessage('btnGenerate');
                    startBtn.disabled = false;
                    startBtn.textContent = chrome.i18n.getMessage('btnStartDone');
                    startBtn.classList.remove('btn-success');
                    startBtn.classList.add('btn-secondary');
                    isDownloadInProgress = false;
                    const resumeInfoDone = document.getElementById('resumeInfo');
                    if (resumeInfoDone) resumeInfoDone.style.display = 'none';

                    let totalDownloaded;
                    if (isProjectMode) {
                        totalDownloaded = state.downloadedProjects?.length || 0;
                    } else {
                        totalDownloaded = (state.downloadedImages?.length || 0) + (state.downloadedVideos?.length || 0);
                    }
                    if (!completionMessageShown) {
                        completionMessageShown = true;
                        const failCount = state.failed?.length || 0;
                        let completeMsg;
                        if (isProjectMode) {
                            const projOk = state.downloadedProjects?.length || 0;
                            const projTotal = state.projectCount || 0;
                            completeMsg = chrome.i18n.getMessage('msgDownloadCompleteProjectSummary', [
                                String(projOk), String(projTotal), String(failCount)
                            ]);
                        } else {
                            const imgOk = state.downloadedImages?.length || 0;
                            const imgTotal = state.images?.length || 0;
                            const vidOk = state.downloadedVideos?.length || 0;
                            const vidTotal = state.videos?.length || 0;
                            completeMsg = chrome.i18n.getMessage('msgDownloadCompleteSummary', [
                                String(imgOk), String(imgTotal),
                                String(vidOk), String(vidTotal),
                                String(failCount)
                            ]);
                        }
                        if (failCount > 0) {
                            completeMsg += chrome.i18n.getMessage('msgDownloadCompleteFailHint');
                        }
                        gmdNotify(completeMsg);
                    }
                } else {
                    completionMessageShown = false;
                    // 用 content.js 的 downloadProgress 作為下載中的判斷依據
                    // cancelPending: user already requested cancel, don't re-enter downloading state
                    const downloading = !cancelPending && (isDownloadInProgress || (response.downloadProgress && response.downloadProgress.phase !== 'idle'));
                    if (downloading) {
                        isDownloadInProgress = true;
                        startBtn.classList.remove('btn-success');
                        startBtn.classList.add('btn-secondary');
                        startBtn.textContent = chrome.i18n.getMessage('btnStopDownload');
                        startBtn.disabled = false;
                        generateBtn.disabled = true;
                        const resumeInfoDl = document.getElementById('resumeInfo');
                        if (resumeInfoDl) resumeInfoDl.style.display = 'none';
                    } else {
                        startBtn.classList.remove('btn-secondary');
                        startBtn.classList.add('btn-success');
                        generateBtn.disabled = false;
                        // Show rate limit cooldown message if applicable (once)
                        if (state.rateLimitPaused && !state.completed && !rateLimitMessageShown) {
                            rateLimitMessageShown = true;
                            showMessage(chrome.i18n.getMessage('rateLimitCooldownWaiting'), 'info');
                        } else if (!state.rateLimitPaused) {
                            rateLimitMessageShown = false;
                        }

                        // Show resume progress indicator and change button text if partial download exists
                        const resumeInfo = document.getElementById('resumeInfo');
                        let hasPartialDownload = false;
                        if (needTotal > 0) {
                            let downloaded;
                            if (isProjectMode) {
                                downloaded = state.downloadedProjects?.length || 0;
                            } else {
                                downloaded = (state.downloadedImages?.length || 0) + (state.downloadedVideos?.length || 0);
                            }
                            // Partial download: cancel pending, aborted with remaining items, or downloaded some but not all
                            if (cancelPending || state.aborted || (downloaded > 0 && downloaded < needTotal)) {
                                hasPartialDownload = true;
                                const displayTotal = downloaded + needTotal;
                                if (resumeInfo) {
                                    resumeInfo.textContent = chrome.i18n.getMessage('resumeProgress', [downloaded, displayTotal]);
                                    resumeInfo.style.display = '';
                                }
                            }
                        }
                        if (!hasPartialDownload && resumeInfo) {
                            resumeInfo.style.display = 'none';
                        }

                        // Button text: "Continue Download" if partial, otherwise "Start Download"
                        startBtn.textContent = hasPartialDownload
                            ? chrome.i18n.getMessage('btnContinueDownload')
                            : chrome.i18n.getMessage('btnStart');
                    }

                    // 檢查過濾條件是否改變
                    let filterChanged = false;
                    if (state.filterOptions) {
                        // Task D6: source is now independent of the date-filter radio
                        // group — a source switch (or, for tag, picking a different tag)
                        // must also invalidate a stale generated list, even when the
                        // date-filter fields themselves are unchanged.
                        const currentSourceKey = getCurrentSourceKey();
                        const savedSourceKey = sourceKeyFromFilterOptions(state.filterOptions);
                        if (currentSourceKey !== savedSourceKey) {
                            filterChanged = true;
                        } else if (currentSourceKey === 'tag') {
                            const tagSel = document.getElementById('tagSelector');
                            if ((tagSel?.value || '') !== (state.filterOptions.tagId || '')) {
                                filterChanged = true;
                            }
                        } else {
                            const currentFilterMode = document.querySelector('input[name="downloadDateFilter"]:checked').value;
                            const currentFromDate = fromDate.value;
                            const currentToDate = toDate.value;

                            // 檢查過濾模式是否改變
                            const savedHasDateRange = !!(state.filterOptions.fromDate || state.filterOptions.toDate);
                            const savedHasHoursLimit = !!state.filterOptions.hoursLimit;

                            if (currentFilterMode === 'all') {
                                // 當前是全部，但列表有過濾
                                if (savedHasDateRange || savedHasHoursLimit) {
                                    filterChanged = true;
                                }
                            } else if (currentFilterMode === 'dateRange') {
                                if (currentFromDate || currentToDate) {
                                    const currentFromTimestamp = currentFromDate ? new Date(currentFromDate).setUTCHours(0, 0, 0, 0) : null;
                                    const currentToTimestamp = currentToDate ? new Date(currentToDate).setUTCHours(23, 59, 59, 999) : null;
                                    if (currentFromTimestamp !== state.filterOptions.fromDate ||
                                        currentToTimestamp !== state.filterOptions.toDate) {
                                        filterChanged = true;
                                    }
                                } else if (!savedHasDateRange) {
                                    filterChanged = true;
                                }
                            } else if (currentFilterMode === 'lastHours') {
                                const currentHours = parseInt(document.getElementById('downloadHours').value) || 24;
                                if (currentHours !== state.filterOptions.hoursLimit) {
                                    filterChanged = true;
                                }
                            }
                        }
                    }

                    // Option A: prompt recovery is gated by settings at generate
                    // time and the list records the scope it ran with
                    // (`promptScope`: 'all' | 'folders' | 'none'). If the CURRENT
                    // settings need prompts but the list was generated with a
                    // narrower scope, the filenames/metadata would silently lack
                    // them — ask for a regenerate. Lists generated before
                    // promptScope existed (undefined) are left alone.
                    let promptSettingsChanged = false;
                    if (!filterChanged && state.filterOptions
                        && state.filterOptions.promptScope
                        && state.filterOptions.promptScope !== 'all') {
                        const currentSettings = {
                            filenameMode: document.querySelector('input[name="filenameMode"]:checked')?.value || 'native',
                            saveMetadata: !!document.getElementById('saveMetadata')?.checked,
                            filenameTemplateImage: document.getElementById('filenameTemplateImage')?.value || '',
                            filenameTemplateVideo: document.getElementById('filenameTemplateVideo')?.value || ''
                        };
                        promptSettingsChanged = GrokUtils.promptsNeededFor(currentSettings);
                    }

                    // 啟用/禁用按鈕
                    if (state.hasImages || state.hasVideos) {
                        if (filterChanged || promptSettingsChanged) {
                            startBtn.disabled = true;
                            // 使用固定警告區塊，而不是暫時性訊息
                            filterWarning.textContent = chrome.i18n.getMessage(
                                filterChanged ? 'msgFilterChanged' : 'msgPromptSettingsNeedRegenerate'
                            );
                            filterWarning.style.display = 'block';
                        } else {
                            startBtn.disabled = false;
                            filterWarning.style.display = 'none';
                        }
                    } else {
                        startBtn.disabled = true;
                        filterWarning.style.display = 'none';
                    }
                }
            } else {
                // 沒有狀態
                document.getElementById('imageTotal').textContent = '-';
                document.getElementById('imageDownloaded').textContent = '-';
                document.getElementById('sdVideoTotal').textContent = '-';
                document.getElementById('sdVideoDownloaded').textContent = '-';
                document.getElementById('v720pTotal').textContent = '-';
                document.getElementById('v720pDownloaded').textContent = '-';
                document.getElementById('hdVideoTotal').textContent = '-';
                document.getElementById('hdVideoDownloaded').textContent = '-';
                document.getElementById('currentPhase').textContent = '-';
                document.getElementById('progress').style.display = 'none';
                startBtn.disabled = true;
            }
        } catch (error) {
            console.error('更新狀態失敗:', error);
        }
    }

    // 顯示消息
    function showMessage(text, type = 'info') {
        window.scrollTo({ top: 0, behavior: 'smooth' });

        if (!message) {
            console.error('❌ message 元素不存在！');
            return;
        }

        // 清除之前的計時器
        if (messageTimeout) {
            clearTimeout(messageTimeout);
            messageTimeout = null;
        }

        message.textContent = text;
        message.className = `message ${type} show`;

        messageTimeout = setTimeout(() => {
            message.classList.remove('show');
            messageTimeout = null;
        }, 3000);
    }

    // 顯示帶連結的消息
    function showMessageWithLink(text, url, linkText, type = 'info') {
        window.scrollTo({ top: 0, behavior: 'smooth' });

        if (!message) {
            console.error('❌ message 元素不存在！');
            return;
        }

        // 清除之前的計時器
        if (messageTimeout) {
            clearTimeout(messageTimeout);
            messageTimeout = null;
        }

        // 使用 innerHTML 來支援連結
        message.innerHTML = `${text} <a href="${url}" target="_blank" style="color: inherit; font-weight: bold;">${linkText}</a>`;
        message.className = `message ${type} show`;

        // 帶連結的訊息不自動消失，讓使用者有時間點擊
    }

    // 檢查是否為連接錯誤
    function isConnectionError(error) {
        return error && error.message && (
            error.message.includes('Receiving end does not exist') ||
            error.message.includes('Could not establish connection')
        );
    }

    // Inject the content scripts ONLY if they aren't already present. Re-injecting
    // on an already-loaded tab throws "X already declared" for every top-level
    // const in the non-guarded files (only content.js self-guards) — harmless but
    // it spams the page console. Probe content.js's load flag first and skip the
    // whole injection when it's set.
    async function ensureContentScriptInjected(tabId) {
        let alreadyLoaded = false;
        try {
            const [probe] = await chrome.scripting.executeScript({
                target: { tabId },
                func: () => window.__grokVideoDownloaderLoaded === true
            });
            alreadyLoaded = !!(probe && probe.result === true);
        } catch (e) {
            // Couldn't probe (e.g. a restricted page) — fall through and try to inject.
        }
        // Only inject the files when NOT already present. Re-injecting the
        // non-guarded files (logger/utils/grok-assets/…) throws "X already
        // declared" in the page console.
        if (!alreadyLoaded) {
            await chrome.scripting.executeScript({
                target: { tabId },
                files: ['src/logger.js', 'src/utils.js', 'src/content-utils.js', 'src/recent-posts.js', 'src/video-mode-utils.js', 'src/grok-assets.js', 'content.js']
            });
        }
        // Keep the settle delay unconditionally: on a fresh inject the scripts
        // need to initialise; on an existing one it's a harmless small wait that
        // also keeps callers' timing stable.
        await new Promise(resolve => setTimeout(resolve, 500));
    }

    // 向 content script 發送訊息，如果連接失敗會自動嘗試注入並重試
    async function sendMessageToContentScript(tabId, message, options = {}) {
        const { silent = false, retried = false } = options;

        try {
            return await chrome.tabs.sendMessage(tabId, message);
        } catch (error) {
            if (isConnectionError(error) && !retried) {
                // 嘗試注入 content script
                try {
                    await ensureContentScriptInjected(tabId);
                    // 重試發送訊息
                    return await sendMessageToContentScript(tabId, message, { ...options, retried: true });
                } catch (injectError) {
                    console.error('Failed to inject content script:', injectError);
                }
            }

            // 如果不是靜默模式，顯示錯誤訊息
            if (!silent && isConnectionError(error)) {
                showMessage(chrome.i18n.getMessage('msgRefreshRetry'), 'error');
            }

            throw error;
        }
    }

    // 生成媒體列表
    generateBtn.addEventListener('click', async () => {
        // 讀取複選框狀態
        const includeImages = document.getElementById('includeImages').checked;
        const includeVideos = document.getElementById('includeVideos').checked;

        if (!includeImages && !includeVideos) {
            showMessage(chrome.i18n.getMessage('msgSelectMediaType'), 'error');
            return;
        }

        // 讀取下載來源（Task D6 — 與日期篩選 radio group 完全獨立）
        const source = document.querySelector('input[name="downloadSource"]:checked')?.value || 'favorite';

        // 讀取日期過濾（適用於 favorite 與 allmedia；tag 沒有日期篩選）
        const downloadDateFilter = document.querySelector('input[name="downloadDateFilter"]:checked').value;
        const fromDateValue = fromDate.value;
        const toDateValue = toDate.value;

        // 日期範圍篩選：至少需要填一個日期（僅 favorite / allmedia 適用）
        if (source !== 'tag' && downloadDateFilter === 'dateRange' && !fromDateValue && !toDateValue) {
            showMessage(chrome.i18n.getMessage('msgSelectDate'), 'error');
            return;
        }

        // Tag 來源：必須先選擇一個標籤
        if (source === 'tag') {
            const tagSel = document.getElementById('tagSelector');
            if (!tagSel || !tagSel.value) {
                showMessage(chrome.i18n.getMessage('msgSelectTag') || 'Please select a tag first', 'error');
                return;
            }
        }

        generateBtn.disabled = true;
        generateBtn.textContent = chrome.i18n.getMessage('btnGenerateLoading');
        startBtn.disabled = true;  // 生成列表時禁用下載按鈕，避免誤按

        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

            if (!tab.url.includes('grok.com/imagine/saved')) {
                showMessageWithLink(
                    chrome.i18n.getMessage('msgWrongPageFav'),
                    'https://grok.com/imagine/saved',
                    chrome.i18n.getMessage('msgWrongPageLink'),
                    'error'
                );
                generateBtn.disabled = false;
                generateBtn.textContent = chrome.i18n.getMessage('btnGenerate');
                // startBtn 保持禁用，因為沒有生成列表
                return;
            }

            // 先嘗試注入 content script（如果還沒注入）
            try {
                await ensureContentScriptInjected(tab.id);
            } catch (e) {
                console.log('Content script 可能已經存在:', e.message);
            }

            // 準備選項
            const hdPriority = document.getElementById('hdPriority').checked;
            const saveMetadata = document.getElementById('saveMetadata').checked;
            const filenameMode = document.querySelector('input[name="filenameMode"]:checked')?.value || 'native';
            const options = {
                includeImages,
                includeVideos,
                hdPriority,
                saveMetadata,
                filenameMode,
                promptAsFilename: filenameMode === 'prompt',
                filenameTemplateImage: document.getElementById('filenameTemplateImage')?.value?.trim() || '',
                filenameTemplateVideo: document.getElementById('filenameTemplateVideo')?.value?.trim() || ''
            };

            // 依來源附加對應選項 — Task D6: source 與日期篩選完全獨立
            if (source === 'favorite') {
                // Download mode (standard/project) 僅適用於 favorite 來源
                options.downloadMode = document.getElementById('downloadModeProject')?.checked ? 'project' : 'standard';
            } else if (source === 'tag') {
                const tagSel = document.getElementById('tagSelector');
                const tagOpt = tagSel?.options[tagSel.selectedIndex];
                options.tagId = tagSel?.value || '';
                options.tagName = tagOpt?.dataset?.name || tagOpt?.textContent || '';
            } else if (source === 'allmedia') {
                // "所有生成媒體" — full /rest/assets library pull (by-conversation).
                // Uses its own conversation download-history namespace (Task D1).
                options.source = 'allmedia';
            }

            // 日期過濾（favorite 與 allmedia 共用；tag 不適用）。這是 D6 的關鍵新能力：
            // allmedia 現在也能套用日期範圍 / 最近 N 小時篩選（Task D2 後端已支援）。
            if (source !== 'tag') {
                if (downloadDateFilter === 'dateRange') {
                    if (fromDateValue) {
                        const fromDateObj = new Date(fromDateValue);
                        fromDateObj.setUTCHours(0, 0, 0, 0); // 設為當天開始
                        options.fromDate = fromDateObj.getTime();
                    }
                    if (toDateValue) {
                        const toDateObj = new Date(toDateValue);
                        toDateObj.setUTCHours(23, 59, 59, 999); // 設為當天結束
                        options.toDate = toDateObj.getTime();
                    }
                } else if (downloadDateFilter === 'lastHours') {
                    options.hoursLimit = parseInt(document.getElementById('downloadHours').value) || 24;
                }
            }

            // Free tier on the whole-library source: cap to a recent window.
            // The source itself is deliberately NOT paywalled (the legacy
            // Favorite path can no longer see new media, so everyone needs a
            // working source), but the FULL library stays a Pro capability.
            // Overrides any date filter — those controls are Pro-locked anyway,
            // so a free user can only reach this via a stale saved setting.
            if (!isProUser && source === 'allmedia') {
                options.hoursLimit = FREE_ALLMEDIA_HOURS;
                delete options.fromDate;
                delete options.toDate;
            }

            // 先清除舊的 generateResult
            await chrome.storage.local.remove('generateResult');

            const response = await sendMessageToContentScript(tab.id, {
                action: 'generateMedia',
                options: options
            });

            if (response && response.success && response.status === 'generating') {
                // 顯示生成中狀態，等待 storage 通知
                showMessage(chrome.i18n.getMessage('msgGenerating') || 'Generating list...', 'info');

                // Inactivity watchdog (armed below, re-armed on every progress
                // message). A FIXED timeout fired mid-run on large libraries —
                // scan + prompt recovery + quality resolution legitimately
                // exceed 10 min — showing "Timeout" and re-enabling Generate
                // while content.js kept running. Progress-aware, it only fires
                // after GENERATE_WATCHDOG_MS of real silence, and then tells
                // the content script to abort the orphaned run.
                const GENERATE_WATCHDOG_MS = 600000;
                let watchdogId = null;
                // Expose timeout IDs for test cleanup (prevents worker leak in Jest)
                window.__generateTimeouts = window.__generateTimeouts || [];
                const armWatchdog = () => {
                    if (watchdogId !== null) clearTimeout(watchdogId);
                    watchdogId = setTimeout(onWatchdog, GENERATE_WATCHDOG_MS);
                    window.__generateTimeouts.push(watchdogId);
                };

                // Listen for real-time scan progress from content script
                const progressListener = (msg) => {
                    if (msg.action !== 'generateListProgress') return;
                    armWatchdog();
                    if (msg.phase === 'resolving') {
                        generateBtn.textContent = chrome.i18n.getMessage('msgResolvingVideoQuality', [String(msg.current), String(msg.total)]);
                    } else if (msg.phase === 'titles') {
                        generateBtn.textContent = chrome.i18n.getMessage('statusPreparingFolders', [String(msg.current), String(msg.total)]);
                    } else if (msg.phase === 'prompts') {
                        generateBtn.textContent = chrome.i18n.getMessage('statusFetchingPrompts', [String(msg.current), String(msg.total)]);
                    } else if (msg.count) {
                        generateBtn.textContent = chrome.i18n.getMessage('msgGenerateListProgress', [String(msg.count)]);
                    }
                };
                chrome.runtime.onMessage.addListener(progressListener);

                // 監聽 storage 變化
                const storageListener = async (changes, areaName) => {
                    if (areaName !== 'local' || !changes.generateResult) return;

                    const result = changes.generateResult.newValue;
                    if (!result) return;

                    // 移除監聽器
                    chrome.storage.onChanged.removeListener(storageListener);
                    chrome.runtime.onMessage.removeListener(progressListener);
                    if (watchdogId !== null) { clearTimeout(watchdogId); watchdogId = null; }

                    // 處理結果
                    if (result.success) {
                        const parts = [];
                        if (includeImages && result.imageCount > 0) {
                            parts.push(`${result.imageCount} ${chrome.i18n.getMessage('mediaTypeImages').replace('🖼️ ', '')}`);
                        }
                        if (includeVideos && result.videoCount > 0) {
                            parts.push(`${result.videoCount} ${chrome.i18n.getMessage('mediaTypeVideos').replace('🎬 ', '')}`);
                        }
                        if (parts.length > 0) {
                            const baseMsg = chrome.i18n.getMessage('msgFoundMedia', [parts.join(' & ')]);
                            if (result.partial) {
                                const note = chrome.i18n.getMessage('msgGenerateListPartial')
                                    || 'Scan interrupted — partial list saved';
                                showMessage(`${baseMsg} (${note})`, 'info');
                            } else {
                                showMessage(baseMsg, 'info');
                            }
                            startBtn.disabled = false;
                        } else if (result.partial) {
                            const note = chrome.i18n.getMessage('msgGenerateListPartial')
                                || 'Scan interrupted — partial list saved';
                            showMessage(note, 'error');
                        } else {
                            // The legacy favorite/tag sources no longer receive
                            // media generated after grok's 2026-07 change, so an
                            // empty result there is usually the source, not the
                            // filter — point the user at the working one.
                            const noneMsg = chrome.i18n.getMessage('msgNoMediaFound') || 'No media found';
                            showMessage(
                                source !== 'allmedia'
                                    ? `${noneMsg} ${chrome.i18n.getMessage('msgTryAllMediaSource')}`
                                    : noneMsg,
                                'info'
                            );
                        }
                        await updateStatus();

                        // Auto-collapse filter section to free up space
                        const dateFilterSection = document.getElementById('dateFilterSection');
                        if (dateFilterSection) dateFilterSection.removeAttribute('open');

                        // Scan and show confirm dialog after generate
                        if (parts.length > 0) {
                            await scanAndConfirmDownload(tab);
                        }
                    } else {
                        showMessage(chrome.i18n.getMessage('msgGenerateFailed') + (result.error ? ': ' + result.error : ''), 'error');
                    }

                    // Only re-enable generate button if download didn't start
                    if (!isDownloadInProgress) {
                        generateBtn.disabled = false;
                        generateBtn.textContent = chrome.i18n.getMessage('btnGenerate');
                    }
                };

                chrome.storage.onChanged.addListener(storageListener);

                // 超時保護：10 分鐘沒有任何進度才觸發（見上方 armWatchdog）
                async function onWatchdog() {
                    watchdogId = null;
                    chrome.storage.onChanged.removeListener(storageListener);
                    chrome.runtime.onMessage.removeListener(progressListener);
                    // 檢查是否已經完成
                    let data = {};
                    try { data = await chrome.storage.local.get('generateResult'); } catch (e) { data = {}; }
                    if (data && data.generateResult) return;
                    showMessage(chrome.i18n.getMessage('msgGenerateFailed') + ': Timeout', 'error');
                    generateBtn.disabled = false;
                    generateBtn.textContent = chrome.i18n.getMessage('btnGenerate');
                    // Stop the orphaned run so a fresh Generate is not rejected
                    // as generate_in_progress and does not race the old one.
                    try {
                        await sendMessageToContentScript(tab.id, { action: 'cancelDownload' }, { silent: true });
                    } catch (e) { /* content script gone — nothing to stop */ }
                }
                armWatchdog();

            } else if (response && response.success) {
                // 舊版回應格式（向下相容）
                const parts = [];
                if (includeImages && response.imageCount > 0) {
                    parts.push(`${response.imageCount} ${chrome.i18n.getMessage('mediaTypeImages').replace('🖼️ ', '')}`);
                }
                if (includeVideos && response.videoCount > 0) {
                    parts.push(`${response.videoCount} ${chrome.i18n.getMessage('mediaTypeVideos').replace('🎬 ', '')}`);
                }
                showMessage(chrome.i18n.getMessage('msgFoundMedia', [parts.join(' & ')]), 'info');
                startBtn.disabled = false;
                await updateStatus();
                generateBtn.disabled = false;
                generateBtn.textContent = chrome.i18n.getMessage('btnGenerate');
            } else {
                // e.g. { success:false, error:'generate_in_progress' } — a run is still going
                const detail = response && response.error ? ': ' + response.error : '';
                showMessage(chrome.i18n.getMessage('msgGenerateFailed') + detail, 'error');
                generateBtn.disabled = false;
                generateBtn.textContent = chrome.i18n.getMessage('btnGenerate');
            }
        } catch (error) {
            console.error('生成失敗:', error);
            if (error.message.includes('Receiving end does not exist')) {
                showMessage(chrome.i18n.getMessage('msgRefreshRetry'), 'error');
            } else {
                showMessage(chrome.i18n.getMessage('msgGenerateFailed') + ': ' + error.message, 'error');
            }
            generateBtn.disabled = false;
            generateBtn.textContent = chrome.i18n.getMessage('btnGenerate');
        }
    });

    // 下載狀態追蹤
    let isDownloadInProgress = false;
    let cancelPending = false; // true between sending cancelDownload and receiving aborted confirmation

    // 檢查下載狀態並更新按鈕
    async function checkAndUpdateDownloadStatus() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab.url.includes('grok.com')) return;

            const status = await sendMessageToContentScript(tab.id, {
                action: 'getDownloadStatus'
            });

            if (status && status.inProgress && !cancelPending) {
                isDownloadInProgress = true;
                const phaseText = status.phase === 'images' ? '🖼️' :
                                  status.phase === 'videos' ? '🎬' :
                                  status.phase === 'projects' ? '📂' : '';
                startBtn.textContent = chrome.i18n.getMessage('btnStopDownload');
                startBtn.disabled = false; // 允許點擊以中斷
                startBtn.classList.remove('btn-success');
                startBtn.classList.add('btn-secondary');
                generateBtn.disabled = true;
            } else {
                isDownloadInProgress = false;
            }
        } catch (e) {
            console.log('檢查下載狀態失敗:', e.message);
        }
    }

    // popup 開啟時檢查狀態
    checkAndUpdateDownloadStatus();

    // 掃描並確認下載（Generate List 完成後 / 手動按 Start 時共用）
    async function scanAndConfirmDownload(tab) {
        startBtn.disabled = true;
        startBtn.textContent = chrome.i18n.getMessage('msgDownloadScanning');

        let scanResult;
        try {
            scanResult = await sendMessageToContentScript(tab.id, { action: 'scanForDownload' });
        } catch (e) {
            startBtn.disabled = false;
            startBtn.textContent = chrome.i18n.getMessage('btnStart');
            return;
        }

        if (!scanResult || !scanResult.success) {
            startBtn.disabled = false;
            startBtn.textContent = chrome.i18n.getMessage('btnStart');
            return;
        }

        const vs = scanResult.videos;
        const totalNeed = scanResult.mode === 'project'
            ? scanResult.projects.need
            : scanResult.images.need + (vs.hdPriority ? vs.need : vs.needSd + vs.need720p + vs.needHd);

        if (totalNeed === 0) {
            const imageCount = scanResult.images.total;
            const videoCount = vs.hdPriority ? vs.total : vs.totalSd;
            const msg = chrome.i18n.getMessage('msgAllDownloaded', [imageCount.toString(), videoCount.toString()]);
            gmdNotify(msg);
            startBtn.disabled = false;
            startBtn.textContent = chrome.i18n.getMessage('btnStart');
            return;
        }

        // Build confirm message with stats
        let confirmMsg;
        if (scanResult.mode === 'project') {
            confirmMsg = chrome.i18n.getMessage('msgDownloadConfirmProject', [
                String(scanResult.projects.need), String(scanResult.projects.done)
            ]);
        } else if (vs.hdPriority) {
            // HD priority: show as single video row with HD/720p/SD breakdown
            confirmMsg = chrome.i18n.getMessage('msgDownloadConfirmHdPriority', [
                String(scanResult.images.need), String(scanResult.images.done),
                String(vs.need), String(vs.done),
                String(vs.needHd), String(vs.need720p), String(vs.needSd),
                String(vs.count1080p ?? 0)
            ]);
        } else {
            confirmMsg = chrome.i18n.getMessage('msgDownloadConfirmStandard', [
                String(scanResult.images.need), String(scanResult.images.done),
                String(vs.needSd), String(vs.doneSd),
                String(vs.need720p), String(vs.done720p),
                String(vs.needHd), String(vs.doneHd),
                String(vs.count1080p ?? 0)
            ]);
        }

        // Append rate limit warning if video count exceeds limit
        const videoNeedCount = scanResult.mode === 'project'
            ? 0 // projects track differently
            : (vs.hdPriority ? vs.need : vs.needSd + vs.need720p + vs.needHd);
        if (videoNeedCount > 250) {
            const cooldownSettings = await chrome.storage.sync.get(['rateLimitCooldown']);
            const cooldownMin = cooldownSettings.rateLimitCooldown || 3;
            confirmMsg += '\n\n' + chrome.i18n.getMessage('rateLimitWarning', ['250', String(cooldownMin)]);
        }

        // Update popup status before showing confirm dialog (confirm blocks JS thread)
        await updateStatus();

        if (!confirm(confirmMsg)) {
            startBtn.disabled = false;
            startBtn.textContent = chrome.i18n.getMessage('btnStart');
            return;
        }

        // Confirmed — start download
        startBtn.textContent = chrome.i18n.getMessage('btnStartLoading');

        try {
            const response = await sendMessageToContentScript(tab.id, { action: 'startDownload' });

            if (response && response.success) {
                showMessage(chrome.i18n.getMessage('msgStartDownload'), 'info');
                isDownloadInProgress = true;
                cancelPending = false;
                // Disable generate, enable start as abort button
                generateBtn.disabled = true;
                startBtn.disabled = false;
                startBtn.textContent = chrome.i18n.getMessage('btnStopDownload');
                startBtn.classList.remove('btn-success');
                startBtn.classList.add('btn-secondary');
            } else if (response && response.reason === 'all_downloaded') {
                const msg = chrome.i18n.getMessage('msgAllDownloaded', [
                    (response.imageCount || 0).toString(), (response.videoCount || 0).toString()
                ]);
                gmdNotify(msg);
                startBtn.disabled = false;
                startBtn.textContent = chrome.i18n.getMessage('btnStart');
            } else {
                showMessage(chrome.i18n.getMessage('msgStartFailed'), 'error');
                startBtn.disabled = false;
                startBtn.textContent = chrome.i18n.getMessage('btnStart');
            }
        } catch (error) {
            console.error('開始失敗:', error);
            showMessage(chrome.i18n.getMessage('msgStartFailed') + ': ' + error.message, 'error');
            startBtn.disabled = false;
            startBtn.textContent = chrome.i18n.getMessage('btnStart');
        }
    }

    // 開始下載
    startBtn.addEventListener('click', async () => {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

            // 檢查是否正在下載中
            const status = await sendMessageToContentScript(tab.id, {
                action: 'getDownloadStatus'
            });

            if (status && status.inProgress) {
                // 正在下載中，詢問是否要中斷
                const phaseText = status.phase === 'images' ? chrome.i18n.getMessage('mediaTypeImages') :
                                  status.phase === 'videos' ? chrome.i18n.getMessage('mediaTypeVideos') :
                                  status.phase === 'projects' ? chrome.i18n.getMessage('optionDownloadModeProject') : status.phase;
                const cancelMsg = chrome.i18n.getMessage('msgDownloadCancelConfirm', [phaseText, status.current, status.total]);
                if (confirm(cancelMsg)) {
                    cancelPending = true;
                    await sendMessageToContentScript(tab.id, {
                        action: 'cancelDownload'
                    });
                    gmdNotify(chrome.i18n.getMessage('msgDownloadCancelled'));
                    startBtn.textContent = chrome.i18n.getMessage('btnContinueDownload');
                    startBtn.classList.remove('btn-secondary');
                    startBtn.classList.add('btn-success');
                    isDownloadInProgress = false;
                    generateBtn.disabled = false;
                    generateBtn.textContent = chrome.i18n.getMessage('btnGenerate');
                }
                return;
            }

            await scanAndConfirmDownload(tab);
        } catch (error) {
            console.error('開始失敗:', error);
            showMessage(chrome.i18n.getMessage('msgStartFailed') + ': ' + error.message, 'error');
            startBtn.disabled = false;
            startBtn.textContent = chrome.i18n.getMessage('btnStart');
        }
    });

    // 監聽下載進度
    const cooldownInfoEl = document.getElementById('cooldownInfo');
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'downloadProgress') {
            if (request.status === 'aborted') {
                startBtn.textContent = chrome.i18n.getMessage('btnContinueDownload');
                startBtn.classList.remove('btn-secondary');
                startBtn.classList.add('btn-success');
                startBtn.disabled = false;
                isDownloadInProgress = false;
                cancelPending = false;
                generateBtn.disabled = false;
                generateBtn.textContent = chrome.i18n.getMessage('btnGenerate');
                if (cooldownInfoEl) cooldownInfoEl.style.display = 'none';
            } else if (request.status === 'rateLimitCooldown') {
                // Rate limit cooldown: keep stop button active and update countdown
                // in place via cooldownInfo element. Do NOT call showMessage here —
                // it scrolls the popup to top, which fought user scrolling every
                // second during the 3-minute cooldown.
                isDownloadInProgress = true;
                startBtn.classList.remove('btn-success');
                startBtn.classList.add('btn-secondary');
                startBtn.textContent = chrome.i18n.getMessage('btnStopDownload');
                startBtn.disabled = false;
                generateBtn.disabled = true;
                if (cooldownInfoEl) {
                    cooldownInfoEl.textContent = chrome.i18n.getMessage('rateLimitCooldown', [
                        String(request.success || 0),
                        request.cooldownRemaining || ''
                    ]);
                    cooldownInfoEl.style.display = '';
                }
            } else {
                // Any other progress status — cooldown is over, hide the banner
                if (cooldownInfoEl) cooldownInfoEl.style.display = 'none';
            }
        }
    });

    // 清除狀態
    clearBtn.addEventListener('click', async () => {
        const confirmed = confirm(chrome.i18n.getMessage('msgConfirmClearState'));

        if (!confirmed) {
            return;
        }

        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

            const response = await sendMessageToContentScript(tab.id, { action: 'clearState' });

            if (response && response.success) {
                showMessage(chrome.i18n.getMessage('msgStateCleared'), 'info');
                await updateStatus();
            }
        } catch (error) {
            console.error('清除失敗:', error);
            showMessage(chrome.i18n.getMessage('msgClearFailed') + ': ' + error.message, 'error');
        }
    });

    // 清除下載歷史
    clearHistoryBtn.addEventListener('click', async () => {
        const confirmed = confirm(chrome.i18n.getMessage('msgConfirmClearHistory'));

        if (!confirmed) {
            return;
        }

        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

            const response = await sendMessageToContentScript(tab.id, { action: 'clearHistory' });

            if (response && response.success) {
                // Resetting the extension's download history also erases any leftover
                // entries in Chrome's own download manager — a "clean slate" reset
                // prevents prior metadata from aggravating shared_proto_db bloat
                // when the user re-runs downloads.
                try {
                    await chrome.runtime.sendMessage({ action: 'clearGrokDownloadHistory' });
                } catch (eraseErr) {
                    console.warn('[clearHistory] Chrome history erase skipped:', eraseErr?.message);
                }
                showMessage(chrome.i18n.getMessage('msgHistoryCleared'), 'info');
                await updateStatus();
            }
        } catch (error) {
            console.error('清除歷史失敗:', error);
            showMessage(chrome.i18n.getMessage('msgClearHistoryFailed') + ': ' + error.message, 'error');
        }
    });

    // Skip-on-disk: import the media-id list packaged at data/ondisk-media-ids.json
    // (built from FILE NAMES of existing downloads). Ids go to grok_skip_ids,
    // not into download history; Start Download then skips them.
    const importSkipIdsBtn = document.getElementById('importSkipIdsBtn');
    const skipIdsStatus = document.getElementById('skipIdsStatus');
    async function refreshSkipIdsStatus(tabId) {
        try {
            const r = await sendMessageToContentScript(tabId, { action: 'getSkipIdsStatus' });
            if (r && r.success && skipIdsStatus) skipIdsStatus.textContent = chrome.i18n.getMessage('msgSkipIdsStatus', [String(r.count)]) || `Skip list: ${r.count} ids`;
        } catch (e) { /* not on a Grok tab */ }
    }
    if (importSkipIdsBtn) {
        chrome.tabs.query({ active: true, currentWindow: true }).then(([t]) => t && refreshSkipIdsStatus(t.id)).catch(() => {});
        importSkipIdsBtn.addEventListener('click', async () => {
            try {
                const res = await fetch(chrome.runtime.getURL(SKIP_IDS_PACKAGED_PATH));
                if (!res.ok) throw new Error(`${SKIP_IDS_PACKAGED_PATH} not found (${res.status})`);
                const ids = PopupSkipIds.extractIds(await res.json());
                if (!ids.length) throw new Error('no ids in file');
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                const r = await sendMessageToContentScript(tab.id, { action: 'importSkipIds', ids });
                if (!r || !r.success) throw new Error((r && r.error) || 'open a grok.com/imagine tab first');
                showMessage(chrome.i18n.getMessage('msgSkipIdsImported', [String(r.read), String(r.after)]) || `Imported ${r.read} ids (skip list now ${r.after})`, 'info');
                await refreshSkipIdsStatus(tab.id);
                await updateStatus();
            } catch (error) {
                showMessage((chrome.i18n.getMessage('msgSkipIdsImportFailed') || 'Import failed') + ': ' + error.message, 'error');
            }
        });
    }

    // Clear Tag History
    const clearTagHistoryBtn = document.getElementById('clearTagHistoryBtn');
    if (clearTagHistoryBtn) {
        clearTagHistoryBtn.addEventListener('click', async () => {
            const confirmed = confirm(chrome.i18n.getMessage('msgConfirmClearTagHistory') || 'Clear all tag download history? This cannot be undone.');
            if (!confirmed) return;
            try {
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                const response = await sendMessageToContentScript(tab.id, { action: 'clearTagHistory' });
                if (response && response.success) {
                    showMessage(chrome.i18n.getMessage('msgTagHistoryCleared') || 'Tag history cleared', 'info');
                }
            } catch (error) {
                showMessage('Failed: ' + error.message, 'error');
            }
        });
    }

    // Clear Conversation History (Task D5)
    const clearConversationHistoryBtn = document.getElementById('clearConversationHistoryBtn');
    if (clearConversationHistoryBtn) {
        clearConversationHistoryBtn.addEventListener('click', async () => {
            const confirmed = confirm(chrome.i18n.getMessage('msgConfirmClearConversationHistory') || 'Clear all conversation download history? This cannot be undone.');
            if (!confirmed) return;
            try {
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                const response = await sendMessageToContentScript(tab.id, { action: 'clearConversationHistory' });
                if (response && response.success) {
                    showMessage(chrome.i18n.getMessage('msgConversationHistoryCleared') || 'Conversation history cleared', 'info');
                }
            } catch (error) {
                showMessage('Failed: ' + error.message, 'error');
            }
        });
    }

    // Clear Chrome download history entries created by this extension
    const clearGrokHistoryBtn = document.getElementById('clearGrokHistoryBtn');
    const clearGrokHistoryStatus = document.getElementById('clearGrokHistoryStatus');
    if (clearGrokHistoryBtn) {
        clearGrokHistoryBtn.addEventListener('click', async () => {
            const confirmed = confirm(chrome.i18n.getMessage('msgConfirmClearGrokHistory') || 'Clear all Grok downloads from Chrome history? Files on disk are not affected.');
            if (!confirmed) return;
            try {
                const response = await chrome.runtime.sendMessage({ action: 'clearGrokDownloadHistory' });
                if (response && response.success) {
                    const msg = chrome.i18n.getMessage('msgGrokHistoryCleared', [String(response.erased)])
                        || `Cleared ${response.erased} entries`;
                    if (clearGrokHistoryStatus) {
                        clearGrokHistoryStatus.textContent = msg;
                        clearGrokHistoryStatus.style.display = 'block';
                        setTimeout(() => { clearGrokHistoryStatus.style.display = 'none'; }, 3000);
                    }
                    showMessage(msg, 'info');
                } else {
                    showMessage('Failed: ' + (response?.error || 'unknown'), 'error');
                }
            } catch (error) {
                showMessage('Failed: ' + error.message, 'error');
            }
        });
    }

    // 匯出數據 (download happens in content script via Blob URL to avoid 64MiB limit)
    exportBtn.addEventListener('click', async () => {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

            const response = await sendMessageToContentScript(tab.id, { action: 'exportData' });

            if (response && response.success) {
                showMessage(chrome.i18n.getMessage('msgExportSuccess', [response.historyCount]), 'info');
            } else {
                showMessage(chrome.i18n.getMessage('msgExportFailed'), 'error');
            }
        } catch (error) {
            console.error('匯出失敗:', error);
            showMessage(chrome.i18n.getMessage('msgExportFailed') + ': ' + error.message, 'error');
        }
    });

    // 匯入數據
    importBtn.addEventListener('click', () => {
        importFile.click();
    });

    importFile.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        try {
            const text = await file.text();
            const data = JSON.parse(text);

            // Stage the parsed data in storage instead of passing it through the
            // message — large exports exceed the 64MiB tabs.sendMessage limit.
            // The content script reads it back from storage and clears the key.
            await chrome.storage.local.set({ grok_import_staging: data });

            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

            const response = await sendMessageToContentScript(tab.id, {
                action: 'importData'
            });

            if (response && response.success) {
                const merged = response.merged;
                showMessage(
                    chrome.i18n.getMessage('msgImportSuccess', [merged.newItems, merged.historyBefore, merged.historyAfter]),
                    'info'
                );
                await updateStatus();
            } else {
                showMessage(chrome.i18n.getMessage('msgImportFailed') + ': ' + (response?.error || '未知錯誤'), 'error');
            }
        } catch (error) {
            console.error('匯入失敗:', error);
            showMessage(chrome.i18n.getMessage('msgImportFailed') + ': ' + error.message, 'error');
        } finally {
            // Clean up staging key in case the content script never consumed it
            // (e.g. message failed to deliver). No-op if already removed.
            await chrome.storage.local.remove('grok_import_staging').catch(() => {});
            // 清除文件選擇
            importFile.value = '';
        }
    });

    // 批量移除收藏
    const removeBtn = document.getElementById('removeBtn');
    const removeFromDate = document.getElementById('removeFromDate');
    const removeToDate = document.getElementById('removeToDate');

    // Handle remove date filter radio buttons
    document.querySelectorAll('input[name="removeDateFilter"]').forEach(radio => {
        radio.addEventListener('change', () => {
            const val = document.querySelector('input[name="removeDateFilter"]:checked').value;
            removeFromDate.disabled = val !== 'dateRange';
            removeToDate.disabled = val !== 'dateRange';
            document.getElementById('removeHours').disabled = val !== 'lastHours';
            if (val !== 'dateRange') {
                removeFromDate.value = '';
                removeToDate.value = '';
            }
        });
    });

    function formatRemoveDateRange(filter, fromDate, toDate, hoursLimit) {
        if (filter === 'all') return chrome.i18n.getMessage('msgDateAll');
        if (filter === 'lastHours') {
            const last = chrome.i18n.getMessage('filterLastHours') || 'Last';
            const unit = chrome.i18n.getMessage('hdUpgradeHoursUnit') || 'hours';
            return `${last} ${hoursLimit || 24} ${unit}`;
        }
        return chrome.i18n.getMessage('msgDateRange', [fromDate || '∞', toDate || '∞']);
    }

    removeBtn.addEventListener('click', async () => {
        const deletePost = document.getElementById('deletePostCheckbox').checked;
        const removeDateFilter = document.querySelector('input[name="removeDateFilter"]:checked').value;
        const fromDateValue = removeFromDate.value;
        const toDateValue = removeToDate.value;

        // 如果是日期範圍，至少需要填一個日期
        if (removeDateFilter === 'dateRange' && !fromDateValue && !toDateValue) {
            showMessage(chrome.i18n.getMessage('msgSelectDate'), 'error');
            return;
        }

        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

            if (!tab.url.includes('grok.com/imagine/saved')) {
                showMessageWithLink(
                    chrome.i18n.getMessage('msgWrongPageFav'),
                    'https://grok.com/imagine/saved',
                    chrome.i18n.getMessage('msgWrongPageLink'),
                    'error'
                );
                return;
            }

            // 先嘗試注入 content script（如果還沒注入）
            try {
                await ensureContentScriptInjected(tab.id);
            } catch (e) {
                console.log('Content script 可能已經存在:', e.message);
            }

            removeBtn.disabled = true;
            removeBtn.textContent = chrome.i18n.getMessage('btnRemoveFavGenerating');

            console.log('發送移除請求...');

            // 準備日期範圍參數
            const removeOptions = {
                removeAll: removeDateFilter === 'all'
            };

            if (removeDateFilter === 'dateRange') {
                if (fromDateValue) {
                    const fromDateObj = new Date(fromDateValue);
                    fromDateObj.setUTCHours(0, 0, 0, 0);
                    removeOptions.fromDate = fromDateObj.getTime();
                }
                if (toDateValue) {
                    const toDateObj = new Date(toDateValue);
                    toDateObj.setUTCHours(23, 59, 59, 999);
                    removeOptions.toDate = toDateObj.getTime();
                }
            } else if (removeDateFilter === 'lastHours') {
                removeOptions.hoursLimit = parseInt(document.getElementById('removeHours').value) || 24;
            }

            // 首先生成移除列表
            const response = await sendMessageToContentScript(tab.id, {
                action: 'removeFavorites',
                options: removeOptions
            });

            console.log('收到回應:', response);

            removeBtn.disabled = false;
            removeBtn.textContent = chrome.i18n.getMessage('btnRemoveFav');

            if (!response) {
                console.error('沒有收到回應');
                showMessage(chrome.i18n.getMessage('msgNoResponse'), 'error');
                return;
            }

            if (!response.success) {
                console.error('操作失敗:', response.error);
                showMessage(chrome.i18n.getMessage('msgOperationFailed') + ': ' + (response.error || '未知錯誤'), 'error');
                return;
            }

            // 處理沒有項目需要移除的情況
            if (response.toRemove === 0 || response.toRemove === undefined) {
                console.log('沒有項目需要移除');
                const dateRange = formatRemoveDateRange(removeDateFilter, fromDateValue, toDateValue, removeOptions.hoursLimit);
                gmdNotify(chrome.i18n.getMessage('msgNoItemsToRemoveRange', [dateRange, response.total]));
                return;
            }

            console.log(`找到 ${response.toRemove} 個項目需要移除`);

            // 顯示詳細確認對話框
            const dateRange = formatRemoveDateRange(removeDateFilter, fromDateValue, toDateValue, removeOptions.hoursLimit);
            let confirmMsg = chrome.i18n.getMessage('msgConfirmRemoveRange', [dateRange, response.total, response.toRemove, response.total - response.toRemove]);
            if (deletePost) {
                confirmMsg += '\n\n' + chrome.i18n.getMessage('msgConfirmDeletePost');
            }

            const confirmed = confirm(confirmMsg);

            if (confirmed) {
                const startResponse = await sendMessageToContentScript(tab.id, {
                    action: 'startRemoveFavorites',
                    deletePost: deletePost
                });

                if (startResponse && startResponse.success) {
                    // 鎖住按鈕並顯示初始進度
                    removeBtn.disabled = true;
                    removeBtn.textContent = chrome.i18n.getMessage('msgRemovingProgress', ['0', String(response.toRemove)]);
                    showMessage(chrome.i18n.getMessage('msgStartRemove', [response.toRemove]), 'info');
                } else {
                    showMessage(chrome.i18n.getMessage('msgStartRemoveFailed'), 'error');
                    removeBtn.disabled = false;
                    removeBtn.textContent = chrome.i18n.getMessage('btnRemoveFav');
                }
            }
        } catch (error) {
            console.error('移除失敗:', error);
            showMessage(chrome.i18n.getMessage('msgOperationFailed') + ': ' + error.message, 'error');
            removeBtn.disabled = false;
            removeBtn.textContent = chrome.i18n.getMessage('btnRemoveFav');
        }
    });

    // 監聽移除進度更新
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'removeProgress') {
            // 更新按鈕顯示進度
            removeBtn.disabled = true;
            removeBtn.textContent = chrome.i18n.getMessage('msgRemovingProgress', [String(request.current), String(request.total)]);
        } else if (request.action === 'removeComplete') {
            // 移除完成，恢復按鈕
            removeBtn.disabled = false;
            removeBtn.textContent = chrome.i18n.getMessage('btnRemoveFav');
            showMessage(chrome.i18n.getMessage('msgRemoveComplete', [String(request.success), String(request.total)]), 'info');
        }
    });

    // HD 升級相關邏輯
    const upgradeBtn = document.getElementById('upgradeBtn');
    const hdUpgradeLock = document.getElementById('hdUpgradeLock');
    const hdUpgradeTimeFilterCheckbox = document.getElementById('hdUpgradeTimeFilter');
    const hdUpgradeHoursInput = document.getElementById('hdUpgradeHours');
    // 1080p 升級需要 SuperGrok Heavy 帳號，預設關閉，需使用者明確勾選才會嘗試
    const upgrade1080pCheckbox = document.getElementById('upgrade1080p');
    let isUpgradeInProgress = false;

    // Load HD upgrade time filter settings (fire-and-forget — does not block the rest
    // of DOMContentLoaded init; chrome.storage.sync.get resolves the Promise form here
    // rather than relying on the legacy callback argument)
    chrome.storage.sync.get(['hdUpgradeTimeFilter', 'hdUpgradeHours', 'upgrade1080p', 'upgradeSource']).then((result) => {
        if (hdUpgradeTimeFilterCheckbox) hdUpgradeTimeFilterCheckbox.checked = result.hdUpgradeTimeFilter === true;
        if (hdUpgradeHoursInput && result.hdUpgradeHours) hdUpgradeHoursInput.value = result.hdUpgradeHours;
        if (upgrade1080pCheckbox) upgrade1080pCheckbox.checked = result.upgrade1080p === true;

        // Upgrade source selector (favorite/allmedia) — defaults to 'favorite'.
        // Default = allmedia: the legacy favorite scan can't see post-2026-07
        // media, so it reports "already upgraded" for videos it never saw.
        const savedUpgradeSource = result.upgradeSource === 'favorite' ? 'favorite' : 'allmedia';
        const savedUpgradeSourceRadio = document.querySelector(`input[name="upgradeSource"][value="${savedUpgradeSource}"]`);
        if (savedUpgradeSourceRadio) savedUpgradeSourceRadio.checked = true;
        applyUpgradeSourceVisibility(savedUpgradeSource);
    });

    // Auto-save HD upgrade time filter settings
    if (hdUpgradeTimeFilterCheckbox) {
        hdUpgradeTimeFilterCheckbox.addEventListener('change', () => {
            chrome.storage.sync.set({ hdUpgradeTimeFilter: hdUpgradeTimeFilterCheckbox.checked });
        });
    }

    // HD-upgrade source selector (favorite/allmedia) — mirrors the download
    // source selector's persist + hint-visibility pattern.
    function applyUpgradeSourceVisibility(source) {
        const hint = document.getElementById('upgradeAllMediaHint');
        if (hint) hint.style.display = source === 'allmedia' ? '' : 'none';
        // The legacy favorite scan can't see post-2026-07 media, so it reports
        // "already upgraded" for videos it never saw — warn when it's picked.
        const favHint = document.getElementById('upgradeFavoriteLegacyHint');
        if (favHint) favHint.style.display = source === 'favorite' ? '' : 'none';
    }

    document.querySelectorAll('input[name="upgradeSource"]').forEach(radio => {
        radio.addEventListener('change', () => {
            const source = document.querySelector('input[name="upgradeSource"]:checked')?.value || 'favorite';
            applyUpgradeSourceVisibility(source);
            chrome.storage.sync.set({ upgradeSource: source });
        });
    });
    if (hdUpgradeHoursInput) {
        hdUpgradeHoursInput.addEventListener('change', () => {
            let val = parseInt(hdUpgradeHoursInput.value) || 24;
            val = Math.max(1, Math.min(240, val));
            hdUpgradeHoursInput.value = val;
            chrome.storage.sync.set({ hdUpgradeHours: val });
        });
    }
    if (upgrade1080pCheckbox) {
        upgrade1080pCheckbox.addEventListener('change', () => {
            chrome.storage.sync.set({ upgrade1080p: upgrade1080pCheckbox.checked });
        });
    }

    // 檢查升級狀態並更新按鈕
    async function checkAndUpdateUpgradeStatus() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab.url.includes('grok.com')) return;

            const status = await sendMessageToContentScript(tab.id, {
                action: 'getUpgradeStatus'
            });

            if (status && status.inProgress) {
                isUpgradeInProgress = true;
                upgradeBtn.textContent = chrome.i18n.getMessage('btnStopUpgrade', [String(status.current), String(status.total)]);
                upgradeBtn.style.background = '#9e9e9e';
                upgradeBtn.disabled = false;
            } else {
                isUpgradeInProgress = false;
                upgradeBtn.textContent = chrome.i18n.getMessage('btnUpgradeHD');
                upgradeBtn.style.background = '#4caf50';
            }
        } catch (e) {
            console.log('檢查升級狀態失敗:', e.message);
        }
    }

    // popup 開啟時檢查狀態
    checkAndUpdateUpgradeStatus();

    upgradeBtn.addEventListener('click', async () => {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

            if (!tab.url.includes('grok.com')) {
                gmdNotify(chrome.i18n.getMessage('msgWrongPage'));
                return;
            }

            // 先嘗試注入 content script
            try {
                await ensureContentScriptInjected(tab.id);
            } catch (e) {
                console.log('Content script 可能已經存在:', e.message);
            }

            // 檢查是否正在升級中
            const status = await sendMessageToContentScript(tab.id, {
                action: 'getUpgradeStatus'
            });

            if (status && status.inProgress) {
                // 正在升級中，詢問是否要中斷
                const cancelMsg = chrome.i18n.getMessage('msgUpgradeCancelConfirm', [status.current, status.total]);
                if (confirm(cancelMsg)) {
                    await sendMessageToContentScript(tab.id, {
                        action: 'cancelUpgrade'
                    });
                    gmdNotify(chrome.i18n.getMessage('msgUpgradeCancelled'));
                    upgradeBtn.textContent = chrome.i18n.getMessage('btnUpgradeHD');
                    upgradeBtn.style.background = '#4caf50';
                    isUpgradeInProgress = false;
                }
                return;
            }

            upgradeBtn.disabled = true;
            upgradeBtn.textContent = chrome.i18n.getMessage('msgUpgradeScanning');

            // Build options with time filter if enabled
            const upgradeOptions = {};
            if (hdUpgradeTimeFilterCheckbox && hdUpgradeTimeFilterCheckbox.checked) {
                upgradeOptions.hoursLimit = parseInt(hdUpgradeHoursInput?.value) || 24;
            }
            // 1080p upscale requires a SuperGrok Heavy account — explicit opt-in, default off.
            // Flows into BOTH scanFavoritesForUpgrade and upgradeFavoritesToHD via the spread below.
            upgradeOptions.include1080p = document.getElementById('upgrade1080p')?.checked === true;
            // Upgrade source: 'favorite' (default) or 'allmedia' (whole generated library).
            // Flows into BOTH scanFavoritesForUpgrade and upgradeFavoritesToHD via the spread below.
            upgradeOptions.upgradeSource = document.querySelector('input[name="upgradeSource"]:checked')?.value || 'favorite';

            // 1. 先掃描獲取需要升級的數量
            const scanResult = await sendMessageToContentScript(tab.id, {
                action: 'scanFavoritesForUpgrade',
                ...upgradeOptions
            });

            if (!scanResult || !scanResult.success) {
                gmdNotify(chrome.i18n.getMessage('msgUpgradeFailed') + (scanResult?.error ? ': ' + scanResult.error : ''));
                return;
            }

            // 使用者在整庫掃描/畫質解析階段按下 Stop（cancelUpgrade）取消了這次掃描 —
            // 不進入 confirm()，直接顯示取消訊息並讓 finally 重置按鈕狀態。
            if (scanResult.scanError === 'aborted') {
                gmdNotify(chrome.i18n.getMessage('msgUpgradeCancelled'));
                return;
            }

            // 2. 顯示掃描結果對話框
            const effectiveCount = upgradeOptions.hoursLimit ? scanResult.needUpgradeFiltered : scanResult.needUpgrade;
            // allmedia's scan already early-stops at hoursLimit (listAllGeneratedAssets),
            // so its total/alreadyHD/needUpgrade are ALREADY the windowed set and
            // needUpgradeFiltered === needUpgrade — the "X of Y in last Nh" filtered
            // framing would just show a duplicate/misleading number. Only favorite's
            // scan is a POST-filter on top of an unfiltered total, so only favorite
            // needs the filtered framing.
            const isAllMedia = upgradeOptions.upgradeSource === 'allmedia';
            const useFilteredFraming = upgradeOptions.hoursLimit && !isAllMedia;
            // 1080p-eligible videos exist but the user hasn't opted in — surfaced separately
            // from the effective (gated) work count so the dialogs can call it out.
            const has1080pGated = !upgradeOptions.include1080p && scanResult.need1080Upgrade > 0;
            // Videos whose quality could not be resolved (429 storm) — excluded from the
            // work list rather than mis-upscaled; tell the user how many were skipped.
            const resolveFailedNote = scanResult.resolveFailedCount > 0
                ? '\n\n' + chrome.i18n.getMessage('msgUpgradeResolveFailed', [String(scanResult.resolveFailedCount)])
                : '';

            if (effectiveCount === 0) {
                // 沒有需要升級的
                let noNeedMsg;
                if (scanResult.total === 0) {
                    // Nothing was even scanned — don't claim "all videos are already
                    // top quality" for a library/time-window that has zero videos.
                    noNeedMsg = chrome.i18n.getMessage('msgUpgradeNoVideos');
                } else if (has1080pGated) {
                    // Nothing needs an SD→HD upgrade (the operation the user actually
                    // requested, since 1080p wasn't opted in) — say THAT first, then
                    // note the 1080p-eligible videos as a secondary hint.
                    noNeedMsg = chrome.i18n.getMessage('msgUpgradeNoHdNeed')
                        + '\n\n' + chrome.i18n.getMessage('msgUpgrade1080pGated', [scanResult.need1080Upgrade]);
                } else if (useFilteredFraming && scanResult.needUpgrade > 0) {
                    // There are upgradeable videos but none in the time range
                    noNeedMsg = chrome.i18n.getMessage('msgUpgradeNoNeedFiltered', [
                        scanResult.total,
                        scanResult.alreadyHD,
                        scanResult.needUpgrade,
                        upgradeOptions.hoursLimit
                    ]);
                } else {
                    noNeedMsg = chrome.i18n.getMessage('msgUpgradeNoNeed', [scanResult.total, scanResult.alreadyHD]);
                }
                // Scanning the legacy favorite list can't see media generated
                // after grok's 2026-07 change, so "nothing to upgrade" there is
                // frequently just an invisible-input problem — suggest the
                // whole-library source rather than letting the user conclude
                // their videos are already HD.
                const legacySourceNote = upgradeOptions.upgradeSource !== 'allmedia'
                    ? '\n\n' + chrome.i18n.getMessage('msgTryWholeLibrarySource')
                    : '';
                gmdNotify(noNeedMsg + resolveFailedNote + legacySourceNote);
                return;
            }

            // 有需要升級的，顯示確認對話框
            // Per-tier breakdown (SD / HD-720p / 1080p) so the user can see exactly what
            // the scan found, not just a total/already/need summary. Older cached scan
            // shapes may lack these fields — coerce to 0 rather than rendering "undefined".
            const tierSd = scanResult.needHdUpgrade ?? 0;
            const tierHd720 = scanResult.need1080Upgrade ?? 0;
            const tier1080p = scanResult.already1080p ?? 0;
            let confirmMsg;
            if (useFilteredFraming) {
                confirmMsg = chrome.i18n.getMessage('msgUpgradeConfirmFiltered', [
                    String(upgradeOptions.hoursLimit),
                    String(scanResult.total),
                    String(tierSd),
                    String(tierHd720),
                    String(tier1080p),
                    String(scanResult.needUpgrade),
                    String(effectiveCount)
                ]);
            } else {
                confirmMsg = chrome.i18n.getMessage('msgUpgradeConfirm', [
                    String(scanResult.total),
                    String(tierSd),
                    String(tierHd720),
                    String(tier1080p),
                    String(effectiveCount)
                ]);
            }
            if (has1080pGated) {
                confirmMsg += '\n\n' + chrome.i18n.getMessage('msgUpgrade1080pGated', [scanResult.need1080Upgrade]);
            }
            confirmMsg += resolveFailedNote;

            if (!confirm(confirmMsg)) {
                return;
            }

            // 3. 用戶確認後執行升級
            upgradeBtn.textContent = chrome.i18n.getMessage('msgUpgrading');
            isUpgradeInProgress = true;

            const response = await sendMessageToContentScript(tab.id, {
                action: 'upgradeFavoritesToHD',
                ...upgradeOptions
            });

            if (response && response.success) {
                let completeMsg = chrome.i18n.getMessage('msgUpgradeComplete', [response.upgradedCount, response.total]);
                if (response.resolution1080pUnavailable || response.skipped1080pCount > 0) {
                    completeMsg += '\n\n' + chrome.i18n.getMessage('msgUpgrade1080pUnavailable', [String(response.skipped1080pCount || 0)]);
                }
                gmdNotify(completeMsg);
            } else if (response && response.aborted) {
                // 被中斷的情況在 cancelUpgrade 處理時已經顯示訊息
            } else {
                gmdNotify(chrome.i18n.getMessage('msgUpgradeFailed') + (response?.error ? ': ' + response.error : ''));
            }
        } catch (error) {
            console.error('升級失敗:', error);
            gmdNotify(chrome.i18n.getMessage('msgUpgradeFailed') + ': ' + error.message);
        } finally {
            upgradeBtn.disabled = false;
            upgradeBtn.textContent = chrome.i18n.getMessage('btnUpgradeHD');
            upgradeBtn.style.background = '#4caf50';
            isUpgradeInProgress = false;
        }
    });

    // 監聽升級進度
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'upgradeProgress') {
            if (request.status === 'scanning') {
                upgradeBtn.textContent = chrome.i18n.getMessage('msgUpgradeScanning');
                upgradeBtn.style.background = '#9e9e9e';
                upgradeBtn.disabled = false; // 整庫掃描本身也可被中斷（Stop）— content.js 現在會在此階段設置 upgradeInProgress
                isUpgradeInProgress = true;
            } else if (request.status === 'resolving') {
                // Whole-Library scan path only: per-video quality resolution progress
                // after the /rest/assets listing completes (content.js scanVideosForUpgrade).
                upgradeBtn.textContent = chrome.i18n.getMessage('msgUpgradeResolving', [String(request.current), String(request.total)]);
                upgradeBtn.style.background = '#9e9e9e';
                upgradeBtn.disabled = false; // 同上：畫質解析階段也可被中斷（Stop）
                isUpgradeInProgress = true;
            } else if (request.status === 'upgrading') {
                upgradeBtn.textContent = chrome.i18n.getMessage('btnStopUpgrade', [String(request.current), String(request.total)]);
                upgradeBtn.style.background = '#9e9e9e';
                upgradeBtn.disabled = false; // 允許點擊以中斷
                isUpgradeInProgress = true;
            } else if (request.status === 'idle') {
                upgradeBtn.textContent = chrome.i18n.getMessage('btnUpgradeHD');
                upgradeBtn.style.background = '#4caf50';
                upgradeBtn.disabled = false;
                isUpgradeInProgress = false;
            }
        }
    });

    // 串流擷取相關邏輯
    const streamToggle = document.getElementById('streamToggle');
    const downloadStreamBtn = document.getElementById('downloadStreamBtn');
    const clearStreamBtn = document.getElementById('clearStreamBtn');
    const streamCapturedCount = document.querySelector('[data-i18n="streamCapturedCount"]');
    const streamStatus = document.getElementById('streamStatus');
    let streamStatusTimeout = null;

    function showStreamStatus(text, type = 'info') {
        if (!streamStatus) return;
        streamStatus.textContent = text;
        streamStatus.style.display = 'block';
        streamStatus.style.color = type === 'error' ? '#e53935' : '#4caf50';
        if (streamStatusTimeout) clearTimeout(streamStatusTimeout);
        streamStatusTimeout = setTimeout(() => {
            streamStatus.style.display = 'none';
            streamStatusTimeout = null;
        }, 3000);
    }

    // 監聽來自 content script 的計數更新
    chrome.runtime.onMessage.addListener((request) => {
        if (request.action === 'streamImageCaptured') {
            // 這裡通常只更新計數，但如果 content script 傳來狀態也可以更新
            updateStreamCount(request.count, true);
        } else if (request.action === 'streamCaptureStopped') {
            streamToggle.checked = false;
            showStreamStatus(chrome.i18n.getMessage('msgStreamStopped'));
        }
    });

    // Stream Capture v2: the background owns the queue (auto-download on
    // capture). This section shows the persisted toggle, a health line and a
    // "Retry failed" button. Counts are tracked as numbers (the old
    // textContent.includes('0') check disabled the button at 10/20/100).
    const streamHealth = document.getElementById('streamHealth');
    var streamFailedCount = 0; // var: the Pro lock/unlock code below may run first
    var streamSavedCount = 0;
    var streamLicensed = !streamToggle.disabled;

    function renderStreamButtons() {
        streamCapturedCount.textContent = chrome.i18n.getMessage('streamCapturedCount', [String(streamSavedCount)]);
        downloadStreamBtn.textContent = chrome.i18n.getMessage('btnRetryFailedCaptures', [String(streamFailedCount)]) || `Retry failed (${streamFailedCount})`;
        downloadStreamBtn.disabled = !streamLicensed || streamFailedCount === 0;
    }

    async function updateStreamCount() {
        try {
            const [{ streamCaptureEnabled }, status] = await Promise.all([
                chrome.storage.local.get('streamCaptureEnabled'),
                chrome.runtime.sendMessage({ action: 'getCaptureStatus' })
            ]);
            streamToggle.checked = streamCaptureEnabled === true;
            if (status && status.success) {
                streamSavedCount = status.counts.saved || 0;
                streamFailedCount = status.counts.failed || 0;
                if (streamHealth) streamHealth.textContent = status.line;
            }
        } catch (e) {
            if (streamHealth) streamHealth.textContent = 'Capture status unavailable';
        }
        renderStreamButtons();
    }
    const streamHealthTimer = setInterval(updateStreamCount, 5000);
    window.addEventListener('unload', () => clearInterval(streamHealthTimer));

    streamToggle.addEventListener('change', async () => {
        const enabled = streamToggle.checked;
        try {
            // Persisted: every /imagine tab (and future ones) follows this flag.
            await chrome.storage.local.set({ streamCaptureEnabled: enabled });
            showStreamStatus(chrome.i18n.getMessage(enabled ? 'msgStreamStarted' : 'msgStreamStopped'));
        } catch (error) {
            console.error('串流切換失敗:', error);
            streamToggle.checked = !enabled; // 回滾狀態
        }
        updateStreamCount();
    });

    downloadStreamBtn.addEventListener('click', async () => {
        try {
            const res = await chrome.runtime.sendMessage({ action: 'captureRetryFailed' });
            if (res && res.success) showStreamStatus(chrome.i18n.getMessage('msgCaptureRetried', [String(res.requeued)]) || `Requeued ${res.requeued}`);
        } catch (error) {
            console.error('重試失敗:', error);
            showStreamStatus(chrome.i18n.getMessage('msgStartFailed'), 'error');
        }
        updateStreamCount();
    });

    clearStreamBtn.addEventListener('click', async () => {
        if (!confirm(chrome.i18n.getMessage('msgConfirmClearStream'))) return;
        // Clears this session's counters only. The saved ledger (used for
        // dedupe) and files on disk are never touched.
        try {
            const tabs = await chrome.tabs.query({ url: ['https://grok.com/imagine', 'https://grok.com/imagine/*'] });
            for (const t of tabs) sendMessageToContentScript(t.id, { action: 'clearCapturedImages' }, { silent: true }).catch(() => {});
            showStreamStatus(chrome.i18n.getMessage('msgStateCleared'));
        } catch (error) {
            console.error('清除失敗:', error);
        }
        updateStreamCount();
    });

    // 初始化串流計數
    updateStreamCount();

    // ==========================================
    // 設定功能
    // ==========================================
    const pathImagesInput = document.getElementById('pathImages');
    const pathVideosInput = document.getElementById('pathVideos');
    const pathStreamInput = document.getElementById('pathStream');
    const pathFramesInput = document.getElementById('pathFrames');
    const pathProjectsInput = document.getElementById('pathProjects');
    const hdPriorityCheckbox = document.getElementById('hdPriority');
    const saveMetadataCheckbox = document.getElementById('saveMetadata');
    const autoCleanHistoryCheckbox = document.getElementById('autoCleanDownloadHistory');
    const filenameTemplateImageInput = document.getElementById('filenameTemplateImage');
    const filenameTemplateVideoInput = document.getElementById('filenameTemplateVideo');
    const rateLimitCooldownInput = document.getElementById('rateLimitCooldown');
    const downloadModeStandard = document.getElementById('downloadModeStandard');
    const downloadModeProject = document.getElementById('downloadModeProject');
    const saveSettingsBtn = document.getElementById('saveSettingsBtn');
    const settingsStatus = document.getElementById('settingsStatus');
    const footerImagesPath = document.getElementById('footerImagesPath');
    const footerVideosPath = document.getElementById('footerVideosPath');

    // 預設路徑
    const defaultPaths = {
        pathImages: 'grok_downloads/images',
        pathVideos: 'grok_downloads/videos',
        pathStream: 'grok_downloads/stream',
        pathFrames: 'grok_downloads/frames',
        pathProjects: 'grok_downloads/projects',
        pathTags: 'grok_downloads/tags',
        pathConversations: 'grok_downloads/conversations'
    };

    // 載入設定
    async function loadSettings() {
        const result = await chrome.storage.sync.get([
            'pathImages', 'pathVideos', 'pathStream', 'pathFrames', 'pathProjects', 'pathTags', 'pathConversations',
            'hdPriority', 'saveMetadata', 'promptAsFilename', 'autoCleanDownloadHistory',
            'filenameMode', 'filenameTemplateImage', 'filenameTemplateVideo',
            'downloadMode', 'rateLimitCooldown',
            'selectedTagId', 'selectedTagName',
            'downloadSource',
            'downloadDateFilter', 'downloadFromDate', 'downloadToDate', 'downloadHours'
        ]);

        if (pathImagesInput) pathImagesInput.value = result.pathImages || defaultPaths.pathImages;
        if (pathVideosInput) pathVideosInput.value = result.pathVideos || defaultPaths.pathVideos;
        if (pathStreamInput) pathStreamInput.value = result.pathStream || defaultPaths.pathStream;
        if (pathFramesInput) pathFramesInput.value = result.pathFrames || defaultPaths.pathFrames;
        if (pathProjectsInput) pathProjectsInput.value = result.pathProjects || defaultPaths.pathProjects;
        const pathTagsInput = document.getElementById('pathTags');
        if (pathTagsInput) pathTagsInput.value = result.pathTags || defaultPaths.pathTags;
        const pathConversationsInput = document.getElementById('pathConversations');
        if (pathConversationsInput) pathConversationsInput.value = result.pathConversations || defaultPaths.pathConversations;

        // 載入下載選項（hdPriority、autoCleanDownloadHistory 預設為 true，saveMetadata 預設為 false）
        if (hdPriorityCheckbox) hdPriorityCheckbox.checked = result.hdPriority !== false;
        if (saveMetadataCheckbox) saveMetadataCheckbox.checked = result.saveMetadata === true;
        if (autoCleanHistoryCheckbox) autoCleanHistoryCheckbox.checked = result.autoCleanDownloadHistory !== false;
        if (rateLimitCooldownInput) rateLimitCooldownInput.value = result.rateLimitCooldown || 3;

        // 載入 filename mode（migration: 舊版 promptAsFilename → filenameMode）
        let filenameMode = result.filenameMode;
        if (!filenameMode) {
            filenameMode = result.promptAsFilename === true ? 'prompt' : 'native';
            chrome.storage.sync.set({ filenameMode });
        }
        const filenameModeRadio = document.querySelector(`input[name="filenameMode"][value="${filenameMode}"]`);
        if (filenameModeRadio) filenameModeRadio.checked = true;
        const customTemplateInputs = document.getElementById('customTemplateInputs');
        if (customTemplateInputs) customTemplateInputs.style.display = filenameMode === 'custom' ? '' : 'none';
        if (filenameTemplateImageInput) filenameTemplateImageInput.value = result.filenameTemplateImage || '';
        if (filenameTemplateVideoInput) filenameTemplateVideoInput.value = result.filenameTemplateVideo || '';

        // 載入下載模式（預設為 standard）
        const downloadMode = result.downloadMode || 'standard';
        if (downloadModeStandard) downloadModeStandard.checked = downloadMode === 'standard';
        if (downloadModeProject) downloadModeProject.checked = downloadMode === 'project';
        updateProjectModeHint();

        // 載入下載來源（Task D6 — 與日期篩選 radio group 各自獨立持久化）
        if (result.downloadSource) {
            const sourceRadio = document.querySelector(`input[name="downloadSource"][value="${result.downloadSource}"]`);
            if (sourceRadio) {
                sourceRadio.checked = true;
                sourceRadio.dispatchEvent(new Event('change', { bubbles: true }));
            }
        } else {
            // 預設 allmedia — grok 2026-07 改版後 favorite 來源會漏掉新生成的媒體，
            // 所以未設定過的使用者直接落在可用的來源上（HTML 預設已是 allmedia）。
            applySourceVisibility('allmedia');
        }

        // 載入日期篩選設定
        if (result.downloadDateFilter) {
            const filterRadio = document.querySelector(`input[name="downloadDateFilter"][value="${result.downloadDateFilter}"]`);
            if (filterRadio) {
                filterRadio.checked = true;
                filterRadio.dispatchEvent(new Event('change', { bubbles: true }));
            }
        }
        if (result.downloadFromDate && fromDate) fromDate.value = result.downloadFromDate;
        if (result.downloadToDate && toDate) toDate.value = result.downloadToDate;
        if (result.downloadHours) {
            const hoursInput = document.getElementById('downloadHours');
            if (hoursInput) hoursInput.value = result.downloadHours;
        }

        // 更新 footer 顯示
        if (footerImagesPath) footerImagesPath.textContent = result.pathImages || defaultPaths.pathImages;
        if (footerVideosPath) footerVideosPath.textContent = result.pathVideos || defaultPaths.pathVideos;
    }

    // 使用 GrokUtils.cleanPath 替代本地實作

    // 儲存下載路徑設定（checkbox/radio 已自動保存）
    async function saveSettings() {
        const settings = {
            pathImages: GrokUtils.cleanPath(pathImagesInput?.value, defaultPaths.pathImages),
            pathVideos: GrokUtils.cleanPath(pathVideosInput?.value, defaultPaths.pathVideos),
            pathStream: GrokUtils.cleanPath(pathStreamInput?.value, defaultPaths.pathStream),
            pathFrames: GrokUtils.cleanPath(pathFramesInput?.value, defaultPaths.pathFrames),
            pathProjects: GrokUtils.cleanPath(pathProjectsInput?.value, defaultPaths.pathProjects),
            pathTags: GrokUtils.cleanPath(document.getElementById('pathTags')?.value, defaultPaths.pathTags),
            pathConversations: GrokUtils.cleanPath(document.getElementById('pathConversations')?.value, defaultPaths.pathConversations),
        };

        // 儲存到 storage
        await chrome.storage.sync.set(settings);

        // 更新輸入框
        if (pathImagesInput) pathImagesInput.value = settings.pathImages;
        if (pathVideosInput) pathVideosInput.value = settings.pathVideos;
        if (pathStreamInput) pathStreamInput.value = settings.pathStream;
        if (pathFramesInput) pathFramesInput.value = settings.pathFrames;
        if (pathProjectsInput) pathProjectsInput.value = settings.pathProjects;
        const pathTagsEl = document.getElementById('pathTags');
        if (pathTagsEl) pathTagsEl.value = settings.pathTags;
        const pathConversationsEl = document.getElementById('pathConversations');
        if (pathConversationsEl) pathConversationsEl.value = settings.pathConversations;

        // 更新 footer
        if (footerImagesPath) footerImagesPath.textContent = settings.pathImages;
        if (footerVideosPath) footerVideosPath.textContent = settings.pathVideos;

        // 顯示成功訊息
        if (settingsStatus) {
            settingsStatus.textContent = chrome.i18n.getMessage('settingsSaved') || '✓ Settings saved!';
            settingsStatus.style.display = 'block';
            setTimeout(() => {
                settingsStatus.style.display = 'none';
            }, 2000);
        }
    }

    // 綁定事件
    if (saveSettingsBtn) {
        saveSettingsBtn.addEventListener('click', saveSettings);
    }

    // 自動保存 checkbox 設定（當用戶改變時）
    if (hdPriorityCheckbox) {
        hdPriorityCheckbox.addEventListener('change', () => {
            chrome.storage.sync.set({ hdPriority: hdPriorityCheckbox.checked });
        });
    }
    if (saveMetadataCheckbox) {
        saveMetadataCheckbox.addEventListener('change', () => {
            chrome.storage.sync.set({ saveMetadata: saveMetadataCheckbox.checked });
        });
    }
    if (autoCleanHistoryCheckbox) {
        autoCleanHistoryCheckbox.addEventListener('change', () => {
            chrome.storage.sync.set({ autoCleanDownloadHistory: autoCleanHistoryCheckbox.checked });
        });
    }
    // filename mode radio auto-save
    document.querySelectorAll('input[name="filenameMode"]').forEach(radio => {
        radio.addEventListener('change', () => {
            const mode = radio.value;
            chrome.storage.sync.set({ filenameMode: mode, promptAsFilename: mode === 'prompt' });
            const customInputs = document.getElementById('customTemplateInputs');
            if (customInputs) customInputs.style.display = mode === 'custom' ? '' : 'none';
        });
    });

    // template inputs auto-save + uniqueness warning
    const UNIQUE_TOKENS = ['{id}', '{shortid}', '{datetime}'];
    function hasUniqueToken(val) { return UNIQUE_TOKENS.some(t => val.includes(t)); }
    if (filenameTemplateImageInput) {
        filenameTemplateImageInput.addEventListener('change', () => {
            const val = filenameTemplateImageInput.value.trim();
            chrome.storage.sync.set({ filenameTemplateImage: val });
            const warn = document.getElementById('filenameTemplateImageWarn');
            if (warn) warn.style.display = val && !hasUniqueToken(val) ? '' : 'none';
        });
    }
    if (filenameTemplateVideoInput) {
        filenameTemplateVideoInput.addEventListener('change', () => {
            const val = filenameTemplateVideoInput.value.trim();
            chrome.storage.sync.set({ filenameTemplateVideo: val });
            const warn = document.getElementById('filenameTemplateVideoWarn');
            if (warn) warn.style.display = val && !hasUniqueToken(val) ? '' : 'none';
        });
    }
    if (rateLimitCooldownInput) {
        rateLimitCooldownInput.addEventListener('change', () => {
            const val = Math.max(1, Math.min(60, parseInt(rateLimitCooldownInput.value) || 3));
            rateLimitCooldownInput.value = val;
            chrome.storage.sync.set({ rateLimitCooldown: val });
        });
    }

    // 自動保存下載模式設定 + 顯示/隱藏提示
    const projectModeHint = document.getElementById('projectModeHint');
    function updateProjectModeHint() {
        if (projectModeHint) {
            projectModeHint.style.display = downloadModeProject?.checked ? 'block' : 'none';
        }
    }
    if (downloadModeStandard) {
        downloadModeStandard.addEventListener('change', () => {
            if (downloadModeStandard.checked) {
                chrome.storage.sync.set({ downloadMode: 'standard' });
            }
            updateProjectModeHint();
        });
    }
    if (downloadModeProject) {
        downloadModeProject.addEventListener('change', () => {
            if (downloadModeProject.checked) {
                chrome.storage.sync.set({ downloadMode: 'project' });
            }
            updateProjectModeHint();
        });
    }

    // 初始載入設定
    loadSettings();

    // 授權相關邏輯
    const licenseKeyInput = document.getElementById('licenseKey');
    const activateBtn = document.getElementById('activateBtn');
    const licenseStatus = document.getElementById('licenseStatus');
    const licenseMessage = document.getElementById('licenseMessage');
    const buySection = document.getElementById('buySection');
    const buyBtn = document.getElementById('buyBtn');

    // Pro 功能鎖定層
    const dateFilterLock = document.getElementById('dateFilterLock');
    const removeFavoritesLock = document.getElementById('removeFavoritesLock');
    const dataManageLock = document.getElementById('dataManageLock');
    const streamCaptureLock = document.getElementById('streamCaptureLock');
    const includeVideosCheckbox = document.getElementById('includeVideos');
    const videoLockIcon = document.getElementById('videoLockIcon');

    // 檢查授權狀態
    async function checkLicenseStatus() {
        const result = await chrome.storage.sync.get(['isPro', 'licenseKey']);
        if (result.isPro) {
            // 已激活
            licenseStatus.classList.remove('hidden');
            licenseKeyInput.style.display = 'none';
            activateBtn.style.display = 'none';
            if (buySection) buySection.style.display = 'none';

            // 解鎖 Pro 功能
            unlockProFeatures();
        } else {
            // 未激活
            licenseStatus.classList.add('hidden');
            licenseKeyInput.style.display = 'block';
            activateBtn.style.display = 'block';
            if (buySection) buySection.style.display = 'block';

            // 鎖定 Pro 功能
            lockProFeatures();
        }
    }

    function unlockProFeatures() {
        isProUser = true;
        refreshSourceHints();
        if (dateFilterLock) dateFilterLock.style.display = 'none';
        if (removeFavoritesLock) removeFavoritesLock.style.display = 'none';
        if (dataManageLock) dataManageLock.style.display = 'none';
        if (streamCaptureLock) streamCaptureLock.style.display = 'none';
        if (hdUpgradeLock) hdUpgradeLock.style.display = 'none';


        // 啟用輸入框和按鈕（根據 radio 狀態）
        const downloadFilterVal = document.querySelector('input[name="downloadDateFilter"]:checked').value;
        fromDate.disabled = downloadFilterVal !== 'dateRange';
        toDate.disabled = downloadFilterVal !== 'dateRange';
        document.getElementById('downloadHours').disabled = downloadFilterVal !== 'lastHours';
        const removeFilterVal = document.querySelector('input[name="removeDateFilter"]:checked').value;
        removeFromDate.disabled = removeFilterVal !== 'dateRange';
        removeToDate.disabled = removeFilterVal !== 'dateRange';
        document.getElementById('removeHours').disabled = removeFilterVal !== 'lastHours';
        removeBtn.disabled = false;
        exportBtn.disabled = false;
        importBtn.disabled = false;

        // 解鎖串流擷取
        streamToggle.disabled = false;
        streamLicensed = true;
        downloadStreamBtn.disabled = streamFailedCount === 0; // numeric (was textContent.includes('0'))
        clearStreamBtn.disabled = false;

        // 解鎖 HD 升級
        upgradeBtn.disabled = false;

        // 解鎖視頻下載
        includeVideosCheckbox.disabled = false;
        if (videoLockIcon) videoLockIcon.style.display = 'none';
    }

    function lockProFeatures() {
        isProUser = false;
        refreshSourceHints();
        if (dateFilterLock) dateFilterLock.style.display = 'flex';
        if (removeFavoritesLock) removeFavoritesLock.style.display = 'flex';
        if (dataManageLock) dataManageLock.style.display = 'flex';
        if (streamCaptureLock) streamCaptureLock.style.display = 'flex';
        if (hdUpgradeLock) hdUpgradeLock.style.display = 'flex';


        // 禁用輸入框和按鈕
        fromDate.disabled = true;
        toDate.disabled = true;
        document.getElementById('downloadHours').disabled = true;
        removeFromDate.disabled = true;
        removeToDate.disabled = true;
        document.getElementById('removeHours').disabled = true;
        removeBtn.disabled = true;
        exportBtn.disabled = true;
        importBtn.disabled = true;

        // 鎖定串流擷取
        streamToggle.disabled = true;
        streamToggle.checked = false;
        streamLicensed = false;
        downloadStreamBtn.disabled = true;
        clearStreamBtn.disabled = true;

        // 鎖定 HD 升級
        upgradeBtn.disabled = true;

        // 鎖定視頻下載
        includeVideosCheckbox.disabled = true;
        includeVideosCheckbox.checked = false;
        if (videoLockIcon) videoLockIcon.style.display = 'inline';
    }

    // 激活授權
    activateBtn.addEventListener('click', async () => {
        const key = licenseKeyInput.value.trim();
        if (!key) {
            showMessage(chrome.i18n.getMessage('msgEnterLicenseKey'), 'error');
            return;
        }

        activateBtn.disabled = true;
        activateBtn.textContent = chrome.i18n.getMessage('licenseVerifying');

        try {
            const response = await chrome.runtime.sendMessage({
                action: 'activateLicense',
                licenseKey: key
            });

            if (response.success) {
                showMessage(chrome.i18n.getMessage('msgActivateSuccess'), 'info');
                await checkLicenseStatus();
            } else {
                showMessage(chrome.i18n.getMessage('msgActivateFailed') + ': ' + (response.error || '無效的 Key'), 'error');
            }
        } catch (error) {
            console.error('激活錯誤:', error);
            showMessage(chrome.i18n.getMessage('msgActivateError') + ': ' + error.message, 'error');
        } finally {
            activateBtn.disabled = false;
            activateBtn.textContent = chrome.i18n.getMessage('licenseActivateBtn');
        }
    });

    // 購買按鈕
    if (buyBtn) {
        buyBtn.addEventListener('click', () => {
            chrome.tabs.create({
                url: buildMarketingUrl('pricing.html', 'popup_buy_btn')
            });
        });
    }

    // Pro 功能鎖定層點擊事件
    document.querySelectorAll('.pro-lock-overlay').forEach(overlay => {
        overlay.addEventListener('click', () => {
            chrome.tabs.create({
                url: buildMarketingUrl('pricing.html', 'feature_limit')
            });
        });
    });

    // 初始化時檢查授權
    await checkLicenseStatus();

    // Task D4: restore the per-source stats cache from a previous popup session
    // BEFORE the first updateStatus()/render, so a switch right after opening
    // the popup can still show cached numbers instead of a blank placeholder.
    await loadStatsCacheFromStorage();

    // 初始化時更新狀態
    await updateStatus();

    // 每 2 秒自動更新狀態
    window.__updateStatusInterval = setInterval(updateStatus, 2000);
});
