// Background script for handling downloads and license validation
// Grok Video Studio v2.0

// Import IndexedDB module for video storage
importScripts('lib/db.js');

// Import Queue DB module (separate database)
importScripts('lib/queue-db.js');

// Import shared utilities
importScripts('src/utils.js');

// Import logger for queue logging
importScripts('src/logger.js');

// Import pure queue decision logic
importScripts('src/queue-logic.js');

// Capture queue (Stream Capture v2): pure core, IndexedDB store, manager,
// filename router, and the asset resolver used for finished videos.
importScripts('lib/capture-core.js', 'lib/capture-db.js', 'src/capture-manager.js', 'src/download-router.js', 'src/grok-assets.js');

// Intended filenames, bound to the download id (not the URL — same-URL
// downloads used to collide). See src/download-router.js.
const downloadRouter = GrokDownloadRouter.createRouter();

// downloadId → { historyKey, filename, tabId } for interruption detection.
// Mirrored to chrome.storage.session so an SW restart mid-batch still knows
// which history keys to roll back when a download is interrupted.
const STARTED_DOWNLOADS_KEY = 'grok_started_downloads';
const startedDownloads = (() => {
    const map = new Map();
    let write = Promise.resolve();
    const persist = () => {
        write = write.then(() => chrome.storage.session.set({ [STARTED_DOWNLOADS_KEY]: Object.fromEntries(map) })).catch(() => {});
        return write;
    };
    const ready = chrome.storage.session.get(STARTED_DOWNLOADS_KEY).then((r) => {
        for (const [k, v] of Object.entries(r[STARTED_DOWNLOADS_KEY] || {})) if (!map.has(Number(k))) map.set(Number(k), v);
    }).catch(() => {});
    return {
        ready,
        get: (id) => map.get(id),
        set: (id, v) => { map.set(id, v); persist(); },
        delete: (id) => { const had = map.delete(id); if (had) persist(); return had; }
    };
})();

function ensureFilenameListener() {
    if (!chrome.downloads.onDeterminingFilename.hasListener(onDeterminingFilename)) {
        chrome.downloads.onDeterminingFilename.addListener(onDeterminingFilename);
    }
}

// Fetch a blob in the background and turn it into a data: URL for
// chrome.downloads (FileReader is already used this way in downloadVideoFromDB).
function readBlobAsDataUrl(blob) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = () => reject(new Error('Failed to read blob'));
        reader.readAsDataURL(blob);
    });
}

// Cookie-bearing fetch for grok.com / assets.grok.com (host_permissions).
const credFetch = (url, init = {}) => fetch(url, { credentials: 'include', ...init });

const captureManager = GrokCaptureManager.createCaptureManager({
    db: GrokCaptureDB,
    core: GrokCaptureCore,
    chromeApi: {
        storage: chrome.storage,
        runtime: chrome.runtime,
        alarms: chrome.alarms,
        downloads: {
            download: (opts, cb) => { ensureFilenameListener(); chrome.downloads.download(opts, cb); }
        }
    },
    router: downloadRouter,
    fetchImpl: credFetch,
    readBlobAsDataUrl,
    resolveVideo: async (mediaId) => GrokAssets.resolveVideoQuality(credFetch, mediaId, true, { maxRetries: 2 }),
    getBasePath: async () => (await chrome.storage.sync.get(['pathStream'])).pathStream || 'grok_downloads/stream',
    log: SystemLogger
});

if (chrome.alarms && chrome.alarms.onAlarm) {
    chrome.alarms.onAlarm.addListener((alarm) => {
        if (alarm.name === GrokCaptureManager.ALARM) captureManager.runDue().catch(() => {});
    });
}
// SW (re)start: resume anything left pending/retrying, prune the ledger.
setTimeout(() => {
    captureManager.runDue().catch(() => {});
    captureManager.prune().catch(() => {});
}, 3000);

// SPA navigation into /imagine from another grok.com page leaves no content
// script (manifest only matches /imagine at load). Ping the tab; inject the
// same file list if nothing answers.
const CONTENT_SCRIPT_FILES = ['src/logger.js', 'src/utils.js', 'src/content-utils.js', 'src/recent-posts.js', 'src/video-mode-utils.js', 'src/grok-assets.js', 'lib/capture-core.js', 'content.js'];
const injectingTabs = new Set();
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    const url = changeInfo.url || (changeInfo.status === 'complete' ? tab && tab.url : null);
    if (!url || !/^https:\/\/grok\.com\/imagine(\/|$|\?|#)/.test(url) || injectingTabs.has(tabId)) return;
    injectingTabs.add(tabId);
    chrome.tabs.sendMessage(tabId, { action: 'gmdPing' }).then((res) => {
        if (res && res.ok) return;
        throw new Error('no content script');
    }).catch(() => chrome.scripting.executeScript({ target: { tabId }, files: CONTENT_SCRIPT_FILES })
        .then(() => SystemLogger.info('Content script injected', `SPA entry into /imagine (tab ${tabId})`))
        .catch((e) => console.warn('[inject] failed:', e && e.message)))
        .finally(() => setTimeout(() => injectingTabs.delete(tabId), 2000));
});

// Serialize grok_interrupted_keys updates — concurrent onChanged events would
// otherwise interleave get/set and lose entries. Cap the list so keys that
// never match any cache cannot grow it unboundedly.
let interruptedKeysWrite = Promise.resolve();
function recordInterruptedKey(historyKey) {
    interruptedKeysWrite = interruptedKeysWrite.then(async () => {
        const { grok_interrupted_keys = [] } = await chrome.storage.local.get('grok_interrupted_keys');
        if (!grok_interrupted_keys.includes(historyKey)) {
            grok_interrupted_keys.push(historyKey);
            await chrome.storage.local.set({ grok_interrupted_keys: grok_interrupted_keys.slice(-1000) });
        }
    }).catch(e => {
        console.warn('[download] failed to persist interrupted key:', e);
    });
    return interruptedKeysWrite;
}

// Symmetric to recordInterruptedKey: a completed download proves its historyKey
// is valid, so drop any stale pending-removal entry left by a prior interruption.
// Serialized through the same interruptedKeysWrite chain to avoid interleaving
// with a concurrent recordInterruptedKey for the same key.
function clearInterruptedKey(historyKey) {
    interruptedKeysWrite = interruptedKeysWrite.then(async () => {
        const { grok_interrupted_keys = [] } = await chrome.storage.local.get('grok_interrupted_keys');
        if (grok_interrupted_keys.includes(historyKey)) {
            await chrome.storage.local.set({
                grok_interrupted_keys: grok_interrupted_keys.filter(k => k !== historyKey)
            });
        }
    }).catch(e => {
        console.warn('[download] failed to clear interrupted key:', e);
    });
    return interruptedKeysWrite;
}

// Auto-clean Chrome's download history for entries created by this extension.
// Rationale: Chrome persists per-download metadata and Safe Browsing verdicts in
// internal LevelDB stores (including shared_proto_db). After thousands of
// downloads these can bloat and crash Chrome — users then have to delete the
// shared_proto_db folder manually to recover. Erasing our entries from the
// download history after each completion removes the metadata Chrome tracks
// for them, without touching the files on disk.
chrome.downloads.onChanged.addListener(async (delta) => {
    const newState = delta.state?.current;
    if (newState === 'complete' || newState === 'interrupted') {
        // Capture queue: mark saved only on completion / schedule a retry.
        captureManager.onDownloadChanged(delta).catch(() => {});
        await startedDownloads.ready;
    }

    if (newState === 'interrupted') {
        const started = startedDownloads.get(delta.id);
        startedDownloads.delete(delta.id);
        if (started) {
            SystemLogger.fail('Download interrupted', `${started.filename} (${started.historyKey})`);
            // Persist for reconciliation in case the tab is gone
            await recordInterruptedKey(started.historyKey);
            // Tell the originating tab so its in-memory history cache is corrected
            if (started.tabId) {
                chrome.tabs.sendMessage(started.tabId, {
                    action: 'downloadInterrupted',
                    historyKey: started.historyKey,
                    filename: started.filename
                }).catch(() => {});
            }
        }
        return;
    }

    if (newState !== 'complete') return;
    const startedC = startedDownloads.get(delta.id);
    startedDownloads.delete(delta.id);
    if (startedC && startedC.historyKey) {
        clearInterruptedKey(startedC.historyKey); // completed download proves the key is valid history
    }
    try {
        const { autoCleanDownloadHistory } = await chrome.storage.sync.get(['autoCleanDownloadHistory']);
        if (autoCleanDownloadHistory === false) return; // default: enabled
        const results = await chrome.downloads.search({ id: delta.id });
        const item = results && results[0];
        if (item && item.byExtensionId === chrome.runtime.id) {
            await chrome.downloads.erase({ id: delta.id });
        }
    } catch (err) {
        console.warn('[auto-clean] failed:', err?.message || err);
    }
});

// Cache for videos pre-fetched at drag-start (url → Promise<{success, videoId?, size?, error?}>)
// Prevents 403s caused by short-lived signed CDN URLs that expire between dragstart and drop.
const preFetchedVideos = new Map();

// Offscreen document state
let creatingOffscreen = null;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Defense in depth: only accept messages originating from this extension
    // (content scripts, popup, sidepanel, offscreen all share chrome.runtime.id).
    if (sender.id !== chrome.runtime.id) {
        return false;
    }

    if (request.action === 'systemLogAppend') {
        if (request.entry && typeof request.entry === 'object') SystemLogger.appendEntries([request.entry]);
        sendResponse({ ok: true });
        return false;
    }

    // ---- Capture queue -------------------------------------------------
    if (request.action === 'captureItem') {
        captureManager.handleItem(request.item, { tabId: sender.tab?.id ?? null })
            .then(sendResponse).catch((e) => sendResponse({ accepted: false, error: e.message }));
        return true;
    }
    if (request.action === 'captureHeartbeat') {
        captureManager.heartbeat(sender.tab?.id ?? null).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
        return true;
    }
    if (request.action === 'captureParseError') {
        captureManager.noteParseError(Math.max(1, Math.min(100, Number(request.count) || 1))).then(() => sendResponse({ ok: true }));
        return true;
    }
    if (request.action === 'getCaptureStatus') {
        captureManager.status().then((st) => sendResponse({ success: true, ...st })).catch((e) => sendResponse({ success: false, error: e.message }));
        return true;
    }
    if (request.action === 'captureRetryFailed') {
        captureManager.retryFailed().then((n) => sendResponse({ success: true, requeued: n })).catch((e) => sendResponse({ success: false, error: e.message }));
        return true;
    }

    // Large files: fetch in the background (no 64 MB message limit, longer
    // timeout) and download from here. Used by content.js when its own
    // fetch+data-URL path times out or the file is too big to message.
    if (request.action === 'downloadViaBackground') {
        (async () => {
            const ctrl = new AbortController();
            const t = setTimeout(() => ctrl.abort(), 300000);
            try {
                const res = await credFetch(request.url, { signal: ctrl.signal });
                if (!res.ok) { sendResponse({ success: false, status: res.status, error: `HTTP ${res.status}` }); return; }
                const dataUrl = await readBlobAsDataUrl(await res.blob());
                ensureFilenameListener();
                downloadRouter.expect(dataUrl, { filename: request.filename, overwrite: request.overwrite === true });
                chrome.downloads.download({ url: dataUrl, filename: request.filename, saveAs: false,
                    conflictAction: request.overwrite === true ? 'overwrite' : 'uniquify' }, (downloadId) => {
                    if (chrome.runtime.lastError) {
                        downloadRouter.cancel(dataUrl);
                        sendResponse({ success: false, error: chrome.runtime.lastError.message });
                        return;
                    }
                    downloadRouter.bind(dataUrl, downloadId);
                    if (request.historyKey) startedDownloads.set(downloadId, { historyKey: request.historyKey, filename: request.filename, tabId: sender.tab?.id ?? null });
                    sendResponse({ success: true, downloadId });
                });
            } catch (e) {
                sendResponse({ success: false, timeout: e && e.name === 'AbortError', error: e && e.name === 'AbortError' ? 'Background fetch timed out (300s)' : e.message });
            } finally {
                clearTimeout(t);
            }
        })();
        return true;
    }

    if (request.action === 'download') {
        // Register listener + store intended filename (dynamic — only active while downloads are pending)
        ensureFilenameListener();
        downloadRouter.expect(request.url, {
            filename: request.filename,
            overwrite: request.overwrite === true
        });

        // Use a direct callback (not Promise/await) so Chrome keeps the service worker
        // alive during the native API callback — avoiding MV3 channel-closed errors.
        const hasQueryString = request.url.includes('?');
        console.log(`[download] ${request.filename} | hasQuery=${hasQueryString} | url=${request.url.substring(0, 80)}...`);
        chrome.downloads.download({
            url: request.url,
            filename: request.filename,
            saveAs: false,
            conflictAction: request.overwrite === true ? 'overwrite' : 'uniquify'
        }, (downloadId) => {
            if (chrome.runtime.lastError) {
                console.error(`[download] FAILED: ${request.filename} — ${chrome.runtime.lastError.message}`);
                downloadRouter.cancel(request.url);
                if (downloadRouter.size() === 0) {
                    chrome.downloads.onDeterminingFilename.removeListener(onDeterminingFilename);
                }
                sendResponse({ success: false, error: chrome.runtime.lastError.message });
            } else {
                downloadRouter.bind(request.url, downloadId);
                if (request.historyKey) {
                    startedDownloads.set(downloadId, {
                        historyKey: request.historyKey,
                        filename: request.filename,
                        tabId: sender.tab?.id ?? null
                    });
                }
                sendResponse({ success: true, downloadId });
            }
        });
        return true; // Keep channel open until callback fires
    }

    if (request.action === 'activateLicense') {
        validateLicense(request.licenseKey).then(result => {
            sendResponse(result);
        }).catch(error => {
            sendResponse({ success: false, error: error.message });
        });
        return true;
    }

    // Video merge request from side panel (legacy - with data)
    if (request.action === 'mergeVideos') {
        handleMergeVideos(request.files, request.includeAudio);
        sendResponse({ received: true });
        return true;
    }

    // Video merge request from side panel (new - with video IDs only, avoids 64MB limit)
    if (request.action === 'mergeVideosFromDB') {
        handleMergeVideosFromDB(request.videoInfos, request.targetWidth, request.targetHeight, request.includeAudio);
        sendResponse({ received: true });
        return true;
    }

    // Normalize video (scale to target resolution)
    if (request.action === 'normalizeVideo') {
        (async () => {
            try {
                await ensureOffscreenDocument();
                await new Promise(resolve => setTimeout(resolve, 100));

                const result = await chrome.runtime.sendMessage({
                    action: 'normalizeVideo',
                    videoData: request.videoData,
                    targetWidth: request.targetWidth,
                    targetHeight: request.targetHeight,
                    duration: request.duration,
                    hasAudio: request.hasAudio
                });

                sendResponse(result);
            } catch (error) {
                console.error('[Background] Video normalization failed:', error);
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // Download merged result
    if (request.action === 'downloadResult') {
        handleDownload(request.dataUrl, request.filename).then(() => {
            sendResponse({ success: true });
        }).catch(error => {
            sendResponse({ success: false, error: error.message });
        });
        return true;
    }

    // FFmpeg progress/complete/error from offscreen - forward to side panel
    if (request.action === 'ffmpegProgress' ||
        request.action === 'ffmpegComplete' ||
        request.action === 'ffmpegError') {
        // Forward to all extension pages (side panel will receive it)
        forwardToSidePanel(request);
        sendResponse({ received: true });
        return true;
    }

    // Open side panel request
    if (request.action === 'openSidePanel') {
        chrome.sidePanel.open({ windowId: request.windowId }).then(() => {
            sendResponse({ success: true });
        }).catch(error => {
            sendResponse({ success: false, error: error.message });
        });
        return true;
    }

    // ==========================================
    // Video Studio - IndexedDB Operations
    // ==========================================

    // Store video blob in IndexedDB
    if (request.action === 'storeVideoBlob') {
        (async () => {
            try {
                const videoData = new Uint8Array(request.videoData);
                const blob = new Blob([videoData], { type: 'video/mp4' });
                const videoId = await GrokDB.saveVideo(blob, request.metadata || {});
                sendResponse({ success: true, videoId });
            } catch (error) {
                console.error('[Background] Failed to store video:', error);
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // Capture video from URL directly in background (avoids 64MB message limit)
    if (request.action === 'captureVideoFromUrl') {
        (async () => {
            try {
                const response = await fetch(request.videoUrl, { credentials: 'include' });
                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                const blob = await response.blob();
                const metadata = { ...(request.metadata || {}), size: blob.size };
                const videoId = await GrokDB.saveVideo(blob, metadata);
                const sizeMB = (blob.size / 1024 / 1024).toFixed(2) + ' MB';
                sendResponse({ success: true, videoId, size: sizeMB });
            } catch (error) {
                console.error('[Background] Failed to capture video from URL:', error);
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // Download video directly from IndexedDB (avoids 64MB message limit)
    if (request.action === 'downloadVideoFromDB') {
        (async () => {
            try {
                const video = await GrokDB.getVideo(request.videoId);
                if (video) {
                    // Convert blob to base64 dataUrl for download API
                    const reader = new FileReader();
                    reader.onloadend = async () => {
                        try {
                            await handleDownload(reader.result, request.filename);
                            sendResponse({ success: true });
                        } catch (downloadError) {
                            sendResponse({ success: false, error: downloadError.message });
                        }
                    };
                    reader.onerror = () => {
                        sendResponse({ success: false, error: 'Failed to read video blob' });
                    };
                    reader.readAsDataURL(video.blob);
                } else {
                    sendResponse({ success: false, error: 'Video not found' });
                }
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // Get video from IndexedDB
    if (request.action === 'getVideoFromDB') {
        (async () => {
            try {
                const video = await GrokDB.getVideo(request.videoId);
                if (video) {
                    // Convert blob to array for transfer
                    const arrayBuffer = await video.blob.arrayBuffer();
                    sendResponse({
                        success: true,
                        video: {
                            id: video.id,
                            data: Array.from(new Uint8Array(arrayBuffer)),
                            metadata: video.metadata,
                            timestamp: video.timestamp
                        }
                    });
                } else {
                    sendResponse({ success: false, error: 'Video not found' });
                }
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // Get all videos from IndexedDB (metadata only, no blob data)
    if (request.action === 'getAllVideosFromDB') {
        (async () => {
            try {
                const videos = await GrokDB.getAllVideos();
                sendResponse({
                    success: true,
                    videos: videos.map(v => ({
                        id: v.id,
                        metadata: v.metadata,
                        timestamp: v.timestamp
                    }))
                });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // Delete video from IndexedDB
    if (request.action === 'deleteVideoFromDB') {
        (async () => {
            try {
                await GrokDB.deleteVideo(request.videoId);
                // Also delete associated frames
                const frames = await GrokDB.getFramesByVideoId(request.videoId);
                for (const frame of frames) {
                    await GrokDB.deleteFrame(frame.id);
                }
                sendResponse({ success: true });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // Extract frame from video using FFmpeg
    if (request.action === 'extractFrameFromVideo') {
        (async () => {
            try {
                // Get video from IndexedDB
                const video = await GrokDB.getVideo(request.videoId);
                if (!video) {
                    sendResponse({ success: false, error: 'Video not found' });
                    return;
                }

                // Ensure offscreen document is ready
                await ensureOffscreenDocument();
                await new Promise(resolve => setTimeout(resolve, 100));

                // Send videoId only — offscreen reads the blob from IndexedDB itself
                // to avoid boxing the whole video into a plain-number array (OOM risk).
                const result = await chrome.runtime.sendMessage({
                    action: 'extractFrame',
                    videoId: request.videoId,
                    position: request.position || 'last'
                });

                if (result.success) {
                    // Store frame in IndexedDB
                    const frameId = await GrokDB.saveFrame(
                        request.videoId,
                        result.dataUrl,
                        request.position || 'last'
                    );
                    sendResponse({ success: true, frameId, dataUrl: result.dataUrl });
                } else {
                    sendResponse({ success: false, error: result.error });
                }
            } catch (error) {
                console.error('[Background] Frame extraction failed:', error);
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // Analyze video specs using FFmpeg
    if (request.action === 'analyzeVideoFromDB') {
        (async () => {
            try {
                const video = await GrokDB.getVideo(request.videoId);
                if (!video) {
                    sendResponse({ success: false, error: 'Video not found' });
                    return;
                }

                await ensureOffscreenDocument();
                await new Promise(resolve => setTimeout(resolve, 100));

                // Send videoId only — offscreen reads the blob from IndexedDB itself
                // to avoid boxing the whole video into a plain-number array (OOM risk).
                const result = await chrome.runtime.sendMessage({
                    action: 'analyzeVideo',
                    videoId: request.videoId
                });

                if (result.success) {
                    // Update video metadata in IndexedDB
                    await GrokDB.updateVideoMetadata(request.videoId, result.info);
                    sendResponse({ success: true, info: result.info });
                } else {
                    sendResponse({ success: false, error: result.error });
                }
            } catch (error) {
                console.error('[Background] Video analysis failed:', error);
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // Get frame from IndexedDB
    if (request.action === 'getFrameFromDB') {
        (async () => {
            try {
                const frame = await GrokDB.getVideoFrame(request.videoId, request.position || 'last');
                if (frame) {
                    sendResponse({ success: true, frame });
                } else {
                    sendResponse({ success: false, error: 'Frame not found' });
                }
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // Save/update sequence
    if (request.action === 'saveSequence') {
        (async () => {
            try {
                await GrokDB.saveSequence(request.sequence);
                sendResponse({ success: true });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // Get sequence
    if (request.action === 'getSequence') {
        (async () => {
            try {
                const sequence = await GrokDB.getSequence();
                sendResponse({ success: true, sequence });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // Clear sequence
    if (request.action === 'clearSequence') {
        (async () => {
            try {
                await GrokDB.clearSequence();
                sendResponse({ success: true });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // Clear all IndexedDB data (videos, frames, sequence)
    if (request.action === 'clearAllDB') {
        (async () => {
            try {
                await GrokDB.clearAllData();
                sendResponse({ success: true });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // Get storage usage
    if (request.action === 'getStorageUsage') {
        (async () => {
            try {
                const usage = await GrokDB.getStorageUsage();
                sendResponse({ success: true, usage });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // Forward new video detected to sidepanel
    if (request.action === 'newVideoDetected') {
        forwardToSidePanel(request);
        sendResponse({ received: true });
        return true;
    }

    // Pre-fetch video at drag-start so the URL is still fresh when dropped in Story Mode.
    // Fire-and-forget: content.js sends this without waiting for a response.
    if (request.action === 'preFetchVideoForDrop') {
        if (!preFetchedVideos.has(request.url)) {
            const fetchPromise = (async () => {
                try {
                    const response = await fetch(request.url, {
                        credentials: 'include',
                        headers: { 'Accept': 'video/*,*/*' }
                    });
                    if (!response.ok) return { success: false, error: `HTTP ${response.status}: ${response.statusText}` };

                    const blob = await response.blob();
                    const contentType = blob.type || '';
                    if (contentType.startsWith('image/')) return { success: false, error: 'URL is an image, not a video' };
                    if (blob.size < 100 * 1024) {
                        const header = new Uint8Array(await blob.slice(0, 12).arrayBuffer());
                        if (GrokUtils.detectImageFromHeader(header).isImage) return { success: false, error: 'URL is an image thumbnail' };
                    }

                    const filename = GrokUtils.extractFilenameFromUrl(request.url, 'grok_video.mp4');
                    const videoId = await GrokDB.saveVideo(blob, {
                        name: filename,
                        sourceUrl: request.url,
                        size: blob.size,
                        isMaster: true,
                        capturedAt: Date.now()
                    });
                    console.log(`[Background] Pre-fetched video stored: ${videoId}`);
                    return { success: true, videoId, size: blob.size };
                } catch (error) {
                    return { success: false, error: error.message };
                }
            })();
            preFetchedVideos.set(request.url, fetchPromise);
            // Expire cache after 5 minutes
            setTimeout(() => preFetchedVideos.delete(request.url), 5 * 60 * 1000);
        }
        sendResponse({ received: true });
        return false;
    }

    // Fetch video from URL and store in IndexedDB (for drag-drop from Grok Favorites)
    if (request.action === 'fetchAndStoreVideo') {
        (async () => {
            try {
                // Use pre-fetched result if available (captured at drag-start while URL was fresh)
                if (preFetchedVideos.has(request.url)) {
                    const cached = await preFetchedVideos.get(request.url);
                    preFetchedVideos.delete(request.url);
                    if (cached.success) {
                        console.log(`[Background] Using pre-fetched video: ${cached.videoId}`);
                        sendResponse({ success: true, videoId: cached.videoId, size: cached.size });
                        return;
                    }
                    console.log('[Background] Pre-fetch failed, retrying:', cached.error);
                }

                console.log('[Background] Fetching video from URL:', request.url?.substring(0, 100) + '...');

                const response = await fetch(request.url, {
                    credentials: 'include',
                    headers: {
                        'Accept': 'video/*,*/*'
                    }
                });

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }

                const blob = await response.blob();
                const sizeMB = blob.size / 1024 / 1024;
                console.log(`[Background] Content fetched: ${sizeMB.toFixed(2)} MB, type: ${blob.type}`);

                // Validate that we got a video, not an image
                const contentType = blob.type || response.headers.get('content-type') || '';
                if (contentType.startsWith('image/')) {
                    throw new Error('This URL points to an image, not a video. Please drag the actual video element or copy the video URL.');
                }

                // Check file size - videos should be at least 100KB
                if (blob.size < 100 * 1024) {
                    // Try to detect if it's actually an image by checking magic bytes（使用 GrokUtils）
                    const header = new Uint8Array(await blob.slice(0, 12).arrayBuffer());
                    const imageDetection = GrokUtils.detectImageFromHeader(header);

                    if (imageDetection.isImage) {
                        throw new Error('This URL points to an image thumbnail, not a video. Try right-clicking the video and selecting "Copy video address".');
                    }

                    console.warn('[Background] File is very small, may not be a valid video');
                }

                // Determine filename from URL or use default（使用 GrokUtils）
                const filename = GrokUtils.extractFilenameFromUrl(request.url, 'grok_video.mp4');

                // Store in IndexedDB
                const videoId = await GrokDB.saveVideo(blob, {
                    name: request.filename || filename,
                    sourceUrl: request.url,
                    size: blob.size,
                    isMaster: request.isMaster || false,
                    capturedAt: Date.now()
                });

                console.log(`[Background] Video stored with ID: ${videoId}`);
                sendResponse({ success: true, videoId, size: blob.size });

            } catch (error) {
                console.error('[Background] fetchAndStoreVideo failed:', error);
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // ==========================================
    // Video Gen Queue - CRUD Operations
    // ==========================================

    if (request.action === 'addQueueItem') {
        (async () => {
            try {
                const item = await GrokQueueDB.addQueueItem(request.item);
                SystemLogger.info('Queue item added', `PostId: ${item.postId}, Target: ${item.targetSuccess}, MaxRetries: ${item.maxRetries}`);
                sendResponse({ success: true, item });
                // Notify side panel to refresh queue list
                chrome.runtime.sendMessage({ action: 'queueProgressUpdate' }).catch(() => {});
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'getQueueItem') {
        (async () => {
            try {
                const item = await GrokQueueDB.getQueueItem(request.id);
                sendResponse({ success: true, item });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'updateQueueItem') {
        (async () => {
            try {
                const item = await GrokQueueDB.updateQueueItem(request.id, request.updates);
                sendResponse({ success: true, item });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'updateQueueItemIf') {
        (async () => {
            try {
                const result = await GrokQueueDB.updateQueueItemIf(request.id, request.expectedStatus, request.updates);
                sendResponse({ success: true, applied: result.applied, item: result.item });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'getNextPendingItem') {
        (async () => {
            try {
                const item = await GrokQueueDB.getNextPendingItem();
                sendResponse({ success: true, item });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'reconcileQueueActive') {
        (async () => {
            try {
                const reset = await GrokQueueDB.reconcileStaleActiveItems();
                if (reset > 0) SystemLogger.info('Queue reconciled', `${reset} stale active item(s) reset to pending`);
                sendResponse({ success: true, reset });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'getActiveQueueItem') {
        (async () => {
            try {
                const item = await GrokQueueDB.getActiveQueueItem();
                sendResponse({ success: true, item });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'getAllQueueItems') {
        (async () => {
            try {
                const items = await GrokQueueDB.getAllQueueItems();
                sendResponse({ success: true, items });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'deleteQueueItem') {
        (async () => {
            try {
                await GrokQueueDB.deleteQueueItem(request.id);
                sendResponse({ success: true });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'deletePendingItems') {
        (async () => {
            try {
                const count = await GrokQueueDB.deletePendingItems();
                sendResponse({ success: true, count });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'deleteCompletedItems') {
        (async () => {
            try {
                const count = await GrokQueueDB.deleteCompletedItems();
                sendResponse({ success: true, count });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'clearQueue') {
        (async () => {
            try {
                await GrokQueueDB.clearQueue();
                sendResponse({ success: true });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // ==========================================
    // Video Gen Queue - Prompt Stats
    // ==========================================

    if (request.action === 'upsertPromptStats') {
        (async () => {
            try {
                const stats = await GrokQueueDB.upsertPromptStats(request.prompt, request.moderated);
                sendResponse({ success: true, stats });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'getAllPromptStats') {
        (async () => {
            try {
                const stats = await GrokQueueDB.getAllPromptStats();
                sendResponse({ success: true, stats });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'updatePromptRating') {
        (async () => {
            try {
                const stats = await GrokQueueDB.updatePromptRating(request.prompt, request.rating);
                sendResponse({ success: true, stats });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'clearPromptStats') {
        (async () => {
            try {
                await GrokQueueDB.clearPromptStats();
                sendResponse({ success: true });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // ==========================================
    // Video Gen Queue - Result Handler
    // ==========================================

    if (request.action === 'videoGenResult') {
        // Parallel "save" consumer: auto-capture the finished video when
        // Stream Capture is on. Moderated results are recorded, never fetched.
        // Deduped by video post id, so the content-script fallback re-send is
        // harmless. Queue counting below is untouched.
        if (request.videoPostId) {
            chrome.storage.local.get(GrokCaptureManager.ENABLED_KEY).then((r) => {
                if (r[GrokCaptureManager.ENABLED_KEY] !== true) return;
                return captureManager.handleItem({ kind: 'video', mediaId: request.videoPostId, moderated: request.moderated === true, source: 'video-gen' }, { tabId: sender.tab?.id ?? null });
            }).catch((e) => console.warn('[capture] video auto-save failed to queue:', e && e.message));
        }
        (async () => {
            try {
                // Find active queue item — since only one item processes at a time,
                // any video gen result during active processing is for the current item.
                // Note: parentPostId from Grok's API may differ from the image postId
                // (it can be the conversation post ID), so we don't strictly match.
                const activeItem = await GrokQueueDB.getActiveQueueItem();

                if (!activeItem) {
                    // No active queue item — might be manual generation, or the original
                    // result already completed the item but its relay to the tab was lost.
                    // Include the next pending item so the fallback can keep the queue moving.
                    const nextItem = await GrokQueueDB.getNextPendingItem();
                    SystemLogger.info('Queue videoGenResult ignored', `No active item, parentPostId: ${request.parentPostId}`);
                    sendResponse({ success: true, queued: false, nextItem: nextItem || null });
                    return;
                }
                SystemLogger.info('Queue videoGenResult matched', `activeItem: ${activeItem.postId}, parentPostId: ${request.parentPostId}`);

                // Idempotency: the content-script fallback may re-send the same result
                // if the bridge relay was merely slow. Never double-count.
                // Note: this is a best-effort read-check, not an atomic compare-and-set —
                // duplicate suppression is only guaranteed when the first write commits
                // before this read runs, which holds here since the fallback waits 5s.
                if (request.resultId && activeItem.lastResultId === request.resultId) {
                    SystemLogger.info('Queue videoGenResult duplicate ignored', `resultId: ${request.resultId}`);
                    // Already processed — but the earlier queueItemResult relay to the tab
                    // may have been lost (that is usually why the fallback re-sent this).
                    // Re-relay from persisted state so the queue never stalls: the item is
                    // still 'active', so the correct instruction is a retry.
                    if (sender.tab && sender.tab.id) {
                        chrome.tabs.sendMessage(sender.tab.id, {
                            action: 'queueItemResult',
                            queueItem: activeItem,
                            moderated: request.moderated,
                            shouldRetry: true,
                            shouldMoveNext: false,
                            nextItem: null,
                            usageLimitReached: false
                        }).catch(() => {});
                    }
                    sendResponse({ success: true, queued: true, duplicate: true });
                    return;
                }

                // Update queue item counts + determine next action (pure decision logic)
                const { updates, shouldRetry, shouldMoveNext } =
                    QueueLogic.computeQueueResultUpdates(activeItem, request.moderated, request.resultId || null);

                if (request.moderated) {
                    SystemLogger.fail('Queue video moderated', `PostId: ${activeItem.postId}, Failure: ${updates.currentFailure}/${activeItem.maxRetries}`);
                } else {
                    SystemLogger.ok('Queue video generated', `PostId: ${activeItem.postId}, Success: ${updates.currentSuccess}/${activeItem.targetSuccess}`);

                    // Increment queue video gen usage count (non-critical: a sync
                    // quota/network failure must not abort result processing)
                    try {
                        const { queueVideoGenCount = 0 } = await chrome.storage.sync.get('queueVideoGenCount');
                        await chrome.storage.sync.set({ queueVideoGenCount: queueVideoGenCount + 1 });
                    } catch (e) {
                        SystemLogger.warn('queueVideoGenCount update failed', e.message);
                    }
                }

                // Update prompt stats
                await GrokQueueDB.upsertPromptStats(activeItem.prompt, request.moderated);

                const newSuccess = updates.currentSuccess !== undefined ? updates.currentSuccess : activeItem.currentSuccess;

                if (updates.status === 'completed') {
                    SystemLogger.ok('Queue item completed', `PostId: ${activeItem.postId}, Success: ${newSuccess}`);
                } else if (updates.status === 'failed') {
                    SystemLogger.fail('Queue item failed', `PostId: ${activeItem.postId}, Max retries reached`);
                }

                const updatedItem = await GrokQueueDB.updateQueueItem(activeItem.id, updates);

                // Get next item if moving on (check usage limit for non-Pro)
                let nextItem = null;
                let usageLimitReached = false;
                if (shouldMoveNext) {
                    const { queueVideoGenCount: currentCount = 0, isPro: isProUser = false } = await chrome.storage.sync.get(['queueVideoGenCount', 'isPro']);
                    if (!isProUser && currentCount >= 50) {
                        usageLimitReached = true;
                        SystemLogger.fail('Queue usage limit reached', `Count: ${currentCount}/50`);
                    } else {
                        nextItem = await GrokQueueDB.getNextPendingItem();
                    }
                }

                // Relay result to content.js tab
                SystemLogger.info('Queue relay to content', `shouldRetry: ${shouldRetry}, shouldMoveNext: ${shouldMoveNext}, usageLimitReached: ${usageLimitReached}, tabId: ${sender.tab?.id || 'none'}`);
                if (sender.tab && sender.tab.id) {
                    chrome.tabs.sendMessage(sender.tab.id, {
                        action: 'queueItemResult',
                        queueItem: updatedItem,
                        moderated: request.moderated,
                        shouldRetry,
                        shouldMoveNext,
                        nextItem,
                        usageLimitReached
                    }).catch((err) => {
                        SystemLogger.fail('Queue relay failed', `Error: ${err.message}`);
                    });
                } else {
                    SystemLogger.fail('Queue relay failed', 'No sender.tab.id available');
                }

                // Forward update to sidepanel for real-time UI refresh
                forwardToSidePanel({
                    action: 'queueProgressUpdate',
                    queueItem: updatedItem,
                    moderated: request.moderated,
                    shouldMoveNext,
                    nextItem,
                    usageLimitReached
                });

                sendResponse({ success: true, queued: true });
            } catch (error) {
                console.error('[Background] videoGenResult handler error:', error);
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // ==========================================
    // Video Gen Queue - Error Handler
    // ==========================================

    if (request.action === 'queueItemError') {
        (async () => {
            try {
                const activeItem = await GrokQueueDB.getActiveQueueItem();
                if (activeItem) {
                    await GrokQueueDB.updateQueueItem(activeItem.id, {
                        status: 'error',
                        errorMessage: request.error
                    });
                    SystemLogger.fail('Queue item error', `PostId: ${activeItem.postId}, Error: ${request.error}`);
                }

                // Notify sidepanel about error
                forwardToSidePanel({
                    action: 'queueItemError',
                    error: request.error,
                    queueItem: activeItem
                });

                sendResponse({ success: true });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'queueRetryErrorItem') {
        (async () => {
            try {
                // Reset to pending — item will be picked up by normal queue processing order
                await GrokQueueDB.updateQueueItem(request.id, { status: 'pending', errorMessage: null });

                sendResponse({ success: true });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    if (request.action === 'queueSkipErrorItem') {
        (async () => {
            try {
                await GrokQueueDB.updateQueueItem(request.id, { status: 'failed' });
                const nextItem = await GrokQueueDB.getNextPendingItem();

                if (request.tabId) {
                    chrome.tabs.sendMessage(request.tabId, {
                        action: 'queueProcessNext',
                        nextItem
                    }).catch(() => {});
                }

                forwardToSidePanel({
                    action: 'queueProgressUpdate',
                    nextItem
                });

                sendResponse({ success: true, nextItem });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // ==========================================
    // Queue Usage
    // ==========================================

    if (request.action === 'getQueueUsage') {
        (async () => {
            try {
                const { queueVideoGenCount = 0, isPro = false } = await chrome.storage.sync.get(['queueVideoGenCount', 'isPro']);
                sendResponse({ success: true, count: queueVideoGenCount, limit: 50, isPro });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // ==========================================
    // Sidepanel Switching
    // ==========================================

    if (request.action === 'switchSidePanel') {
        (async () => {
            try {
                await chrome.sidePanel.setOptions({ path: request.path });
                sendResponse({ success: true });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // Manually erase all completed downloads created by this extension.
    // Files on disk are untouched — only Chrome's in-browser history records are removed.
    if (request.action === 'clearGrokDownloadHistory') {
        (async () => {
            try {
                const items = await chrome.downloads.search({
                    byExtensionId: chrome.runtime.id,
                    state: 'complete',
                    limit: 0
                });
                let erased = 0;
                for (const item of items) {
                    try {
                        await chrome.downloads.erase({ id: item.id });
                        erased++;
                    } catch (innerErr) {
                        console.warn('[clearGrokDownloadHistory] erase failed for', item.id, innerErr?.message);
                    }
                }
                sendResponse({ success: true, erased });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        })();
        return true;
    }

    // 不處理其他消息，不返回 true，避免通道懸空
    return false;
});

// Named listener so we can add/remove dynamically — only registered while downloads are pending
function onDeterminingFilename(item, suggest) {
    const options = downloadRouter.resolve(item);
    if (options) {
        suggest({
            filename: options.filename,
            conflictAction: options.overwrite ? 'overwrite' : 'uniquify'
        });

        if (downloadRouter.size() === 0) {
            chrome.downloads.onDeterminingFilename.removeListener(onDeterminingFilename);
        }
    }
    // Unknown download: don't call suggest — let Chrome handle it automatically
}

async function validateLicense(licenseKey) {
    // 真正的驗證邏輯
    // TODO: 請在此處填入您的 Lemon Squeezy Product ID
    // 您可以在 Lemon Squeezy 後台的 Products 列表中找到 ID (例如: 12345)
    const REQUIRED_PRODUCT_ID = '701501';

    try {
        // 開發者測試 Key
        if (licenseKey === 'DEV-TEST-8888') {
            // 檢查是否為開發模式 (未打包安裝通常沒有 update_url)
            const isDevelopment = !chrome.runtime.getManifest().update_url;

            if (!isDevelopment) {
                return { success: false, error: 'Developer key is not available in production build' };
            }

            await chrome.storage.sync.set({
                licenseKey: licenseKey,
                isPro: true,
                licenseData: {
                    activated: true,
                    meta: {
                        variant_name: 'Developer License'
                    }
                }
            });
            return { success: true, data: { activated: true } };
        }

        const response = await fetch('https://api.lemonsqueezy.com/v1/licenses/activate', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                license_key: licenseKey,
                instance_name: 'GrokDownloadExtension'
            })
        });

        const data = await response.json();

        if (data.activated) {
            // 驗證 Product ID (確保 Key 屬於正確的產品)
            // 如果您設置了 REQUIRED_PRODUCT_ID，我們會檢查它是否匹配
            if (REQUIRED_PRODUCT_ID && data.meta.product_id !== parseInt(REQUIRED_PRODUCT_ID)) {
                return {
                    success: false,
                    error: '此 License Key 不屬於本產品 (Product ID 不匹配)'
                };
            }

            // 保存授權狀態 (使用 sync 以便跨設備同步)
            await chrome.storage.sync.set({
                licenseKey: licenseKey,
                isPro: true,
                licenseData: data
            });
            return { success: true, data: data };
        } else {
            return { success: false, error: data.error || 'Invalid license key' };
        }
    } catch (error) {
        return { success: false, error: error.message };
    }
}

// 遷移舊的本地授權到同步存儲，並自我修復同步存儲中損壞/漂移的授權項目。
// Local (chrome.storage.local) 永遠是授權真相來源；sync 只是盡力而為的跨裝置備份。
// 修復方向永遠是「local → sync」單向：絕不從 sync 反向覆蓋 local，也絕不在
// local 非 Pro 時碰觸 sync — 避免誤將非授權使用者升級為 Pro，或誤將合法 Pro
// 使用者降級。若 sync 自己持有 Pro 狀態而 local 沒有，那不在本函式處理範圍內
// (可能是合法的 sync-only 授權，不應被清除)。
async function migrateLicenseToSync() {
    try {
        // 檢查本地是否有授權
        const localData = await chrome.storage.local.get(['isPro', 'licenseKey', 'licenseData']);

        if (localData.isPro === true && localData.licenseKey) {
            // 讀取 sync 存儲，獨立包在自己的 try/catch — 讀取本身拋出
            // (例如 LevelDB 損壞) 不可以讓整個遷移/修復流程中斷或拋出。
            let syncData = null;
            let syncReadFailed = false;
            try {
                syncData = await chrome.storage.sync.get(['isPro', 'licenseKey']);
            } catch (syncReadError) {
                syncReadFailed = true;
                console.warn('[License] chrome.storage.sync.get threw (possibly corrupt store):', syncReadError?.message);
            }

            // 判斷 sync 是否需要修復：讀取失敗 / 缺少 isPro / licenseKey 與本地
            // 不一致 (代表 sync 資料漂移或已損毀成垃圾值)。
            const needsHeal = syncReadFailed
                || !syncData
                || syncData.isPro !== true
                || syncData.licenseKey !== localData.licenseKey;

            if (needsHeal) {
                console.warn('[License] Sync license entry missing/corrupt/drifted — self-healing from local storage (source of truth).');

                // Overwrite via set (no remove — a failed set must never strip a
                // working isPro). set() 對這三個 key 已是完整覆寫，不需要先
                // remove()。若先 remove() 再 set()，set 失敗時會留下「已清除但
                // 尚未寫入」的空窗，等於把合法 Pro 使用者降級。只用單一 set()，
                // 失敗時 sync 會維持修復前的狀態 (漂移案例下仍是 isPro:true)，
                // 確保修復失敗絕不會讓使用者比修復前更差。
                try {
                    await chrome.storage.sync.set({
                        isPro: true,
                        licenseKey: localData.licenseKey,
                        licenseData: localData.licenseData
                    });
                    console.log('[License] Self-heal complete: sync license entry rewritten from local storage.');
                } catch (setError) {
                    console.error('[License] chrome.storage.sync.set during self-heal failed — local license remains authoritative, sync stays best-effort:', setError?.message);
                }
            } else {
                console.log('[License] Sync storage already consistent with local license — no heal needed.');
            }
        }
    } catch (error) {
        console.error('Migration failed:', error);
    }
}

// 測試專用匯出：正式的 MV3 Service Worker 透過 manifest 的 importScripts 直接
// 載入本檔案，不存在 `module`；此區塊只在 Node/Jest 環境下生效，不影響正式行為。
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { migrateLicenseToSync, recordInterruptedKey, clearInterruptedKey };
}

// 在擴充功能啟動或安裝時運行遷移
chrome.runtime.onInstalled.addListener(() => {
    migrateLicenseToSync();
    // Enable side panel for all tabs
    chrome.sidePanel.setOptions({
        enabled: true,
        path: 'sidepanel/sidepanel.html'
    });
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false });
});
chrome.runtime.onStartup.addListener(() => {
    migrateLicenseToSync();
    GrokDB.cleanupOrphanVideos().catch(err =>
        console.warn('[Background] Orphan video cleanup failed:', err?.message));
});

async function handleDownload(url, filename) {
    return new Promise((resolve, reject) => {
        chrome.downloads.download({
            url: url,
            filename: filename,
            saveAs: false
        }, (downloadId) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            } else {
                resolve(downloadId);
            }
        });
    });
}

// ==========================================
// Offscreen Document Management
// ==========================================

async function ensureOffscreenDocument() {
    const offscreenUrl = 'offscreen/offscreen.html';

    // Check if already exists
    const existingContexts = await chrome.runtime.getContexts({
        contextTypes: ['OFFSCREEN_DOCUMENT'],
        documentUrls: [chrome.runtime.getURL(offscreenUrl)]
    });

    if (existingContexts.length > 0) {
        return; // Already exists
    }

    // Avoid race condition with multiple creation requests
    if (creatingOffscreen) {
        await creatingOffscreen;
        return;
    }

    creatingOffscreen = chrome.offscreen.createDocument({
        url: offscreenUrl,
        reasons: ['WORKERS'],
        justification: 'Run ffmpeg.wasm for video processing'
    }).finally(() => {
        creatingOffscreen = null;
    });

    await creatingOffscreen;
    console.log('[Background] Offscreen document created');
}

async function closeOffscreenDocument() {
    try {
        await chrome.offscreen.closeDocument();
        console.log('[Background] Offscreen document closed');
    } catch (error) {
        // Ignore if not open
    }
}

// Handle video merge request (legacy - receives full data)
async function handleMergeVideos(files, includeAudio = true) {
    console.log('[Background] Starting video merge with', files.length, 'files, includeAudio:', includeAudio);

    try {
        // Ensure offscreen document is ready
        await ensureOffscreenDocument();

        // Small delay to ensure offscreen is fully loaded
        await new Promise(resolve => setTimeout(resolve, 100));

        // Send files to offscreen for processing
        chrome.runtime.sendMessage({
            action: 'concat',
            files: files,
            includeAudio: includeAudio
        });

    } catch (error) {
        console.error('[Background] Failed to start merge:', error);
        forwardToSidePanel({
            action: 'ffmpegError',
            error: `Failed to start processing: ${error.message}`
        });
    }
}

// Handle video merge request from DB (new - avoids 64MB limit)
// Offscreen document reads directly from IndexedDB
async function handleMergeVideosFromDB(videoInfos, targetWidth, targetHeight, includeAudio = true) {
    console.log('[Background] Starting video merge from DB with', videoInfos.length, 'videos');

    try {
        // Ensure offscreen document is ready
        await ensureOffscreenDocument();

        // Small delay to ensure offscreen is fully loaded
        await new Promise(resolve => setTimeout(resolve, 100));

        // Send only video IDs to offscreen - it will read from IndexedDB directly
        chrome.runtime.sendMessage({
            action: 'concatFromDB',
            videoInfos: videoInfos,
            targetWidth: targetWidth,
            targetHeight: targetHeight,
            includeAudio: includeAudio
        });

    } catch (error) {
        console.error('[Background] Failed to start merge from DB:', error);
        forwardToSidePanel({
            action: 'ffmpegError',
            error: `Failed to start processing: ${error.message}`
        });
    }
}

// Forward message to side panel
function forwardToSidePanel(message) {
    // Send to all extension contexts - side panel will receive it
    chrome.runtime.sendMessage(message).catch(() => {
        // Ignore errors if no listeners
    });
}

