// node test/capture.test.js — capture core, IndexedDB queue (fake-indexeddb), manager, download router.
// Needs fake-indexeddb on NODE_PATH for the DB/manager part (test/run-all.sh sets it).
const assert = require('assert');
const C = require('../lib/capture-core.js');
const { createRouter } = require('../src/download-router.js');
const U1 = '1b4e28ba-2fa1-11d2-883f-0016d3cca427', U2 = '6fa459ea-ee8a-3ca4-894e-db77e160355e', U3 = '16fd2706-8baf-433b-82eb-8c7fada847da';

(async () => {
  // ---- core ----
  assert.strictEqual(C.dedupeKey({ mediaId: U1.toUpperCase() }), 'id:' + U1);
  assert.strictEqual(C.dedupeKey({ sha256: 'A'.repeat(64) }), 'sha:' + 'a'.repeat(64));
  assert.strictEqual(C.dedupeKey({}), null);
  assert.strictEqual(C.isBlocked({ moderated: true }), true);
  assert.strictEqual(C.isBlocked({ moderationStatus: 'MODERATION_STATUS_BLOCKED' }), true);
  assert.strictEqual(C.isBlocked({ moderated: false, status: 'DONE' }), false);
  const fn = C.stableFilename({ basePath: 'grok_downloads/stream/', mediaId: U1, kind: 'video', createdAt: new Date(2026, 9, 19, 15, 0).getTime() });
  assert.strictEqual(fn, `grok_downloads/stream/2026-10-19/2026-10-19_${U1}.mp4`);
  assert.ok(/\/2026-10-19_sha-abcdefabcdefabcd\.png$/.test(C.stableFilename({ sha256: 'abcdef'.repeat(11), mime: 'image/png', createdAt: new Date(2026, 9, 19).getTime() })));
  console.log('PASS 1: dedupeKey / isBlocked / stableFilename (date + media id)');

  // network extraction: video-gen final, image-gen progress, WS blob, blocked, prompt never returned
  const sse = { result: { response: { streamingVideoGenerationResponse: { progress: 100, videoPostId: U1, videoUrl: `https://assets.grok.com/users/x/${U1}/generated_video.mp4`, moderated: false, prompt: 'SECRET' } } } };
  let r = C.extractMediaResults(sse);
  assert.strictEqual(r.length, 1); assert.strictEqual(r[0].kind, 'video'); assert.strictEqual(r[0].mediaId, U1); assert.strictEqual(r[0].blocked, false);
  assert.ok(!JSON.stringify(r).includes('SECRET'), 'no prompt text extracted');
  assert.strictEqual(C.extractMediaResults({ streamingVideoGenerationResponse: { progress: 40, videoPostId: U1 } }).length, 0, 'unfinished video ignored');
  r = C.extractMediaResults({ streamingImageGenerationResponse: { imageId: U2, imageUrl: `https://assets.grok.com/users/x/generated/${U2}/image.jpg`, progress: 100 } });
  assert.strictEqual(r.length, 1); assert.strictEqual(r[0].kind, 'image'); assert.strictEqual(r[0].mediaId, U2);
  assert.strictEqual(C.extractMediaResults({ streamingImageGenerationResponse: { imageId: U2, imageUrl: `https://assets.grok.com/a/${U2}.jpg`, progress: 50 } }).length, 0);
  r = C.extractMediaResults({ type: 'image', url: `https://grok.com/images/${U3}.jpg`, blob: 'A'.repeat(5000), stage: 'final' });
  assert.strictEqual(r.length, 1); assert.strictEqual(r[0].mediaId, U3); assert.ok(r[0].dataBase64);
  assert.strictEqual(C.extractMediaResults({ type: 'image', url: `x/${U3}`, blob: 'A'.repeat(5000), stage: 'preview' }).length, 0, 'preview stage ignored');
  r = C.extractMediaResults({ streamingVideoGenerationResponse: { progress: 100, videoPostId: U3, moderated: true } });
  assert.strictEqual(r[0].blocked, true);
  assert.deepStrictEqual(C.extractMediaResults({ unrelated: { url: 'https://evil.example.com/x.jpg', id: U1 } }), [], 'foreign hosts ignored');
  assert.deepStrictEqual(C.extractMediaResults('not json'), []);
  assert.strictEqual(C.parseEventLine('data: {"a":1}').a, 1);
  assert.strictEqual(C.parseEventLine('data: {broken'), null);
  assert.strictEqual(C.parseEventLine(': keepalive'), undefined);
  console.log('PASS 2: extractMediaResults (video final, image final, WS final blob, blocked flag, foreign host, no prompt)');

  // final rendition + retry policy + prune + health
  const base = { src: 'data:x', lastSrc: 'data:x', changedAt: 0, complete: true, naturalWidth: 1024, naturalHeight: 1024 };
  assert.strictEqual(C.isFinalRendition({ ...base, now: 1600 }), true);
  assert.strictEqual(C.isFinalRendition({ ...base, now: 1000 }), false, 'still changing');
  assert.strictEqual(C.isFinalRendition({ ...base, now: 1600, naturalWidth: 300, naturalHeight: 300 }), false, 'preview size');
  assert.strictEqual(C.isFinalRendition({ ...base, now: 1600, lastSrc: 'data:y' }), false);
  assert.deepStrictEqual([1, 2, 3].map((a) => C.nextRetry({ attempts: a, status: 403 }).delayMs), [5000, 30000, 120000]);
  assert.strictEqual(C.nextRetry({ attempts: 4, status: 404 }).retry, false);
  assert.strictEqual(C.nextRetry({ attempts: 1, status: 410 }).reresolve, true);
  assert.strictEqual(C.nextRetry({ attempts: 1, timeout: true }).retry, true);
  assert.strictEqual(C.nextRetry({ attempts: 1, status: 400 }).retry, false);
  assert.strictEqual(C.nextRetry({ attempts: 1, blocked: true }).retry, false);
  const day = 24 * 3600e3, T = 200 * day;
  const p = C.selectPrunable([
    { key: 'a', status: 'saved', updatedAt: T - 100 * day }, { key: 'b', status: 'saved', updatedAt: T - day, dataUrl: 'data:x' },
    { key: 'c', status: 'failed', updatedAt: T - 40 * day }, { key: 'd', status: 'pending', updatedAt: T - 400 * day }], T);
  assert.deepStrictEqual(p.delete.sort(), ['a', 'c']); assert.deepStrictEqual(p.stripPayload, ['b']);
  const line = C.formatHealth({ enabled: true, lastHeartbeatAt: 1000, lastSavedAt: 500, saved: 3, failed: 1 }, 11000, () => '3:14 PM');
  assert.strictEqual(line, 'Capture alive (10s ago) · last saved 3:14 PM · 3 saved · 1 failed');
  assert.ok(C.formatHealth({ enabled: false }, 0).startsWith('Capture off'));
  console.log('PASS 3: final-rendition check, retry 5s/30s/120s (re-resolve on 403/404/410), prune, health line');

  // ---- download router ----
  const rt = createRouter();
  rt.expect('data:same', { filename: 'a.png' }); rt.expect('data:same', { filename: 'b.png' });
  rt.bind('data:same', 1);                                           // callback first for #1
  assert.strictEqual(rt.resolve({ id: 2, url: 'data:same' }).filename, 'b.png'); // listener first for #2
  rt.bind('data:same', 2);
  assert.strictEqual(rt.resolve({ id: 1, url: 'data:same' }).filename, 'a.png');
  assert.strictEqual(rt.resolve({ id: 3, url: 'data:other' }), null); assert.strictEqual(rt.size(), 0);
  console.log('PASS 4: download router keeps same-URL downloads apart (by id, FIFO)');

  // ---- DB + manager ----
  try { require('fake-indexeddb/auto'); } catch (e) { console.log('SKIP 5-7: fake-indexeddb not on NODE_PATH'); console.log('ALL TESTS PASSED'); return; }
  const DB = require('../lib/capture-db.js');
  const { createCaptureManager } = require('../src/capture-manager.js');
  const store = {}; let nextId = 100; const downloads = []; let clock = 1_000_000;
  const chromeApi = {
    storage: { local: { get: async (k) => ({ [k]: store[k] }), set: async (o) => Object.assign(store, o) } },
    downloads: { download: (opts, cb) => { downloads.push(opts); cb(nextId++); } },
    runtime: { lastError: null }, alarms: { create: () => {} }
  };
  let fetchPlan = []; const fetched = [];
  const fetchImpl = async (url) => { fetched.push(url); const st = fetchPlan.shift() ?? 200;
    return st === 200 ? { ok: true, status: 200, blob: async () => ({ type: 'video/mp4' }) } : { ok: false, status: st }; };
  const timers = [];
  const resolved = [];
  const m = createCaptureManager({ db: DB, core: C, chromeApi, fetchImpl, now: () => clock,
    resolveVideo: async (id) => { resolved.push(id); return { url: `https://assets.grok.com/u/${id}/v${resolved.length}.mp4` }; },
    readBlobAsDataUrl: async () => 'data:video/mp4;base64,AAAA', setTimer: (fn, ms) => { timers.push(ms); return 0; } });

  // image from DOM: queued, downloaded, saved only on complete; dupes skipped
  let a = await m.handleItem({ kind: 'image', dataUrl: 'data:image/png;base64,iVBOR', sha256: 'f'.repeat(64), source: 'dom' });
  assert.strictEqual(a.accepted, true); await m.idle();
  let row = await DB.get(a.key);
  assert.strictEqual(row.status, 'downloading', 'not saved at download start'); assert.strictEqual(downloads.length, 1);
  assert.ok(/stream\/\d{4}-\d\d-\d\d\/\d{4}-\d\d-\d\d_sha-ffffffffffffffff\.png$/.test(downloads[0].filename));
  assert.strictEqual(downloads[0].conflictAction, 'uniquify');
  assert.strictEqual((await m.handleItem({ kind: 'image', dataUrl: 'data:image/png;base64,iVBOR', sha256: 'f'.repeat(64) })).duplicate, true);
  await m.onDownloadChanged({ id: row.downloadId, state: { current: 'complete' } });
  row = await DB.get(a.key);
  assert.strictEqual(row.status, 'saved'); assert.strictEqual(row.dataUrl, null, 'payload pruned on save');
  assert.strictEqual((await m.handleItem({ kind: 'image', dataUrl: 'data:image/png;base64,iVBOR', sha256: 'f'.repeat(64) })).duplicate, true, 'ledger dedupe after save');
  console.log('PASS 5: DOM image -> IndexedDB -> download -> saved only on complete; dedupe vs ledger; payload pruned');

  // finished video: background fetch; 403 then 404 then OK -> 3 fetches, URL re-resolved, then saved
  fetchPlan = [403, 404, 200];
  a = await m.handleItem({ kind: 'video', mediaId: U1, source: 'video-gen' }); await m.idle();
  row = await DB.get(a.key); assert.strictEqual(row.status, 'retry'); assert.strictEqual(row.attempts, 1); assert.strictEqual(row.url, null, 're-resolve after 403');
  clock += 5000; await m.runDue(); await m.idle();
  row = await DB.get(a.key); assert.strictEqual(row.status, 'retry'); assert.strictEqual(row.attempts, 2);
  clock += 30000; await m.runDue(); await m.idle();
  row = await DB.get(a.key); assert.strictEqual(row.status, 'downloading');
  assert.strictEqual(fetched.length, 3); assert.strictEqual(resolved.length, 3, 'URL re-resolved each retry');
  assert.deepStrictEqual(timers.filter((ms) => ms <= 30000), [5000, 30000], 'retry timers'); assert.ok(timers.includes(180000), 'video fetch timeout 180s');
  // download interrupted (timeout) -> retry 3 (120s) -> then exhausted -> failed
  await m.onDownloadChanged({ id: row.downloadId, state: { current: 'interrupted' }, error: { current: 'NETWORK_TIMEOUT' } });
  row = await DB.get(a.key); assert.strictEqual(row.status, 'retry'); assert.strictEqual(row.attempts, 3);
  assert.strictEqual(row.nextAttemptAt - clock, 120000);
  clock += 120000; fetchPlan = [410]; await m.runDue(); await m.idle();
  row = await DB.get(a.key); assert.strictEqual(row.status, 'failed'); assert.strictEqual(row.attempts, 4);
  console.log('PASS 6: video background fetch retries 403/404/410/timeout x3 (5s/30s/120s) with re-resolve, then failed');

  // blocked/moderated: recorded, never fetched; retryFailed requeues; status line
  const before = fetched.length;
  const b = await m.handleItem({ kind: 'video', mediaId: U2, moderated: true, source: 'video-gen' });
  assert.strictEqual(b.blocked, true); await m.idle(); assert.strictEqual(fetched.length, before, 'blocked never fetched');
  assert.strictEqual((await DB.get('id:' + U2)).status, 'blocked');
  assert.strictEqual((await m.handleItem({ kind: 'image', url: 'https://evil.example.com/x.jpg', mediaId: U3 })).reason, 'host');
  fetchPlan = [200];
  assert.strictEqual(await m.retryFailed(), 1); await m.idle();
  assert.strictEqual((await DB.get('id:' + U1)).status, 'downloading');
  await m.heartbeat(7);
  store.streamCaptureEnabled = true;
  const st = await m.status();
  assert.strictEqual(st.counts.saved, 1); assert.strictEqual(st.counts.blocked, 1);
  assert.ok(st.line.startsWith('Capture alive (0s ago) · last saved'), st.line);
  console.log('PASS 7: blocked skipped (never fetched), foreign host rejected, retryFailed, status line:', st.line);
  console.log('ALL TESTS PASSED');
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
