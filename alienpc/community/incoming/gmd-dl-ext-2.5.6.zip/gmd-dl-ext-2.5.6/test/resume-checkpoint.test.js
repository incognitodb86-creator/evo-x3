// node test/resume-checkpoint.test.js — mocks fetch + storage; no network, no timers.
const assert = require('assert');
const GA = require('../src/grok-assets.js');
const PER = 60;
const sleepImpl = async () => {};
let PAGES = 6;
const id = (p, i) => `a-${p}-${i}`;
const mk = (p, i) => ({ assetId: id(p, i), mimeType: 'image/jpeg', key: `k${p}-${i}`, isModelGenerated: true,
  createTime: new Date(Date.UTC(2026, 9, 19) - (p * PER + i) * 60000).toISOString() });
function mockFetch({ failPage = null, failTimes = 0, extraHead = 0 } = {}) {
  const calls = []; let left = failTimes;
  const f = async (url) => {
    const u = new URL(url); const ids = u.searchParams.getAll('assetIds');
    if (ids.length) { calls.push('ids:' + ids.length);
      return { ok: true, json: async () => ({ assets: ids.map((x) => { const [, p, i] = x.split('-'); return mk(Number(p), Number(i)); }) }) }; }
    const tok = u.searchParams.get('pageToken'); const p = tok ? Number(tok) : 1; calls.push(p);
    if (p === failPage && left > 0) { left--; return { ok: false, status: 503, headers: { get: () => null } }; }
    let rows = Array.from({ length: PER }, (_, i) => mk(p, i));
    if (p === 1 && extraHead) rows = [...Array.from({ length: extraHead }, (_, i) => mk(0, i)), ...rows].slice(0, PER);
    return { ok: true, json: async () => ({ assets: rows, nextPageToken: p < PAGES ? String(p + 1) : null }) };
  };
  f.calls = calls; return f;
}
const memStore = () => { const s = { cp: null, saves: 0, clears: 0 };
  s.load = async () => s.cp; s.save = async (cp) => { s.saves++; s.cp = JSON.parse(JSON.stringify(cp)); }; s.clear = async () => { s.clears++; s.cp = null; }; return s; };
(async () => {
  // 1) healthy full scan: checkpoint written per page, cleared at the end
  let st = memStore(); let f = mockFetch();
  let r = await GA.scanAllWithCheckpoint(f, { store: st, scope: {}, sleepImpl });
  assert.strictEqual(r.assets.length, PAGES * PER); assert.strictEqual(r.completed, true); assert.strictEqual(r.resumed, false);
  assert.strictEqual(st.saves, PAGES - 1, 'checkpoint after each non-final page'); assert.strictEqual(st.cp, null, 'cleared on healthy completion');
  console.log('PASS 1: healthy scan -> checkpoint saved', st.saves, 'times, cleared at end');

  // 2) page 4 fails all retries -> partial, checkpoint points at page 4 with 180 ids
  st = memStore(); f = mockFetch({ failPage: 4, failTimes: 99 });
  r = await GA.scanAllWithCheckpoint(f, { store: st, scope: {}, sleepImpl });
  assert.strictEqual(r.partial, true); assert.strictEqual(r.assets.length, 3 * PER);
  assert.strictEqual(st.cp.pageToken, '4'); assert.strictEqual(st.cp.pageCount, 3); assert.strictEqual(st.cp.assetIds.length, 3 * PER);
  console.log('PASS 2: partial scan keeps checkpoint at cursor', st.cp.pageToken, 'pages', st.cp.pageCount, 'ids', st.cp.assetIds.length);

  // 3) resume: head refresh finds 5 new items, tail continues at page 4 (NOT page 1 walk), old rows re-read by id
  f = mockFetch({ extraHead: 5 });
  r = await GA.scanAllWithCheckpoint(f, { store: st, scope: {}, sleepImpl });
  assert.strictEqual(r.resumed, true); assert.strictEqual(r.resumedFromPage, 4); assert.strictEqual(r.completed, true);
  assert.deepStrictEqual(f.calls.filter((c) => typeof c === 'number'), [1, 4, 5, 6], 'head page 1 only, then tail from saved cursor');
  assert.strictEqual(r.headNew, 5);
  const ids = new Set(r.assets.map((a) => a.assetId));
  assert.strictEqual(ids.size, r.assets.length, 'no duplicates');
  assert.strictEqual(ids.size, PAGES * PER + 5, 'all pages + new head items');
  assert.strictEqual(st.cp, null, 'cleared after resumed healthy completion');
  console.log('PASS 3: resume -> fetch calls', f.calls.join(','), '; assets', r.assets.length, '(+5 new), checkpoint cleared');

  // 4) user abort mid-scan -> aborted:true, checkpoint kept
  st = memStore(); f = mockFetch(); let n = 0;
  r = await GA.scanAllWithCheckpoint(f, { store: st, scope: {}, sleepImpl, signalAborted: () => f.calls.length >= 2 && ++n > 0 });
  assert.strictEqual(r.aborted, true); assert.ok(st.cp && st.cp.pageToken, 'checkpoint kept on abort');
  console.log('PASS 4: aborted scan keeps checkpoint at cursor', st.cp.pageToken);

  // 5) planner rejects other scope / stale / lastHours windows / missing cursor
  const cp = GA.buildScanCheckpoint({ fromDate: 1000 }, { pageToken: '3', pageCount: 2, assetIds: ['x'] }, 0);
  assert.strictEqual(GA.planScanResume(cp, { fromDate: 1000 }, { now: 10 }).resume, true);
  assert.strictEqual(GA.planScanResume(cp, { fromDate: 2000 }, { now: 10 }).reason, 'scope');
  assert.strictEqual(GA.planScanResume(cp, { fromDate: 1000 }, { now: 25 * 3600e3 }).reason, 'stale');
  assert.strictEqual(GA.planScanResume(GA.buildScanCheckpoint({ hoursLimit: 24 }, { pageToken: '3', assetIds: ['x'] }, 0), { hoursLimit: 24 }, { now: 10 }).reason, 'relative-window');
  assert.strictEqual(GA.planScanResume({ ...cp, pageToken: null }, { fromDate: 1000 }, { now: 10 }).reason, 'no-cursor');
  assert.strictEqual(GA.planScanResume(null, {}).reason, 'none');
  // non-resumable leftover checkpoint is cleared before a fresh scan
  st = memStore(); st.cp = { ...cp, updatedAt: 0 }; f = mockFetch();
  r = await GA.scanAllWithCheckpoint(f, { store: st, scope: {}, sleepImpl, now: 10 });
  assert.strictEqual(r.resumed, false); assert.strictEqual(r.resumeReason, 'scope'); assert.strictEqual(r.completed, true);
  console.log('PASS 5: planner rejects scope/stale/relative-window/no-cursor; leftover cleared');
  console.log('ALL TESTS PASSED');
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
