// node test/background-smoke.test.js — evaluates background.js (+ its importScripts)
// in a sandbox with stub chrome.* APIs to catch load-time errors, then drives the
// new message handlers once.
const assert = require('assert');
const fs = require('fs'); const vm = require('vm'); const path = require('path');
const root = path.join(__dirname, '..');
const listeners = {};
const stubEvent = (name) => ({ addListener: (f) => { (listeners[name] ||= []).push(f); }, removeListener() {}, hasListener: () => false });
const store = {}, session = {};
const chrome = {
  runtime: { id: 'self', lastError: null, onMessage: stubEvent('onMessage'), onInstalled: stubEvent('onInstalled'), onStartup: stubEvent('onStartup'),
    sendMessage: async () => {}, getManifest: () => ({ update_url: 'x' }), getURL: (p) => p, getContexts: async () => [] },
  storage: { local: { get: async (k) => (typeof k === 'string' ? { [k]: store[k] } : {}), set: async (o) => Object.assign(store, o), remove: async () => {} },
    session: { get: async (k) => ({ [k]: session[k] }), set: async (o) => Object.assign(session, o) },
    sync: { get: async () => ({}), set: async () => {} }, onChanged: stubEvent('storage.onChanged') },
  downloads: { onChanged: stubEvent('downloads.onChanged'), onDeterminingFilename: stubEvent('onDeterminingFilename'), download: (o, cb) => cb(1), search: async () => [], erase: async () => {} },
  tabs: { onUpdated: stubEvent('tabs.onUpdated'), sendMessage: async () => ({ ok: true }), query: async () => [] },
  alarms: { create() {}, onAlarm: stubEvent('alarms.onAlarm') },
  scripting: { executeScript: async () => {} }, sidePanel: { setOptions() {}, setPanelBehavior() {} }, offscreen: {}
};
const ctx = { chrome, console: { log() {}, warn() {}, error() {} }, setTimeout: () => 0, clearTimeout() {}, setInterval: () => 0, fetch: async () => ({ ok: false, status: 500 }),
  AbortController, URL, TextDecoder, Promise, Date, Math, JSON };
ctx.self = ctx; ctx.globalThis = ctx;
try { require('fake-indexeddb/auto'); ctx.indexedDB = globalThis.indexedDB; ctx.IDBKeyRange = globalThis.IDBKeyRange; } catch (e) {}
ctx.importScripts = (...files) => { for (const f of files) vm.runInContext(fs.readFileSync(path.join(root, f), 'utf8'), ctx, { filename: f }); };
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(root, 'background.js'), 'utf8'), ctx, { filename: 'background.js' });
for (const g of ['GrokCaptureCore', 'GrokCaptureDB', 'GrokCaptureManager', 'GrokDownloadRouter', 'GrokAssets', 'SystemLogger']) assert.ok(vm.runInContext(`typeof ${g} !== 'undefined'`, ctx), g + ' loaded');
assert.ok(listeners.onMessage.length >= 1 && listeners['tabs.onUpdated'] && listeners['alarms.onAlarm'], 'listeners registered');
console.log('PASS 1: background.js + importScripts load cleanly; capture, tabs, alarms listeners registered');
(async () => {
  const call = (msg) => new Promise((resolve) => { for (const l of listeners.onMessage) { const r = l(msg, { id: 'self', tab: { id: 3 } }, resolve); if (r === true) return; } resolve(undefined); });
  if (ctx.indexedDB) {
    const r = await call({ action: 'captureItem', item: { kind: 'video', mediaId: '1b4e28ba-2fa1-11d2-883f-0016d3cca427', moderated: true, source: 'video-gen' } });
    assert.strictEqual(r.blocked, true);
    const st = await call({ action: 'getCaptureStatus' });
    assert.strictEqual(st.success, true); assert.strictEqual(st.counts.blocked, 1);
    console.log('PASS 2: captureItem / getCaptureStatus round-trip through the real handlers:', st.line);
  } else console.log('SKIP 2: fake-indexeddb not on NODE_PATH');
  const lr = await call({ action: 'systemLogAppend', entry: { level: 'INFO', message: 'm' } });
  assert.strictEqual(lr && lr.ok, true);
  console.log('PASS 3: systemLogAppend handled');
  console.log('ALL TESTS PASSED');
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
