// node test/logger.test.js — concurrent SystemLogger writes must not drop lines.
const assert = require('assert');
const fs = require('fs'); const vm = require('vm'); const path = require('path');
const src = fs.readFileSync(path.join(__dirname, '..', 'src/logger.js'), 'utf8');
function load({ reachBackground }) {
  const store = {}; const sentToBg = [];
  const delay = () => new Promise((r) => setTimeout(r, Math.random() * 3));
  const chrome = { storage: { local: {
    get: async (k) => { await delay(); return { [k]: store[k] ? JSON.parse(JSON.stringify(store[k])) : undefined }; },
    set: async (o) => { await delay(); Object.assign(store, JSON.parse(JSON.stringify(o))); },
    remove: async () => {} } },
    runtime: { sendMessage: async (m) => { if (!reachBackground) throw new Error('no receiver'); sentToBg.push(m); return { ok: true }; } } };
  const ctx = { chrome, console: { log() {}, warn() {}, error() {} }, setTimeout, Promise, Date, String, JSON };
  ctx.window = ctx; vm.createContext(ctx); vm.runInContext(src + '\nwindow.SystemLogger = SystemLogger;', ctx);
  return { L: ctx.SystemLogger, store, sentToBg };
}
(async () => {
  let { L, store } = load({ reachBackground: false });
  await Promise.all(Array.from({ length: 60 }, (_, i) => L.info('line ' + i)));
  assert.strictEqual(store.system_logs.length, 60, 'no lost entries under concurrency');
  console.log('PASS 1: 60 concurrent local writes -> 60 entries (serialized, batched)');
  ({ L, store } = load({ reachBackground: false }));
  await Promise.all(Array.from({ length: 1100 }, (_, i) => L.warn('x' + i)));
  assert.strictEqual(store.system_logs.length, 1000); assert.strictEqual(store.system_logs[999].message, 'x1099');
  console.log('PASS 2: rotation keeps the newest 1000');
  const r = load({ reachBackground: true });
  await r.L.ok('hello', 'd');
  assert.strictEqual(r.sentToBg.length, 1); assert.strictEqual(r.sentToBg[0].action, 'systemLogAppend'); assert.strictEqual(r.store.system_logs, undefined);
  r.L.appendEntries([r.sentToBg[0].entry]); await new Promise((res) => setTimeout(res, 20));
  assert.strictEqual(r.store.system_logs.length, 1);
  console.log('PASS 3: non-background contexts hand entries to the background (systemLogAppend)');
  console.log('ALL TESTS PASSED');
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
