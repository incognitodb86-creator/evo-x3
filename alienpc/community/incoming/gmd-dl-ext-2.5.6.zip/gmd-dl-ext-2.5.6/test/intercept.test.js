// node test/intercept.test.js — loads the MAIN-world scripts in a vm sandbox
// with a fake page (fetch/XHR/WebSocket/EventSource) and checks the passive taps.
const assert = require('assert');
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const U1 = '1b4e28ba-2fa1-11d2-883f-0016d3cca427', U2 = '6fa459ea-ee8a-3ca4-894e-db77e160355e';

function sandbox(fetchImpl) {
  const posted = [];
  const dataset = {};
  class FakeXHR { constructor() { this.l = {}; this.responseType = ''; } addEventListener(t, f) { (this.l[t] ||= []).push(f); }
    open() {} send() { this.responseText = this._body; (this.l.load || []).forEach((f) => f()); } }
  class FakeWS { constructor(url) { this.url = url; this.l = []; } addEventListener(t, f) { if (t === 'message') this.l.push(f); } emit(d) { this.l.forEach((f) => f({ data: d })); } }
  class FakeES extends FakeWS {}
  const ctx = {
    console: { log() {}, warn() {}, error() {} }, setTimeout: (f) => 0, clearTimeout() {},
    TextDecoder, Response, Request, URL, ReadableStream, JSON, Date, Math, Proxy, Reflect, Object, Array, String, Number, Promise,
    document: { documentElement: { dataset }, querySelector: () => null },
    location: { origin: 'https://grok.com' },
    addEventListener() {},
    postMessage: (msg) => posted.push(msg),
    XMLHttpRequest: FakeXHR, WebSocket: FakeWS, EventSource: FakeES,
    fetch: fetchImpl
  };
  ctx.window = ctx; ctx.self = ctx; ctx.globalThis = ctx;
  vm.createContext(ctx);
  for (const f of ['src/rate-limit.js', 'lib/capture-core.js', 'src/intercept.js']) vm.runInContext(fs.readFileSync(path.join(__dirname, '..', f), 'utf8'), ctx, { filename: f });
  return { ctx, posted, dataset };
}
const tick = () => new Promise((r) => setTimeout(r, 20));
const streamBody = (lines) => lines.map((l) => JSON.stringify(l)).join('\n') + '\n';

(async () => {
  // 1) fetch(url, init) POST to conversation stream: page gets the ORIGINAL response, capture + queue signal posted
  const videoEvt = { result: { response: { streamingVideoGenerationResponse: { progress: 100, postId: U1, moderated: false, videoUrl: `https://assets.grok.com/u/${U1}/v.mp4` } } } };
  const imgEvt = { result: { response: { streamingImageGenerationResponse: { imageId: U2, imageUrl: `https://assets.grok.com/u/${U2}/i.jpg`, progress: 100 } } } };
  const original = new Response(streamBody([{ progress: 10 }, imgEvt, videoEvt]) + 'data: {broken\n', { status: 200 });
  let sent = [];
  let s = sandbox(async (res, init) => { sent.push([res, init]); return original; });
  const res = await s.ctx.fetch('https://grok.com/rest/app-chat/conversations/new', { method: 'POST', body: JSON.stringify({ message: 'x' }) });
  assert.strictEqual(res, original, 'page receives the original Response object (not a re-wrapped one)');
  const pageText = await res.text(); assert.ok(pageText.includes('streamingImageGenerationResponse'), 'page body intact');
  await tick();
  const cap = s.posted.filter((m) => m.type === 'GROK_MEDIA_CAPTURE').flatMap((m) => m.payload.items);
  assert.deepStrictEqual(cap.map((i) => [i.kind, i.mediaId]).sort(), [['image', U2], ['video', U1]]);
  assert.strictEqual(s.posted.filter((m) => m.type === 'GROK_VIDEO_GEN_RESULT').length, 1, 'queue signal still sent once');
  assert.ok(!JSON.stringify(cap).includes('prompt'), 'no prompt forwarded');
  console.log('PASS 1: fetch tap clones, page gets original response; image+video captured; queue signal once');

  // 2) fetch(Request) POST: method read from the Request, queue override patched into the Request body
  s = sandbox(async (resource, init) => { sent = [resource, init]; return new Response(streamBody([videoEvt]), { status: 200 }); });
  Object.assign(s.dataset, { grokQueueVideoLength: '10', grokQueueSetAt: String(Date.now()) });
  const body = { message: 'm', responseMetadata: { modelConfigOverride: { modelMap: { videoGenModelConfig: { videoLength: 6 } } } } };
  await s.ctx.fetch(new Request('https://grok.com/rest/app-chat/conversations/abc/responses', { method: 'POST', body: JSON.stringify(body) }));
  await tick();
  const sentBody = JSON.parse(await sent[0].text());
  assert.strictEqual(sentBody.responseMetadata.modelConfigOverride.modelMap.videoGenModelConfig.videoLength, 10, 'Request body patched');
  assert.strictEqual(s.dataset.grokQueueVideoLength, undefined, 'overrides single-use');
  assert.strictEqual(s.posted.filter((m) => m.type === 'GROK_VIDEO_GEN_RESULT').length, 1, 'Request path also inspected');
  console.log('PASS 2: fetch(Request) treated as POST, body patched, response inspected');

  // 3) stale overrides (TTL) are ignored and cleared
  s = sandbox(async (resource, init) => { sent = [resource, init]; return new Response('', { status: 200 }); });
  Object.assign(s.dataset, { grokQueueVideoLength: '10', grokQueueSetAt: String(Date.now() - 10 * 60e3) });
  await s.ctx.fetch('https://grok.com/rest/app-chat/conversations/new', { method: 'POST', body: JSON.stringify(body) });
  assert.strictEqual(JSON.parse(sent[1].body).responseMetadata.modelConfigOverride.modelMap.videoGenModelConfig.videoLength, 6, 'stale override not applied');
  assert.strictEqual(s.dataset.grokQueueVideoLength, undefined, 'stale override cleared');
  console.log('PASS 3: queue overrides older than the TTL are ignored and cleared');

  // 4) XHR, WebSocket, EventSource taps capture media but never send the queue signal
  s = sandbox(async () => new Response(''));
  const x = new s.ctx.XMLHttpRequest(); x.open('POST', 'https://grok.com/rest/app-chat/conversations/new'); x._body = streamBody([imgEvt]); x.send();
  const ws = new s.ctx.WebSocket('wss://grok.com/ws/imagine/listen');
  assert.ok(ws instanceof s.ctx.WebSocket, 'instanceof preserved');
  ws.emit(JSON.stringify({ type: 'image', url: `https://grok.com/i/${U1}`, blob: 'A'.repeat(4000), stage: 'final' }));
  ws.emit(JSON.stringify({ type: 'image', url: `https://grok.com/i/${U1}`, blob: 'A'.repeat(4000), stage: 'preview' }));
  ws.emit('not json at all');
  const es = new s.ctx.EventSource('https://grok.com/rest/app-chat/conversations/x/stream'); es.emit(JSON.stringify(videoEvt));
  const other = new s.ctx.WebSocket('wss://example.com/ws/'); other.emit(JSON.stringify(imgEvt));
  await tick();
  const items = s.posted.filter((m) => m.type === 'GROK_MEDIA_CAPTURE').flatMap((m) => m.payload.items);
  assert.deepStrictEqual(items.map((i) => i.kind + ':' + i.mediaId + ':' + (i.dataBase64 ? 'b64' : 'url')).sort(), [`image:${U1}:b64`, `image:${U2}:url`, `video:${U1}:url`]);
  assert.strictEqual(s.posted.filter((m) => m.type === 'GROK_VIDEO_GEN_RESULT').length, 0, 'taps never feed queue counting');
  console.log('PASS 4: XHR / WebSocket / EventSource taps (final frames only, foreign sockets ignored, no queue signal)');

  // 5) moderated video forwarded as blocked; non-conversation fetch untouched
  s = sandbox(async () => new Response(streamBody([{ streamingVideoGenerationResponse: { progress: 100, postId: U2, moderated: true } }])));
  await s.ctx.fetch('https://grok.com/rest/app-chat/conversations/new', { method: 'POST', body: '{}' }); await tick();
  const blocked = s.posted.find((m) => m.type === 'GROK_MEDIA_CAPTURE').payload.items[0];
  assert.strictEqual(blocked.blocked, true); assert.strictEqual(blocked.url, null);
  let passthrough = 0; s = sandbox(async () => { passthrough++; return new Response('{}'); });
  await s.ctx.fetch('https://grok.com/rest/media/post/list', { method: 'POST', body: '{}' }); await tick();
  assert.strictEqual(passthrough, 1); assert.strictEqual(s.posted.length, 0);
  console.log('PASS 5: moderated result flagged blocked (no URL); other endpoints passed through untouched');
  console.log('ALL TESTS PASSED');
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
