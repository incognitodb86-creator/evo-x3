// node test/skip-on-disk.test.js — pure helpers; no storage, no files read.
const assert = require('assert');
const CU = require('../src/content-utils.js');
const U1 = '1b4e28ba-2fa1-11d2-883f-0016d3cca427', U2 = '6fa459ea-ee8a-3ca4-894e-db77e160355e', U3 = '16fd2706-8baf-433b-82eb-8c7fada847da';
// 1) normalize: bare ids, file names, paths, _hd/_sd suffixes, junk
const ids = CU.normalizeSkipIds([U1, `/x/Grok/conv/${U2.toUpperCase()}_hd.mp4`, 'C:\\dl\\abcdef123.jpg', 'plain-id-99_sd', '', '  ', 42, null, 'ab', U1]);
assert.deepStrictEqual(ids.sort(), [U1, U2, 'abcdef123', 'plain-id-99'].sort());
console.log('PASS 1: normalizeSkipIds ->', ids.length, 'ids');
// 2) withSkipIds: has() true for id, id_hd, id_sd; history untouched; other keys unaffected
const added = [];
const base = { has: (k) => k === 'hist-only', add: async (k) => added.push(k), toArray: () => ['hist-only'], flush: async () => {} };
const h = CU.withSkipIds(base, new Set(ids));
assert.ok(h.has(U1) && h.has(`${U2}_hd`) && h.has(`${U2}_sd`) && h.has('hist-only'));
assert.ok(!h.has(U3) && !h.has(`project_${U1}_c3`), 'metadata marker keys never match');
assert.deepStrictEqual(h.toArray(), ['hist-only'], 'real history not polluted');
assert.strictEqual(CU.withSkipIds(base, new Set()), base, 'empty list -> unchanged adapter');
console.log('PASS 2: withSkipIds skips media ids (any quality), leaves history and marker keys alone');
// 3) stats see the skip list (images + hd-priority videos)
const imgs = [{ id: U1 }, { id: U3 }], vids = [{ id: U2, hdUrl: 'x' }, { id: 'v-new', hdUrl: 'y' }];
const is = CU.calculateImageStats(imgs, h), vs = CU.calculateVideoStats(vids, h, true);
assert.strictEqual(is.alreadyDownloaded, 1); assert.strictEqual(is.needDownload, 1);
assert.strictEqual(vs.alreadyDownloadedFiles, 1); assert.strictEqual(vs.needDownloadFiles, 1);
// download-loop style filter (downloadImages: state.images.filter(img => !hist.has(img.id)))
assert.deepStrictEqual(imgs.filter((i) => !h.has(i.id)).map((i) => i.id), [U3]);
console.log('PASS 3: stats + download filter skip on-disk ids (images 1/2, videos 1/2 need download)');
// 4) regression: HD-priority video loop filters via hist.toArray(), which never
//    contains skip ids -> on-disk videos were re-downloaded. dropSkipped fixes it.
const GU = require('../src/utils.js');
const GUf = GU.filterVideosForHdPriority || global.GrokUtils.filterVideosForHdPriority;
const raw = GUf(vids, h.toArray(), true);
assert.strictEqual(raw.length, 2, 'toArray-based filter alone misses the skip list (the bug)');
assert.deepStrictEqual(CU.dropSkipped(raw, h).map(v => v.id), ['v-new']);
assert.deepStrictEqual(CU.dropSkipped(GUf(vids, h.toArray(), false), h).map(v => v.id), ['v-new'], 'non-HD-priority too');
assert.strictEqual(CU.dropSkipped(vids, base), vids, 'no skip list -> unchanged');
console.log('PASS 4: dropSkipped removes on-disk videos from the toArray()-based video filters');
// 5) popup import file format: {ids:[...]} object or bare array; scan-format names normalise
const PS = require('../src/popup-skip-ids.js');
assert.deepStrictEqual(PS.extractIds({ count: 2, ids: [U1, U2, 3, ''] }), [U1, U2]);
assert.deepStrictEqual(PS.extractIds([`grok_image_20260101_${U3}.jpg`]), [`grok_image_20260101_${U3}.jpg`]);
assert.deepStrictEqual(PS.extractIds(null), []);
assert.deepStrictEqual(CU.normalizeSkipIds([`grok_video_hd_20260101_${U3} (1).mp4`]), [U3]);
assert.strictEqual(PS.SKIP_IDS_PACKAGED_PATH, 'data/ondisk-media-ids.json');
console.log('PASS 5: popup import accepts the on-disk scan format');
// 6) candidate ids: record id, URL-path id, baked-filename id match; sourceAssetId,
//    userId and conversation ids never do (they name a different file).
const USER = 'aaaaaaaa-1111-4222-8333-444444444444', SRC = 'bbbbbbbb-1111-4222-8333-444444444444';
const VID = 'cccccccc-1111-4222-8333-444444444444', OTHER = 'dddddddd-1111-4222-8333-444444444444';
const rec = { id: VID, sourceAssetId: SRC, userId: USER, sourceConversationId: OTHER,
    url: `https://assets.grok.com/users/${USER}/generated/${VID}/generated_video.mp4?cache=1`,
    filename: `grok_video_20260101_${VID}.mp4` };
assert.deepStrictEqual(CU.mediaIdCandidates(rec), [VID]);
const urlOnly = { id: 'legacy-post-7', userId: USER, url: `https://assets.grok.com/users/${USER}/${OTHER}/content` };
assert.deepStrictEqual(CU.mediaIdCandidates(urlOnly).sort(), ['legacy-post-7', OTHER].sort());
const hs = CU.withSkipIds(base, new Set([SRC, USER]));
assert.deepStrictEqual(CU.dropSkipped([rec], hs).map(v => v.id), [VID], 'source image / user id on disk does NOT skip the video');
const hu = CU.withSkipIds(base, new Set([OTHER]));
assert.deepStrictEqual(CU.dropSkipped([urlOnly, rec], hu).map(v => v.id), [VID], 'URL-path id on disk skips the item');
const hf = CU.withSkipIds(base, new Set([VID]));
assert.deepStrictEqual(CU.dropSkipped([{ id: 'x', filename: `grok_image_20260101_${VID}.jpg` }], hf), [], 'baked filename id skips');
assert.ok(hf.skipHasItem(rec) && !hs.skipHasItem(rec));
console.log('PASS 6: candidate ids (id / URL path / filename) match; sourceAssetId, userId, conversation ids never do');
console.log('ALL TESTS PASSED');
