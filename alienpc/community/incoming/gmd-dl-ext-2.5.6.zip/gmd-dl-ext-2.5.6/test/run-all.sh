#!/usr/bin/env bash
# Runs every test; fake-indexeddb comes from GMD_TEST_DEPS (default /workspace/gmd-test-deps).
set -e
cd "$(dirname "$0")/.."
export NODE_PATH="${GMD_TEST_DEPS:-/workspace/gmd-test-deps}/node_modules${NODE_PATH:+:$NODE_PATH}"
for f in $(git ls-files '*.js' 2>/dev/null || true) lib/*.js src/*.js test/*.js; do node --check "$f"; done
echo "node --check OK"
for t in test/*.test.js; do echo "== $t"; node "$t"; done
