// node test/paging-retry.test.js — mocks fetch; no network.
const assert = require('assert');
const GA = require('../src/grok-assets.js');
const PAGES = 5, PER = 60;
const mkAsset = (p, i) => ({ assetId: `a-${p}-${i}`, mimeType: 'image/jpeg', key: `k${p}${i}`, isModelGenerated: true, createTime: new Date(Date.UTC(2026, 9, 19) - (p * PER + i) * 60000).toISOString() });
function mockFetch(failPlan) { // failPlan: {page: [statuses...]} failures before success
  const calls = []; const left = JSON.parse(JSON.stringify(failPlan));
  const f = async (url) => {
    const tok = new URL(url).searchParams.get('pageToken'); const p = tok ? Number(tok) : 1;
    calls.push(p);
    if (left[p] && left[p].length) { const st = left[p].shift();
      if (st === 'net') throw new TypeError('Failed to fetch');
      return { ok: false, status: st, headers: { get: (h) => h === 'Retry-After' ? '40' : null } }; }
    return { ok: true, status: 200, json: async () => ({ assets: Array.from({ length: PER }, (_, i) => mkAsset(p, i)), nextPageToken: p < PAGES ? String(p + 1) : null }) };
  };
  f.calls = calls; return f;
}
(async () => {
  // 1) page 3 fails twice (429 w/ Retry-After 40s, then network error), then succeeds
  let sleeps = []; const sleepImpl = async (ms) => { sleeps.push(ms); };
  let f = mockFetch({ 3: [429, 'net'] });
  let r = await GA.listAllGeneratedAssets(f, { sleepImpl });
  assert.strictEqual(r.assets.length, PAGES * PER, 'full list');
  assert.strictEqual(new Set(r.assets.map(a => a.assetId)).size, PAGES * PER);
  assert.strictEqual(r.partial, false); assert.strictEqual(r.errors, 0); assert.strictEqual(r.retryErrors, 2);
  assert.deepStrictEqual(f.calls, [1, 2, 3, 3, 3, 4, 5], 'same cursor retried');
  assert.ok(sleeps.includes(40000), 'Retry-After 40s honored over 15s');
  assert.ok(sleeps.includes(30000), '2nd retry 30s');
  assert.strictEqual(sleeps[0], 1200, 'base throttle 1200ms');
  console.log('PASS 1: page 3 fails twice then succeeds ->', r.assets.length, 'assets; sleeps', sleeps.join(','));
  // 2) page 3 fails 6 times -> partial after 5 retries
  sleeps = []; f = mockFetch({ 3: [429, 429, 503, 'net', 429, 429] });
  r = await GA.listAllGeneratedAssets(f, { sleepImpl });
  assert.strictEqual(r.partial, true); assert.strictEqual(r.errors, 1); assert.strictEqual(r.retryErrors, 6);
  assert.strictEqual(r.assets.length, 2 * PER);
  assert.deepStrictEqual(sleeps.filter(ms => ms >= 15000), [40000, 40000, 60000, 120000, 180000]);
  console.log('PASS 2: exhausted retries -> partial:true, errors=1, retryErrors=6, kept', r.assets.length);
  // 3) merge guard helper: union, fresh wins
  const stored = [{ id: 'x', v: 'old' }, { id: 'y' }, { id: 'z' }];
  const m = GA.mergeAssetListsById(stored, [{ id: 'x', v: 'new' }]);
  assert.deepStrictEqual(m.items.map(i => i.id), ['x', 'y', 'z']); assert.strictEqual(m.items[0].v, 'new'); assert.strictEqual(m.added, 2);
  assert.strictEqual(GA.parseRetryAfterMs('7'), 7000); assert.strictEqual(GA.parseRetryAfterMs(null), null);
  console.log('PASS 3: mergeAssetListsById union + parseRetryAfterMs');
  // 4) merge guard: partial scan smaller than stored list -> union by id, never shrinks
  const img = (id) => ({ id, type: 'image' }), vid = (id) => ({ id, type: 'video' });
  const prevState = { filterOptions: { source: 'allmedia', fromDate: null, toDate: null, hoursLimit: null },
    allImages: [img('i1'), img('i2'), img('i3'), img('i4')], allVideos: [vid('v1'), vid('v2')] };
  let g = GA.mergePartialWithStored(prevState, { images: [img('i1'), img('i9')], videos: [vid('v1')], scope: {} });
  assert.strictEqual(g.merged, true);
  assert.deepStrictEqual(g.images.map(i => i.id), ['i1', 'i9', 'i2', 'i3', 'i4']);
  assert.deepStrictEqual(g.videos.map(i => i.id), ['v1', 'v2']);
  assert.ok(g.images.length + g.videos.length >= 6, 'never smaller than stored');
  assert.strictEqual(g.addedImages, 3); assert.strictEqual(g.addedVideos, 1);
  // different scope (other date range / other source) -> not merged
  g = GA.mergePartialWithStored({ ...prevState, filterOptions: { source: 'allmedia', fromDate: 123 } }, { images: [img('i1')], videos: [], scope: {} });
  assert.strictEqual(g.merged, false); assert.strictEqual(g.images.length, 1);
  g = GA.mergePartialWithStored({ ...prevState, filterOptions: { source: 'favorite' } }, { images: [img('i1')], videos: [], scope: {} });
  assert.strictEqual(g.merged, false);
  g = GA.mergePartialWithStored(null, { images: [img('i1')], videos: [], scope: {} });
  assert.strictEqual(g.merged, false);
  g = GA.mergePartialWithStored({ ...prevState, filterOptions: { ...prevState.filterOptions, promptScope: 'folders' } }, { images: [img('i1')], videos: [], scope: {} });
  assert.strictEqual(g.merged, true); assert.strictEqual(g.prevPromptScope, 'folders');
  console.log('PASS 4: merge guard: 6 stored + partial 3 (1 new) -> 7 kept by id union; other scopes not merged');
  // 5) default sleep path with stubbed setTimeout: default 15s/30s backoff, no real waiting
  const realST = global.setTimeout; const timers = [];
  global.setTimeout = (fn, ms) => { timers.push(ms); return realST(fn, 0); };
  try {
    f = mockFetch({ 3: ['net', 'net'] });
    const t0 = Date.now();
    r = await GA.listAllGeneratedAssets(f, {});
    assert.strictEqual(r.assets.length, PAGES * PER); assert.strictEqual(r.partial, false); assert.strictEqual(r.retryErrors, 2);
    assert.deepStrictEqual(timers.filter(ms => ms >= 15000), [15000, 30000], 'default backoff 15s then 30s');
    assert.strictEqual(timers[0], 1200);
    assert.ok(Date.now() - t0 < 2000, 'ran fast');
  } finally { global.setTimeout = realST; }
  console.log('PASS 5: stubbed setTimeout -> default backoff', timers.join(','));
  console.log('ALL TESTS PASSED');
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
